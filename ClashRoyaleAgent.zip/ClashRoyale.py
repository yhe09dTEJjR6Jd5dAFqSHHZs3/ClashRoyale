"""Windows launcher for the local Clash Royale agent."""
import sys

# Keep Python bytecode out of the extracted application directory.
sys.dont_write_bytecode = True

from core.ui import launch


if __name__ == "__main__":
    launch()
