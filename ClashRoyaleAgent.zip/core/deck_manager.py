"""Self-supervised card fingerprint tracking and optional local semantics.

The active agent preserves the user's deck and never opens the deck editor to
rearrange cards. This module learns stable battle-hand fingerprints and cost
intervals, and may resolve names/roles only from a verified local catalog.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Mapping

from .cards import CardDatabase
from .vision import GameState


MAX_PROFILE_BYTES = 1_000_000
MAX_CATALOG_BYTES = 2_000_000
PROFILE_VERSION = 1
CATALOG_VERSION = 1


def _hamming(left: str, right: str) -> int:
    try:
        return (int(left, 16) ^ int(right, 16)).bit_count()
    except (TypeError, ValueError):
        return 64


def _finite(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and value == value and abs(value) != float("inf")


def _safe_int(value, default: int = 0) -> int:
    try:
        number = int(value)
        return number if 0 <= number <= 10**9 else default
    except (TypeError, ValueError, OverflowError):
        return default


@dataclass
class CardProfile:
    profile_id: str
    fingerprint: str
    observations: int = 0
    ready_observations: int = 0
    cost_samples: int = 0
    cost_estimate: float | None = None
    cost_low: float | None = None
    cost_high: float | None = None
    last_ready: bool | None = None
    last_elixir: float | None = None
    last_seen: int = 0
    descriptor: list[float] = field(default_factory=list)

    @property
    def cost_confidence(self) -> float:
        if self.cost_samples <= 0 or self.cost_low is None or self.cost_high is None:
            return 0.0
        width = max(0.0, self.cost_high - self.cost_low)
        return max(0.0, min(1.0, (self.cost_samples / 4.0) * (1.0 - width / 3.0)))


@dataclass(frozen=True)
class DeckAssessment:
    observed_unique_cards: int
    known_costs: int
    average_cost: float | None
    cost_spread: float | None
    unknown_semantics: int
    can_recommend: bool
    reason: str


class DeckManager:
    """Builds a local visual card index; it never fabricates card semantics."""

    def __init__(self, profile_path: Path, catalog: Mapping[str, dict] | None = None,
                 catalog_path: Path | None = None,
                 card_database: CardDatabase | None = None,
                 bundled_catalog_path: Path | None = None):
        self.profile_path = Path(profile_path)
        self.catalog_path = Path(catalog_path) if catalog_path is not None else self.profile_path.parent / "card_catalog.json"
        self.card_database = card_database or CardDatabase()
        bundled = self._load_catalog_file(bundled_catalog_path) if bundled_catalog_path is not None else {}
        local = self._validate_catalog(catalog) if catalog is not None else self._load_catalog()
        self.catalog = self._merge_catalogs(bundled, local)
        self.profiles: dict[str, CardProfile] = {}
        self._metadata_cache: dict[str, tuple[tuple, dict | None]] = {}
        self._next_id = 1
        self._slot_profile: dict[int, str] = {}
        self._catalog_dirty = False
        self._last_catalog_sample_at: dict[str, float] = {}
        self._load()

    @staticmethod
    def _validate_catalog(raw: Mapping[str, dict] | None) -> dict[str, dict]:
        if not isinstance(raw, Mapping) or len(raw) > 512:
            return {}
        validated: dict[str, dict] = {}
        allowed_roles = {"win_condition", "spell", "air_defense", "building",
                         "tank_killer", "swarm", "support", "cycle", "tank", "ranged", "melee"}
        for fingerprint, metadata in raw.items():
            if (not isinstance(fingerprint, str) or len(fingerprint) != 16 or
                    any(char not in "0123456789abcdefABCDEF" for char in fingerprint) or
                    not isinstance(metadata, dict)):
                continue
            roles = metadata.get("roles", [metadata.get("role")] if isinstance(metadata.get("role"), str) else [])
            if not isinstance(roles, list):
                continue
            roles = sorted({role for role in roles if isinstance(role, str) and role in allowed_roles})
            name = metadata.get("name", "")
            if not isinstance(name, str) or len(name) > 80:
                name = ""
            card_key = metadata.get("card_key", "")
            if (not isinstance(card_key, str) or len(card_key) > 80 or
                    any(ch not in "abcdefghijklmnopqrstuvwxyz0123456789-" for ch in card_key)):
                card_key = ""
            form = metadata.get("form", "base")
            if form not in ("base", "evolution", "hero", "champion"):
                form = "base"
            source = metadata.get("source", "")
            if not isinstance(source, str) or len(source) > 48:
                source = ""
            card_type = metadata.get("card_type", "")
            if not isinstance(card_type, str) or len(card_type) > 32:
                card_type = ""
            variable_cost = metadata.get("variable_cost") is True
            cost, level = metadata.get("cost"), metadata.get("level")
            if cost is None:
                # Unknown/variable costs are allowed only when explicitly
                # represented by the bundled record or a tower-troop type.
                if not (variable_cost or card_type.casefold() == "tower troop"):
                    continue
            elif not _finite(cost) or not 1 <= float(cost) <= 10:
                continue
            if level is None and source not in ("runtime_ocr_visual_scan", "bundled_card_image"):
                level = 1
            if level is not None and (not _finite(level) or not 1 <= float(level) <= 16):
                continue
            cost_options = metadata.get("cost_options", [])
            if not isinstance(cost_options, list):
                cost_options = []
            cost_options = sorted({int(value) for value in cost_options
                                   if _finite(value) and 1 <= float(value) <= 10})
            descriptor = metadata.get("descriptor", [])
            if (not isinstance(descriptor, list) or len(descriptor) not in (0, 19, 131) or
                    not all(_finite(value) and 0.0 <= float(value) <= 1.0 for value in descriptor)):
                descriptor = []
            confidence = metadata.get("confidence")
            if confidence is not None and (not _finite(confidence) or not 0.0 <= float(confidence) <= 1.0):
                confidence = None
            validated[fingerprint.lower()] = {
                "name": name, "owned": metadata.get("owned") is True,
                "roles": roles, "cost": float(cost) if cost is not None else None,
                "level": float(level) if level is not None else None,
                "descriptor": [float(value) for value in descriptor],
                "card_key": card_key, "form": form, "source": source,
                "confidence": float(confidence) if confidence is not None else None,
                "samples": max(1, min(99, _safe_int(metadata.get("samples", 1), 1))),
                "card_type": card_type, "variable_cost": variable_cost,
                "cost_options": cost_options,
            }
        return validated

    def _load_catalog_file(self, path: Path | None) -> dict[str, dict]:
        if path is None:
            return {}
        try:
            path = Path(path)
            if path.stat().st_size > MAX_CATALOG_BYTES:
                return {}
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return {}
        if not isinstance(raw, dict) or raw.get("version") != CATALOG_VERSION:
            return {}
        cards = raw.get("cards")
        return self._validate_catalog(cards) if isinstance(cards, dict) else {}

    def _load_catalog(self) -> dict[str, dict]:
        return self._load_catalog_file(self.catalog_path)

    @staticmethod
    def _merge_catalogs(bundled: Mapping[str, dict], local: Mapping[str, dict]) -> dict[str, dict]:
        """Merge packaged references with user-captured samples safely.

        A runtime sample for the same card/form supersedes its bundled image
        reference. If two different identities share a 64-bit fingerprint,
        discard that fingerprint entirely rather than guessing either card.
        """
        merged = dict(bundled)
        conflicted: set[str] = set()
        for fingerprint, metadata in local.items():
            existing = merged.get(fingerprint)
            if existing is not None:
                old_identity = (existing.get("card_key"), existing.get("form", "base"))
                new_identity = (metadata.get("card_key"), metadata.get("form", "base"))
                if old_identity != new_identity:
                    merged.pop(fingerprint, None)
                    conflicted.add(fingerprint)
                    continue
            if fingerprint not in conflicted:
                merged[fingerprint] = metadata
        for fingerprint in conflicted:
            merged.pop(fingerprint, None)
        return merged

    def _load(self) -> None:
        try:
            if self.profile_path.stat().st_size > MAX_PROFILE_BYTES:
                return
            raw = json.loads(self.profile_path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return
        if not isinstance(raw, dict) or raw.get("version") != PROFILE_VERSION:
            return
        items = raw.get("profiles")
        if not isinstance(items, list) or len(items) > 256:
            return
        for item in items:
            if not isinstance(item, dict):
                continue
            pid, fingerprint = item.get("profile_id"), item.get("fingerprint")
            if not isinstance(pid, str) or not pid.startswith("card_"):
                continue
            if not isinstance(fingerprint, str) or len(fingerprint) != 16:
                continue
            observations = item.get("observations", 0)
            if not isinstance(observations, int) or not 0 <= observations <= 10**8:
                continue
            cost = item.get("cost_estimate")
            if cost is not None and (not _finite(cost) or not 1 <= cost <= 10):
                cost = None
            descriptor = item.get("descriptor", [])
            if not isinstance(descriptor, list) or len(descriptor) > 256 or not all(_finite(x) for x in descriptor):
                descriptor = []
            cost_low = float(item["cost_low"]) if _finite(item.get("cost_low")) else None
            cost_high = float(item["cost_high"]) if _finite(item.get("cost_high")) else None
            if cost_low is not None and not 1 <= cost_low <= 10:
                cost_low = None
            if cost_high is not None and not 1 <= cost_high <= 10:
                cost_high = None
            if cost_low is not None and cost_high is not None and cost_low > cost_high:
                cost_low, cost_high = None, None
            profile = CardProfile(
                profile_id=pid,
                fingerprint=fingerprint,
                observations=observations,
                ready_observations=_safe_int(item.get("ready_observations", 0)),
                cost_samples=_safe_int(item.get("cost_samples", 0)),
                cost_estimate=float(cost) if cost is not None else None,
                cost_low=cost_low,
                cost_high=cost_high,
                last_ready=item.get("last_ready") if isinstance(item.get("last_ready"), bool) else None,
                last_elixir=float(item["last_elixir"]) if _finite(item.get("last_elixir")) else None,
                last_seen=_safe_int(item.get("last_seen", 0)),
                descriptor=[float(x) for x in descriptor],
            )
            self.profiles[pid] = profile
            try:
                self._next_id = max(self._next_id, int(pid.split("_", 1)[1]) + 1)
            except ValueError:
                pass

    def _match_or_create(self, fingerprint: str, descriptor: tuple[float, ...]) -> CardProfile:
        if not fingerprint:
            raise ValueError("Card fingerprint is empty.")
        ranked: list[tuple[float, int, CardProfile]] = []
        for profile in self.profiles.values():
            hash_distance = _hamming(fingerprint, profile.fingerprint)
            if descriptor and profile.descriptor and len(profile.descriptor) == len(descriptor):
                descriptor_distance = sum(abs(old - new) for old, new in
                                          zip(profile.descriptor, descriptor)) / len(descriptor)
                # A loose dHash threshold alone merges visually distinct cards.
                # Require agreement in both spatial hash and color descriptor.
                if hash_distance > 10 or descriptor_distance > 0.14:
                    continue
                score = hash_distance / 64.0 * 0.55 + descriptor_distance * 0.45
            else:
                # Without a descriptor, demand a much closer hash match.
                if hash_distance > 6:
                    continue
                score = hash_distance / 64.0
            ranked.append((score, hash_distance, profile))

        ranked.sort(key=lambda item: item[0])
        best: CardProfile | None = ranked[0][2] if ranked else None
        if len(ranked) > 1:
            first_score, first_hash, _ = ranked[0]
            second_score, second_hash, _ = ranked[1]
            # If two profiles explain this observation almost equally well,
            # do not silently merge their histories/cost estimates.  An extra
            # profile is safer than corrupting two distinct card identities.
            ambiguous = (second_score - first_score < 0.006 and
                         second_hash == first_hash)
            if ambiguous:
                best = None

        if best is not None:
            best.observations += 1
            if descriptor:
                if not best.descriptor or len(best.descriptor) != len(descriptor):
                    best.descriptor = list(descriptor)
                else:
                    best.descriptor = [0.90 * old + 0.10 * new
                                       for old, new in zip(best.descriptor, descriptor)]
            best.last_seen = int(time.time())
            return best
        if len(self.profiles) >= 256:
            oldest = min(self.profiles.values(), key=lambda item: item.last_seen)
            self.profiles.pop(oldest.profile_id, None)
            self._metadata_cache.pop(oldest.profile_id, None)
        profile_id = f"card_{self._next_id:04d}"
        self._next_id += 1
        profile = CardProfile(profile_id, fingerprint, observations=1,
                              last_seen=int(time.time()), descriptor=list(descriptor))
        self.profiles[profile_id] = profile
        return profile

    def metadata_for_profile(self, profile: CardProfile) -> dict | None:
        """Resolve a learned fingerprint against verified local catalog entries.

        Entries with a reference descriptor can tolerate small rendering changes
        such as readiness glow. Hash-only entries require an almost exact match.
        Ambiguous nearest-neighbour matches are deliberately rejected.
        """
        cache_key = (profile.fingerprint, tuple(round(value, 2) for value in profile.descriptor))
        cached = self._metadata_cache.get(profile.profile_id)
        if cached is not None and cached[0] == cache_key:
            return cached[1]
        # Multiple reference views may belong to the same card/form. Collapse
        # them before ambiguity checks so additional fingerprints improve recall
        # without making one card ambiguous with itself.
        ranked_by_identity: dict[tuple[str, str], tuple[float, dict]] = {}
        for fingerprint, metadata in self.catalog.items():
            hash_distance = _hamming(profile.fingerprint, fingerprint)
            reference = metadata.get("descriptor", [])
            if reference and profile.descriptor and len(reference) == len(profile.descriptor):
                descriptor_distance = sum(abs(a - b) for a, b in
                                          zip(reference, profile.descriptor)) / len(reference)
                if hash_distance > 22 or descriptor_distance > 0.135:
                    continue
                score = 0.30 * (hash_distance / 64.0) + 0.70 * descriptor_distance
                if score > 0.105:
                    continue
            else:
                if hash_distance > 1:
                    continue
                score = hash_distance / 64.0
            identity = (str(metadata.get("card_key") or metadata.get("name") or fingerprint),
                        str(metadata.get("form") or "base"))
            previous = ranked_by_identity.get(identity)
            if previous is None or score < previous[0]:
                ranked_by_identity[identity] = (score, metadata)
        ranked = sorted(ranked_by_identity.values(), key=lambda item: item[0])
        if not ranked:
            self._metadata_cache[profile.profile_id] = (cache_key, None)
            return None
        ambiguity_margin = 0.018 if ranked and ranked[0][1].get("descriptor") else 0.012
        if len(ranked) > 1 and ranked[1][0] - ranked[0][0] < ambiguity_margin:
            self._metadata_cache[profile.profile_id] = (cache_key, None)
            return None
        result = ranked[0][1]
        self._metadata_cache[profile.profile_id] = (cache_key, result)
        return result

    def add_catalog_sample(self, card_key: str, form: str, fingerprint: str,
                           descriptor: tuple[float, ...], confidence: float,
                           *, persist: bool = True) -> bool:
        """Persist one OCR-labelled, visually stable card reference sample."""
        record = self.card_database.get(card_key)
        if (record is None or form not in record.available_forms or
                not isinstance(fingerprint, str) or len(fingerprint) != 16 or
                any(ch not in "0123456789abcdef" for ch in fingerprint.lower()) or
                len(descriptor) not in (19, 131) or
                not all(_finite(value) and 0.0 <= float(value) <= 1.0 for value in descriptor) or
                not _finite(confidence) or not 0.0 <= float(confidence) <= 1.0):
            return False
        roles = list(self.card_database.roles_for(record))
        metadata = {
            "name": record.name_en,
            "owned": False,
            "roles": roles,
            "cost": float(record.elixir_cost) if record.elixir_cost is not None else None,
            "cost_options": list(record.elixir_cost_options),
            "variable_cost": record.variable_elixir_cost,
            "card_type": record.card_type,
            "level": None,
            "descriptor": [float(value) for value in descriptor],
            "card_key": record.key,
            "form": form,
            "source": "runtime_ocr_visual_scan",
            "confidence": float(confidence),
        }
        fingerprint = fingerprint.lower()
        existing = self.catalog.get(fingerprint)
        if existing is None:
            same_identity_count = sum(
                1 for item in self.catalog.values()
                if item.get("card_key") == record.key and item.get("form", "base") == form
            )
            if len(self.catalog) >= 512 or same_identity_count >= 6:
                return False
        if existing is not None:
            same_identity = (existing.get("card_key") == record.key and
                             existing.get("form", "base") == form)
            if not same_identity:
                # A 64-bit hash collision is not silently assigned to either card.
                return False
            old_descriptor = existing.get("descriptor", [])
            if len(old_descriptor) == len(descriptor):
                count = max(1, int(existing.get("samples", 1)))
                metadata["descriptor"] = [
                    round((float(old) * count + float(new)) / (count + 1), 5)
                    for old, new in zip(old_descriptor, descriptor)
                ]
            metadata["confidence"] = max(float(existing.get("confidence") or 0.0), float(confidence))
            metadata["samples"] = min(99, int(existing.get("samples", 1)) + 1)
        else:
            metadata["samples"] = 1
        self.catalog[fingerprint] = metadata
        self._metadata_cache.clear()
        self._catalog_dirty = True
        if persist:
            self.save_catalog()
        return True

    def save_catalog(self) -> None:
        """Atomically save the local visual index inside the chosen workspace."""
        self.catalog_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"version": CATALOG_VERSION, "cards": self.catalog}
        temp = self.catalog_path.with_suffix(self.catalog_path.suffix + ".tmp")
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(payload, stream, ensure_ascii=False, indent=2, allow_nan=False)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.catalog_path)
            self._catalog_dirty = False
        finally:
            try:
                if temp.exists():
                    temp.unlink()
            except OSError:
                pass

    @staticmethod
    def _observe_cost(profile: CardProfile, ready: bool, elixir: float,
                      ready_confidence: float) -> None:
        if ready_confidence < 0.72:
            return
        previous_ready = profile.last_ready
        previous_elixir = profile.last_elixir
        if previous_ready is False and ready and previous_elixir is not None and elixir > previous_elixir:
            # The card became playable between two observations.  The cost is
            # bounded by that elixir interval, not asserted as an exact value.
            low = max(1.0, min(10.0, previous_elixir - 0.15))
            high = max(low, min(10.0, elixir + 0.15))
            if high - low <= 2.0:
                if profile.cost_low is None:
                    profile.cost_low, profile.cost_high = low, high
                else:
                    # Intersect repeated intervals when they overlap; otherwise
                    # widen gently rather than accepting an inconsistent sample.
                    new_low = max(profile.cost_low, low)
                    new_high = min(profile.cost_high, high)
                    if new_low <= new_high:
                        profile.cost_low, profile.cost_high = new_low, new_high
                    else:
                        profile.cost_low = min(profile.cost_low, low)
                        profile.cost_high = max(profile.cost_high, high)
                profile.cost_samples += 1
                profile.cost_estimate = round((profile.cost_low + profile.cost_high) / 2.0, 2)
        profile.last_ready = ready
        profile.last_elixir = max(0.0, min(10.0, elixir))
        if ready:
            profile.ready_observations += 1

    def observe(self, state: GameState) -> GameState:
        # The four bottom slots are battle-hand positions. Visual fingerprints
        # identify a persistent slot; offline OCR can additionally bind a name
        # when the game exposes readable card text. A verified custom fingerprint
        # catalog has priority, followed by an exact bundled card-name match.
        if state.scene.value != "battle":
            return state
        costs: list[float | None] = []
        names: list[str] = []
        roles: list[tuple[str, ...]] = []
        forms = list(state.card_forms)
        levels = list(state.card_levels)
        elite = list(state.card_elite)
        for slot in range(4):
            fingerprint = state.card_fingerprints[slot]
            descriptor = state.card_descriptors[slot] if slot < len(state.card_descriptors) else ()
            observed_name = state.card_names[slot] if slot < len(state.card_names) else ""
            record = self.card_database.find(observed_name)
            profile = None
            metadata = None
            if fingerprint:
                profile = self._match_or_create(fingerprint, descriptor)
                self._slot_profile[slot] = profile.profile_id
                self._observe_cost(profile, state.card_ready[slot], state.elixir,
                                   state.card_ready_confidence[slot])
                # When the local OCR lexicon verifies a card name, bind this
                # exact visual appearance to that identity. A game update may
                # replace every illustration; the new fingerprint then becomes
                # a fresh local reference instead of requiring a model download.
                verified_card_confidence = state.ocr_confidence
                for recognized in state.recognized_cards:
                    if getattr(recognized, "card_key", None) == getattr(record, "key", None):
                        verified_card_confidence = max(
                            verified_card_confidence, float(getattr(recognized, "confidence", 0.0)),
                        )
                if (record is not None and descriptor and verified_card_confidence >= 0.72
                        and (record.elixir_cost is not None or record.variable_elixir_cost
                             or record.card_type.casefold() == "tower troop")):
                    form = forms[slot] if slot < len(forms) else "base"
                    existing = self.catalog.get(fingerprint)
                    same_identity = bool(existing and existing.get("card_key") == record.key
                                         and existing.get("form", "base") == form)
                    sample_count = int(existing.get("samples", 0)) if same_identity else 0
                    now = time.monotonic()
                    last_sample = self._last_catalog_sample_at.get(fingerprint, 0.0)
                    if (existing is None or (same_identity and sample_count < 3 and now - last_sample >= 15.0)):
                        if self.add_catalog_sample(
                                record.key, form, fingerprint, descriptor,
                                min(0.99, max(0.72, verified_card_confidence)), persist=False):
                            self._last_catalog_sample_at[fingerprint] = now
                metadata = self.metadata_for_profile(profile)
            if metadata is not None:
                meta_cost = metadata.get("cost")
                costs.append(float(meta_cost) if _finite(meta_cost) else None)
                names.append(str(metadata.get("name", "")) or observed_name)
                roles.append(tuple(metadata.get("roles", ())))
                forms[slot] = str(metadata.get("form", forms[slot] if slot < len(forms) else "base"))
                meta_level = metadata.get("level")
                if _finite(meta_level):
                    levels[slot] = int(round(float(meta_level)))
            elif record is not None:
                costs.append(float(record.elixir_cost) if record.elixir_cost is not None else None)
                names.append(record.name_en)
                roles.append(self.card_database.roles_for(record))
            elif profile is not None:
                costs.append(profile.cost_estimate if profile.cost_confidence >= 0.35 else None)
                names.append(observed_name)
                roles.append(state.card_roles[slot] if slot < len(state.card_roles) else ())
            else:
                costs.append(None)
                names.append(observed_name)
                roles.append(state.card_roles[slot] if slot < len(state.card_roles) else ())
        while len(costs) < 4:
            costs.append(None)
            names.append("")
            roles.append(())
        return replace(state, card_costs=tuple(costs[:4]),
                       card_names=tuple(names[:4]), card_roles=tuple(roles[:4]),
                       card_forms=tuple(forms[:4]), card_levels=tuple(levels[:4]),
                       card_elite=tuple(elite[:4]))

    @property
    def unknown_visual_profiles(self) -> int:
        """Learned hand-card profiles whose identity is not in the local catalog."""
        return sum(1 for profile in self.profiles.values()
                   if self.metadata_for_profile(profile) is None)

    @property
    def runtime_catalog_samples(self) -> int:
        return sum(1 for metadata in self.catalog.values()
                   if metadata.get("source") == "runtime_ocr_visual_scan")

    def assessment(self) -> DeckAssessment:
        profiles = list(self.profiles.values())
        known_costs = [p.cost_estimate for p in profiles if p.cost_estimate is not None and p.cost_confidence >= 0.35]
        catalogued = [p for p in profiles if self.metadata_for_profile(p) is not None]
        average = sum(known_costs) / len(known_costs) if known_costs else None
        spread = (max(known_costs) - min(known_costs)) if len(known_costs) >= 2 else None
        # Visual fingerprints alone do not reveal win conditions, spell coverage,
        # air defense, card ownership, or the complete eight-card collection.
        can_recommend = len(catalogued) >= 8 and len(known_costs) >= 6
        reason = ("verified local card metadata is available" if can_recommend else
                  "card identities/roles and the full owned collection are not verified")
        return DeckAssessment(len(profiles), len(known_costs),
                              round(average, 2) if average is not None else None,
                              round(spread, 2) if spread is not None else None,
                              max(0, len(profiles) - len(catalogued)), can_recommend, reason)

    def build_plan(self) -> tuple[str, ...] | None:
        """Return a role-balanced deck only with a complete verified local catalog.

        Metadata is keyed by the learned fingerprint and must explicitly mark a
        card as owned.  The stock release has no fabricated card-name/image map,
        so this planner remains dormant until identity evidence exists.
        """
        if not self.assessment().can_recommend:
            return None
        candidates = []
        for profile in self.profiles.values():
            metadata = self.metadata_for_profile(profile)
            if not isinstance(metadata, dict) or metadata.get("owned") is not True:
                continue
            roles = metadata.get("roles")
            if not isinstance(roles, list):
                role = metadata.get("role")
                roles = [role] if isinstance(role, str) else []
            roles = {role for role in roles if isinstance(role, str)}
            cost = metadata.get("cost")
            level = metadata.get("level", 1)
            if not roles or not _finite(cost) or not 1 <= cost <= 10:
                continue
            if not _finite(level):
                level = 1
            candidates.append({
                "id": profile.profile_id,
                "roles": roles,
                "cost": float(cost),
                "level": max(1.0, min(16.0, float(level))),
            })
        if len(candidates) < 8:
            return None

        def score(item: dict, target_cost: float = 3.8) -> float:
            return item["level"] * 0.08 - abs(item["cost"] - target_cost) * 0.55

        selected: list[dict] = []
        used: set[str] = set()

        def take(predicate, count: int = 1) -> bool:
            available = [item for item in candidates
                         if item["id"] not in used and predicate(item)]
            available.sort(key=score, reverse=True)
            if len(available) < count:
                return False
            for item in available[:count]:
                selected.append(item)
                used.add(item["id"])
            return True

        # Preserve basic strategic coverage before filling remaining slots.
        if not take(lambda item: "win_condition" in item["roles"]):
            return None
        if not take(lambda item: "spell" in item["roles"], 2):
            return None
        if not take(lambda item: "air_defense" in item["roles"]):
            return None
        if not take(lambda item: bool(item["roles"] & {"building", "tank_killer"})):
            return None

        while len(selected) < 8:
            remaining = [item for item in candidates if item["id"] not in used]
            if not remaining:
                return None
            current_average = sum(item["cost"] for item in selected) / len(selected)
            remaining.sort(key=lambda item: score(item, target_cost=max(2.8, min(4.6, 4.0 + (3.8 - current_average)))), reverse=True)
            selected.append(remaining[0])
            used.add(remaining[0]["id"])

        average_cost = sum(item["cost"] for item in selected) / 8.0
        role_coverage = set().union(*(item["roles"] for item in selected))
        if not 2.6 <= average_cost <= 5.2 or len(role_coverage) < 5:
            return None
        return tuple(item["id"] for item in selected)

    def save(self) -> None:
        self.profile_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": PROFILE_VERSION,
            "profiles": [
                {
                    "profile_id": p.profile_id,
                    "fingerprint": p.fingerprint,
                    "observations": p.observations,
                    "ready_observations": p.ready_observations,
                    "cost_samples": p.cost_samples,
                    "cost_estimate": p.cost_estimate,
                    "cost_low": p.cost_low,
                    "cost_high": p.cost_high,
                    "last_ready": p.last_ready,
                    "last_elixir": p.last_elixir,
                    "last_seen": p.last_seen,
                    "descriptor": p.descriptor,
                }
                for p in sorted(self.profiles.values(), key=lambda item: item.profile_id)
            ][:256],
        }
        temp = self.profile_path.with_suffix(self.profile_path.suffix + ".tmp")
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.profile_path)
            if self._catalog_dirty:
                self.save_catalog()
        finally:
            try:
                if temp.exists():
                    temp.unlink()
            except OSError:
                pass
