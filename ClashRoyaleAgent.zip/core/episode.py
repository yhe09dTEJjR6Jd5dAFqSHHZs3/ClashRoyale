"""Hysteresis for ending a match episode when the result banner is unreadable.

A single missed battle frame must not terminate an episode.  Only a stable,
confident non-battle scene or a prolonged unknown scene closes it, and the
caller must record the episode as unlabeled rather than inventing an outcome.
"""
from __future__ import annotations

import time

from .vision import GameState, Scene


class MatchExitDetector:
    """Detect a confirmed exit from battle without guessing win/loss/draw."""

    STABLE_EXIT_FRAMES = 3
    MIN_EXIT_CONFIDENCE = 0.78
    UNKNOWN_TIMEOUT_SECONDS = 15.0
    EXIT_SCENES = frozenset({
        Scene.HOME, Scene.DECK, Scene.RESULT, Scene.MODE_SELECT,
        Scene.RECOVERY, Scene.MATCHMAKING, Scene.LOADING,
    })

    def __init__(self) -> None:
        self._candidate_scene: Scene | None = None
        self._candidate_frames = 0
        self._last_battle_at: float | None = None

    def reset(self) -> None:
        self._candidate_scene = None
        self._candidate_frames = 0
        self._last_battle_at = None

    def observe(self, state: GameState, *, now: float | None = None) -> str | None:
        """Return a reason only after a stable exit; never return an outcome."""
        now = time.monotonic() if now is None else float(now)
        if state.scene is Scene.BATTLE and state.battle_detected:
            self._last_battle_at = now
            self._candidate_scene = None
            self._candidate_frames = 0
            return None

        if (state.scene in self.EXIT_SCENES and
                state.scene_confidence >= self.MIN_EXIT_CONFIDENCE):
            if state.scene is self._candidate_scene:
                self._candidate_frames += 1
            else:
                self._candidate_scene = state.scene
                self._candidate_frames = 1
            if self._candidate_frames >= self.STABLE_EXIT_FRAMES:
                return f"stable_{state.scene.value}"
            return None

        self._candidate_scene = None
        self._candidate_frames = 0
        if state.scene is Scene.UNKNOWN and self._last_battle_at is not None:
            if now - self._last_battle_at >= self.UNKNOWN_TIMEOUT_SECONDS:
                return "unknown_timeout"
        return None
