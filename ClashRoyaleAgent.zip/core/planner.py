"""Deterministic, model-free placement search over a small legal arena grid.

The planner never assigns identities to generic color blobs.  It uses only
verified card roles, visible clusters, short-lived tracks, and lane pressure.
Its scores are tactical heuristics, not a full game simulator or a claim of
optimal play.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import exp, hypot

from .tactics import assess_lane
from .tracking import TemporalBattleTracker
from .vision import GameState


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


@dataclass(frozen=True)
class DeploymentPlan:
    x: float
    y: float
    score: float
    confidence: float
    reason: str


def _lane_center(lane: int) -> float:
    return 0.30 if lane == 0 else 0.70


def _arena_point(state: GameState, x: float, y: float) -> tuple[float, float]:
    """Map canonical placement points into the arena found in the current frame."""
    bounds = state.arena_bounds
    if bounds is None:
        return _clamp(x), _clamp(y)
    ax0, ay0, ax1, ay1 = bounds
    arena_w, arena_h = max(0.1, ax1 - ax0), max(0.1, ay1 - ay0)
    # Canonical anchors match the original arena proportions; only the viewport
    # edges/height are recalibrated, so a modest UI rearrangement cannot move a
    # troop onto the hand or opponent's side.
    u = _clamp((x - 0.06) / 0.88)
    v = _clamp((y - 0.14) / 0.66)
    return _clamp(ax0 + u * arena_w), _clamp(ay0 + v * arena_h)


def _enemy_observations(state: GameState, lane: int):
    clusters = tuple(
        item for item in state.enemy_clusters
        if (item.x < 0.5) == (lane == 0) and item.confidence >= 0.30
    )
    tracks = tuple(
        item for item in state.enemy_tracks
        if item.lane == lane and item.observations >= 2 and item.confidence >= 0.35
    )
    predicted_items = []
    for item in tracks:
        px, py = TemporalBattleTracker.predicted_position(item, 0.16)
        predicted_items.append((px, py, max(0.05, item.area * item.confidence * 60.0),
                                item.confidence))
    predicted = tuple(predicted_items)
    observed = tuple(
        (item.x, item.y, max(0.05, item.area * item.confidence * 60.0), item.confidence)
        for item in clusters
    )
    # Tracks and clusters often represent the same object.  Prefer the tracked
    # prediction when it is close to a current cluster to avoid double weight.
    points = list(predicted)
    for point in observed:
        if not any(hypot((point[0] - other[0]) * 1.2, point[1] - other[1]) < 0.055
                   for other in predicted):
            points.append(point)
    return tuple(points), clusters, tracks


def _candidate_score(
    state: GameState,
    x: float,
    y: float,
    lane: int,
    roles: set[str],
    enemies,
    friendly_clusters,
    urgency: float,
    opportunity: float,
) -> float:
    lane_x = _lane_center(lane)
    score = 0.0
    defensive = bool(roles & {"building", "tank_killer", "swarm", "air_defense", "melee"})
    offensive = bool(roles & {"win_condition", "tank", "support", "ranged"})

    if defensive and enemies:
        best = 0.0
        for ex, ey, weight, confidence in enemies:
            dx = (x - ex) * 1.25
            dy = y - ey
            # A troop/building should be placed on the friendly side, near
            # enough to engage the threat without blindly dropping on top of it.
            vertical_gap = y - ey
            gap_fit = exp(-abs(vertical_gap - 0.105) * 8.0)
            proximity = exp(-hypot(dx, dy) * 5.5)
            best = max(best, proximity * gap_fit * _clamp(weight, 0.0, 1.0) * confidence)
        score += 0.52 * best + 0.24 * urgency
    elif offensive:
        score += 0.30 * opportunity
        score += 0.12 * (1.0 - abs(x - lane_x) / 0.18)
        preferred_y = 0.635 if "win_condition" in roles else 0.685
        score += 0.16 * exp(-abs(y - preferred_y) * 10.0)
    else:
        score += 0.12 * (1.0 - abs(x - lane_x) / 0.18)
        score += 0.08 * (1.0 - abs(y - 0.66) / 0.20)

    # Buildings benefit from central pull geometry and can respond to either lane.
    if "building" in roles:
        combined_pressure = max(state.left_threat, state.right_threat)
        score += 0.22 * combined_pressure
        score += 0.16 * (1.0 - min(1.0, abs(x - 0.5) / 0.12))
        score += 0.08 * exp(-abs(y - 0.675) * 9.0)

    # Do not stack a new troop directly on top of an existing friendly blob.
    crowding = 0.0
    for item in friendly_clusters:
        distance = hypot((x - item.x) * 1.2, y - item.y)
        crowding = max(crowding, max(0.0, 0.075 - distance) / 0.075 * item.confidence)
    score -= 0.14 * crowding
    return score


def _spell_plan(state: GameState, lane: int, enemies, clusters, tracks) -> DeploymentPlan:
    if not enemies:
        # A lane-pressure-only guess is not a reliable spell target.
        return DeploymentPlan(_lane_center(lane), 0.50, -0.25, 0.0,
                              "no reliable enemy target; spell placement suppressed")

    # Pick the densest observed area, then test a small offset grid around its
    # short-horizon prediction.  This is a compact search, not hitbox inference.
    seed = max(enemies, key=lambda item: item[2] * item[3])
    nearby = [item for item in enemies
              if hypot((item[0] - seed[0]) * 1.2, item[1] - seed[1]) <= 0.12]
    total_weight = sum(max(0.01, item[2] * item[3]) for item in nearby)
    center_x = sum(item[0] * max(0.01, item[2] * item[3]) for item in nearby) / total_weight
    center_y = sum(item[1] * max(0.01, item[2] * item[3]) for item in nearby) / total_weight

    best = None
    for dx, dy in ((0.0, 0.0), (-0.025, 0.0), (0.025, 0.0),
                   (0.0, -0.025), (0.0, 0.025), (-0.025, -0.025),
                   (0.025, 0.025)):
        if state.arena_bounds is not None:
            ax0, ay0, ax1, ay1 = state.arena_bounds
            arena_w, arena_h = max(0.1, ax1 - ax0), max(0.1, ay1 - ay0)
            x = _clamp(center_x + dx * arena_w, ax0 + arena_w * 0.03, ax1 - arena_w * 0.03)
            y = _clamp(center_y + dy * arena_h, ay0 + arena_h * 0.08, ay1 - arena_h * 0.02)
        else:
            x = _clamp(center_x + dx, 0.08, 0.92)
            y = _clamp(center_y + dy, 0.18, 0.74)
        covered = sum(
            max(0.01, item[2] * item[3]) * exp(-hypot((x - item[0]) * 1.2, y - item[1]) * 9.0)
            for item in enemies
        )
        candidate = (covered, x, y)
        if best is None or candidate[0] > best[0]:
            best = candidate
    assert best is not None
    evidence = max((item[3] for item in enemies), default=0.0)
    confidence = min(0.78, 0.32 + 0.35 * evidence + min(0.10, len(enemies) * 0.025))
    return DeploymentPlan(best[1], best[2], _clamp(best[0], 0.0, 1.0), confidence,
                          "grid search over the densest visible enemy cluster")


def plan_deployment(
    state: GameState,
    card: int,
    lane: int,
    lane_assessments=None,
) -> DeploymentPlan:
    """Search role-appropriate candidate cells and return the highest score.

    Callers evaluating all eight hand/lane actions may pass precomputed lane
    assessments to avoid repeating track aggregation in the hot policy loop.
    """
    if not 0 <= int(card) < 4 or lane not in (0, 1):
        raise ValueError("card must be 0..3 and lane must be 0 (left) or 1 (right)")

    roles = set(state.card_roles[card]) if card < len(state.card_roles) else set()
    assessments = lane_assessments or (assess_lane(state, 0), assess_lane(state, 1))
    current = assessments[lane]
    enemies, clusters, tracks = _enemy_observations(state, lane)
    if "spell" in roles:
        return _spell_plan(state, lane, enemies, clusters, tracks)

    friendly_clusters = tuple(
        item for item in state.friendly_clusters
        if (item.x < 0.5) == (lane == 0)
    )
    if "building" in roles:
        xs = (0.44, 0.48, 0.50, 0.52, 0.56)
        ys = (0.615, 0.655, 0.675, 0.695, 0.735)
        reason = "center-pull grid search for a defensive building"
    else:
        center = _lane_center(lane)
        offsets = (-0.075, -0.035, 0.0, 0.035, 0.075)
        xs = tuple(_clamp(center + offset, 0.12, 0.88) for offset in offsets)
        if roles & {"tank_killer", "swarm", "air_defense", "melee"}:
            ys = (0.565, 0.605, 0.645, 0.685, 0.725, 0.765)
            reason = "defensive interception grid search"
        elif "win_condition" in roles:
            ys = (0.595, 0.625, 0.655, 0.685)
            reason = "win-condition lane-entry grid search"
        elif roles & {"tank", "support", "ranged"}:
            ys = (0.635, 0.675, 0.715, 0.755)
            reason = "support spacing grid search"
        else:
            ys = (0.615, 0.655, 0.695, 0.735)
            reason = "conservative fallback grid search"

    best: tuple[float, float, float] | None = None
    for canonical_x in xs:
        for canonical_y in ys:
            x, y = _arena_point(state, canonical_x, canonical_y)
            score = _candidate_score(
                state, x, y, lane, roles, enemies, friendly_clusters,
                current.defensive_urgency, current.offensive_opportunity,
            )
            candidate = (score, x, y)
            if best is None or candidate[0] > best[0]:
                best = candidate
    assert best is not None
    evidence = max((item[3] for item in enemies), default=0.0)
    confidence = min(0.78, 0.34 + 0.28 * max(state.confidence, state.scene_confidence)
                     + 0.20 * evidence)
    if not enemies and not friendly_clusters:
        confidence = min(confidence, 0.52)
    return DeploymentPlan(best[1], best[2], _clamp(best[0], -0.5, 1.0), confidence, reason)
