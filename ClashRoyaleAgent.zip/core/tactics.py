"""Deterministic tactical scoring built only from locally observed game signals.

This module does not pretend that color blobs are troop identities.  It combines
lane pressure, short-lived motion tracks, verified card roles and observed card
costs into a conservative action adjustment for the contextual learner.
"""
from __future__ import annotations

from dataclasses import dataclass

from .tracking import TemporalBattleTracker
from .vision import GameState


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


@dataclass(frozen=True)
class LaneAssessment:
    lane: int
    pixel_threat: float
    pixel_support: float
    enemy_cluster_strength: float
    friendly_cluster_strength: float
    enemy_advance: float
    friendly_advance: float
    enemy_front_y: float
    projected_enemy_front_y: float
    enemy_count: int
    friendly_count: int
    defensive_urgency: float
    offensive_opportunity: float


def assess_lane(state: GameState, lane: int) -> LaneAssessment:
    """Estimate lane urgency without assigning semantic troop identities.

    The y-axis grows toward the player's side.  Persistent enemy tracks moving
    toward positive y raise urgency; friendly tracks moving toward negative y
    raise counter-push potential.  Pixel pressure remains the baseline signal.
    """
    if lane not in (0, 1):
        raise ValueError("lane must be 0 (left) or 1 (right)")

    pixel_threat = state.left_threat if lane == 0 else state.right_threat
    pixel_support = state.left_support if lane == 0 else state.right_support
    enemy_clusters = tuple(item for item in state.enemy_clusters if (item.x < 0.5) == (lane == 0))
    friendly_clusters = tuple(item for item in state.friendly_clusters if (item.x < 0.5) == (lane == 0))
    enemy_tracks = tuple(item for item in state.enemy_tracks
                         if item.lane == lane and item.observations >= 2 and item.confidence >= 0.30)
    friendly_tracks = tuple(item for item in state.friendly_tracks
                            if item.lane == lane and item.observations >= 2 and item.confidence >= 0.30)

    enemy_cluster_strength = _clamp(sum(
        min(0.24, item.area * item.confidence * 24.0) for item in enemy_clusters
    ))
    friendly_cluster_strength = _clamp(sum(
        min(0.24, item.area * item.confidence * 24.0) for item in friendly_clusters
    ))
    enemy_advance = _clamp(TemporalBattleTracker.lane_advance(
        state.enemy_tracks, lane, toward_positive_y=True
    ))
    friendly_advance = _clamp(TemporalBattleTracker.lane_advance(
        state.friendly_tracks, lane, toward_positive_y=False
    ))

    enemy_front_y = max(
        (item.y for item in enemy_tracks),
        default=max((item.y for item in enemy_clusters), default=0.0),
    )
    projected_enemy_front_y = max(
        (TemporalBattleTracker.predicted_position(item, 0.32)[1] for item in enemy_tracks),
        default=enemy_front_y,
    )
    # The lower half of the arena is closer to friendly towers.  This cue is
    # intentionally gradual because the exact arena crop varies by emulator.
    front_pressure = _clamp((projected_enemy_front_y - 0.43) / 0.36)
    threat_evidence = _clamp(
        0.50 * _clamp(pixel_threat)
        + 0.22 * enemy_cluster_strength
        + 0.18 * enemy_advance
        + 0.10 * front_pressure
    )
    support_evidence = _clamp(
        0.50 * _clamp(pixel_support)
        + 0.25 * friendly_cluster_strength
        + 0.25 * friendly_advance
    )
    defensive_urgency = _clamp(max(_clamp(pixel_threat), threat_evidence) - 0.34 * support_evidence)
    offensive_opportunity = _clamp(
        0.46 * support_evidence + 0.24 * friendly_advance + 0.30 * (1.0 - defensive_urgency)
    )
    return LaneAssessment(
        lane=lane,
        pixel_threat=_clamp(pixel_threat),
        pixel_support=_clamp(pixel_support),
        enemy_cluster_strength=enemy_cluster_strength,
        friendly_cluster_strength=friendly_cluster_strength,
        enemy_advance=enemy_advance,
        friendly_advance=friendly_advance,
        enemy_front_y=_clamp(enemy_front_y),
        projected_enemy_front_y=_clamp(projected_enemy_front_y),
        enemy_count=len(enemy_clusters) + len(enemy_tracks),
        friendly_count=len(friendly_clusters) + len(friendly_tracks),
        defensive_urgency=defensive_urgency,
        offensive_opportunity=offensive_opportunity,
    )


def tactical_adjustment(state: GameState, card: int, lane: int,
                        lane_assessments: tuple[LaneAssessment, LaneAssessment] | None = None) -> float:
    """Return a bounded deterministic adjustment to a learned action score.

    Callers scoring all eight actions should pass the two precomputed lane
    assessments so visual tracking evidence is aggregated only once per frame.
    """
    if not 0 <= card < 4 or lane not in (0, 1):
        return -1.0
    if lane_assessments is None:
        lane_assessments = (assess_lane(state, 0), assess_lane(state, 1))
    current = lane_assessments[lane]
    other = lane_assessments[1 - lane]
    roles = set(state.card_roles[card]) if card < len(state.card_roles) else set()
    cost = state.card_costs[card] if card < len(state.card_costs) else None
    cost_known = isinstance(cost, (int, float)) and not isinstance(cost, bool)

    urgency = current.defensive_urgency
    score = 0.13 * urgency + 0.07 * (urgency - other.defensive_urgency)

    defensive_roles = roles & {"building", "tank_killer", "swarm", "melee", "air_defense"}
    offensive_roles = roles & {"win_condition", "tank", "support", "ranged"}
    if urgency >= 0.16:
        if defensive_roles:
            score += 0.075 + 0.12 * urgency
        if "air_defense" in roles and current.enemy_count:
            score += 0.025
        if "spell" in roles:
            # Do not spend an identified spell on a lone/uncertain color blob.
            if current.enemy_cluster_strength >= 0.12 and current.enemy_count >= 2:
                score += 0.045 + 0.07 * current.enemy_cluster_strength
            elif current.enemy_cluster_strength < 0.06:
                score -= 0.11
        if "win_condition" in roles and urgency >= 0.55:
            score -= 0.035
    else:
        score += 0.055 * current.offensive_opportunity
        if offensive_roles:
            score += 0.045
        if "spell" in roles and current.enemy_cluster_strength < 0.08:
            score -= 0.10

    if "cycle" in roles and state.elixir < 4.2:
        score += 0.025
    if cost_known:
        numeric_cost = float(cost)
        if state.elixir < 4.0 and numeric_cost >= 5.0 and urgency < 0.58:
            score -= 0.12
        elif state.elixir < 5.0 and numeric_cost >= 4.5 and urgency < 0.40:
            score -= 0.07
        elif state.elixir >= 8.6 and numeric_cost >= 4.0:
            score += 0.025
        if state.elixir - numeric_cost < 1.0 and urgency < 0.35:
            score -= 0.045
    elif not roles and urgency < 0.30:
        # Unknown cards remain available for urgent recovery/near-overflow, but
        # are not preferred over cards with verified semantic metadata.
        score -= 0.025

    return max(-0.30, min(0.30, score))
