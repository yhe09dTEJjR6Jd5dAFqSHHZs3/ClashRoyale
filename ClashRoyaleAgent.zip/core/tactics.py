"""Deterministic tactical scoring built only from locally observed game signals.

This module does not pretend that color blobs are troop identities.  It combines
lane pressure, short-lived motion tracks, verified card roles and observed card
costs into a conservative action adjustment for the contextual learner.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import hypot

from .tracking import TemporalBattleTracker
from .vision import GameState


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


@dataclass(frozen=True)
class LaneAssessment:
    lane: int
    pixel_threat: float
    pixel_support: float
    enemy_cluster_strength: float
    friendly_cluster_strength: float
    enemy_advance: float
    friendly_advance: float
    enemy_front_y: float
    projected_enemy_front_y: float
    enemy_count: int
    friendly_count: int
    semantic_enemy_strength: float
    semantic_friendly_strength: float
    defensive_urgency: float
    offensive_opportunity: float


def _deduplicated_observation_count(clusters, tracks, association_clusters=None) -> int:
    """Count visible blobs plus persistent tracks not represented this frame.

    The tracker is built from the same color clusters supplied in ``state``.
    Counting both collections additively double-counts every currently matched
    object.  A track is counted separately only when no current cluster lies
    within the tracker's association radius (a short occlusion/missed frame).
    """
    current = tuple(clusters)
    association = tuple(association_clusters) if association_clusters is not None else current
    persistent = tuple(
        track for track in tracks
        if track.observations >= 2 and track.confidence >= 0.30
    )
    unmatched = 0
    radius = TemporalBattleTracker.MAX_MATCH_DISTANCE
    for track in persistent:
        if not any(hypot(track.x - cluster.x, track.y - cluster.y) <= radius
                   for cluster in association):
            unmatched += 1
    return len(current) + unmatched


def assess_lane(state: GameState, lane: int) -> LaneAssessment:
    """Estimate lane urgency without assigning semantic troop identities.

    The y-axis grows toward the player's side.  Persistent enemy tracks moving
    toward positive y raise urgency; friendly tracks moving toward negative y
    raise counter-push potential.  Pixel pressure remains the baseline signal.
    """
    if lane not in (0, 1):
        raise ValueError("lane must be 0 (left) or 1 (right)")

    pixel_threat = state.left_threat if lane == 0 else state.right_threat
    pixel_support = state.left_support if lane == 0 else state.right_support
    enemy_clusters = tuple(item for item in state.enemy_clusters if (item.x < 0.5) == (lane == 0))
    friendly_clusters = tuple(item for item in state.friendly_clusters if (item.x < 0.5) == (lane == 0))
    enemy_tracks = tuple(item for item in state.enemy_tracks
                         if item.lane == lane and item.observations >= 2 and item.confidence >= 0.30)
    friendly_tracks = tuple(item for item in state.friendly_tracks
                            if item.lane == lane and item.observations >= 2 and item.confidence >= 0.30)

    enemy_cluster_strength = _clamp(sum(
        min(0.24, item.area * item.confidence * 24.0) for item in enemy_clusters
    ))
    friendly_cluster_strength = _clamp(sum(
        min(0.24, item.area * item.confidence * 24.0) for item in friendly_clusters
    ))
    enemy_advance = _clamp(TemporalBattleTracker.lane_advance(
        state.enemy_tracks, lane, toward_positive_y=True
    ))
    friendly_advance = _clamp(TemporalBattleTracker.lane_advance(
        state.friendly_tracks, lane, toward_positive_y=False
    ))

    enemy_front_y = max(
        (item.y for item in enemy_tracks),
        default=max((item.y for item in enemy_clusters), default=0.0),
    )
    projected_enemy_front_y = max(
        (TemporalBattleTracker.predicted_position(item, 0.32)[1] for item in enemy_tracks),
        default=enemy_front_y,
    )
    semantic_enemy = tuple(
        unit for unit in state.semantic_enemy_units
        if (unit.x < 0.5) == (lane == 0) and unit.confidence >= 0.58
    )
    semantic_friendly = tuple(
        unit for unit in state.semantic_friendly_units
        if (unit.x < 0.5) == (lane == 0) and unit.confidence >= 0.58
    )

    def semantic_strength(units, *, enemy: bool) -> float:
        total = 0.0
        for unit in units:
            roles = set(getattr(unit, "roles", ()) or ())
            weight = 0.055
            if "win_condition" in roles:
                weight += 0.105
            if "tank" in roles:
                weight += 0.075
            if "tank_killer" in roles:
                weight += 0.045
            if "support" in roles or "ranged" in roles:
                weight += 0.035
            if "building" in roles:
                weight += 0.025
            progress = _clamp((unit.y - 0.30) / 0.58) if enemy else _clamp((0.70 - unit.y) / 0.58)
            hp_ratio = getattr(unit, "health_ratio", None)
            hp_factor = (0.62 + 0.38 * _clamp(hp_ratio)
                         if isinstance(hp_ratio, (int, float)) else 0.82)
            total += float(unit.confidence) * weight * (0.55 + 0.75 * progress) * hp_factor
        return _clamp(total * 1.35)

    semantic_enemy_strength = semantic_strength(semantic_enemy, enemy=True)
    semantic_friendly_strength = semantic_strength(semantic_friendly, enemy=False)
    # The lower half of the arena is closer to friendly towers. This cue is
    # gradual because the exact arena crop varies by emulator.
    front_pressure = _clamp((projected_enemy_front_y - 0.43) / 0.36)
    threat_evidence = _clamp(
        0.40 * _clamp(pixel_threat)
        + 0.18 * enemy_cluster_strength
        + 0.13 * enemy_advance
        + 0.08 * front_pressure
        + 0.21 * semantic_enemy_strength
    )
    support_evidence = _clamp(
        0.40 * _clamp(pixel_support)
        + 0.20 * friendly_cluster_strength
        + 0.20 * friendly_advance
        + 0.20 * semantic_friendly_strength
    )
    defensive_urgency = _clamp(max(_clamp(pixel_threat), threat_evidence) - 0.34 * support_evidence)
    offensive_opportunity = _clamp(
        0.46 * support_evidence + 0.24 * friendly_advance + 0.30 * (1.0 - defensive_urgency)
    )
    return LaneAssessment(
        lane=lane,
        pixel_threat=_clamp(pixel_threat),
        pixel_support=_clamp(pixel_support),
        enemy_cluster_strength=enemy_cluster_strength,
        friendly_cluster_strength=friendly_cluster_strength,
        enemy_advance=enemy_advance,
        friendly_advance=friendly_advance,
        enemy_front_y=_clamp(enemy_front_y),
        projected_enemy_front_y=_clamp(projected_enemy_front_y),
        enemy_count=_deduplicated_observation_count(
            enemy_clusters, enemy_tracks, state.enemy_clusters
        ),
        friendly_count=_deduplicated_observation_count(
            friendly_clusters, friendly_tracks, state.friendly_clusters
        ),
        semantic_enemy_strength=semantic_enemy_strength,
        semantic_friendly_strength=semantic_friendly_strength,
        defensive_urgency=defensive_urgency,
        offensive_opportunity=offensive_opportunity,
    )


def tactical_adjustment(state: GameState, card: int, lane: int,
                        lane_assessments: tuple[LaneAssessment, LaneAssessment] | None = None) -> float:
    """Return a bounded deterministic adjustment to a learned action score.

    Callers scoring all eight actions should pass the two precomputed lane
    assessments so visual tracking evidence is aggregated only once per frame.
    """
    if not 0 <= card < 4 or lane not in (0, 1):
        return -1.0
    if lane_assessments is None:
        lane_assessments = (assess_lane(state, 0), assess_lane(state, 1))
    current = lane_assessments[lane]
    other = lane_assessments[1 - lane]
    roles = set(state.card_roles[card]) if card < len(state.card_roles) else set()
    cost = state.card_costs[card] if card < len(state.card_costs) else None
    cost_known = isinstance(cost, (int, float)) and not isinstance(cost, bool)

    urgency = current.defensive_urgency
    score = 0.13 * urgency + 0.07 * (urgency - other.defensive_urgency)

    semantic_enemy_roles = {
        role for unit in state.semantic_enemy_units
        if (unit.x < 0.5) == (lane == 0) and unit.confidence >= 0.58
        for role in (getattr(unit, "roles", ()) or ())
    }
    if "tank" in semantic_enemy_roles and roles & {"tank_killer", "building"}:
        score += 0.045 + 0.035 * current.semantic_enemy_strength
    if "win_condition" in semantic_enemy_roles and roles & {"tank_killer", "building", "air_defense"}:
        score += 0.035
    if "swarm" in semantic_enemy_roles and "spell" in roles and current.enemy_cluster_strength >= 0.08:
        score += 0.025

    defensive_roles = roles & {"building", "tank_killer", "swarm", "melee", "air_defense"}
    offensive_roles = roles & {"win_condition", "tank", "support", "ranged"}
    if urgency >= 0.16:
        if defensive_roles:
            score += 0.075 + 0.12 * urgency
        if "air_defense" in roles and current.enemy_count:
            score += 0.025
        if "spell" in roles:
            # Do not spend an identified spell on a lone/uncertain color blob.
            if current.enemy_cluster_strength >= 0.12 and current.enemy_count >= 2:
                score += 0.045 + 0.07 * current.enemy_cluster_strength
            elif current.enemy_cluster_strength < 0.06:
                score -= 0.11
        if "win_condition" in roles and urgency >= 0.55:
            score -= 0.035
    else:
        score += 0.055 * current.offensive_opportunity
        if offensive_roles:
            score += 0.045
        if "spell" in roles and current.enemy_cluster_strength < 0.08:
            score -= 0.10

    if "cycle" in roles and state.elixir < 4.2:
        score += 0.025

    # A named opponent return-card is only emitted when OCR actually reads it.
    # Reserve the appropriate answer rather than treating anonymous blobs as
    # card identities. Anonymous cycle tokens remain diagnostic only.
    if state.opponent_cycle_card and state.opponent_cycle_confidence >= 0.65:
        opponent_roles = set(state.opponent_cycle_roles)
        if "spell" in opponent_roles and "swarm" in roles and urgency < 0.58:
            score -= 0.055
        if "win_condition" in opponent_roles:
            if roles & {"tank_killer", "building", "air_defense"}:
                score += 0.035 + 0.045 * urgency
            elif roles & {"swarm", "support"} and urgency < 0.32:
                score -= 0.025

    if cost_known:
        numeric_cost = float(cost)
        if state.elixir < 4.0 and numeric_cost >= 5.0 and urgency < 0.58:
            score -= 0.12
        elif state.elixir < 5.0 and numeric_cost >= 4.5 and urgency < 0.40:
            score -= 0.07
        elif state.elixir >= 8.6 and numeric_cost >= 4.0:
            score += 0.025
        if state.elixir - numeric_cost < 1.0 and urgency < 0.35:
            score -= 0.045
    elif not roles and urgency < 0.30:
        # Unknown cards remain available for urgent recovery/near-overflow, but
        # are not preferred over cards with verified semantic metadata.
        score -= 0.025

    return max(-0.30, min(0.30, score))
