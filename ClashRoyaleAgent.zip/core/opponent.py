"""Observed-play four-card-cycle bookkeeping for the opponent.

Enemy unit detections are generic red/blue visual tracks, not card identities.
The tracker therefore records anonymous deployment events unless a card name is
actually read from the frame. It predicts the return slot only from the observed
play order and exposes confidence so the policy cannot mistake a guess for fact.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, replace
import json
import math
import os
import time

from .cards import CardDatabase
from .vision import GameState, Scene


@dataclass(frozen=True)
class OpponentPlay:
    token: str
    card_key: str
    confidence: float
    timestamp: float
    lane: int
    strength: float
    source: str
    track_id: int = 0
    card_form: str = "base"


class OpponentCycleTracker:
    """Track newly observed opponent deployments and the four-card return queue."""

    MAX_HISTORY = 64
    EVENT_MERGE_SECONDS = 0.55
    MIN_TRACK_CONFIDENCE = 0.30
    MAX_SEEN_TRACK_IDS = 512
    UNKNOWN_SCENE_GRACE_SECONDS = 2.0

    def __init__(self, card_database: CardDatabase | None = None):
        self.card_database = card_database or CardDatabase()
        self.history: list[OpponentPlay] = []
        self._seen_track_ids: set[int] = set()
        self._seen_track_order: deque[int] = deque()
        self._seen_semantic_track_ids: set[int] = set()
        self._next_token = 1
        self._last_event_at = -1e9
        self._last_battle_at: float | None = None
        self._last_summary: dict = {}

    def reset(self) -> None:
        self.history.clear()
        self._seen_track_ids.clear()
        self._seen_track_order.clear()
        self._seen_semantic_track_ids.clear()
        self._next_token = 1
        self._last_event_at = -1e9
        self._last_battle_at = None
        self._last_summary = {}

    def _remember_track_id(self, track_id: int) -> bool:
        """Remember a deployment track ID with a strict memory bound."""
        if track_id in self._seen_track_ids:
            return False
        self._seen_track_ids.add(track_id)
        self._seen_track_order.append(track_id)
        if len(self._seen_track_order) > self.MAX_SEEN_TRACK_IDS:
            expired = self._seen_track_order.popleft()
            self._seen_track_ids.discard(expired)
        return True

    def _with_snapshot(self, state: GameState) -> GameState:
        card_key, token, confidence, roles, recent, seen, complete = self._snapshot()
        return replace(
            state,
            opponent_cycle_card=card_key,
            opponent_cycle_token=token,
            opponent_cycle_confidence=confidence,
            opponent_cycle_roles=roles,
            opponent_play_count=len(self.history),
            opponent_recent_plays=recent,
            opponent_seen_cards=seen,
            opponent_cycle_eta=0 if complete else None,
            opponent_cycle_complete=complete,
        )

    def _card_key_near_track(self, state: GameState, x: float, y: float) -> str:
        frame_width = max(1, state.frame_width)
        frame_height = max(1, state.frame_height)
        candidates = []
        for item in state.recognized_cards:
            if item.confidence < 0.88 or item.bounds is None:
                continue
            x0, y0, x1, y1 = item.bounds
            cx = (x0 + x1) / (2.0 * frame_width)
            cy = (y0 + y1) / (2.0 * frame_height)
            # The opponent's half is above the arena midline. A name read in
            # the player's hand/deck is never attached to an enemy deployment.
            if cy > 0.48:
                continue
            distance = ((cx - x) ** 2 + (cy - y) ** 2) ** 0.5
            if distance <= 0.28:
                candidates.append((distance, item))
        if not candidates:
            return ""
        candidates.sort(key=lambda pair: pair[0])
        return candidates[0][1].card_key

    def _record_event(self, state: GameState, tracks, now: float) -> None:
        representative = max(
            tracks, key=lambda item: item.area * item.confidence, default=None
        )
        if representative is None:
            return
        strength = max(0.0, min(1.0, representative.area * 80.0 * representative.confidence))
        confidence = max(0.0, min(0.82,
            0.30 + representative.confidence * 0.40 + min(0.12, len(tracks) * 0.025)
        ))
        card_key = self._card_key_near_track(state, representative.x, representative.y)
        if card_key:
            # A high-confidence OCR name is stronger evidence than a generic
            # deployment blob; only named four-play windows can drive counters.
            confidence = max(confidence, 0.88)
        if now - self._last_event_at <= self.EVENT_MERGE_SECONDS and self.history:
            previous = self.history[-1]
            # Several blobs born in the same short deployment window are one
            # play (e.g. Skeleton Army), not several cards in the cycle.
            self.history[-1] = replace(
                previous,
                confidence=max(previous.confidence, confidence),
                strength=max(previous.strength, strength),
                card_key=previous.card_key or card_key,
                source="cluster+ocr" if card_key else previous.source,
                track_id=representative.track_id,
            )
            self._last_event_at = now
            return
        token = f"opp_{self._next_token:04d}"
        self._next_token += 1
        lane = 0 if representative.x < 0.5 else 1
        self.history.append(OpponentPlay(
            token=token, card_key=card_key, confidence=confidence,
            timestamp=now, lane=lane, strength=strength,
            source="cluster+ocr" if card_key else "enemy-cluster",
            track_id=representative.track_id,
        ))
        if len(self.history) > self.MAX_HISTORY:
            del self.history[:-self.MAX_HISTORY]
        self._last_event_at = now

    def _record_semantic_units(self, state: GameState, now: float) -> None:
        """Upgrade anonymous track events when a learned visual prototype resolves."""
        for unit in getattr(state, "semantic_enemy_units", ()):
            if unit.confidence < 0.68 or unit.track_id in self._seen_semantic_track_ids:
                continue
            self._seen_semantic_track_ids.add(unit.track_id)
            matched_index = next((index for index in range(len(self.history) - 1, -1, -1)
                                  if self.history[index].track_id == unit.track_id), None)
            if matched_index is None:
                # The initial generic event may have been merged with another
                # simultaneous spawn. Reuse only a very recent anonymous event
                # in the same lane; otherwise keep a separate play record.
                for index in range(len(self.history) - 1, max(-1, len(self.history) - 4), -1):
                    previous = self.history[index]
                    if (not previous.card_key and now - previous.timestamp <= 1.5
                            and previous.lane == (0 if unit.x < 0.5 else 1)):
                        matched_index = index
                        break
            if matched_index is not None:
                previous = self.history[matched_index]
                self.history[matched_index] = replace(
                    previous, card_key=unit.card_key, card_form=unit.form,
                    confidence=max(previous.confidence, unit.confidence),
                    source="cluster+semantic", track_id=unit.track_id,
                )
                continue
            token = f"opp_{self._next_token:04d}"
            self._next_token += 1
            self.history.append(OpponentPlay(
                token=token, card_key=unit.card_key, card_form=unit.form,
                confidence=unit.confidence, timestamp=now,
                lane=0 if unit.x < 0.5 else 1,
                strength=max(0.0, min(1.0, unit.area * 80.0 * unit.confidence)),
                source="semantic-visual", track_id=unit.track_id,
            ))
        if len(self.history) > self.MAX_HISTORY:
            del self.history[:-self.MAX_HISTORY]
        if len(self._seen_semantic_track_ids) > 1024:
            self._seen_semantic_track_ids = set(sorted(self._seen_semantic_track_ids)[-512:])

    def _snapshot(self) -> tuple[str, str, float, tuple[str, ...], tuple[str, ...], tuple[str, ...], bool]:
        # Clash Royale's hand contains four cards. After four verified plays,
        # the first played card is the next one to return to the hand; waiting
        # for five plays shifts the prediction by one card.
        if len(self.history) < 4:
            return "", "", 0.0, (), (), (), False
        window = self.history[-4:]
        returned = window[0]
        known = [item for item in window if item.card_key]
        base = min(item.confidence for item in window)
        known_ratio = len(known) / 4.0
        # Visual deployment detection misses some spells and can merge quick
        # plays. Keep anonymous-cycle confidence deliberately capped below 0.5.
        confidence = min(0.46, base * 0.62) if known_ratio < 1.0 else min(0.92, base * 0.96)
        if known_ratio >= 0.60:
            confidence = min(0.78, base * (0.65 + 0.30 * known_ratio))
        card_key = returned.card_key
        roles = self.card_database.roles_for(card_key) if card_key else ()
        recent = tuple(item.card_key or item.token for item in self.history[-8:])
        seen = tuple(dict.fromkeys(item.card_key for item in self.history if item.card_key))
        tokens = tuple(item.token for item in self.history[-8:])
        return card_key, returned.token, confidence, tuple(roles), recent, seen, True

    def observe(self, state: GameState, *, now: float | None = None) -> GameState:
        now = time.monotonic() if now is None else float(now)
        if state.scene is Scene.UNKNOWN:
            # A transient classifier miss used to erase the opponent's entire
            # four-card cycle. Keep the last verified sequence briefly while
            # the temporal tracker decays its generic blobs.
            if (self._last_battle_at is not None and
                    now - self._last_battle_at <= self.UNKNOWN_SCENE_GRACE_SECONDS):
                return self._with_snapshot(state)
            self.reset()
            return replace(
                state, opponent_cycle_card="", opponent_cycle_token="",
                opponent_cycle_confidence=0.0, opponent_cycle_roles=(),
                opponent_play_count=0, opponent_recent_plays=(),
                opponent_seen_cards=(), opponent_cycle_eta=None,
                opponent_cycle_complete=False,
            )
        if state.scene is not Scene.BATTLE or not state.battle_detected:
            self.reset()
            return replace(
                state, opponent_cycle_card="", opponent_cycle_token="",
                opponent_cycle_confidence=0.0, opponent_cycle_roles=(),
                opponent_play_count=0, opponent_recent_plays=(),
                opponent_seen_cards=(), opponent_cycle_eta=None,
                opponent_cycle_complete=False,
            )
        self._last_battle_at = now
        new_tracks = []
        for track in state.enemy_tracks:
            if not self._remember_track_id(track.track_id):
                continue
            if (track.observations <= 1 and track.confidence >= self.MIN_TRACK_CONFIDENCE
                    and 0.16 <= track.y <= 0.80):
                new_tracks.append(track)
        if new_tracks:
            self._record_event(state, new_tracks, now)
        self._record_semantic_units(state, now)
        card_key, token, confidence, roles, recent, seen, complete = self._snapshot()
        self._last_summary = {
            "plays": len(self.history), "known_cards": len(seen),
            "predicted_card": card_key, "predicted_token": token,
            "confidence": confidence, "complete": complete,
        }
        return replace(
            state,
            opponent_cycle_card=card_key,
            opponent_cycle_token=token,
            opponent_cycle_confidence=confidence,
            opponent_cycle_roles=roles,
            opponent_play_count=len(self.history),
            opponent_recent_plays=recent,
            opponent_seen_cards=seen,
            opponent_cycle_eta=0 if complete else None,
            opponent_cycle_complete=complete,
        )

    def summary(self) -> dict:
        return dict(self._last_summary)


class OpponentElixirTracker:
    """Conservative opponent-elixir interval from observed spend and regen.

    If the agent saw matchmaking immediately before battle, the initial
    interval is anchored at the normal five-elixir start. If it attaches in the
    middle of a match, the interval begins at [0, 10] instead of inventing an
    initial value. Unknown deployments consume a broad 1–9 elixir interval.
    """

    MAX_ELIXIR = 10.0
    NORMAL_REGEN_SECONDS = 2.8
    DOUBLE_ELIXIR_AT = 120.0
    MATCHMAKING_ANCHOR_SECONDS = 90.0
    UNKNOWN_SCENE_GRACE_SECONDS = 2.0

    def __init__(self, card_database: CardDatabase | None = None):
        self.card_database = card_database or CardDatabase()
        self._matchmaking_seen_at: float | None = None
        self._match_started_at: float | None = None
        self._last_battle_at: float | None = None
        self._anchored = False
        self._last_summary: dict[str, object] = {}

    def reset(self, *, preserve_matchmaking: bool = False) -> None:
        matchmaking_seen_at = self._matchmaking_seen_at if preserve_matchmaking else None
        self._matchmaking_seen_at = matchmaking_seen_at
        self._match_started_at = None
        self._last_battle_at = None
        self._anchored = False
        self._last_summary = {}

    def _regenerated(self, start: float, end: float) -> float:
        if self._match_started_at is None or end <= start:
            return 0.0
        boundary = self._match_started_at + self.DOUBLE_ELIXIR_AT
        normal_end = min(end, max(start, boundary))
        normal_seconds = max(0.0, normal_end - start)
        double_seconds = max(0.0, end - max(start, boundary))
        return (normal_seconds / self.NORMAL_REGEN_SECONDS +
                double_seconds / (self.NORMAL_REGEN_SECONDS / 2.0))

    def _card_cost_range(self, play: OpponentPlay) -> tuple[float, float] | None:
        if not play.card_key or play.confidence < 0.55:
            return None
        record = self.card_database.get(play.card_key)
        if record is None:
            return None
        if record.elixir_cost is not None:
            cost = float(record.elixir_cost)
            return (cost, cost)
        options = tuple(float(value) for value in (record.elixir_cost_options or ())
                        if isinstance(value, (int, float)) and 0.0 <= float(value) <= 10.0)
        if options:
            return min(options), max(options)
        return None

    def observe(self, state: GameState, plays, *, now: float | None = None) -> GameState:
        now = time.monotonic() if now is None else float(now)
        if state.scene is Scene.MATCHMAKING:
            self.reset()
            self._matchmaking_seen_at = now
            return replace(state, opponent_elixir_lower=0.0,
                           opponent_elixir_upper=self.MAX_ELIXIR,
                           opponent_elixir_confidence=0.0)
        if state.scene is Scene.UNKNOWN and self._last_battle_at is not None and \
                now - self._last_battle_at <= self.UNKNOWN_SCENE_GRACE_SECONDS:
            summary = self._last_summary
            return replace(
                state,
                opponent_elixir_lower=float(summary.get("lower", 0.0)),
                opponent_elixir_upper=float(summary.get("upper", self.MAX_ELIXIR)),
                opponent_elixir_confidence=max(0.0, float(summary.get("confidence", 0.0)) * 0.75),
            )
        matchmaking_recent = (
            self._matchmaking_seen_at is not None and
            0.0 <= now - self._matchmaking_seen_at <= self.MATCHMAKING_ANCHOR_SECONDS
        )
        if (state.scene in (Scene.LOADING, Scene.UNKNOWN) or
                (state.scene is Scene.BATTLE and not state.battle_detected)) and matchmaking_recent:
            # Keep the observed match-start anchor through the transition and
            # loading screen; the first confirmed battle frame starts regen.
            return replace(state, opponent_elixir_lower=0.0,
                           opponent_elixir_upper=self.MAX_ELIXIR,
                           opponent_elixir_confidence=0.0)
        if state.scene is not Scene.BATTLE or not state.battle_detected:
            self.reset()
            return replace(state, opponent_elixir_lower=0.0,
                           opponent_elixir_upper=self.MAX_ELIXIR,
                           opponent_elixir_confidence=0.0)

        if self._match_started_at is None:
            self._anchored = bool(
                self._matchmaking_seen_at is not None and
                0.0 <= now - self._matchmaking_seen_at <= self.MATCHMAKING_ANCHOR_SECONDS
            )
            self._match_started_at = now
        self._last_battle_at = now
        lower, upper = ((5.0, 5.0) if self._anchored else (0.0, self.MAX_ELIXIR))
        cursor = self._match_started_at
        known_plays = unknown_plays = 0
        inconsistent = False

        for play in sorted(tuple(plays or ()), key=lambda item: float(item.timestamp)):
            timestamp = max(cursor, min(now, float(play.timestamp)))
            regen = self._regenerated(cursor, timestamp)
            lower = min(self.MAX_ELIXIR, lower + regen)
            upper = min(self.MAX_ELIXIR, upper + regen)
            cursor = timestamp
            cost_range = self._card_cost_range(play)
            if cost_range is None:
                # The visual deployment is real enough to be a spend event,
                # but its card/cost is unknown. Keep the resulting interval wide.
                before_lower = max(lower, 1.0)
                before_upper = max(upper, before_lower)
                lower = max(0.0, before_lower - 9.0)
                upper = max(0.0, before_upper - 1.0)
                unknown_plays += 1
                continue

            cost_min, cost_max = cost_range
            if upper + 0.25 < cost_min:
                # Missed earlier plays or a late attach can invalidate a tight
                # estimate. Widen rather than force an impossible exact value.
                lower, upper = 0.0, self.MAX_ELIXIR
                inconsistent = True
                before_lower = max(lower, cost_min)
                before_upper = max(upper, before_lower)
            else:
                before_lower = max(lower, cost_min)
                before_upper = max(upper, before_lower)
            lower = max(0.0, before_lower - cost_max)
            upper = max(0.0, before_upper - cost_min)
            known_plays += 1

        regen = self._regenerated(cursor, now)
        lower = min(self.MAX_ELIXIR, lower + regen)
        upper = min(self.MAX_ELIXIR, upper + regen)
        upper = max(lower, upper)
        width = max(0.0, upper - lower)
        total_plays = known_plays + unknown_plays
        known_ratio = known_plays / max(1, total_plays)
        sample_factor = min(1.0, total_plays / 4.0)
        precision = 1.0 - min(1.0, width / self.MAX_ELIXIR)
        confidence = (0.20 if self._anchored else 0.05)
        confidence += 0.38 * known_ratio + 0.18 * sample_factor + 0.14 * precision
        confidence = min(0.85, max(0.0, confidence))
        if not self._anchored:
            confidence = min(0.49, confidence)
        if inconsistent:
            confidence = min(0.30, confidence)

        self._last_summary = {
            "lower": round(lower, 2), "upper": round(upper, 2),
            "confidence": round(confidence, 3), "known_plays": known_plays,
            "unknown_plays": unknown_plays, "match_start_anchored": self._anchored,
            "inconsistent_observation": inconsistent,
        }
        return replace(
            state,
            opponent_elixir_lower=round(lower, 2),
            opponent_elixir_upper=round(upper, 2),
            opponent_elixir_confidence=round(confidence, 3),
        )

    def summary(self) -> dict[str, object]:
        return dict(self._last_summary)


@dataclass(frozen=True)
class _MetaDeck:
    rank: int
    name: str
    usage: float
    slugs: tuple[str, ...]
    keys: tuple[str, ...]


class OpponentDeckInferencer:
    """Open-world eight-card hypotheses from local evidence and card metadata.

    No third-party meta-deck snapshot is bundled. When no locally learned full
    deck is available, deterministic role/curve-balanced seed decks provide a
    deliberately weak structural prior. Directly observed cards always remain
    in every candidate, and heuristic-only confidence is tightly capped.
    """

    MAX_LEARNED_DECKS = 128
    MAX_LEARNING_BYTES = 300_000
    OPEN_WORLD_LIMIT = 128

    def __init__(self, card_database: CardDatabase | None = None, path=None,
                 learning_path=None):
        from pathlib import Path
        self.card_database = card_database or CardDatabase()
        self.path = Path(path) if path is not None else (
            Path(__file__).resolve().parents[1] / "data" / "meta_decks.tsv"
        )
        self.learning_path = Path(learning_path) if learning_path is not None else None
        self.meta_decks: list[_MetaDeck] = []
        self.learned_decks: dict[tuple[str, ...], int] = {}
        self.observed: dict[str, tuple[str, float, str]] = {}
        self._processed_tokens: set[str] = set()
        self._episode_complete_signature: tuple[str, ...] | None = None
        self._last_ranked_signature = None
        self._cached_ranked: list[tuple[tuple[str, ...], float, str]] = []
        self._rank_details: dict[str, object] = {}
        self._last_summary: dict = {}
        self._fallback_seed_cache: list[tuple[tuple[str, ...], float]] | None = None
        self._load()
        self._load_learning()

    @staticmethod
    def _split_slug(slug: str) -> tuple[str, str]:
        value = str(slug or "").strip().lower()
        for suffix, form in (("-ev1", "evolution"), ("-hero", "hero"),
                             ("-champion", "champion")):
            if value.endswith(suffix):
                return value[:-len(suffix)], form
        return value, "base"

    def _load(self) -> None:
        try:
            lines = self.path.read_text(encoding="utf-8-sig").splitlines()
            decks = []
            for line in lines:
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                parts = line.split("|")
                if len(parts) != 4:
                    continue
                rank, name, usage, cards = parts
                slugs = tuple(item.strip() for item in cards.split(",") if item.strip())
                keys = tuple(self._split_slug(item)[0] for item in slugs)
                try:
                    rank_value, usage_value = int(rank), float(usage)
                except (ValueError, TypeError):
                    continue
                if (len(keys) != 8 or len(set(keys)) != 8 or
                        not all(self.card_database.get(k) for k in keys) or
                        not math.isfinite(usage_value) or usage_value <= 0):
                    continue
                decks.append(_MetaDeck(rank_value, name[:96], max(0.00001, usage_value), slugs, keys))
            self.meta_decks = decks[:100]
        except (OSError, UnicodeError):
            self.meta_decks = []

    def _load_learning(self) -> None:
        if self.learning_path is None:
            return
        try:
            if self.learning_path.stat().st_size > self.MAX_LEARNING_BYTES:
                return
            raw = json.loads(self.learning_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, UnicodeError, ValueError, TypeError):
            return
        if not isinstance(raw, dict) or raw.get("version") != 1:
            return
        decks = raw.get("decks")
        if not isinstance(decks, list) or len(decks) > self.MAX_LEARNED_DECKS:
            return
        loaded = {}
        for item in decks:
            if not isinstance(item, dict):
                continue
            cards = item.get("cards")
            count = item.get("count")
            if (not isinstance(cards, list) or len(cards) != 8 or
                    not all(isinstance(key, str) and self.card_database.get(key) for key in cards) or
                    len(set(cards)) != 8 or not isinstance(count, int) or
                    isinstance(count, bool) or not 1 <= count <= 100_000):
                continue
            loaded[tuple(sorted(cards))] = count
        self.learned_decks = loaded

    def _save_learning(self) -> bool:
        if self.learning_path is None:
            return False
        try:
            self.learning_path.parent.mkdir(parents=True, exist_ok=True)
            items = [
                {"cards": list(cards), "count": count}
                for cards, count in sorted(
                    self.learned_decks.items(), key=lambda item: item[1], reverse=True
                )[:self.MAX_LEARNED_DECKS]
            ]
            encoded = json.dumps({"version": 1, "decks": items},
                                 ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            if len(encoded) > self.MAX_LEARNING_BYTES:
                return False
            temporary = self.learning_path.with_suffix(self.learning_path.suffix + ".tmp")
            with temporary.open("wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.learning_path)
            return True
        except (OSError, ValueError, TypeError):
            return False

    def reset(self) -> None:
        self.observed.clear()
        self._processed_tokens.clear()
        self._episode_complete_signature = None
        self._last_ranked_signature = None
        self._cached_ranked = []
        self._rank_details = {}
        self._last_summary = {}

    def _observe(self, card_key: str, form: str, confidence: float, source: str) -> None:
        record = self.card_database.get(card_key)
        if record is None or confidence < 0.64:
            return
        if record.card_type.casefold() not in ("troop", "spell", "building"):
            return
        previous = self.observed.get(card_key)
        if previous is None or confidence > previous[1]:
            self.observed[card_key] = (form, max(0.0, min(1.0, confidence)), source)
            self._last_ranked_signature = None

    def _record_complete_deck(self) -> None:
        if (len(self.observed) != 8 or
                min(value[1] for value in self.observed.values()) < 0.82):
            return
        signature = tuple(sorted(self.observed))
        if signature == self._episode_complete_signature:
            return
        self._episode_complete_signature = signature
        self.learned_decks[signature] = min(100_000, self.learned_decks.get(signature, 0) + 1)
        if len(self.learned_decks) > self.MAX_LEARNED_DECKS:
            self.learned_decks = dict(sorted(
                self.learned_decks.items(), key=lambda item: item[1], reverse=True
            )[:self.MAX_LEARNED_DECKS])
        self._save_learning()
        self._last_ranked_signature = None

    def _role_importance(self, key: str, deck_keys: tuple[str, ...]) -> float:
        roles = set(self.card_database.roles_for(key))
        deck_roles = [set(self.card_database.roles_for(item)) for item in deck_keys]
        importance = 0.0
        if "win_condition" in roles and sum("win_condition" in r for r in deck_roles) <= 1:
            importance += 5.0
        if "spell" in roles and sum("spell" in r for r in deck_roles) <= 1:
            importance += 2.2
        if "air_defense" in roles and sum("air_defense" in r for r in deck_roles) <= 1:
            importance += 1.5
        if "building" in roles and sum("building" in r for r in deck_roles) <= 1:
            importance += 1.2
        return importance

    def _complete_deck(self, deck: _MetaDeck, observed_keys: tuple[str, ...]) -> tuple[tuple[str, ...], int, float]:
        cards = list(deck.keys)
        replacements = 0
        for key in observed_keys:
            if key in cards:
                continue
            removable = [item for item in cards if item not in observed_keys]
            if not removable:
                continue
            removable.sort(key=lambda item: (
                self._role_importance(item, tuple(cards)),
                len(self.card_database.roles_for(item)),
                -float(self.card_database.get(item).elixir_cost or 0),
            ))
            removed = removable[0]
            cards[cards.index(removed)] = key
            replacements += 1
        score = math.log(deck.usage + 0.0001) + 1.45 * (len(observed_keys) - replacements) - 0.85 * replacements
        costs = [self._card_cost(key) for key in cards]
        costs = [value for value in costs if value is not None]
        if costs:
            average = sum(costs) / len(costs)
            score -= abs(average - 3.6) * 0.16
        if len(set(cards)) != 8:
            score -= 8.0
        return tuple(cards), replacements, score

    def _card_cost(self, key: str) -> float | None:
        record = self.card_database.get(key)
        if record is None:
            return None
        if record.elixir_cost is not None:
            return float(record.elixir_cost)
        if record.elixir_cost_options:
            return sum(record.elixir_cost_options) / len(record.elixir_cost_options)
        return None

    def _fallback_seed_decks(self) -> list[tuple[tuple[str, ...], float]]:
        """Create deterministic, explicitly non-meta seed decks from local roles.

        This is a structural completion aid, not a claim about popular or
        competitive decks. The generated pool is bounded and contains one
        principal win condition per seed where the local role table identifies
        one. Cost and role balance are soft preferences only.
        """
        if self._fallback_seed_cache is not None:
            return list(self._fallback_seed_cache)
        pool = [
            record.key for record in self.card_database.cards
            if record.card_type.casefold() in ("troop", "spell", "building")
        ]
        if len(pool) < 8:
            self._fallback_seed_cache = []
            return []
        pool_order = {key: index for index, key in enumerate(pool)}
        role_map = {key: set(self.card_database.roles_for(key)) for key in pool}
        win_conditions = [key for key in pool if "win_condition" in role_map[key]]
        if not win_conditions:
            win_conditions = pool
        seeds: dict[tuple[str, ...], float] = {}
        for win_condition in win_conditions:
            deck = [win_condition]
            while len(deck) < 8:
                current_roles = [role_map[key] for key in deck]
                role_counts = {
                    role: sum(role in roles for roles in current_roles)
                    for role in ("spell", "air_defense", "tank_killer", "building", "support")
                }
                current_costs = [self._card_cost(key) for key in deck]
                current_costs = [value for value in current_costs if value is not None]
                current_total = sum(current_costs)
                best_key = ""
                best_score = -1e30
                for key in pool:
                    if key in deck:
                        continue
                    roles = role_map[key]
                    cost = self._card_cost(key)
                    score = 0.0
                    if "air_defense" in roles and role_counts["air_defense"] == 0:
                        score += 2.0
                    if "tank_killer" in roles and role_counts["tank_killer"] == 0:
                        score += 1.65
                    if "spell" in roles and role_counts["spell"] < 2:
                        score += 1.25 if role_counts["spell"] == 0 else 0.45
                    if "building" in roles and role_counts["building"] == 0:
                        score += 0.55
                    if "support" in roles and role_counts["support"] < 2:
                        score += 0.55
                    score += 0.10 * sum(1 for role in roles
                                        if role in ("air_defense", "tank_killer", "support", "ranged"))
                    if cost is not None:
                        projected_average = (current_total + cost) / (len(current_costs) + 1)
                        score -= abs(projected_average - 3.6) * 0.30
                    else:
                        score -= 0.18
                    # Stable tie-breaks keep the result reproducible across runs.
                    score -= pool_order[key] * 1e-7
                    if score > best_score:
                        best_score, best_key = score, key
                if not best_key:
                    break
                deck.append(best_key)
            if len(deck) != 8:
                continue
            candidate = tuple(sorted(deck))
            costs = [self._card_cost(key) for key in candidate]
            costs = [value for value in costs if value is not None]
            average = sum(costs) / len(costs) if costs else 4.0
            score = self._partial_score(candidate, {}, {}) - abs(average - 3.6) * 0.12
            seeds[candidate] = max(score, seeds.get(candidate, -1e30))
        ranked = sorted(seeds.items(), key=lambda item: (item[1], item[0]), reverse=True)
        self._fallback_seed_cache = ranked[:32]
        return list(self._fallback_seed_cache)

    def _prior_tables(self):
        frequency: dict[str, float] = {}
        pairs: dict[tuple[str, str], float] = {}
        for deck in self.meta_decks:
            weight = max(0.05, float(deck.usage) * 100.0)
            for key in deck.keys:
                frequency[key] = frequency.get(key, 0.0) + weight
            for index, left in enumerate(deck.keys):
                for right in deck.keys[index + 1:]:
                    pair = tuple(sorted((left, right)))
                    pairs[pair] = pairs.get(pair, 0.0) + weight
        for deck, count in self.learned_decks.items():
            weight = min(8.0, 0.75 + math.log1p(count))
            for key in deck:
                frequency[key] = frequency.get(key, 0.0) + weight
            for index, left in enumerate(deck):
                for right in deck[index + 1:]:
                    pair = tuple(sorted((left, right)))
                    pairs[pair] = pairs.get(pair, 0.0) + weight
        return frequency, pairs

    def _partial_score(self, keys: tuple[str, ...], frequency, pairs) -> float:
        roles = [set(self.card_database.roles_for(key)) for key in keys]
        costs = [self._card_cost(key) for key in keys]
        known_costs = [cost for cost in costs if cost is not None]
        score = sum(math.log(0.25 + frequency.get(key, 0.0)) * 0.075 for key in keys)
        for index, left in enumerate(keys):
            for right in keys[index + 1:]:
                pair = tuple(sorted((left, right)))
                co = pairs.get(pair, 0.0)
                left_f = frequency.get(left, 0.0)
                right_f = frequency.get(right, 0.0)
                # Smoothed pointwise association: observed pair synergy helps,
                # but a missing pair is not treated as an impossible deck.
                association = math.log((co + 0.18) / (0.18 + 0.012 * left_f * right_f))
                score += max(-1.2, min(1.2, association)) * 0.045
        win_conditions = sum("win_condition" in item for item in roles)
        spells = sum("spell" in item for item in roles)
        air_defense = sum("air_defense" in item for item in roles)
        tank_killers = sum("tank_killer" in item for item in roles)
        buildings = sum("building" in item for item in roles)
        if len(keys) >= 6 and win_conditions == 0:
            score -= 0.52
        if win_conditions > 2:
            score -= 0.28 * (win_conditions - 2)
        if spells > 3:
            score -= 0.24 * (spells - 3)
        if len(keys) >= 7 and spells == 0:
            score -= 0.30
        if len(keys) >= 7 and air_defense == 0:
            score -= 0.26
        if len(keys) >= 7 and tank_killers == 0:
            score -= 0.16
        if buildings > 2:
            score -= 0.16 * (buildings - 2)
        if known_costs:
            average = sum(known_costs) / len(known_costs)
            if average > 4.8:
                score -= (average - 4.8) * 0.35
            elif average < 2.4 and len(keys) >= 6:
                score -= (2.4 - average) * 0.25
        return score

    def _open_world_candidates(self, observed_keys: tuple[str, ...],
                               frequency, pairs,
                               base_decks: list[tuple[tuple[str, ...], float]]) -> list[tuple[tuple[str, ...], float]]:
        """Mutate several strong seed decks across the full card vocabulary.

        This deliberately avoids a combinatorial 8-card search in the live
        perception loop. Every playable catalog card is considered as a
        replacement anchor, while a few paired mutations cover decks that
        diverge from the public snapshot in more than one slot.
        """
        pool = tuple(
            record.key for record in self.card_database.cards
            if record.card_type.casefold() in ("troop", "spell", "building")
        )
        if len(observed_keys) > 8:
            observed_keys = observed_keys[:8]
        if not observed_keys or not all(key in pool for key in observed_keys):
            return []
        if not base_decks:
            return []
        role_map = {key: set(self.card_database.roles_for(key)) for key in pool}
        generated: dict[tuple[str, ...], float] = {}
        seeds = sorted(base_decks, key=lambda item: item[1], reverse=True)[:3]

        for base_deck, base_score in seeds:
            removable = [key for key in base_deck if key not in observed_keys]
            removable.sort(key=lambda key: (
                self._role_importance(key, base_deck),
                len(role_map.get(key, ())),
                -float(self._card_cost(key) or 0.0),
            ))
            if not removable:
                continue
            weakest = removable[0]
            second_weakest = removable[1] if len(removable) > 1 else None
            for anchor in pool:
                if anchor in base_deck:
                    continue
                deck = tuple(sorted((set(base_deck) - {weakest}) | {anchor}))
                if len(deck) != 8 or not set(observed_keys).issubset(deck):
                    continue
                structure = self._partial_score(deck, frequency, pairs)
                anchor_frequency = frequency.get(anchor, 0.0)
                base_frequency = frequency.get(weakest, 0.0)
                novelty_adjustment = 0.035 * math.log1p(anchor_frequency) - 0.025 * math.log1p(base_frequency)
                score = base_score - 0.52 + 0.055 * structure + novelty_adjustment
                generated[deck] = max(score, generated.get(deck, -1e30))

            # Deterministic two-card mutations expand beyond a single missing
            # slot without enumerating every possible pair in the 123-card pool.
            if second_weakest is not None:
                anchors = [key for key in pool if key not in base_deck]
                anchors.sort(key=lambda key: (frequency.get(key, 0.0), key), reverse=True)
                for offset in range(0, min(48, len(anchors) - 1), 3):
                    first, second = anchors[offset], anchors[offset + 1]
                    if first == second:
                        continue
                    deck = tuple(sorted((set(base_deck) - {weakest, second_weakest}) | {first, second}))
                    if len(deck) != 8 or not set(observed_keys).issubset(deck):
                        continue
                    structure = self._partial_score(deck, frequency, pairs)
                    score = base_score - 0.98 + 0.045 * structure
                    generated[deck] = max(score, generated.get(deck, -1e30))

        completed = sorted(generated.items(), key=lambda item: item[1], reverse=True)
        return completed[:self.OPEN_WORLD_LIMIT]

    def _rank(self) -> list[tuple[tuple[str, ...], float, str]]:
        observed_items = sorted(self.observed.items(), key=lambda item: item[1][1], reverse=True)
        observed_keys = tuple(key for key, _value in observed_items[:8])
        signature = (
            tuple((key, round(value[1], 2)) for key, value in observed_items[:8]),
            tuple(sorted(self.learned_decks.items())),
        )
        if signature == self._last_ranked_signature:
            return list(self._cached_ranked)
        self._last_ranked_signature = signature
        if not observed_keys:
            self._cached_ranked = []
            self._rank_details = {"generated_hypotheses": 0, "candidate_pool": 0}
            return []

        candidates: dict[tuple[str, ...], tuple[float, str]] = {}
        seed_scores: list[tuple[tuple[str, ...], float]] = []
        for deck in self.meta_decks:
            cards, _replacements, score = self._complete_deck(deck, observed_keys)
            seed_scores.append((cards, score))
            previous = candidates.get(cards)
            if previous is None or score > previous[0]:
                candidates[cards] = (score, f"meta:{deck.name}")

        if not self.meta_decks:
            for index, (seed_keys, seed_score) in enumerate(self._fallback_seed_decks()):
                seed = _MetaDeck(index + 1, "local-role-heuristic", 0.01,
                                 tuple(seed_keys), tuple(seed_keys))
                completed, _replacements, score = self._complete_deck(seed, observed_keys)
                if len(completed) != 8 or len(set(completed)) != 8:
                    continue
                score += seed_score * 0.08
                seed_scores.append((completed, score))
                previous = candidates.get(completed)
                if previous is None or score > previous[0]:
                    candidates[completed] = (score, "local-role-heuristic")

        for deck, count in self.learned_decks.items():
            if not set(observed_keys).issubset(deck):
                continue
            score = -5.2 + 0.45 * len(observed_keys) + 0.22 * math.log1p(count)
            previous = candidates.get(deck)
            if previous is None or score > previous[0]:
                candidates[deck] = (score, "learned-local")
            seed_scores.append((deck, score))

        open_world = []
        exact_observation = (len(self.observed) == 8 and
                             min(value[1] for value in self.observed.values()) >= 0.82)
        if not exact_observation:
            frequency, pairs = self._prior_tables()
            open_world = self._open_world_candidates(observed_keys, frequency, pairs, seed_scores)
            for deck, score in open_world:
                previous = candidates.get(deck)
                if previous is None or score > previous[0]:
                    candidates[deck] = (score, "open-world")
        else:
            exact = tuple(observed_keys)
            candidates = {exact: (100.0, "observed-exact-eight")}
        if not candidates:
            self._cached_ranked = []
            self._rank_details = {"generated_hypotheses": len(open_world),
                                  "candidate_pool": 0, "card_pool": 0}
            return []
        maximum = max(value[0] for value in candidates.values())
        weights = {cards: math.exp(max(-40.0, score - maximum))
                   for cards, (score, _name) in candidates.items()}
        total = sum(weights.values()) or 1.0
        ranked = [(cards, weights[cards] / total, name)
                  for cards, (score, name) in candidates.items()]
        ranked.sort(key=lambda item: item[1], reverse=True)
        self._cached_ranked = ranked[:8]
        self._rank_details = {
            "generated_hypotheses": len(open_world),
            "candidate_pool": len(candidates),
            "card_pool": sum(1 for record in self.card_database.cards
                             if record.card_type.casefold() in ("troop", "spell", "building")),
            "sources": {
                "meta": sum(1 for _cards, _p, name in self._cached_ranked if name.startswith("meta:")),
                "learned": sum(1 for _cards, _p, name in self._cached_ranked if name == "learned-local"),
                "open_world": sum(1 for _cards, _p, name in self._cached_ranked if name == "open-world"),
            },
        }
        return list(self._cached_ranked)

    def observe(self, state: GameState, plays=()) -> GameState:
        if state.scene is not Scene.BATTLE or not state.battle_detected:
            self.reset()
            return replace(state, opponent_deck_top=(), opponent_deck_confirmed=(),
                           opponent_deck_confidence=0.0, opponent_deck_unknown_slots=8,
                           opponent_deck_complete=False, opponent_deck_candidates=(),
                           opponent_deck_candidate_confidences=())
        for play in plays:
            if play.token in self._processed_tokens or not play.card_key:
                continue
            self._processed_tokens.add(play.token)
            self._observe(play.card_key, getattr(play, "card_form", "base"),
                          play.confidence, play.source)
        if len(self._processed_tokens) > 2048:
            self._processed_tokens = set(sorted(self._processed_tokens)[-1024:])
        for item in state.recognized_cards:
            if item.confidence >= 0.92 and item.bounds is not None:
                _x0, y0, _x1, _y1 = item.bounds
                if y0 / max(1, state.frame_height) < 0.45:
                    self._observe(item.card_key, item.form, item.confidence, "opponent-half-ocr")
        self._record_complete_deck()
        ranked = self._rank()
        confirmed = tuple(key for key, _value in sorted(
            self.observed.items(), key=lambda item: item[1][1], reverse=True
        ))[:8]
        if ranked:
            top_cards, top_posterior, top_source = ranked[0]
            avg_evidence = (sum(value[1] for value in self.observed.values()) /
                            max(1, len(self.observed)))
            coverage = min(1.0, len(confirmed) / 8.0)
            margin = (top_posterior - ranked[1][1]) if len(ranked) > 1 else top_posterior
            # Evidence coverage, not candidate count, governs certainty. The
            # open-world prior is intentionally low-confidence until more cards
            # are directly observed.
            confidence = avg_evidence * (0.10 + 0.76 * coverage) * (0.58 + 0.42 * self._clamp(margin * 4.0))
            confidence = min(0.82, confidence)
            if not self.meta_decks:
                # Structural heuristics are not empirical deck-frequency data.
                # Keep their confidence low until complete decks are learned.
                confidence = min(confidence, 0.24 if not self.learned_decks else 0.48)
            if (len(self.observed) == 8 and
                    min(value[1] for value in self.observed.values()) >= 0.82):
                top_cards = confirmed
                confidence = avg_evidence
                top_source = "observed-exact-eight"
        else:
            top_cards, confidence, top_source = (), 0.0, "none"
        candidate_cards = tuple(item[0] for item in ranked[:8])
        candidate_confidences = tuple(float(item[1]) for item in ranked[:8])
        self._last_summary = {
            "confirmed": len(confirmed),
            "unknown_slots": max(0, 8 - len(confirmed)),
            "confidence": max(0.0, min(1.0, confidence)),
            "candidate_count": int(self._rank_details.get("candidate_pool", len(ranked))),
            "ranked_candidates": len(ranked),
            "top_deck": top_cards,
            "top_source": top_source,
            "meta_priors": len(self.meta_decks),
            "seed_source": ("licensed-meta-prior" if self.meta_decks else
                            "local-role-heuristic" if ranked else "none"),
            "learned_complete_decks": len(self.learned_decks),
            **self._rank_details,
        }
        return replace(
            state,
            opponent_deck_top=tuple(top_cards),
            opponent_deck_confirmed=confirmed,
            opponent_deck_confidence=max(0.0, min(1.0, confidence)),
            opponent_deck_unknown_slots=max(0, 8 - len(confirmed)),
            opponent_deck_complete=(len(self.observed) == 8 and
                                    min((value[1] for value in self.observed.values()), default=0.0) >= 0.82),
            opponent_deck_candidates=candidate_cards,
            opponent_deck_candidate_confidences=candidate_confidences,
        )

    @staticmethod
    def _clamp(value: float) -> float:
        if not math.isfinite(float(value)):
            return 0.0
        return max(0.0, min(1.0, float(value)))

    def summary(self) -> dict:
        return dict(self._last_summary)
