"""Observed-play four-card-cycle bookkeeping for the opponent.

Enemy unit detections are generic red/blue visual tracks, not card identities.
The tracker therefore records anonymous deployment events unless a card name is
actually read from the frame. It predicts the return slot only from the observed
play order and exposes confidence so the policy cannot mistake a guess for fact.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import time

from .cards import CardDatabase
from .vision import GameState, Scene


@dataclass(frozen=True)
class OpponentPlay:
    token: str
    card_key: str
    confidence: float
    timestamp: float
    lane: int
    strength: float
    source: str


class OpponentCycleTracker:
    """Track newly observed opponent deployments and the four-card return queue."""

    MAX_HISTORY = 64
    EVENT_MERGE_SECONDS = 0.55
    MIN_TRACK_CONFIDENCE = 0.30

    def __init__(self, card_database: CardDatabase | None = None):
        self.card_database = card_database or CardDatabase()
        self.history: list[OpponentPlay] = []
        self._seen_track_ids: set[int] = set()
        self._next_token = 1
        self._last_event_at = -1e9
        self._last_battle = False
        self._last_summary: dict = {}

    def reset(self) -> None:
        self.history.clear()
        self._seen_track_ids.clear()
        self._next_token = 1
        self._last_event_at = -1e9
        self._last_battle = False
        self._last_summary = {}

    def _card_key_near_track(self, state: GameState, x: float, y: float) -> str:
        frame_width = max(1, state.frame_width)
        frame_height = max(1, state.frame_height)
        candidates = []
        for item in state.recognized_cards:
            if item.confidence < 0.88 or item.bounds is None:
                continue
            x0, y0, x1, y1 = item.bounds
            cx = (x0 + x1) / (2.0 * frame_width)
            cy = (y0 + y1) / (2.0 * frame_height)
            # The opponent's half is above the arena midline. A name read in
            # the player's hand/deck is never attached to an enemy deployment.
            if cy > 0.48:
                continue
            distance = ((cx - x) ** 2 + (cy - y) ** 2) ** 0.5
            if distance <= 0.28:
                candidates.append((distance, item))
        if not candidates:
            return ""
        candidates.sort(key=lambda pair: pair[0])
        return candidates[0][1].card_key

    def _record_event(self, state: GameState, tracks, now: float) -> None:
        representative = max(
            tracks, key=lambda item: item.area * item.confidence, default=None
        )
        if representative is None:
            return
        strength = max(0.0, min(1.0, representative.area * 80.0 * representative.confidence))
        confidence = max(0.0, min(0.82,
            0.30 + representative.confidence * 0.40 + min(0.12, len(tracks) * 0.025)
        ))
        card_key = self._card_key_near_track(state, representative.x, representative.y)
        if card_key:
            # A high-confidence OCR name is stronger evidence than a generic
            # deployment blob; only named five-play windows can drive counters.
            confidence = max(confidence, 0.88)
        if now - self._last_event_at <= self.EVENT_MERGE_SECONDS and self.history:
            previous = self.history[-1]
            # Several blobs born in the same short deployment window are one
            # play (e.g. Skeleton Army), not several cards in the cycle.
            self.history[-1] = replace(
                previous,
                confidence=max(previous.confidence, confidence),
                strength=max(previous.strength, strength),
                card_key=previous.card_key or card_key,
                source="cluster+ocr" if card_key else previous.source,
            )
            self._last_event_at = now
            return
        token = f"opp_{self._next_token:04d}"
        self._next_token += 1
        lane = 0 if representative.x < 0.5 else 1
        self.history.append(OpponentPlay(
            token=token, card_key=card_key, confidence=confidence,
            timestamp=now, lane=lane, strength=strength,
            source="cluster+ocr" if card_key else "enemy-cluster",
        ))
        if len(self.history) > self.MAX_HISTORY:
            del self.history[:-self.MAX_HISTORY]
        self._last_event_at = now

    def _snapshot(self) -> tuple[str, str, float, tuple[str, ...], tuple[str, ...], tuple[str, ...], bool]:
        if len(self.history) < 5:
            return "", "", 0.0, (), (), (), False
        window = self.history[-5:]
        returned = window[0]
        known = [item for item in window if item.card_key]
        base = min(item.confidence for item in window)
        known_ratio = len(known) / 5.0
        # Visual deployment detection misses some spells and can merge quick
        # plays. Keep anonymous-cycle confidence deliberately capped below 0.5.
        confidence = min(0.46, base * 0.62) if known_ratio < 1.0 else min(0.92, base * 0.96)
        if known_ratio >= 0.60:
            confidence = min(0.78, base * (0.65 + 0.30 * known_ratio))
        card_key = returned.card_key
        roles = self.card_database.roles_for(card_key) if card_key else ()
        recent = tuple(item.card_key or item.token for item in self.history[-8:])
        seen = tuple(dict.fromkeys(item.card_key for item in self.history if item.card_key))
        tokens = tuple(item.token for item in self.history[-8:])
        return card_key, returned.token, confidence, tuple(roles), recent, seen, True

    def observe(self, state: GameState, *, now: float | None = None) -> GameState:
        now = time.monotonic() if now is None else float(now)
        if state.scene not in (Scene.BATTLE, Scene.UNKNOWN) or not state.battle_detected:
            self.reset()
            return replace(
                state, opponent_cycle_card="", opponent_cycle_token="",
                opponent_cycle_confidence=0.0, opponent_cycle_roles=(),
                opponent_play_count=0, opponent_recent_plays=(),
                opponent_seen_cards=(), opponent_cycle_eta=None,
                opponent_cycle_complete=False,
            )
        self._last_battle = True
        new_tracks = []
        for track in state.enemy_tracks:
            if track.track_id in self._seen_track_ids:
                continue
            self._seen_track_ids.add(track.track_id)
            if (track.observations <= 1 and track.confidence >= self.MIN_TRACK_CONFIDENCE
                    and 0.16 <= track.y <= 0.80):
                new_tracks.append(track)
        if new_tracks:
            self._record_event(state, new_tracks, now)
        card_key, token, confidence, roles, recent, seen, complete = self._snapshot()
        self._last_summary = {
            "plays": len(self.history), "known_cards": len(seen),
            "predicted_card": card_key, "predicted_token": token,
            "confidence": confidence, "complete": complete,
        }
        return replace(
            state,
            opponent_cycle_card=card_key,
            opponent_cycle_token=token,
            opponent_cycle_confidence=confidence,
            opponent_cycle_roles=roles,
            opponent_play_count=len(self.history),
            opponent_recent_plays=recent,
            opponent_seen_cards=seen,
            opponent_cycle_eta=0 if complete else None,
            opponent_cycle_complete=complete,
        )

    def summary(self) -> dict:
        return dict(self._last_summary)
