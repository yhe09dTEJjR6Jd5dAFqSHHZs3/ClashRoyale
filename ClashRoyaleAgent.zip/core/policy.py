"""Local, model-free contextual policy with bounded self-learning.

No remote inference, downloaded model, or third-party pretrained weights are
used.  The learner operates on visual/card features and only receives terminal
match labels when the perception layer can support them.
"""
from __future__ import annotations

import json
import math
import os
import time
from pathlib import Path
from typing import Iterable

from .tracking import TemporalBattleTracker
from .tactics import assess_lane, tactical_adjustment
from .planner import plan_deployment
from .tactical_search import SearchAction
from .vision import GameState


ROLE_FEATURES = (
    "win_condition", "spell", "air_defense", "building", "tank_killer",
    "swarm", "support", "cycle", "tank", "ranged", "melee",
)
LEGACY_V7_FEATURES = 18 + len(ROLE_FEATURES)
FINGERPRINT_BITS = 64
FEATURES = LEGACY_V7_FEATURES + FINGERPRINT_BITS
# The hand slot is not a stable card identity: the four-card hand rotates after
# every deployment.  Keep one shared contextual model per lane and let the
# verified card-role and 64-bit visual-identity features distinguish cards.
# This allows experience to follow a card when it moves to another hand slot.
ARMS = 2  # shared left/right lane policies
LEGACY_ARMS = 8  # v2-v8 models used four hand slots x two lanes
MODEL_VERSION = 9
LEGACY_FEATURES = 9
LEGACY_V5_FEATURES = 15
LEGACY_V6_FEATURES = 18
REPLAY_LIMIT = 256
MAX_MODEL_BYTES = 4_000_000


def _finite_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _solve(matrix: list[list[float]], vector: list[float]) -> list[float]:
    """Small Gaussian elimination with pivoting and bounded regularization."""
    n = len(vector)
    a = [matrix[i][:] + [vector[i]] for i in range(n)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(a[row][col]))
        if abs(a[pivot][col]) < 1e-9:
            a[pivot][col] = 1e-8
        if pivot != col:
            a[col], a[pivot] = a[pivot], a[col]
        scale = a[col][col]
        if abs(scale) < 1e-9:
            scale = 1e-8
        for j in range(col, n + 1):
            a[col][j] /= scale
        for row in range(n):
            if row == col:
                continue
            factor = a[row][col]
            for j in range(col, n + 1):
                a[row][j] -= factor * a[col][j]
    result = [a[i][n] for i in range(n)]
    return [v if math.isfinite(v) else 0.0 for v in result]


def _invert(matrix: list[list[float]]) -> list[list[float]]:
    """Invert one small SPD action matrix for reuse across many decisions."""
    n = len(matrix)
    augmented = [matrix[row][:] + [1.0 if row == col else 0.0 for col in range(n)]
                 for row in range(n)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        if abs(augmented[pivot][col]) < 1e-9:
            # The regularized identity is a safe fallback for a damaged cache;
            # persisted matrices are independently Cholesky-validated.
            return _matrix_identity(n)
        if pivot != col:
            augmented[col], augmented[pivot] = augmented[pivot], augmented[col]
        scale = augmented[col][col]
        for j in range(col, n * 2):
            augmented[col][j] /= scale
        for row in range(n):
            if row == col:
                continue
            factor = augmented[row][col]
            if factor == 0.0:
                continue
            for j in range(col, n * 2):
                augmented[row][j] -= factor * augmented[col][j]
    return [row[n:] for row in augmented]


def _matvec(matrix: list[list[float]], vector: list[float]) -> list[float]:
    return [_dot(row, vector) for row in matrix]


def _dot(a: Iterable[float], b: Iterable[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def _matrix_identity(size: int = FEATURES) -> list[list[float]]:
    return [[1.0 if r == c else 0.0 for c in range(size)] for r in range(size)]


def _positive_definite(matrix: list[list[float]]) -> bool:
    """Cholesky check; symmetry and positive diagonal alone are insufficient."""
    n = len(matrix)
    lower = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1):
            value = matrix[i][j] - sum(lower[i][k] * lower[j][k] for k in range(j))
            if i == j:
                if not math.isfinite(value) or value <= 1e-8:
                    return False
                lower[i][j] = math.sqrt(value)
            else:
                if lower[j][j] <= 0:
                    return False
                lower[i][j] = value / lower[j][j]
    return True


class LocalLearner:
    """A small contextual bandit with per-match terminal feedback."""

    def __init__(self, model_path: Path):
        self.model_path = Path(model_path)
        self.matrices = [_matrix_identity() for _ in range(ARMS)]
        self.targets = [[0.0 for _ in range(FEATURES)] for _ in range(ARMS)]
        self.learn_count = 0
        self.reward_sum = 0.0
        self.replay: list[dict] = []
        self.episode_count = 0
        self.wins = 0
        self.losses = 0
        self.draws = 0
        self.unlabeled_episodes = 0
        self.recent_results: list[dict] = []
        self._pending_episode: list[dict] = []
        self._episode_open = False
        self._prediction_cache: list[tuple[list[list[float]], list[float]] | None] = [None] * ARMS
        self._prediction_cache_builds = 0
        self.load_status = "new"
        self._load()

    @staticmethod
    def _valid_model(raw) -> bool:
        if not isinstance(raw, dict) or raw.get("version") not in (2, 3, 4, 5, 6, 7, 8, MODEL_VERSION):
            return False
        version = raw["version"]
        arm_count = ARMS if version == MODEL_VERSION else LEGACY_ARMS
        dimension = (LEGACY_FEATURES if version in (2, 3) else
                     LEGACY_V5_FEATURES if version in (4, 5) else
                     LEGACY_V6_FEATURES if version == 6 else
                     LEGACY_V7_FEATURES if version == 7 else FEATURES)
        matrices, targets = raw.get("matrices"), raw.get("targets")
        if not isinstance(matrices, list) or len(matrices) != arm_count:
            return False
        if not isinstance(targets, list) or len(targets) != arm_count:
            return False
        for matrix in matrices:
            if not isinstance(matrix, list) or len(matrix) != dimension:
                return False
            for row in matrix:
                if not isinstance(row, list) or len(row) != dimension:
                    return False
                if not all(_finite_number(v) and abs(v) <= 1e9 for v in row):
                    return False
            for i in range(dimension):
                for j in range(i + 1, dimension):
                    if abs(matrix[i][j] - matrix[j][i]) > 1e-4:
                        return False
            if not _positive_definite(matrix):
                return False
        for vector in targets:
            if not isinstance(vector, list) or len(vector) != dimension:
                return False
            if not all(_finite_number(v) and abs(v) <= 1e9 for v in vector):
                return False
        count, reward_sum = raw.get("learn_count"), raw.get("reward_sum")
        if not isinstance(count, int) or isinstance(count, bool) or count < 0 or count > 10**12:
            return False
        if not _finite_number(reward_sum) or abs(reward_sum) > 1e12:
            return False
        replay = raw.get("replay", [])
        if not isinstance(replay, list) or len(replay) > REPLAY_LIMIT:
            return False
        for item in replay:
            if not isinstance(item, dict):
                return False
            if (not isinstance(item.get("action"), int) or isinstance(item.get("action"), bool)
                    or not 0 <= item["action"] < arm_count):
                return False
            if not isinstance(item.get("features"), list) or len(item["features"]) != dimension:
                return False
            if not all(_finite_number(v) and abs(v) <= 100 for v in item["features"]):
                return False
            if not _finite_number(item.get("reward")) or abs(item["reward"]) > 1:
                return False
            confidence = item.get("confidence", 1.0)
            if not _finite_number(confidence) or not 0.0 <= confidence <= 1.0:
                return False
            outcome = item.get("outcome")
            if outcome is not None and outcome not in ("win", "loss", "draw"):
                return False
        for key in ("episode_count", "wins", "losses", "draws", "unlabeled_episodes"):
            value = raw.get(key, 0)
            if not isinstance(value, int) or isinstance(value, bool) or value < 0 or value > 10**9:
                return False
        recent = raw.get("recent_results", [])
        if not isinstance(recent, list) or len(recent) > 50:
            return False
        for item in recent:
            if not isinstance(item, dict) or item.get("outcome") not in ("win", "loss", "draw"):
                return False
            if not _finite_number(item.get("confidence", 1.0)) or not 0.0 <= item.get("confidence", 1.0) <= 1.0:
                return False
            if not isinstance(item.get("time", 0), int) or item.get("time", 0) < 0:
                return False
        return True

    def _apply_loaded_model(self, raw: dict, *, recovered: bool = False) -> None:
        old_version = raw["version"]
        self.learn_count = raw["learn_count"]
        self.reward_sum = float(raw["reward_sum"])
        self.episode_count = raw.get("episode_count", 0)
        self.wins = raw.get("wins", 0)
        self.losses = raw.get("losses", 0)
        self.draws = raw.get("draws", 0)
        self.unlabeled_episodes = raw.get("unlabeled_episodes", 0)
        self.recent_results = raw.get("recent_results", [])[-50:]
        old_dimension = (LEGACY_FEATURES if old_version in (2, 3) else
                         LEGACY_V5_FEATURES if old_version in (4, 5) else
                         LEGACY_V6_FEATURES if old_version == 6 else
                         LEGACY_V7_FEATURES if old_version == 7 else FEATURES)
        old_arms = ARMS if old_version == MODEL_VERSION else LEGACY_ARMS
        self.matrices = [_matrix_identity() for _ in range(ARMS)]
        self.targets = [[0.0 for _ in range(FEATURES)] for _ in range(ARMS)]
        for lane in range(ARMS):
            source_actions = (lane,) if old_arms == ARMS else tuple(
                slot * 2 + lane for slot in range(4)
            )
            source_count = float(len(source_actions))
            for row in range(old_dimension):
                self.targets[lane][row] = sum(
                    float(raw["targets"][action][row]) for action in source_actions
                ) / source_count
                for col in range(old_dimension):
                    self.matrices[lane][row][col] = sum(
                        float(raw["matrices"][action][row][col])
                        for action in source_actions
                    ) / source_count
        migrated_replay = []
        for item in raw.get("replay", [])[-REPLAY_LIMIT:]:
            features = [float(v) for v in item["features"]]
            features.extend([0.0] * (FEATURES - len(features)))
            replay_action = int(item["action"])
            if old_arms == LEGACY_ARMS:
                replay_action %= 2
            migrated_replay.append({**item, "action": replay_action,
                                    "features": features})
        self.replay = migrated_replay
        self._prediction_cache = [None] * ARMS
        if recovered:
            self.load_status = "recovered_backup"
        elif old_version == MODEL_VERSION:
            self.load_status = "loaded"
        else:
            self.load_status = f"migrated_v{old_version}"

    def _load(self) -> None:
        primary_status = "new"
        raw = None
        try:
            if self.model_path.stat().st_size > MAX_MODEL_BYTES:
                primary_status = "oversize_reset"
            else:
                raw = json.loads(self.model_path.read_text(encoding="utf-8"))
                primary_status = "invalid_reset" if not self._valid_model(raw) else "loaded"
        except FileNotFoundError:
            primary_status = "new"
        except (OSError, ValueError, TypeError):
            primary_status = "corrupt_reset"

        if raw is not None and self._valid_model(raw):
            self._apply_loaded_model(raw)
            return

        backup = self.model_path.with_suffix(self.model_path.suffix + ".bak")
        try:
            if backup.stat().st_size <= MAX_MODEL_BYTES:
                backup_raw = json.loads(backup.read_text(encoding="utf-8"))
                if self._valid_model(backup_raw):
                    self._apply_loaded_model(backup_raw, recovered=True)
                    return
        except (OSError, ValueError, TypeError):
            pass
        self.load_status = primary_status

    @staticmethod
    def _fingerprint_bits(fingerprint: str) -> list[float]:
        """Encode a 64-bit dHash as independent binary features.

        Treating a perceptual hash as one normalized scalar creates a false
        numeric ordering (e.g. hash 0x80... is considered "larger" than 0x01...).
        Binary dimensions preserve bit identity without claiming that hashes are
        ordinal measurements. Invalid/unknown fingerprints map to all zeros.
        """
        try:
            if (not isinstance(fingerprint, str) or len(fingerprint) != 16 or
                    any(char not in "0123456789abcdefABCDEF" for char in fingerprint)):
                raise ValueError("invalid 64-bit fingerprint")
            value = int(fingerprint, 16)
            return [float((value >> shift) & 1) for shift in range(63, -1, -1)]
        except (TypeError, ValueError):
            return [0.0] * FINGERPRINT_BITS

    def features(self, state: GameState, card: int, lane: int,
                 elapsed_seconds: float) -> list[float]:
        phase = min(1.0, max(0.0, elapsed_seconds / 240.0))
        lane_threat = state.left_threat if lane == 0 else state.right_threat
        other_threat = state.right_threat if lane == 0 else state.left_threat
        lane_support = state.left_support if lane == 0 else state.right_support
        other_support = state.right_support if lane == 0 else state.left_support
        imbalance = state.left_threat - state.right_threat
        cost = state.card_costs[card] if card < len(state.card_costs) else None
        cost_known = cost is not None and _finite_number(cost)
        ready_conf = state.card_ready_confidence[card] if card < len(state.card_ready_confidence) else 0.0
        fingerprint = state.card_fingerprints[card] if card < len(state.card_fingerprints) else ""
        enemy_clusters = [item for item in state.enemy_clusters
                          if (item.x < 0.5) == (lane == 0)]
        friendly_clusters = [item for item in state.friendly_clusters
                             if (item.x < 0.5) == (lane == 0)]
        enemy_front = max((item.y for item in enemy_clusters), default=0.0)
        roles = set(state.card_roles[card]) if card < len(state.card_roles) else set()
        features = [
            1.0,
            max(0.0, min(1.0, state.elixir / 10.0)),
            lane_threat,
            other_threat,
            lane_support,
            other_support,
            state.card_scores[card],
            phase,
            max(-1.0, min(1.0, (lane_threat - lane_support) + 0.20 * imbalance)),
            max(0.0, min(1.0, float(cost) / 10.0)) if cost_known else 0.0,
            1.0 if cost_known else 0.0,
            max(0.0, min(1.0, ready_conf)),
            TemporalBattleTracker.lane_advance(
                state.enemy_tracks, lane, toward_positive_y=True
            ),
            max(0.0, min(1.0, state.confidence)),
            max(0.0, min(1.0, state.elixir_confidence)),
            min(1.0, len(enemy_clusters) / 5.0),
            min(1.0, len(friendly_clusters) / 5.0),
            max(0.0, min(1.0, enemy_front)),
        ]
        features.extend(1.0 if role in roles else 0.0 for role in ROLE_FEATURES)
        features.extend(self._fingerprint_bits(fingerprint))
        return features

    def _prediction(self, action: int) -> tuple[list[list[float]], list[float]]:
        cached = self._prediction_cache[action]
        if cached is None:
            inverse = _invert(self.matrices[action])
            theta = _matvec(inverse, self.targets[action])
            cached = (inverse, theta)
            self._prediction_cache[action] = cached
            self._prediction_cache_builds += 1
        return cached

    @staticmethod
    def _card_identity(state: GameState, card: int, card_database):
        if card_database is None or card >= len(state.card_names):
            return "", "base", None
        name = state.card_names[card]
        record = card_database.find(name) if name else None
        if record is None and name:
            record = card_database.get(name)
        if record is None:
            return "", "base", None
        form = state.card_forms[card] if card < len(state.card_forms) else "base"
        level = state.card_levels[card] if card < len(state.card_levels) else None
        return record.key, form, level

    @staticmethod
    def _normalized_uncertainty(inverse: list[list[float]], features: list[float]) -> float:
        """Return a scale-invariant LinUCB uncertainty bonus.

        The 64 binary card-fingerprint dimensions can make raw feature norms
        much larger for some cards than others.  Dividing by the feature norm
        prevents fingerprint bit-count from masquerading as strategic novelty.
        """
        projected = _matvec(inverse, features)
        quadratic = max(0.0, _dot(features, projected))
        norm_squared = max(1.0, _dot(features, features))
        return math.sqrt(quadratic / norm_squared)

    @staticmethod
    def _opponent_counter_bonus(state: GameState, roles: set[str], card_key: str) -> float:
        """Small, confidence-weighted counter prior from the inferred full deck."""
        confidence = max(0.0, min(0.86, state.opponent_deck_confidence))
        if confidence < 0.16 or not state.opponent_deck_top:
            return 0.0
        known = set(state.opponent_deck_confirmed)
        deck = set(state.opponent_deck_top)
        predicted = deck - known
        # Confirmed win conditions have stronger counter weight than inferred slots.
        weight = confidence * (1.0 if card_key in known else 0.48)
        bonus = 0.0
        if deck & {"hog-rider", "ram-rider", "battle-ram", "royal-hogs", "goblin-drill", "x-bow", "mortar"}:
            if "building" in roles:
                bonus += 0.055
            if "tank_killer" in roles:
                bonus += 0.025
        if deck & {"balloon", "lava-hound", "skeleton-barrel", "phoenix"}:
            if "air_defense" in roles:
                bonus += 0.065
            if "building" in roles:
                bonus += 0.018
        if deck & {"golem", "giant", "goblin-giant", "electro-giant", "rune-giant", "mega-knight"}:
            if "tank_killer" in roles:
                bonus += 0.065
            if "air_defense" in roles:
                bonus += 0.025
        if deck & {"graveyard", "goblin-barrel", "wall-breakers", "skeleton-barrel"}:
            if "spell" in roles:
                bonus += 0.045
        # A card predicted in the opponent deck is not automatically a card in
        # hand; the bonus is intentionally too small to override hard safety gates.
        return min(0.085, bonus * weight)

    def choose(self, state: GameState, elapsed_seconds: float, *,
               combat_simulator=None, card_database=None,
               tactical_search=None, tactical_memory=None) -> tuple[int, int, list[float]] | None:
        # Low-confidence elixir/card overlays are not sufficient evidence for
        # an action. A missed opportunity is preferable to spending the wrong card.
        if state.elixir_confidence < 0.45:
            return None
        available = []
        for index, ready in enumerate(state.card_ready):
            ready_confidence = (state.card_ready_confidence[index]
                                if index < len(state.card_ready_confidence) else 0.0)
            if not ready or ready_confidence < 0.62:
                continue
            cost = state.card_costs[index] if index < len(state.card_costs) else None
            if cost is not None and _finite_number(cost) and state.elixir + 0.10 < float(cost):
                continue
            available.append(index)
        if not available:
            return None

        pressure = max(state.left_threat, state.right_threat)
        enemy_evidence = bool(state.enemy_clusters or state.enemy_tracks)
        verified_roles = {
            index: set(state.card_roles[index])
            for index in available
            if index < len(state.card_roles) and state.card_roles[index]
        }
        known_cycle = any(
            "cycle" in verified_roles.get(index, set()) and
            index < len(state.card_costs) and
            state.card_costs[index] is not None and
            _finite_number(state.card_costs[index]) and
            float(state.card_costs[index]) <= 3.0
            for index in available
        )
        # A top-level policy needs a real hold action.  In a quiet lane, preserve
        # elixir instead of dumping an arbitrary unidentified card; allow a
        # verified cheap cycle card or a near-full meter to prevent overflow.
        if pressure < 0.10 and not enemy_evidence and state.elixir < 8.7 and not known_cycle:
            return None
        if pressure < 0.10 and not enemy_evidence and not verified_roles and state.elixir < 9.6:
            return None
        if pressure < 0.16 and not enemy_evidence and state.elixir < 4.0 and not known_cycle:
            return None

        best_score = -1e30
        best_action = -1
        best_card = -1
        best_features: list[float] | None = None
        search_actions: list[SearchAction] = []
        lane_assessments = (assess_lane(state, 0), assess_lane(state, 1))
        alpha = max(0.06, 0.48 / math.sqrt(1.0 + self.learn_count / 50.0))
        for card in available:
            card_key, card_form, card_level = self._card_identity(state, card, card_database)
            for lane in range(2):
                # Card identity travels with the feature vector, not the
                # transient hand slot.  Both lanes learn from every card.
                action = lane
                features = self.features(state, card, lane, elapsed_seconds)
                inverse, theta = self._prediction(action)
                uncertainty = self._normalized_uncertainty(inverse, features)
                score = _dot(theta, features) + alpha * uncertainty
                lane_threat = state.left_threat if lane == 0 else state.right_threat
                lane_support = state.left_support if lane == 0 else state.right_support
                other_threat = state.right_threat if lane == 0 else state.left_threat
                enemy_advance = TemporalBattleTracker.lane_advance(
                    state.enemy_tracks, lane, toward_positive_y=True
                )
                friendly_advance = TemporalBattleTracker.lane_advance(
                    state.friendly_tracks, lane, toward_positive_y=False
                )
                roles = (state.card_roles[card] if card < len(state.card_roles) else ())
                roles = set(roles)
                score += self._opponent_counter_bonus(state, roles, card_key)
                lane_enemy_clusters = [item for item in state.enemy_clusters
                                       if (item.x < 0.5) == (lane == 0)]
                cluster_strength = min(1.0, sum(item.area * item.confidence * 24.0
                                                for item in lane_enemy_clusters))
                if lane_enemy_clusters:
                    score += min(0.06, len(lane_enemy_clusters) * 0.018)
                if pressure >= 0.12 or enemy_advance >= 0.08:
                    # Prioritize visible lane pressure and persistent blobs moving
                    # toward our side. The motion cue is generic, not a unit label.
                    score += 0.24 * lane_threat - 0.09 * lane_support
                    score += min(0.12, enemy_advance * 0.16)
                    if roles & {"building", "tank_killer", "swarm", "melee"}:
                        score += 0.10 * lane_threat + min(0.06, enemy_advance * 0.08)
                    if "air_defense" in roles:
                        score += 0.025 * lane_threat
                else:
                    score += 0.045 * (1.0 - lane_support) - 0.03 * other_threat
                    score += min(0.025, friendly_advance * 0.03)
                    if roles & {"win_condition", "tank", "support"}:
                        score += 0.055
                if "cycle" in roles and state.elixir < 4.0:
                    score += 0.035
                if "spell" in roles and pressure >= 0.18:
                    score += 0.025 * lane_threat + 0.065 * cluster_strength
                elif "spell" in roles and not lane_enemy_clusters:
                    # Do not spend a catalogued spell blindly when no target
                    # cluster or meaningful lane pressure is visible.
                    score -= 0.075
                score += state.card_scores[card] * 0.012
                cost = state.card_costs[card] if card < len(state.card_costs) else None
                if cost is not None and _finite_number(cost):
                    cost = float(cost)
                    # Keep elixir for emergency defense unless the meter is near
                    # full; use a modest preference for cycle cards at low elixir.
                    score += 0.025 * (1.0 - cost / 10.0)
                    # Prefer cheaper verified cards when the hand offers a
                    # choice; reserve expensive answers unless the meter is full.
                    score -= 0.012 * cost
                    if state.elixir < 4.0 and cost >= 5.0:
                        score -= 0.10
                    elif state.elixir >= 8.5 and cost >= 4.0:
                        score += 0.035
                score += tactical_adjustment(state, card, lane, lane_assessments)
                placement = plan_deployment(
                    state, card, lane, lane_assessments,
                    combat_simulator=combat_simulator, card_key=card_key,
                    form=card_form, level=card_level, roles_override=roles,
                )
                # Placement search is a bounded tie-breaker, not a substitute
                # for the learned action value or the explicit tactical rules.
                score += max(-0.045, min(0.045, (placement.score - 0.30) * 0.045))
                if "spell" in roles and placement.confidence < 0.30:
                    score -= 0.18
                known_cost = cost if cost is not None and _finite_number(cost) else None
                if known_cost is None and card_database is not None:
                    record = card_database.get(card_key) if card_key else None
                    if record is not None and record.elixir_cost is not None:
                        known_cost = float(record.elixir_cost)
                search_actions.append(SearchAction(
                    card=card, lane=lane, features=features, base_score=float(score),
                    card_key=card_key, form=card_form, level=card_level,
                    cost=float(known_cost) if known_cost is not None else None,
                    roles=tuple(sorted(roles)),
                ))
                if score > best_score:
                    best_score, best_action, best_card, best_features = score, action, card, features
        if best_action < 0 or best_card < 0 or best_features is None:
            return None
        if tactical_search is not None:
            try:
                searched = tactical_search.choose(
                    state, search_actions, card_database=card_database,
                    tactical_memory=tactical_memory, elapsed_seconds=elapsed_seconds,
                )
                if searched is not None:
                    return (searched.action.card, searched.action.lane,
                            searched.action.features)
            except Exception:
                # The search is an additive decision layer. If its bounded
                # planner fails, retain the already-computed safe policy choice.
                pass
        return best_card, best_action, best_features

    def begin_episode(self) -> None:
        self._pending_episode.clear()
        self._episode_open = True

    def record_action(self, card: int, lane: int, features: list[float],
                      confidence: float = 1.0) -> None:
        if not 0 <= card < 4 or lane not in (0, 1) or len(features) != FEATURES:
            return
        action = lane
        if not all(_finite_number(v) and abs(v) <= 100 for v in features):
            return
        if not _finite_number(confidence):
            return
        self._pending_episode.append({
            "action": action,
            "features": [float(v) for v in features],
            "confidence": max(0.0, min(1.0, float(confidence))),
        })
        if len(self._pending_episode) > 128:
            del self._pending_episode[:len(self._pending_episode) - 128]

    def abort_episode(self, *, unknown_result: bool = False) -> None:
        # The caller marks an active match independently of whether a card was
        # successfully played.  Count an unknown match even when no actions were
        # recorded, so result-label coverage is not biased toward active games.
        if unknown_result and self._episode_open:
            self.unlabeled_episodes += 1
        self._pending_episode.clear()
        self._episode_open = False

    def finish_episode(self, outcome: str, confidence: float = 1.0) -> int:
        rewards = {"win": 1.0, "loss": -1.0, "draw": 0.0}
        if not self._episode_open or outcome not in rewards or not _finite_number(confidence):
            self._pending_episode.clear()
            self._episode_open = False
            return 0
        confidence = max(0.0, min(1.0, float(confidence)))
        if confidence < 0.80:
            self.abort_episode(unknown_result=True)
            return 0
        reward = rewards[outcome]
        pending, self._pending_episode = self._pending_episode, []
        self._episode_open = False
        self.episode_count += 1
        if outcome == "win":
            self.wins += 1
        elif outcome == "loss":
            self.losses += 1
        else:
            self.draws += 1
        self.recent_results.append({
            "outcome": outcome, "confidence": confidence, "time": int(time.time()),
        })
        self.recent_results = self.recent_results[-50:]
        count = len(pending)
        # Terminal feedback is shared cautiously: later actions receive more
        # credit, and total update weight is normalized by match action count.
        # This reduces the old bias where every action received almost the same
        # full-strength win/loss label.
        normalizer = math.sqrt(max(1.0, count / 4.0))
        for index, item in enumerate(pending):
            progress = (index + 1) / count
            recency = 0.10 + 0.90 * progress * progress
            weight = max(0.004, min(0.55, confidence * 0.48 * recency / normalizer))
            weight *= max(0.25, min(1.0, item["confidence"]))
            self._apply(item["action"], item["features"], reward, weight, decay=1.0)
            self.learn_count += 1
            self.reward_sum += reward * weight
            self.replay.append({
                "action": item["action"], "features": item["features"],
                "reward": reward, "confidence": weight, "outcome": outcome,
                "time": int(time.time()),
            })
        if len(self.replay) > REPLAY_LIMIT:
            del self.replay[:len(self.replay) - REPLAY_LIMIT]
        return count

    @property
    def recent_win_rate(self) -> float | None:
        labeled = [item for item in self.recent_results if item.get("confidence", 0.0) >= 0.80]
        if not labeled:
            return None
        return sum(item["outcome"] == "win" for item in labeled) / len(labeled)

    @staticmethod
    def _rank_one_prediction_update(
        cached: tuple[list[list[float]], list[float]],
        features: list[float], reward: float, weight: float, decay: float,
    ) -> tuple[list[list[float]], list[float]] | None:
        """Update a cached ridge-regression prediction in O(n²), not O(n³).

        The action matrix changes as A' = decay*A + weight*x*xᵀ and its target
        as b' = decay*b + weight*reward*x.  Sherman–Morrison gives the new
        inverse and coefficient vector directly from the cached pair.  If
        numerical conditioning is questionable, return None and let the next
        prediction rebuild the inverse using the conservative Gaussian solver.
        """
        if not math.isfinite(decay) or decay <= 1e-9 or weight < 0.0:
            return None
        inverse, theta = cached
        beta = weight / decay
        projected = _matvec(inverse, features)
        quadratic = _dot(features, projected)
        denominator = 1.0 + beta * quadratic
        if (not math.isfinite(denominator) or denominator <= 1e-9 or
                not all(math.isfinite(value) for value in projected)):
            return None
        gain = beta / denominator
        inverse_scale = 1.0 / decay
        updated_inverse = [
            [
                (inverse[row][col] - gain * projected[row] * projected[col]) * inverse_scale
                for col in range(FEATURES)
            ]
            for row in range(FEATURES)
        ]
        innovation = reward - _dot(theta, features)
        updated_theta = [theta[index] + projected[index] * gain * innovation
                         for index in range(FEATURES)]
        if not all(math.isfinite(value) for row in updated_inverse for value in row):
            return None
        if not all(math.isfinite(value) for value in updated_theta):
            return None
        return updated_inverse, updated_theta

    def _apply(self, action: int, features: list[float], reward: float, weight: float,
               decay: float = 1.0) -> None:
        matrix, target = self.matrices[action], self.targets[action]
        cached = self._prediction_cache[action]
        updated_cache = (self._rank_one_prediction_update(
            cached, features, reward, weight, decay
        ) if cached is not None else None)
        for row in range(FEATURES):
            for col in range(FEATURES):
                matrix[row][col] *= decay
                matrix[row][col] += weight * features[row] * features[col]
            target[row] = target[row] * decay + weight * reward * features[row]
        self._prediction_cache[action] = updated_cache

    def update(self, card: int, lane: int, features: list[float], reward: float,
               confidence: float = 1.0) -> bool:
        """Apply low-weight immediate feedback; return True only if trained."""
        if not 0 <= card < 4 or lane not in (0, 1) or len(features) != FEATURES:
            return False
        action = lane
        if not all(_finite_number(v) and abs(v) <= 100 for v in features):
            return False
        if not _finite_number(reward) or not _finite_number(confidence):
            return False
        reward = max(-1.0, min(1.0, float(reward)))
        confidence = max(0.0, min(1.0, float(confidence)))
        if confidence < 0.25:
            return False
        clean = [float(v) for v in features]
        self._apply(action, clean, reward, confidence * 0.45, decay=0.9997)
        self.learn_count += 1
        self.reward_sum += reward * confidence * 0.45
        self.replay.append({"action": action, "features": clean,
                            "reward": reward, "confidence": confidence * 0.45,
                            "time": int(time.time())})
        if len(self.replay) > REPLAY_LIMIT:
            del self.replay[:len(self.replay) - REPLAY_LIMIT]
        # Replay is applied only on the transition into a multiple of eight;
        # callers persist based on learn-count deltas, never a repeated modulo.
        if self.learn_count % 8 == 0 and len(self.replay) > 1:
            for item in self.replay[-min(6, len(self.replay) - 1):-1]:
                self._apply(item["action"], item["features"], item["reward"],
                            0.02 * item.get("confidence", 1.0), decay=1.0)
        return True

    def save(self) -> None:
        self.model_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": MODEL_VERSION,
            "learn_count": self.learn_count,
            "reward_sum": round(self.reward_sum, 6),
            "episode_count": self.episode_count,
            "wins": self.wins,
            "losses": self.losses,
            "draws": self.draws,
            "unlabeled_episodes": self.unlabeled_episodes,
            "recent_results": self.recent_results[-50:],
            "matrices": self.matrices,
            "targets": self.targets,
            "replay": self.replay[-REPLAY_LIMIT:],
        }
        temp = self.model_path.with_suffix(self.model_path.suffix + ".tmp")
        backup = self.model_path.with_suffix(self.model_path.suffix + ".bak")
        backup_temp = backup.with_suffix(backup.suffix + ".tmp")
        try:
            # Keep the previous known-good model as an atomic recovery point.
            try:
                if self.model_path.is_file() and self.model_path.stat().st_size <= MAX_MODEL_BYTES:
                    old = json.loads(self.model_path.read_text(encoding="utf-8"))
                    if self._valid_model(old):
                        with self.model_path.open("rb") as source, backup_temp.open("wb") as target:
                            while True:
                                chunk = source.read(1024 * 1024)
                                if not chunk:
                                    break
                                target.write(chunk)
                            target.flush()
                            os.fsync(target.fileno())
                        os.replace(backup_temp, backup)
            except (OSError, ValueError, TypeError):
                pass
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.model_path)
        finally:
            for leftover in (temp, backup_temp):
                try:
                    if leftover.exists():
                        leftover.unlink()
                except OSError:
                    pass
