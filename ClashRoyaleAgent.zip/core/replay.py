"""Bounded, local battle-state replay capture and deterministic decoding.

The replay stores normalized, already-perceived GameState snapshots and action
outcomes. It deliberately does not store raw screenshots, account data, or
process memory. All files are written under the selected workspace.
"""
from __future__ import annotations

from dataclasses import asdict, fields
from datetime import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import time
from typing import Iterator

from . import APP_VERSION
from .cards import CardRecognition
from .vision import (
    ClusterTrack, GameState, NavigationTarget, Scene, SemanticUnit, VisualCluster,
)


REPLAY_FORMAT_VERSION = 1
MAX_EVENTS = 4096
MAX_EVENT_BYTES = 96_000
MAX_COMPRESSED_BYTES = 8_000_000
MAX_UNCOMPRESSED_BYTES = 64_000_000
STATE_SAMPLE_INTERVAL_SECONDS = 0.50


def _jsonable(value):
    if hasattr(value, "value") and isinstance(getattr(value, "value"), (str, int, float)):
        return value.value
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


def state_to_dict(state: GameState) -> dict:
    """Serialize a GameState into a stable JSON-compatible record."""
    if not isinstance(state, GameState):
        raise TypeError("state must be a GameState")
    return _jsonable(asdict(state))


def _tuple(value):
    return tuple(value) if isinstance(value, (list, tuple)) else ()


def _cluster(value: dict) -> VisualCluster:
    item = dict(value)
    item["appearance"] = _tuple(item.get("appearance"))
    return VisualCluster(**item)


def _track(value: dict) -> ClusterTrack:
    item = dict(value)
    item["appearance"] = _tuple(item.get("appearance"))
    return ClusterTrack(**item)


def _semantic_unit(value: dict) -> SemanticUnit:
    item = dict(value)
    item["roles"] = _tuple(item.get("roles"))
    return SemanticUnit(**item)


def _target(value: dict) -> NavigationTarget:
    return NavigationTarget(**dict(value))


def _card_recognition(value: dict) -> CardRecognition:
    item = dict(value)
    if item.get("bounds") is not None:
        item["bounds"] = _tuple(item["bounds"])
    return CardRecognition(**item)


def state_from_dict(raw: dict) -> GameState:
    """Rehydrate a serialized state, validating nested records and enum values."""
    if not isinstance(raw, dict):
        raise ValueError("replay state must be an object")
    item = dict(raw)
    try:
        item["scene"] = Scene(str(item.get("scene", Scene.UNKNOWN.value)))
    except ValueError as exc:
        raise ValueError("replay contains an unknown scene value") from exc

    tuple_fields = (
        "card_scores", "card_ready", "card_fingerprints", "card_ready_confidence",
        "card_costs", "card_names", "card_forms", "card_levels", "card_elite",
        "ocr_text", "opponent_cycle_roles", "opponent_recent_plays",
        "opponent_seen_cards", "opponent_deck_top", "opponent_deck_confirmed",
        "opponent_deck_candidate_confidences",
    )
    for name in tuple_fields:
        if name in item:
            item[name] = _tuple(item[name])
    for name in ("card_descriptors", "card_roles", "opponent_deck_candidates"):
        if name in item:
            item[name] = tuple(_tuple(value) for value in item[name])
    for name in ("viewport", "arena_bounds", "elixir_bounds"):
        if item.get(name) is not None:
            item[name] = _tuple(item[name])
    if "card_bounds" in item:
        item["card_bounds"] = tuple(_tuple(value) for value in item["card_bounds"])

    nested = (
        ("targets", _target),
        ("enemy_clusters", _cluster),
        ("friendly_clusters", _cluster),
        ("enemy_tracks", _track),
        ("friendly_tracks", _track),
        ("semantic_enemy_units", _semantic_unit),
        ("semantic_friendly_units", _semantic_unit),
        ("recognized_cards", _card_recognition),
    )
    for name, constructor in nested:
        if name in item:
            values = item[name]
            if not isinstance(values, (list, tuple)):
                raise ValueError(f"replay field {name} must be an array")
            item[name] = tuple(constructor(value) for value in values)

    allowed = {field.name for field in fields(GameState)}
    item = {key: value for key, value in item.items() if key in allowed}
    required = {"battle_detected", "elixir", "left_threat", "right_threat",
                "left_support", "right_support", "card_scores", "green_ratio",
                "red_ratio", "blue_ratio", "purple_ratio", "confidence"}
    if not required.issubset(item):
        raise ValueError("replay state is missing required GameState fields")
    try:
        return GameState(**item)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"replay GameState is invalid: {exc}") from exc


def canonical_state_hash(state: GameState) -> str:
    payload = json.dumps(state_to_dict(state), ensure_ascii=False,
                         sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


class BattleReplayRecorder:
    """Keep a bounded in-memory trace and persist one compact replay per match."""

    def __init__(self, workspace: Path, *, enabled: bool = True):
        self.workspace = Path(workspace).resolve()
        self.enabled = bool(enabled)
        self.active = False
        self._events: list[dict] = []
        self._started_at = 0.0
        self._last_state_at = float("-inf")
        self._last_path: Path | None = None
        self._state_count = 0
        self._action_count = 0
        self._dropped_states = 0
        self._match_sequence = 0
        self._last_result: str | None = None

    def begin_match(self, *, frame_index: int = 0) -> None:
        if not self.enabled:
            return
        if self.active:
            self.finish_match(None, reason="superseded_by_next_match")
        self._match_sequence += 1
        self._started_at = time.monotonic()
        self._last_state_at = float("-inf")
        self._state_count = 0
        self._action_count = 0
        self._dropped_states = 0
        self._last_result = None
        self._events = [{
            "type": "match_start",
            "format_version": REPLAY_FORMAT_VERSION,
            "app_version": APP_VERSION,
            "sequence": self._match_sequence,
            "started_local": datetime.now().astimezone().isoformat(timespec="seconds"),
            "frame_index": max(0, int(frame_index)),
        }]
        self.active = True

    def _append(self, event: dict) -> bool:
        if not self.active:
            return False
        try:
            encoded = json.dumps(event, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        except (TypeError, ValueError):
            return False
        if len(encoded) > MAX_EVENT_BYTES:
            if event.get("type") == "state":
                self._dropped_states += 1
            return False
        if len(self._events) >= MAX_EVENTS:
            # Preserve action and terminal events. Evict the oldest state first.
            index = next((i for i, old in enumerate(self._events)
                          if old.get("type") == "state"), None)
            if index is not None:
                self._events.pop(index)
                self._dropped_states += 1
            else:
                return False
        self._events.append(event)
        return True

    def record_state(self, state: GameState, *, frame_index: int,
                     now: float | None = None) -> bool:
        if not self.enabled or not self.active:
            return False
        now = time.monotonic() if now is None else float(now)
        if now - self._last_state_at < STATE_SAMPLE_INTERVAL_SECONDS:
            return False
        payload = state_to_dict(state)
        event = {
            "type": "state",
            "elapsed_ms": round(max(0.0, now - self._started_at) * 1000.0, 1),
            "frame_index": max(0, int(frame_index)),
            "state": payload,
        }
        if self._append(event):
            self._last_state_at = now
            self._state_count += 1
            return True
        return False

    def record_decision(self, *, card: int, lane: int, features=(),
                        policy_ms: float = 0.0, search_summary: dict | None = None) -> None:
        if not self.enabled or not self.active:
            return
        self._append({
            "type": "decision",
            "elapsed_ms": round(max(0.0, time.monotonic() - self._started_at) * 1000.0, 1),
            "card_slot": int(card), "lane": int(lane),
            "features": [round(float(value), 6) for value in tuple(features)[:128]],
            "policy_ms": round(max(0.0, float(policy_ms)), 3),
            "search": dict(search_summary or {}),
        })

    def record_action(self, *, card_key: str, form: str, slot: int, lane: int,
                      status: str, plan: tuple[float, float] | None = None) -> None:
        if not self.enabled or not self.active:
            return
        if status not in ("rejected", "sent_unverified", "verified"):
            status = "unknown"
        self._append({
            "type": "action", "elapsed_ms": round(
                max(0.0, time.monotonic() - self._started_at) * 1000.0, 1),
            "card_key": str(card_key or "")[:64], "form": str(form or "base")[:16],
            "card_slot": int(slot), "lane": int(lane), "status": status,
            "placement": ([round(float(plan[0]), 5), round(float(plan[1]), 5)]
                          if plan is not None else None),
        })
        self._action_count += 1

    def finish_match(self, result: str | None, *, confidence: float = 0.0,
                     reason: str = "completed") -> Path | None:
        if not self.enabled or not self.active:
            return None
        label = result if result in ("win", "loss", "draw") else None
        self._last_result = label
        self._append({
            "type": "match_end", "elapsed_ms": round(
                max(0.0, time.monotonic() - self._started_at) * 1000.0, 1),
            "result": label, "result_confidence": round(
                max(0.0, min(1.0, float(confidence))), 4),
            "reason": str(reason or "completed")[:96],
            "state_count": self._state_count, "action_count": self._action_count,
            "dropped_state_count": self._dropped_states,
        })
        self.active = False
        try:
            self._last_path = self._persist()
        except OSError:
            self._last_path = None
        self._events = []
        return self._last_path

    def _persist(self) -> Path:
        if not self._events:
            raise OSError("No replay events were recorded.")
        events = list(self._events)
        compressed = self._compress(events)
        if len(compressed) > MAX_COMPRESSED_BYTES:
            # Reduce only sampled perception states; keep every action and the
            # final outcome so the trace remains diagnostically useful.
            stride = 2
            while len(compressed) > MAX_COMPRESSED_BYTES and stride <= 64:
                kept = []
                state_index = 0
                for event in events:
                    if event.get("type") == "state":
                        if state_index % stride == 0:
                            kept.append(event)
                        state_index += 1
                    else:
                        kept.append(event)
                compressed = self._compress(kept)
                stride *= 2
        if len(compressed) > MAX_COMPRESSED_BYTES:
            raise OSError("Replay exceeds the local size safety limit.")
        directory = self.workspace / "replays"
        directory.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        target = directory / f"match_{stamp}_{self._match_sequence:04d}.crr.gz"
        temporary = target.with_suffix(target.suffix + ".tmp")
        with temporary.open("wb") as stream:
            stream.write(compressed)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(target)
        return target

    @staticmethod
    def _compress(events: list[dict]) -> bytes:
        raw = b"\n".join(
            json.dumps(event, ensure_ascii=False, sort_keys=True,
                       separators=(",", ":")).encode("utf-8")
            for event in events
        ) + b"\n"
        return gzip.compress(raw, compresslevel=6, mtime=0)

    def summary(self) -> dict:
        return {
            "enabled": self.enabled,
            "active": self.active,
            "state_snapshots": self._state_count,
            "action_events": self._action_count,
            "dropped_state_snapshots": self._dropped_states,
            "last_result": self._last_result,
            "last_replay": self._last_path.name if self._last_path else None,
            "max_events": MAX_EVENTS,
            "max_compressed_bytes": MAX_COMPRESSED_BYTES,
        }


def load_replay(path: Path) -> list[dict]:
    """Load a replay with strict compressed/uncompressed size and schema bounds."""
    path = Path(path)
    if path.stat().st_size > MAX_COMPRESSED_BYTES:
        raise ValueError("replay file exceeds the compressed size limit")
    with gzip.open(path, "rb") as stream:
        raw = stream.read(MAX_UNCOMPRESSED_BYTES + 1)
    if len(raw) > MAX_UNCOMPRESSED_BYTES:
        raise ValueError("replay expands beyond the uncompressed size limit")
    events = []
    for line_number, line in enumerate(raw.splitlines(), 1):
        if not line:
            continue
        if len(events) >= MAX_EVENTS:
            raise ValueError("replay contains too many events")
        try:
            event = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise ValueError(f"invalid replay event at line {line_number}") from exc
        if not isinstance(event, dict) or not isinstance(event.get("type"), str):
            raise ValueError(f"invalid replay event shape at line {line_number}")
        if event.get("type") == "state":
            event["_decoded_state"] = state_from_dict(event.get("state"))
        events.append(event)
    if not events or events[0].get("type") != "match_start":
        raise ValueError("replay is missing its match-start header")
    if events[0].get("format_version") != REPLAY_FORMAT_VERSION:
        raise ValueError("unsupported replay format version")
    return events


def replay_state_hashes(events: list[dict]) -> Iterator[str]:
    """Yield deterministic hashes of decoded state snapshots in replay order."""
    for event in events:
        state = event.get("_decoded_state")
        if isinstance(state, GameState):
            yield canonical_state_hash(state)
