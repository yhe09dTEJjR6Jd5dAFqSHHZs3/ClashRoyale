"""Fully offline, lexicon/template OCR for Clash Royale UI and card labels.

This is a deterministic raster-template recognizer. It does not call a cloud
service, download weights, or use a third-party AI model. On Windows it renders
its own glyph templates through the system GDI font rasterizer and compares
them with text-like regions from captured frames.
"""
from __future__ import annotations

import ctypes
import math
import os
import re
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .cards import CardDatabase, CardRecognition, normalize_card_name
from .win32 import Frame


OCR_VOCABULARY = (
    "Trophy Road", "Path of Legends", "Royal Journey", "Ranked", "Battle", "Battle Now",
    "Start Battle", "Play", "Cards", "Collection", "My Cards", "Card Collection",
    "Shop", "Clan", "Your Deck", "Battle Deck", "Confirm", "Info", "Remove",
    "Victory", "Defeat", "Draw", "Continue", "Next Battle", "Retry", "Reconnect",
    "Connection Lost", "Connection Error", "Network Error", "Searching for Opponents",
    "Finding Opponent", "Matchmaking", "Loading", "Connecting", "Locked", "Unlocked",
    "Unlock", "Unlock at", "Elite", "Evolution", "Evolved", "Hero", "Champion",
    "Level", "Level 15", "Level 16", "LV 15", "LV 16",
    "獎盃之路", "獎盃路", "傳奇之路", "皇室征程", "天梯", "收藏", "我的牌庫",
    "皇家塔收藏", "已收集", "已擁有", "獎盃數", "獎盃數達到", "時解鎖",
    "確定", "資訊", "移除", "對戰", "戰鬥", "開始對局",
    "開始戰鬥", "卡牌", "商店", "部落", "牌組", "卡組", "勝利", "獲勝",
    "失敗", "敗北", "平手", "平局", "繼續", "下一場", "重新連線", "重試",
    "連線失敗", "網路錯誤", "正在尋找對手", "配對中", "載入中", "連線中",
    "已解鎖", "未解鎖", "鎖定", "解鎖", "精英", "進化", "英雄", "冠軍",
    "奖杯之路", "传奇之路", "天梯", "收藏", "我的牌库", "皇家塔收藏", "已收集",
    "已拥有", "奖杯数", "奖杯数达到", "时解锁", "确定", "信息", "移除",
    "对战", "战斗", "开始对局", "开始战斗", "卡牌",
    "商店", "部落", "牌组", "卡组", "胜利", "获胜", "失败", "败北", "平局",
    "继续", "下一场", "重新连接", "重试", "连接失败", "网络错误",
    "正在寻找对手", "匹配中", "加载中", "连接中", "已解锁", "未解锁",
    "锁定", "解锁", "精英", "进化", "英雄", "冠军",
)


@dataclass(frozen=True)
class OCRLine:
    text: str
    confidence: float
    bounds: tuple[int, int, int, int]
    raw_score: float = 0.0


@dataclass(frozen=True)
class OCRSnapshot:
    lines: tuple[OCRLine, ...] = ()
    cards: tuple[CardRecognition, ...] = ()
    confidence: float = 0.0
    available: bool = False

    @property
    def text(self) -> tuple[str, ...]:
        return tuple(line.text for line in self.lines)


@dataclass(frozen=True)
class _Template:
    text: str
    bits: int
    aspect: float


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", ctypes.c_uint32),
        ("biWidth", ctypes.c_int32),
        ("biHeight", ctypes.c_int32),
        ("biPlanes", ctypes.c_uint16),
        ("biBitCount", ctypes.c_uint16),
        ("biCompression", ctypes.c_uint32),
        ("biSizeImage", ctypes.c_uint32),
        ("biXPelsPerMeter", ctypes.c_int32),
        ("biYPelsPerMeter", ctypes.c_int32),
        ("biClrUsed", ctypes.c_uint32),
        ("biClrImportant", ctypes.c_uint32),
    ]


class _BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", _BITMAPINFOHEADER), ("bmiColors", ctypes.c_uint32 * 1)]


class _GdiTextRenderer:
    """Render known phrases into in-memory 32-bit DIB masks using Windows GDI."""

    def __init__(self):
        if os.name != "nt":
            raise OSError("Windows GDI is available only on Windows.")
        self.gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        self._configure()

    def _configure(self) -> None:
        gdi = self.gdi32
        gdi.CreateCompatibleDC.argtypes = [ctypes.c_void_p]
        gdi.CreateCompatibleDC.restype = ctypes.c_void_p
        gdi.DeleteDC.argtypes = [ctypes.c_void_p]
        gdi.DeleteDC.restype = ctypes.c_int
        gdi.CreateDIBSection.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(_BITMAPINFO), ctypes.c_uint,
            ctypes.POINTER(ctypes.c_void_p), ctypes.c_void_p, ctypes.c_uint,
        ]
        gdi.CreateDIBSection.restype = ctypes.c_void_p
        gdi.SelectObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        gdi.SelectObject.restype = ctypes.c_void_p
        gdi.DeleteObject.argtypes = [ctypes.c_void_p]
        gdi.DeleteObject.restype = ctypes.c_int
        gdi.CreateFontW.argtypes = [
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
            ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
            ctypes.c_wchar_p,
        ]
        gdi.CreateFontW.restype = ctypes.c_void_p
        gdi.SetBkMode.argtypes = [ctypes.c_void_p, ctypes.c_int]
        gdi.SetBkMode.restype = ctypes.c_int
        gdi.SetTextColor.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        gdi.SetTextColor.restype = ctypes.c_uint32
        gdi.TextOutW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                                 ctypes.c_wchar_p, ctypes.c_int]
        gdi.TextOutW.restype = ctypes.c_int
        gdi.GdiFlush.argtypes = []
        gdi.GdiFlush.restype = ctypes.c_int

    def render(self, text: str, family: str, size: int = 26) -> tuple[bytearray, int, int]:
        if not text or len(text) > 64:
            raise ValueError("OCR template text is empty or too long.")
        width = min(2048, max(48, int(size * max(1, len(text)) * 1.55 + 16)))
        height = size * 2 + 14
        info = _BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
        info.bmiHeader.biWidth = width
        info.bmiHeader.biHeight = -height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        bits = ctypes.c_void_p()
        dc = self.gdi32.CreateCompatibleDC(None)
        if not dc:
            raise OSError("CreateCompatibleDC failed.")
        bitmap = None
        font = None
        old_bitmap = None
        old_font = None
        try:
            bitmap = self.gdi32.CreateDIBSection(
                dc, ctypes.byref(info), 0, ctypes.byref(bits), None, 0
            )
            if not bitmap or not bits.value:
                raise OSError("CreateDIBSection failed.")
            old_bitmap = self.gdi32.SelectObject(dc, bitmap)
            ctypes.memset(bits, 0, width * height * 4)
            FW_BOLD = 700
            DEFAULT_CHARSET = 1
            OUT_TT_PRECIS = 4
            CLIP_DEFAULT_PRECIS = 0
            ANTIALIASED_QUALITY = 4
            DEFAULT_PITCH = 0
            FF_DONTCARE = 0
            font = self.gdi32.CreateFontW(
                -int(size), 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
                OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                DEFAULT_PITCH | FF_DONTCARE, str(family),
            )
            if not font:
                raise OSError("CreateFontW failed.")
            old_font = self.gdi32.SelectObject(dc, font)
            self.gdi32.SetBkMode(dc, 1)  # TRANSPARENT
            self.gdi32.SetTextColor(dc, 0x00FFFFFF)
            if not self.gdi32.TextOutW(dc, 4, 4, text, len(text)):
                raise OSError("TextOutW failed.")
            self.gdi32.GdiFlush()
            raw = ctypes.string_at(bits.value, width * height * 4)
            mask = bytearray(width * height)
            for index in range(width * height):
                offset = index * 4
                if max(raw[offset], raw[offset + 1], raw[offset + 2]) >= 72:
                    mask[index] = 1
            return mask, width, height
        finally:
            if old_font:
                self.gdi32.SelectObject(dc, old_font)
            if old_bitmap:
                self.gdi32.SelectObject(dc, old_bitmap)
            if font:
                self.gdi32.DeleteObject(font)
            if bitmap:
                self.gdi32.DeleteObject(bitmap)
            self.gdi32.DeleteDC(dc)


def _trim_mask(mask: bytearray, width: int, height: int):
    xs = [x for y in range(height) for x in range(width) if mask[y * width + x]]
    if not xs:
        return bytearray(), 0, 0, 0, 0
    x0, x1 = min(xs), max(xs) + 1
    ys = [y for y in range(height)
          if any(mask[y * width + x] for x in range(x0, x1))]
    y0, y1 = min(ys), max(ys) + 1
    out_w, out_h = x1 - x0, y1 - y0
    cropped = bytearray(out_w * out_h)
    for y in range(out_h):
        cropped[y * out_w:(y + 1) * out_w] = mask[(y0 + y) * width + x0:(y0 + y) * width + x1]
    return cropped, out_w, out_h, x0, y0


def _normalize_mask(mask: bytearray, width: int, height: int,
                    target_width: int = 48, target_height: int = 16) -> tuple[int, float] | None:
    cropped, source_w, source_h, _x, _y = _trim_mask(mask, width, height)
    if source_w < 2 or source_h < 3:
        return None
    aspect = source_w / max(1.0, source_h)
    scale = min((target_width - 2) / source_w, (target_height - 2) / source_h)
    out_w = max(1, min(target_width - 2, int(round(source_w * scale))))
    out_h = max(1, min(target_height - 2, int(round(source_h * scale))))
    left = (target_width - out_w) // 2
    top = (target_height - out_h) // 2
    packed = 0
    for y in range(out_h):
        sy = min(source_h - 1, int(y * source_h / out_h))
        for x in range(out_w):
            sx = min(source_w - 1, int(x * source_w / out_w))
            if cropped[sy * source_w + sx]:
                packed |= 1 << ((top + y) * target_width + left + x)
    return packed, aspect


def _extract_text_regions(frame: Frame) -> list[tuple[bytearray, int, int, tuple[int, int, int, int]]]:
    """Find compact bright/gold text lines using row/column projections."""
    width, height = frame.width, frame.height
    if width < 120 or height < 160 or len(frame.bgra) < width * height * 4:
        return []
    pixels = memoryview(frame.bgra)
    mask = bytearray(width * height)
    row_hits = [0] * height
    for y in range(height):
        row = y * width * 4
        hits = 0
        for x in range(width):
            i = row + x * 4
            b, g, r = pixels[i], pixels[i + 1], pixels[i + 2]
            high, low = max(r, g, b), min(r, g, b)
            white = high >= 185 and high - low <= 112
            gold = r >= 172 and g >= 112 and b <= 112 and r > g * 1.16
            if white or gold:
                mask[y * width + x] = 1
                hits += 1
        row_hits[y] = hits

    row_threshold = max(2, width // 260)
    active = [count >= row_threshold for count in row_hits]
    bands: list[tuple[int, int]] = []
    start = None
    last_active = -1
    for y, hit in enumerate(active):
        if hit:
            if start is None:
                start = y
            last_active = y
        elif start is not None and y - last_active > 3:
            bands.append((start, last_active + 1))
            start = None
    if start is not None:
        bands.append((start, last_active + 1))

    regions = []
    for y0, y1 in bands:
        band_h = y1 - y0
        if band_h < 5 or band_h > max(52, int(height * 0.075)):
            continue
        col_hits = [0] * width
        for y in range(y0, y1):
            row_start = y * width
            for x in range(width):
                if mask[row_start + x]:
                    col_hits[x] += 1
        min_col_hits = max(1, band_h // 8)
        segments: list[tuple[int, int]] = []
        x = 0
        while x < width:
            while x < width and col_hits[x] < min_col_hits:
                x += 1
            if x >= width:
                break
            x0 = x
            last = x
            x += 1
            gap_limit = max(2, int(band_h * 0.30))
            while x < width:
                if col_hits[x] >= min_col_hits:
                    last = x
                elif x - last > gap_limit:
                    break
                x += 1
            segments.append((x0, last + 1))
        # Split unrelated controls sharing the same baseline, but retain normal
        # word spacing (which is much smaller than a gap between separate UI labels).
        split_segments: list[tuple[int, int]] = []
        for segment in segments:
            if split_segments and segment[0] - split_segments[-1][1] <= max(14, int(band_h * 1.5)):
                previous = split_segments[-1]
                split_segments[-1] = (previous[0], segment[1])
            else:
                split_segments.append(segment)
        for x0, x1 in split_segments:
            box_w = x1 - x0
            if box_w < 6 or box_w / max(1, band_h) < 0.22:
                continue
            cropped = bytearray(box_w * band_h)
            hits = 0
            for y in range(band_h):
                source = (y0 + y) * width + x0
                row = mask[source:source + box_w]
                cropped[y * box_w:(y + 1) * box_w] = row
                hits += sum(row)
            if hits < max(10, box_w * band_h // 100):
                continue
            regions.append((cropped, box_w, band_h, (x0, y0, x1, y1)))
    return regions[:64]


def _variant_marker_scores(frame: Frame, bounds: tuple[int, int, int, int]) -> tuple[float, float]:
    """Measure purple evolution and gold hero accents around a recognized card label."""
    width, height = frame.width, frame.height
    x0, y0, x1, y1 = bounds
    # Card art usually sits above its title. Include a bounded tile-sized region,
    # not the entire screen, to reduce accidental matches with arena effects.
    rx0 = max(0, x0 - int(width * 0.025))
    rx1 = min(width, x1 + int(width * 0.025))
    ry0 = max(0, y0 - int(height * 0.22))
    ry1 = min(height, y1 + int(height * 0.02))
    if rx1 <= rx0 or ry1 <= ry0:
        return 0.0, 0.0
    data = memoryview(frame.bgra)
    total = purple = gold = 0
    step = max(1, min(4, (rx1 - rx0) // 80))
    for y in range(ry0, ry1, step):
        row = y * width * 4
        for x in range(rx0, rx1, step):
            i = row + x * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            total += 1
            if r > 105 and b > 105 and g < min(r, b) * 0.78:
                purple += 1
            if r > 165 and g > 105 and b < 105 and r > g * 1.12:
                gold += 1
    if total <= 0:
        return 0.0, 0.0
    return min(1.0, purple / total * 5.0), min(1.0, gold / total * 5.0)


class OfflineOCR:
    """Offline card/UI OCR with no downloaded model or runtime package dependency."""

    FONT_FAMILIES = ("Segoe UI", "Arial", "Microsoft YaHei UI", "Microsoft JhengHei UI")
    # Windows 11 game clients commonly render text at several effective sizes
    # after DPI scaling. A small multi-size bank improves recall without adding
    # a runtime dependency or loading any external model weights.
    FONT_SIZES = (20, 26, 32)
    MIN_SCORE = 0.69
    MIN_MARGIN = 0.012

    def __init__(self, card_database: CardDatabase | None = None, renderer=None):
        self.card_database = card_database or CardDatabase()
        self.renderer = renderer
        if self.renderer is None:
            try:
                self.renderer = _GdiTextRenderer()
            except (OSError, AttributeError):
                self.renderer = None
        self.available = self.renderer is not None and len(self.card_database) >= 100
        self._templates: list[_Template] = []
        self._template_lock = threading.Lock()
        self._ready = threading.Event()
        self._warmup_error = ""
        self._last_snapshot = OCRSnapshot(available=self.available)

    @property
    def ready(self) -> bool:
        return self._ready.is_set()

    @property
    def template_count(self) -> int:
        return len(self._templates)

    def _lexicon(self) -> tuple[str, ...]:
        values = set(OCR_VOCABULARY)
        for record in self.card_database.cards:
            values.update(record.names)
            if record.has_evolution:
                values.update(f"Evo {record.name_en}" for _ in (0,))
                values.update(f"Evolution {record.name_en}" for _ in (0,))
                if record.name_zh:
                    values.add("进化" + record.name_zh)
                if record.name_zh_tw:
                    values.add("進化" + record.name_zh_tw)
            if record.has_hero:
                values.add(f"Hero {record.name_en}")
                if record.name_zh:
                    values.add("英雄" + record.name_zh)
                if record.name_zh_tw:
                    values.add("英雄" + record.name_zh_tw)
            if record.is_champion:
                values.add(f"Champion {record.name_en}")
            if record.hero_ability_name:
                values.add(record.hero_ability_name)
            if record.champion_ability_name:
                values.add(record.champion_ability_name)
        for level in range(1, 17):
            values.add(str(level))
            values.add(f"Level {level}")
            values.add(f"LV {level}")
        # Common trophy-gate values are rendered as a separate numeric token
        # in several regional mode selectors. Absence of a match remains
        # unknown; these tokens never establish unlock status by themselves.
        values.update(str(value) for value in range(1000, 20001, 1000))
        return tuple(sorted(
            (value for value in values if value and len(value) <= 48),
            key=lambda value: (normalize_card_name(value), value),
        ))

    def warmup(self, stop_event=None) -> bool:
        if not self.available:
            self._ready.set()
            return False
        if self._ready.is_set():
            return not bool(self._warmup_error)
        with self._template_lock:
            if self._ready.is_set():
                return not bool(self._warmup_error)
            try:
                templates: list[_Template] = []
                seen: set[tuple[str, int, float]] = set()
                for text in self._lexicon():
                    if stop_event is not None and stop_event.is_set():
                        self._warmup_error = "cancelled"
                        break
                    for family in self.FONT_FAMILIES:
                        for font_size in self.FONT_SIZES:
                            try:
                                mask, width, height = self.renderer.render(text, family, font_size)
                                normalized = _normalize_mask(mask, width, height)
                            except Exception:
                                continue
                            if normalized is None:
                                continue
                            bits, aspect = normalized
                            key = (normalize_card_name(text), bits, round(aspect, 2))
                            if key in seen:
                                continue
                            seen.add(key)
                            templates.append(_Template(text, bits, aspect))
                self._templates = templates
                if not templates and not self._warmup_error:
                    self._warmup_error = "No system font templates could be rendered."
            except Exception as exc:
                self._warmup_error = str(exc)[:300]
            finally:
                self._ready.set()
        return bool(self._templates) and not bool(self._warmup_error)

    @staticmethod
    def _match(bits: int, aspect: float, templates: list[_Template]) -> tuple[str, float, float] | None:
        best_by_text: dict[str, float] = {}
        for item in templates:
            pixel_error = (bits ^ item.bits).bit_count() / 768.0
            aspect_error = min(1.0, abs(math.log(max(0.05, aspect / max(0.05, item.aspect)))) / 1.5)
            score = 1.0 - (0.84 * pixel_error + 0.16 * aspect_error)
            if score > best_by_text.get(item.text, -1.0):
                best_by_text[item.text] = score
        if not best_by_text:
            return None
        ranked = sorted(best_by_text.items(), key=lambda item: item[1], reverse=True)
        text, score = ranked[0]
        second = ranked[1][1] if len(ranked) > 1 else 0.0
        margin = score - second
        if score < OfflineOCR.MIN_SCORE or margin < OfflineOCR.MIN_MARGIN:
            return None
        confidence = max(0.0, min(0.99,
            0.66 + (score - OfflineOCR.MIN_SCORE) * 0.72 + min(0.24, margin * 2.2)
        ))
        return text, confidence, score

    @staticmethod
    def _nearby_context(line: OCRLine, lines: tuple[OCRLine, ...], frame_height: int) -> str:
        x0, y0, x1, y1 = line.bounds
        center_y = (y0 + y1) / 2.0
        context = []
        for other in lines:
            if other is line:
                continue
            ox0, oy0, ox1, oy1 = other.bounds
            other_y = (oy0 + oy1) / 2.0
            if abs(other_y - center_y) <= max(18, frame_height * 0.12):
                if max(x0, ox0) <= min(x1, ox1) or abs((ox0 + ox1) / 2 - (x0 + x1) / 2) <= frame_height * 0.18:
                    context.append(other.text)
        return " ".join(context)

    @staticmethod
    def _parse_level(lines: tuple[OCRLine, ...], target: OCRLine,
                     context: str) -> int | None:
        combined = f"{target.text} {context}"
        match = re.search(r"(?:level|lvl|lv)\s*\.?\s*(1[0-6]|[1-9])\b", combined, re.I)
        if match:
            return int(match.group(1))
        for line in lines:
            if line is target or line.confidence < 0.78:
                continue
            x0, y0, x1, y1 = target.bounds
            ox0, oy0, ox1, oy1 = line.bounds
            distance = abs((oy0 + oy1) / 2 - (y0 + y1) / 2)
            if distance > 30:
                continue
            number = re.fullmatch(r"(1[0-6]|[1-9])", line.text.strip())
            if number and max(x0, ox0) <= min(x1, ox1) + 28:
                return int(number.group(1))
        return None

    def _recognize_cards(self, frame: Frame, lines: tuple[OCRLine, ...]) -> tuple[CardRecognition, ...]:
        recognized: list[CardRecognition] = []
        for line in lines:
            record = self.card_database.find(line.text)
            if record is None:
                continue
            context = self._nearby_context(line, lines, frame.height)
            lower_context = f"{line.text} {context}".casefold()
            level = self._parse_level(lines, line, context)
            evolution_text = any(term in lower_context for term in (
                "evolution", "evolved", "evo", "進化", "进化",
            ))
            hero_text = any(term in lower_context for term in ("hero", "英雄"))
            purple_score, gold_score = _variant_marker_scores(frame, line.bounds)
            evolution_marker = evolution_text or (record.has_evolution and purple_score >= 0.55)
            hero_marker = hero_text or (
                record.has_hero and record.hero_ability_name and
                normalize_card_name(record.hero_ability_name) in normalize_card_name(context)
            ) or (record.has_hero and gold_score >= 0.72)
            elite_text = any(term in lower_context for term in ("elite", "精英"))
            marker_confidence = max(
                0.90 if evolution_text or hero_text else 0.0,
                purple_score if evolution_marker else 0.0,
                gold_score if hero_marker else 0.0,
            )
            item = self.card_database.resolve(
                record.key, level=level, evolution_marker=evolution_marker,
                hero_marker=hero_marker, elite_marker=elite_text,
                confidence=line.confidence, marker_confidence=marker_confidence,
                bounds=line.bounds,
            )
            if item is not None:
                recognized.append(item)
        # A card name can be repeated by UI labels; keep the strongest recognition.
        best: dict[str, CardRecognition] = {}
        for item in recognized:
            previous = best.get(item.card_key)
            if previous is None or item.confidence > previous.confidence:
                best[item.card_key] = item
        return tuple(best.values())

    def recognize(self, frame: Frame, stop_event=None) -> OCRSnapshot:
        if not self.available:
            return OCRSnapshot(available=False)
        if not self.ready and not self.warmup(stop_event):
            return OCRSnapshot(available=True)
        if stop_event is not None and stop_event.is_set():
            return OCRSnapshot(available=True)
        regions = _extract_text_regions(frame)
        lines: list[OCRLine] = []
        for mask, width, height, bounds in regions:
            if stop_event is not None and stop_event.is_set():
                break
            normalized = _normalize_mask(mask, width, height)
            if normalized is None:
                continue
            bits, _aspect = normalized
            match = self._match(bits, _aspect, self._templates)
            if match is None:
                continue
            text, confidence, score = match
            lines.append(OCRLine(text, confidence, bounds, score))
        # De-duplicate exact labels from overlapping glyph bands.
        unique: dict[tuple[str, tuple[int, int, int, int]], OCRLine] = {}
        for line in lines:
            key = (normalize_card_name(line.text), line.bounds)
            old = unique.get(key)
            if old is None or line.confidence > old.confidence:
                unique[key] = line
        result_lines = tuple(sorted(unique.values(), key=lambda item: (item.bounds[1], item.bounds[0])))
        cards = self._recognize_cards(frame, result_lines)
        confidence = (
            sum(line.confidence for line in result_lines) / len(result_lines)
            if result_lines else 0.0
        )
        snapshot = OCRSnapshot(result_lines, cards, confidence, True)
        self._last_snapshot = snapshot
        return snapshot

    @staticmethod
    def labels_for(snapshot: OCRSnapshot):
        """Convert high-confidence OCR lines to non-clickable semantic labels."""
        from .adb import AccessibilityLabel

        lines = [line for line in snapshot.lines if line.confidence >= 0.78]
        labels = []
        for line in lines:
            x0, y0, x1, y1 = line.bounds
            nearby = []
            center_y = (y0 + y1) / 2.0
            for other in lines:
                if other is line:
                    continue
                ox0, oy0, ox1, oy1 = other.bounds
                if abs((oy0 + oy1) / 2.0 - center_y) <= 42:
                    if max(x0, ox0) <= min(x1, ox1) + 32 or abs(ox0 - x0) <= 48:
                        nearby.append(other.text)
            labels.append(AccessibilityLabel(
                text=line.text, description="", ancestor_text=" ".join(nearby),
                clickable=False, enabled=False, bounds=line.bounds,
                target_bounds=None, target_clickable=False, target_enabled=False,
                visible=True, target_visible=True,
            ))
        return labels

    def enrich_state(self, state, frame: Frame, snapshot: OCRSnapshot):
        """Attach OCR semantics and safely bind recognized labels to visible hand slots."""
        from dataclasses import replace
        from .adb import enrich_state_with_accessibility

        enriched = state
        if snapshot.lines:
            source_confidence = min(0.99, max(0.0, snapshot.confidence))
            enriched = enrich_state_with_accessibility(
                enriched, self.labels_for(snapshot), frame.width, frame.height,
                source_confidence=source_confidence,
            )
        names = list(enriched.card_names)
        costs = list(enriched.card_costs)
        roles = list(enriched.card_roles)
        forms = list(enriched.card_forms)
        levels = list(enriched.card_levels)
        elite = list(enriched.card_elite)
        viewport = enriched.viewport
        vx0, vy0, vx1, vy1 = viewport
        if len(enriched.card_bounds) != 4:
            # OCR may still classify the screen and report visible words, but
            # it must not attach a card identity to guessed hand-slot geometry.
            return replace(
                enriched,
                recognized_cards=snapshot.cards,
                ocr_text=snapshot.text,
                ocr_confidence=snapshot.confidence,
            )
        local_bounds = enriched.card_bounds
        # OCR sees the original captured window; adaptive card bounds are local
        # to the letterbox-free viewport. Convert before matching the rectangles.
        screen_bounds = tuple((
            vx0 + x0 * (vx1 - vx0), vy0 + y0 * (vy1 - vy0),
            vx0 + x1 * (vx1 - vx0), vy0 + y1 * (vy1 - vy0),
        ) for x0, y0, x1, y1 in local_bounds)
        for item in snapshot.cards:
            if item.bounds is None:
                continue
            x0, y0, x1, y1 = item.bounds
            cx = (x0 + x1) / (2.0 * max(1, frame.width))
            cy = (y0 + y1) / (2.0 * max(1, frame.height))
            candidates = []
            for index, (sx0, sy0, sx1, sy1) in enumerate(screen_bounds):
                margin_x = max(0.012, (sx1 - sx0) * 0.10)
                margin_y = max(0.012, (sy1 - sy0) * 0.10)
                if sx0 - margin_x <= cx <= sx1 + margin_x and sy0 - margin_y <= cy <= sy1 + margin_y:
                    center_x, center_y = (sx0 + sx1) / 2.0, (sy0 + sy1) / 2.0
                    candidates.append((abs(center_x - cx) + abs(center_y - cy), index))
            if not candidates:
                continue
            slot = min(candidates)[1]
            record = self.card_database.get(item.card_key)
            if record is None:
                continue
            names[slot] = record.name_en
            costs[slot] = record.elixir_cost
            roles[slot] = self.card_database.roles_for(record)
            forms[slot] = item.form
            levels[slot] = item.level
            elite[slot] = item.elite_level
        return replace(
            enriched,
            card_names=tuple(names),
            card_costs=tuple(costs),
            card_roles=tuple(roles),
            card_forms=tuple(forms),
            card_levels=tuple(levels),
            card_elite=tuple(elite),
            recognized_cards=snapshot.cards,
            ocr_text=snapshot.text,
            ocr_confidence=snapshot.confidence,
        )
