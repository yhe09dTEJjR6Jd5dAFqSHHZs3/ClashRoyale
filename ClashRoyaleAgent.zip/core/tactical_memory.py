"""Bounded, local learning of verified card-to-card tactical sequences.

Only actions that the UI confirms as deployed are recorded. Sequence values are
updated only when the match result itself is confidently labelled; unknown
results never become training labels. The file is small, versioned, and stays in
the user-selected workspace.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
import time


MEMORY_VERSION = 1
MAX_FILE_BYTES = 250_000
MAX_PAIRS = 512
MAX_MATCH_PLAYS = 64


class TacticalMemory:
    """Learn small card-sequence preferences from labelled completed matches."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.pairs: dict[str, dict[str, float | int]] = {}
        self._episode: list[dict[str, object]] = []
        self._last_play: dict[str, object] | None = None
        self.load_status = "new"
        self._last_summary: dict[str, object] = {}
        self._load()

    @staticmethod
    def _valid_card_key(value: object) -> bool:
        return (isinstance(value, str) and 1 <= len(value) <= 64 and
                all(ch.isalnum() or ch in "-_" for ch in value))

    @staticmethod
    def _pair_key(previous: dict[str, object], current: dict[str, object]) -> str:
        lane_delta = "same" if previous.get("lane") == current.get("lane") else "cross"
        return f"{previous['card']}|{current['card']}|{lane_delta}"

    def _load(self) -> None:
        try:
            if self.path.stat().st_size > MAX_FILE_BYTES:
                self.load_status = "oversize"
                return
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, UnicodeError, ValueError, TypeError):
            self.load_status = "invalid"
            return
        if not isinstance(raw, dict) or raw.get("version") != MEMORY_VERSION:
            self.load_status = "unsupported"
            return
        source = raw.get("pairs")
        if not isinstance(source, list) or len(source) > MAX_PAIRS:
            self.load_status = "invalid"
            return
        loaded: dict[str, dict[str, float | int]] = {}
        for item in source:
            if not isinstance(item, dict):
                continue
            previous, current = item.get("previous"), item.get("current")
            lane_delta = item.get("lane_delta")
            value, count = item.get("value"), item.get("count")
            if (not self._valid_card_key(previous) or not self._valid_card_key(current) or
                    lane_delta not in ("same", "cross") or
                    not isinstance(value, (int, float)) or isinstance(value, bool) or
                    not math.isfinite(float(value)) or not -1.0 <= float(value) <= 1.0 or
                    not isinstance(count, int) or isinstance(count, bool) or not 1 <= count <= 100_000):
                continue
            key = f"{previous}|{current}|{lane_delta}"
            loaded[key] = {"value": float(value), "count": count}
        self.pairs = loaded
        self.load_status = "loaded" if loaded else "empty"

    def begin_match(self) -> None:
        self._episode.clear()
        self._last_play = None

    def record_play(self, card_key: str, lane: int, *, confidence: float = 1.0,
                    form: str = "base", roles=()) -> bool:
        """Record a confirmed deployment, never a mere intended click."""
        if (not self._valid_card_key(card_key) or lane not in (0, 1) or
                not isinstance(confidence, (int, float)) or isinstance(confidence, bool) or
                not math.isfinite(float(confidence)) or float(confidence) < 0.70):
            return False
        item = {
            "card": card_key,
            "lane": int(lane),
            "confidence": max(0.0, min(1.0, float(confidence))),
            "form": str(form or "base")[:16],
            "roles": tuple(str(role)[:24] for role in tuple(roles)[:8]),
        }
        self._episode.append(item)
        if len(self._episode) > MAX_MATCH_PLAYS:
            del self._episode[:-MAX_MATCH_PLAYS]
        self._last_play = item
        return True

    def bonus_from(self, previous_card: str, previous_lane: int,
                   card_key: str, lane: int, *, confidence: float = 1.0) -> float:
        """Score a learned transition from an explicit previous action."""
        if (not self._valid_card_key(previous_card) or not self._valid_card_key(card_key) or
                previous_lane not in (0, 1) or lane not in (0, 1)):
            return 0.0
        previous = {"card": previous_card, "lane": int(previous_lane)}
        current = {"card": card_key, "lane": int(lane)}
        stat = self.pairs.get(self._pair_key(previous, current))
        if not stat:
            return 0.0
        count = int(stat.get("count", 0))
        if count < 3:
            return 0.0
        support = count / (count + 5.0)
        certainty = max(0.0, min(1.0, float(confidence)))
        value = float(stat.get("value", 0.0))
        return max(-0.045, min(0.045, value * 0.055 * support * certainty))

    def bonus(self, card_key: str, lane: int, *, confidence: float = 1.0) -> float:
        """Return a deliberately small preference after the last verified play."""
        previous = self._last_play
        if previous is None:
            return 0.0
        return self.bonus_from(
            str(previous.get("card", "")), int(previous.get("lane", -1)),
            card_key, lane, confidence=confidence,
        )

    def finish_match(self, outcome: str | None, confidence: float) -> int:
        """Train from a verified result; discard all unlabelled/weak outcomes."""
        outcome = str(outcome or "").casefold()
        reward = {"win": 1.0, "loss": -1.0, "draw": 0.0}.get(outcome)
        if (reward is None or not isinstance(confidence, (int, float)) or
                isinstance(confidence, bool) or not math.isfinite(float(confidence)) or
                float(confidence) < 0.85):
            self.abort_match()
            return 0
        plays = self._episode
        if len(plays) < 2:
            self.abort_match()
            return 0
        updates = 0
        total = len(plays) - 1
        for index in range(1, len(plays)):
            previous, current = plays[index - 1], plays[index]
            key = self._pair_key(previous, current)
            stat = self.pairs.setdefault(key, {"value": 0.0, "count": 0})
            count = int(stat.get("count", 0))
            # A conservative, recency-weighted update prevents one result from
            # overwhelming a long local history.
            position_weight = 0.55 + 0.45 * (index / max(1, total))
            evidence = min(float(previous["confidence"]), float(current["confidence"]))
            rate = min(0.12, 0.075 * float(confidence) * evidence * position_weight)
            old = float(stat.get("value", 0.0))
            stat["value"] = max(-1.0, min(1.0, old * (1.0 - rate) + float(reward) * rate))
            stat["count"] = min(100_000, count + 1)
            updates += 1
        if len(self.pairs) > MAX_PAIRS:
            ranked = sorted(self.pairs.items(), key=lambda item: (
                int(item[1].get("count", 0)), abs(float(item[1].get("value", 0.0)))
            ), reverse=True)[:MAX_PAIRS]
            self.pairs = dict(ranked)
        self.save()
        self._last_summary = {
            "labelled_matches": int(self._last_summary.get("labelled_matches", 0)) + 1,
            "trained_transitions": int(self._last_summary.get("trained_transitions", 0)) + updates,
            "last_outcome": outcome,
        }
        self.abort_match()
        return updates

    def abort_match(self) -> None:
        self._episode.clear()
        self._last_play = None

    def save(self) -> bool:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            entries = []
            for key, stat in sorted(self.pairs.items()):
                previous, current, lane_delta = key.split("|", 2)
                entries.append({
                    "previous": previous, "current": current,
                    "lane_delta": lane_delta,
                    "value": round(float(stat.get("value", 0.0)), 6),
                    "count": int(stat.get("count", 0)),
                })
            payload = json.dumps({
                "version": MEMORY_VERSION,
                "updated_at": int(time.time()),
                "pairs": entries,
            }, ensure_ascii=False, separators=(",", ":"))
            encoded = payload.encode("utf-8")
            if len(encoded) > MAX_FILE_BYTES:
                return False
            temporary = self.path.with_suffix(self.path.suffix + ".tmp")
            with temporary.open("wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            return True
        except (OSError, ValueError, TypeError):
            return False

    def summary(self) -> dict[str, object]:
        return {
            "learned_transitions": len(self.pairs),
            "current_match_verified_plays": len(self._episode),
            "last_match": dict(self._last_summary),
            "load_status": self.load_status,
        }
