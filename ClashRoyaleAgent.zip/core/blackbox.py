"""Create a privacy-conscious diagnostic ZIP on the real Windows Desktop."""
from __future__ import annotations

import ctypes
import io
import json
import os
import platform
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

from . import APP_VERSION

MAX_BYTES = 1_000_000  # stricter than 1 MiB


def _windows_desktop_path() -> Path | None:
    if os.name != "nt":
        return None
    try:
        class GUID(ctypes.Structure):
            _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                        ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]

        desktop_id = GUID(0xB4BFCC3A, 0xDB2C, 0x424C,
                          (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41))
        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        ole32 = ctypes.WinDLL("ole32", use_last_error=True)
        shell32.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), ctypes.c_uint32,
                                                ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p)]
        shell32.SHGetKnownFolderPath.restype = ctypes.c_long
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        result = ctypes.c_wchar_p()
        hr = shell32.SHGetKnownFolderPath(ctypes.byref(desktop_id), 0, None, ctypes.byref(result))
        if hr == 0 and result.value:
            value = Path(result.value)
            ole32.CoTaskMemFree(ctypes.cast(result, ctypes.c_void_p))
            return value
    except Exception:
        pass
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as key:
            value, _ = winreg.QueryValueEx(key, "Desktop")
        return Path(os.path.expandvars(value))
    except Exception:
        return None


def _desktop_path() -> Path:
    actual = _windows_desktop_path()
    if actual is not None and actual.exists() and actual.is_dir():
        return actual
    home = Path.home()
    candidates = [home / "Desktop", Path(os.environ.get("OneDrive", home / "OneDrive")) / "Desktop"]
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate
    raise OSError("找不到 Windows 桌面文件夹；未在其他目录偷偷创建黑匣子。")


def _tail(path: Path, limit: int) -> bytes | None:
    try:
        with path.open("rb") as stream:
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(max(0, size - limit), os.SEEK_SET)
            return stream.read(limit)
    except OSError:
        return None


def _whole_if_small(path: Path, limit: int) -> bytes | None:
    try:
        if path.stat().st_size > limit:
            return None
        return path.read_bytes()
    except OSError:
        return None


def _redact_diagnostic_text(data: bytes, workspace: Path) -> bytes:
    """Remove common personal paths and window-title fragments from diagnostics."""
    text = data.decode("utf-8", errors="replace")
    replacements = []
    candidates = [
        (str(Path.home()), "<USER_HOME>"),
        (str(workspace.resolve()), "<WORKSPACE>"),
        (os.environ.get("USERPROFILE", ""), "<USER_HOME>"),
    ]
    home_drive = os.environ.get("HOMEDRIVE", "")
    home_path = os.environ.get("HOMEPATH", "")
    if home_drive and home_path:
        candidates.append((home_drive + home_path, "<USER_HOME>"))
    for source, target in candidates:
        if source and len(source) >= 3:
            replacements.append((source, target))
    for source, target in sorted(replacements, key=lambda item: len(item[0]), reverse=True):
        text = re.sub(re.escape(source), target, text, flags=re.IGNORECASE)

    # Redact paths even when an old log contains a path outside the current home.
    text = re.sub(r"(?i)\b[A-Z]:\\(?:[^\\\r\n]+\\)*[^\\\r\n]*", "<WINDOWS_PATH>", text)
    text = re.sub(r"(?i)\\\\[^\\\s]+\\[^\\\s]+(?:\\[^\s]*)?", "<NETWORK_PATH>", text)
    text = re.sub(r"(?i)(window\s*=\s*)[^,\r\n]+", r"\1<WINDOW>", text)
    text = re.sub(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "<EMAIL>", text)
    return text.encode("utf-8")


def _redact_diagnostic_json(data: bytes, workspace: Path) -> bytes:
    """Parse JSON before redaction so escaped Windows paths cannot bypass filters."""
    try:
        parsed = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, TypeError):
        return _redact_diagnostic_text(data, workspace)

    def clean(value):
        if isinstance(value, str):
            return _redact_diagnostic_text(value.encode("utf-8"), workspace).decode("utf-8")
        if isinstance(value, list):
            return [clean(item) for item in value]
        if isinstance(value, dict):
            return {key: clean(item) for key, item in value.items()}
        return value

    return json.dumps(clean(parsed), ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def create_blackbox(workspace: Path, desktop: Path | None = None) -> Path:
    workspace = Path(workspace).resolve()
    if not workspace.exists() or not workspace.is_dir():
        raise OSError("工作文件夹不存在，无法生成黑匣子。")
    metadata = {
        "app_version": APP_VERSION,
        "created_local": datetime.now().astimezone().isoformat(timespec="seconds"),
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "workspace_files": [],
        "note": "Diagnostic bundle. No screenshots, account credentials, personal documents, or game memory are collected.",
    }
    names = ("agent.log", "agent.log.1", "model.json", "model.json.bak",
             "card_profiles.json", "run_summary.json")
    for name in names:
        path = workspace / name
        try:
            if path.is_file():
                metadata["workspace_files"].append({"name": name, "bytes": path.stat().st_size})
        except OSError:
            pass

    desktop_path = Path(desktop) if desktop is not None else _desktop_path()
    desktop_path.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output = desktop_path / f"ClashRoyale_Blackbox_{stamp}.zip"
    # Timestamp collisions are unlikely but must never overwrite a previous
    # diagnostic archive. The final archive is opened exclusively below, so
    # no .tmp/.part sidecar is ever created on the user's Desktop.

    def build(log_limit: int) -> bytes:
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, strict_timestamps=False) as archive:
            archive.writestr("blackbox.json", json.dumps(metadata, ensure_ascii=False, indent=2))
            for name in ("agent.log", "agent.log.1"):
                content = _tail(workspace / name, log_limit)
                if content:
                    archive.writestr(name, _redact_diagnostic_text(content, workspace))
            model = _whole_if_small(workspace / "model.json", 220_000)
            if model:
                archive.writestr("model.json", _redact_diagnostic_json(model, workspace))
            backup = _whole_if_small(workspace / "model.json.bak", 220_000)
            if backup:
                archive.writestr("model.json.bak", _redact_diagnostic_json(backup, workspace))
            profiles = _whole_if_small(workspace / "card_profiles.json", 120_000)
            if profiles:
                archive.writestr("card_profiles.json", _redact_diagnostic_json(profiles, workspace))
            summary = _whole_if_small(workspace / "run_summary.json", 24_000)
            if summary:
                archive.writestr("run_summary.json", _redact_diagnostic_json(summary, workspace))
        return buffer.getvalue()

    data = build(360_000)
    for limit in (160_000, 64_000, 16_000, 4_000):
        if len(data) <= MAX_BYTES:
            break
        data = build(limit)
    if len(data) > MAX_BYTES:
        raise RuntimeError("黑匣子压缩包仍超过 1,000,000 字节；已取消写入。")

    # Create only the requested final .zip. Exclusive creation protects an
    # existing archive even if the system clock repeats the same timestamp.
    for suffix in range(100):
        candidate = output if suffix == 0 else output.with_name(
            f"{output.stem}_{suffix}{output.suffix}"
        )
        try:
            stream = candidate.open("xb")
        except FileExistsError:
            continue
        output = candidate
        break
    else:
        raise OSError("无法为黑匣子分配唯一文件名；未覆盖任何现有文件。")

    try:
        with stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if output.stat().st_size > MAX_BYTES:
            raise RuntimeError("黑匣子超过 1,000,000 字节；已取消写入。")
    except Exception:
        try:
            output.unlink()
        except OSError:
            pass
        raise
    return output
