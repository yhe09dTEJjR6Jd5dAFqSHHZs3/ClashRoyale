"""Create a privacy-conscious diagnostic ZIP on the real Windows Desktop."""
from __future__ import annotations

import ctypes
import io
import json
import os
import platform
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

from . import APP_VERSION

MAX_BYTES = 1_000_000  # stricter than 1 MiB


def _windows_desktop_path() -> Path | None:
    if os.name != "nt":
        return None
    try:
        class GUID(ctypes.Structure):
            _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                        ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]

        desktop_id = GUID(0xB4BFCC3A, 0xDB2C, 0x424C,
                          (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41))
        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        ole32 = ctypes.WinDLL("ole32", use_last_error=True)
        shell32.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), ctypes.c_uint32,
                                                ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar_p)]
        shell32.SHGetKnownFolderPath.restype = ctypes.c_long
        ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        result = ctypes.c_wchar_p()
        hr = shell32.SHGetKnownFolderPath(ctypes.byref(desktop_id), 0, None, ctypes.byref(result))
        if hr == 0 and result.value:
            value = Path(result.value)
            ole32.CoTaskMemFree(ctypes.cast(result, ctypes.c_void_p))
            return value
    except Exception:
        pass
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as key:
            value, _ = winreg.QueryValueEx(key, "Desktop")
        return Path(os.path.expandvars(value))
    except Exception:
        return None


def _desktop_path() -> Path:
    actual = _windows_desktop_path()
    if actual is not None and actual.exists() and actual.is_dir():
        return actual
    home = Path.home()
    candidates = [home / "Desktop", Path(os.environ.get("OneDrive", home / "OneDrive")) / "Desktop"]
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate
    raise OSError("找不到 Windows 桌面文件夹；未在其他目录偷偷创建黑匣子。")


def _tail(path: Path, limit: int) -> bytes | None:
    try:
        with path.open("rb") as stream:
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(max(0, size - limit), os.SEEK_SET)
            return stream.read(limit)
    except OSError:
        return None


def _whole_if_small(path: Path, limit: int) -> bytes | None:
    """Read at most limit+1 bytes, even if the file changes during collection."""
    try:
        with path.open("rb") as stream:
            data = stream.read(max(0, int(limit)) + 1)
        return data if len(data) <= limit else None
    except OSError:
        return None


def _redact_diagnostic_text(data: bytes, workspace: Path) -> bytes:
    """Remove common personal paths and window-title fragments from diagnostics."""
    text = data.decode("utf-8", errors="replace")
    replacements = []
    candidates = [
        (str(Path.home()), "<USER_HOME>"),
        (str(workspace.resolve()), "<WORKSPACE>"),
        (os.environ.get("USERPROFILE", ""), "<USER_HOME>"),
    ]
    home_drive = os.environ.get("HOMEDRIVE", "")
    home_path = os.environ.get("HOMEPATH", "")
    if home_drive and home_path:
        candidates.append((home_drive + home_path, "<USER_HOME>"))
    for source, target in candidates:
        if source and len(source) >= 3:
            replacements.append((source, target))
    for source, target in sorted(replacements, key=lambda item: len(item[0]), reverse=True):
        text = re.sub(re.escape(source), target, text, flags=re.IGNORECASE)

    # Redact paths even when an old log contains a path outside the current home.
    text = re.sub(r"(?i)\b[A-Z]:\\(?:[^\\\r\n]+\\)*[^\\\r\n]*", "<WINDOWS_PATH>", text)
    text = re.sub(r"(?i)\\\\[^\\\s]+\\[^\\\s]+(?:\\[^\s]*)?", "<NETWORK_PATH>", text)
    text = re.sub(r"(?i)(window\s*=\s*)[^,\r\n]+", r"\1<WINDOW>", text)
    text = re.sub(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "<EMAIL>", text)
    return text.encode("utf-8")


def _redact_diagnostic_json(data: bytes, workspace: Path) -> bytes:
    """Parse JSON before redaction so escaped Windows paths cannot bypass filters."""
    try:
        parsed = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, TypeError):
        return _redact_diagnostic_text(data, workspace)

    def clean(value):
        if isinstance(value, str):
            return _redact_diagnostic_text(value.encode("utf-8"), workspace).decode("utf-8")
        if isinstance(value, list):
            return [clean(item) for item in value]
        if isinstance(value, dict):
            return {key: clean(item) for key, item in value.items()}
        return value

    return json.dumps(clean(parsed), ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def create_blackbox(workspace: Path, desktop: Path | None = None) -> Path:
    """Create a privacy-conscious diagnostic ZIP on the real Windows Desktop.

    The current learner model and bounded card visual catalog are high-priority
    diagnostic artifacts. The semantic unit prototypes are included when they
    fit, because they explain local troop-recognition behavior. Optional logs,
    backups and profiles are reduced or omitted before the current model is
    dropped. The final archive is always
    <= 1,000,000 bytes.
    """
    workspace = Path(workspace).resolve()
    if not workspace.exists() or not workspace.is_dir():
        raise OSError("工作文件夹不存在，无法生成黑匣子。")

    base_metadata = {
        "app_version": APP_VERSION,
        "created_local": datetime.now().astimezone().isoformat(timespec="seconds"),
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "workspace_files": [],
        "omitted_files": [],
        "note": "Diagnostic bundle. No screenshots, account credentials, personal documents, or process memory are collected. Redacted local learning files may be included.",
    }

    # Match the application-owned persistence limits while avoiding unbounded
    # reads from a corrupted or user-modified workspace file.
    model = _whole_if_small(workspace / "model.json", 4_000_000)
    backup = _whole_if_small(workspace / "model.json.bak", 4_000_000)
    profiles = _whole_if_small(workspace / "card_profiles.json", 1_000_000)
    catalog = _whole_if_small(workspace / "card_catalog.json", 1_000_000)
    summary = _whole_if_small(workspace / "run_summary.json", 100_000)
    tactical_memory = _whole_if_small(workspace / "tactical_memory.json", 250_000)
    opponent_model = _whole_if_small(workspace / "opponent_model.json", 300_000)
    unit_visual_profiles = _whole_if_small(workspace / "unit_visual_profiles.json", 500_000)
    if model is not None:
        model = _redact_diagnostic_json(model, workspace)
    if backup is not None:
        backup = _redact_diagnostic_json(backup, workspace)
    if profiles is not None:
        profiles = _redact_diagnostic_json(profiles, workspace)
    if catalog is not None:
        catalog = _redact_diagnostic_json(catalog, workspace)
    if summary is not None:
        summary = _redact_diagnostic_json(summary, workspace)
    if tactical_memory is not None:
        tactical_memory = _redact_diagnostic_json(tactical_memory, workspace)
    if opponent_model is not None:
        opponent_model = _redact_diagnostic_json(opponent_model, workspace)
    if unit_visual_profiles is not None:
        unit_visual_profiles = _redact_diagnostic_json(unit_visual_profiles, workspace)

    def original_size(name: str) -> int | None:
        try:
            return (workspace / name).stat().st_size
        except OSError:
            return None

    desktop_path = Path(desktop) if desktop is not None else _desktop_path()
    desktop_path.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output = desktop_path / f"ClashRoyale_Blackbox_{stamp}.zip"

    def build(log_limit: int, *, include_backup: bool, include_profiles: bool,
              include_summary: bool, include_model: bool = True,
              include_catalog: bool = True, include_learning: bool = True) -> bytes:
        entries: list[tuple[str, bytes]] = []
        omitted: list[str] = []
        truncated: list[str] = []

        # Preserve the current model first.  It is much more useful than a long
        # log tail when diagnosing learning/persistence problems.
        if include_model and model is not None:
            entries.append(("model.json", model))
        elif original_size("model.json") is not None:
            omitted.append("model.json")

        if include_backup and backup is not None:
            entries.append(("model.json.bak", backup))
        elif original_size("model.json.bak") is not None:
            omitted.append("model.json.bak")

        if include_profiles and profiles is not None:
            entries.append(("card_profiles.json", profiles))
        elif original_size("card_profiles.json") is not None:
            omitted.append("card_profiles.json")

        if include_catalog and catalog is not None:
            entries.append(("card_catalog.json", catalog))
        elif original_size("card_catalog.json") is not None:
            omitted.append("card_catalog.json")

        if include_learning and tactical_memory is not None:
            entries.append(("tactical_memory.json", tactical_memory))
        elif original_size("tactical_memory.json") is not None:
            omitted.append("tactical_memory.json")
        if include_learning and opponent_model is not None:
            entries.append(("opponent_model.json", opponent_model))
        elif original_size("opponent_model.json") is not None:
            omitted.append("opponent_model.json")

        if include_learning and unit_visual_profiles is not None:
            entries.append(("unit_visual_profiles.json", unit_visual_profiles))
        elif original_size("unit_visual_profiles.json") is not None:
            omitted.append("unit_visual_profiles.json")

        if include_summary and summary is not None:
            entries.append(("run_summary.json", summary))
        elif original_size("run_summary.json") is not None:
            omitted.append("run_summary.json")

        if log_limit > 0:
            for name in ("agent.log", "agent.log.1"):
                content = _tail(workspace / name, log_limit)
                if content:
                    entries.append((name, _redact_diagnostic_text(content, workspace)))
                    source_size = original_size(name)
                    if source_size is not None and source_size > len(content):
                        truncated.append(name)
                elif original_size(name) is not None:
                    omitted.append(name)
        else:
            omitted.extend(name for name in ("agent.log", "agent.log.1")
                           if original_size(name) is not None)

        metadata = dict(base_metadata)
        metadata["workspace_files"] = [
            {"name": name, "source_bytes": original_size(name),
             "included_bytes": len(content)} for name, content in entries
        ]
        metadata["omitted_files"] = sorted(set(omitted))
        metadata["truncated_files"] = sorted(set(truncated))

        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, strict_timestamps=False) as archive:
            archive.writestr("blackbox.json", json.dumps(metadata, ensure_ascii=False,
                                                           separators=(",", ":")))
            for name, content in entries:
                archive.writestr(name, content)
        return buffer.getvalue()

    # Reduce low-priority diagnostics first.  The active model remains included
    # in every normal fitting stage, including the final no-log stage.
    stages = (
        (360_000, True, True, True, True, True, True),
        (160_000, True, True, True, True, True, True),
        (64_000, True, True, True, True, True, True),
        (16_000, True, True, True, True, True, True),
        (4_000, True, True, True, True, True, True),
        (0, True, True, True, True, True, True),
        (0, False, True, True, True, True, True),
        (0, False, False, True, True, True, True),
        (0, False, False, False, True, True, True),
        (0, False, False, False, True, False, True),
        (0, False, False, False, True, False, False),
    )
    data = b""
    for (log_limit, keep_backup, keep_profiles, keep_summary,
         keep_model, keep_catalog, keep_learning) in stages:
        data = build(log_limit, include_backup=keep_backup,
                     include_profiles=keep_profiles, include_summary=keep_summary,
                     include_model=keep_model, include_catalog=keep_catalog,
                     include_learning=keep_learning)
        if len(data) <= MAX_BYTES:
            break
    if len(data) > MAX_BYTES:
        # A pathological/uncompressible current model must not violate the hard
        # output limit.  Emit a metadata-only diagnostic that clearly says why
        # the model was omitted rather than creating an oversized archive.
        data = build(0, include_backup=False, include_profiles=False,
                     include_summary=False, include_model=False, include_catalog=False,
                     include_learning=False)
    if len(data) > MAX_BYTES:
        raise RuntimeError("黑匣子压缩包仍超过 1,000,000 字节；已取消写入。")

    # Create only the requested final .zip. Exclusive creation protects an
    # existing archive even if the system clock repeats the same timestamp.
    for suffix in range(100):
        candidate = output if suffix == 0 else output.with_name(
            f"{output.stem}_{suffix}{output.suffix}"
        )
        try:
            stream = candidate.open("xb")
        except FileExistsError:
            continue
        output = candidate
        break
    else:
        raise OSError("无法为黑匣子分配唯一文件名；未覆盖任何现有文件。")

    try:
        with stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        if output.stat().st_size > MAX_BYTES:
            raise RuntimeError("黑匣子超过 1,000,000 字节；已取消写入。")
    except Exception:
        try:
            output.unlink()
        except OSError:
            pass
        raise
    return output
