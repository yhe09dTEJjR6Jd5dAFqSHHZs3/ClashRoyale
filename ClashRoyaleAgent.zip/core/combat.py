"""Data-driven, deterministic Clash Royale micro-combat simulator.

The simulator is deliberately a local *micro-simulation*, not a byte-perfect
reimplementation of Supercell's private game engine.  It uses a versioned,
level-11 stat snapshot, explicit target rules, movement, attack cadence,
projectile travel, shields, splash, death damage and tower fire.  Unknown
identity/level/health is represented as uncertainty rather than fabricated.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import math
from math import exp, hypot, tanh
from pathlib import Path
from typing import Iterable

from .cards import CardDatabase


PROFILE_VERSION = 1
LEVEL_SCALE = 1.10
MAX_PROFILE_BYTES = 128_000


@dataclass(frozen=True)
class CombatProfile:
    key: str
    hp: float | None
    damage: float | None
    dps: float | None
    hit_speed: float | None
    first_hit: float | None
    speed_units: float | None
    range_tiles: float | None
    targets: str
    transport: str
    count: int
    kind: str
    splash_radius: float
    projectile_speed: float | None
    deploy_time: float
    cast_time: float | None
    duration: float | None
    radius: float | None
    shield_hp: float
    tower_damage: float | None
    death_damage: float

    @property
    def is_air(self) -> bool:
        return self.transport.casefold() == "air"

    @property
    def is_building(self) -> bool:
        return self.kind.casefold() in ("building", "tower troop")

    @property
    def is_spell(self) -> bool:
        return self.kind.casefold() == "spell"

    @property
    def can_fight(self) -> bool:
        kind = self.kind.casefold()
        if kind == "building":
            # Passive spawners/collectors remain targetable even when they do
            # not have an attack profile of their own.
            return self.hp is not None and self.hp > 0
        return bool(
            kind in ("troop", "tower troop")
            and self.hp is not None and self.hp > 0
            and self.damage is not None and self.damage > 0
            and self.hit_speed is not None and self.hit_speed > 0
            and self.range_tiles is not None
        )


@dataclass(frozen=True)
class CombatEvaluation:
    score: float = 0.0
    confidence: float = 0.0
    damage_to_enemy: float = 0.0
    damage_to_friendly: float = 0.0
    enemy_kills: int = 0
    friendly_losses: int = 0
    horizon_seconds: float = 0.0
    reason: str = "insufficient semantic observations"


@dataclass
class _Unit:
    unit_id: int
    team: int  # 0 = friendly/player, 1 = opponent
    key: str
    profile: CombatProfile
    x: float
    y: float
    hp: float
    max_hp: float
    shield: float
    confidence: float
    cooldown: float
    deploy_delay: float = 0.0
    target_id: int | None = None
    alive: bool = True
    is_tower: bool = False
    beam_target: int | None = None
    beam_time: float = 0.0


@dataclass(frozen=True)
class _Projectile:
    impact_at: float
    source_team: int
    target_id: int
    source_id: int
    damage: float
    splash_radius: float


# Radius and timing values are kept explicit because card attributes encode
# different mechanics (e.g. Poison ticks, Arrows' three volleys, Freeze duration).
SPELL_RULES: dict[str, dict[str, float | str]] = {
    "arrows": {"radius": 3.5, "ticks": 3.0, "tick_interval": 0.08},
    "zap": {"radius": 2.5, "ticks": 1.0, "stun": 0.5},
    "giant-snowball": {"radius": 2.5, "ticks": 1.0, "slow": 2.0},
    "fireball": {"radius": 2.5, "ticks": 1.0},
    "rocket": {"radius": 2.0, "ticks": 1.0},
    "earthquake": {"radius": 3.5, "ticks": 3.0, "tick_interval": 0.8, "building_multiplier": 3.4},
    "vines": {"radius": 2.5, "ticks": 2.0, "tick_interval": 0.3},
    "freeze": {"radius": 3.0, "ticks": 1.0, "stun": 3.0},
    "poison": {"radius": 3.0, "ticks": 8.0, "tick_interval": 1.0},
    "lightning": {"radius": 3.5, "ticks": 1.0, "max_targets": 3.0},
    "the-log": {"radius": 10.1, "ticks": 1.0},
    "tornado": {"radius": 5.5, "ticks": 1.0, "pull": 1.05},
    "goblin-curse": {"radius": 3.0, "ticks": 6.0, "tick_interval": 1.0},
    "void": {"radius": 2.5, "ticks": 3.0, "tick_interval": 0.4},
    "rage": {"radius": 3.0, "ticks": 1.0, "duration": 4.5},
    "graveyard": {"radius": 4.0, "duration": 9.0, "mode": "spawn", "spawn_count": 12.0},
    "goblin-barrel": {"radius": 1.5, "duration": 1.1, "mode": "spawn", "spawn_count": 3.0},
    "barbarian-barrel": {"radius": 10.1, "duration": 0.5, "mode": "spawn", "spawn_count": 1.0},
    "royal-delivery": {"radius": 3.0, "duration": 3.0, "mode": "spawn",
                       "spawn_count": 1.0, "impact_damage": 240.0},
    "clone": {"radius": 3.0, "ticks": 1.0, "clone": 1.0},
}


class CombatDatabase:
    """Read-only combat stat snapshot bundled with the application."""

    def __init__(self, path: Path | None = None, card_database: CardDatabase | None = None):
        self.path = Path(path) if path is not None else (
            Path(__file__).resolve().parents[1] / "data" / "combat_profiles.tsv"
        )
        self.card_database = card_database or CardDatabase()
        self.profiles: dict[str, CombatProfile] = {}
        self.load_error = ""
        self._load()

    @staticmethod
    def _number(value: str, *, minimum: float = 0.0, maximum: float = 100_000.0) -> float | None:
        value = str(value or "").strip()
        if not value:
            return None
        try:
            number = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        if number != number or abs(number) == float("inf") or not minimum <= number <= maximum:
            return None
        return number

    def _load(self) -> None:
        try:
            if self.path.stat().st_size > MAX_PROFILE_BYTES:
                raise ValueError("combat profile file exceeds size limit")
            rows = self.path.read_text(encoding="utf-8-sig").splitlines()
            profiles: dict[str, CombatProfile] = {}
            for line_number, line in enumerate(rows, 1):
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                parts = line.split("|")
                if len(parts) > 21:
                    raise ValueError(f"too many fields on combat profile row {line_number}")
                parts.extend([""] * (21 - len(parts)))
                (key, hp, damage, dps, hit, first, speed, reach, targets, transport,
                 count, kind, splash, projectile, deploy, cast, duration, radius,
                 shield, tower, death) = parts
                key = key.strip().lower()
                if not key or key in profiles:
                    raise ValueError(f"invalid or duplicate combat profile row {line_number}")
                parsed_count = self._number(count, minimum=0, maximum=100)
                profiles[key] = CombatProfile(
                    key=key,
                    hp=self._number(hp),
                    damage=self._number(damage),
                    dps=self._number(dps),
                    hit_speed=self._number(hit, minimum=0.05, maximum=30),
                    first_hit=self._number(first, minimum=0, maximum=30),
                    speed_units=self._number(speed, minimum=0, maximum=1000),
                    range_tiles=self._number(reach, minimum=0, maximum=20),
                    targets=targets.strip(),
                    transport=transport.strip(),
                    count=max(1, min(30, int(parsed_count or 1))),
                    kind=kind.strip(),
                    splash_radius=self._number(splash, minimum=0, maximum=20) or 0.0,
                    projectile_speed=self._number(projectile, minimum=0, maximum=100_000),
                    deploy_time=self._number(deploy, minimum=0, maximum=20) or 0.0,
                    cast_time=self._number(cast, minimum=0, maximum=20),
                    duration=self._number(duration, minimum=0, maximum=60),
                    radius=self._number(radius, minimum=0, maximum=20),
                    shield_hp=self._number(shield, minimum=0) or 0.0,
                    tower_damage=self._number(tower, minimum=0),
                    death_damage=self._number(death, minimum=0) or 0.0,
                )
            if len(profiles) < 110:
                raise ValueError("combat profile snapshot is incomplete")
            self.profiles = profiles
            self.load_error = ""
        except (OSError, UnicodeError, ValueError) as exc:
            self.profiles = {}
            self.load_error = str(exc)[:240]

    def __len__(self) -> int:
        return len(self.profiles)

    def base(self, key: str) -> CombatProfile | None:
        return self.profiles.get(str(key or "").strip().lower())

    def get(self, key: str, *, form: str = "base", level: int | None = 11) -> tuple[CombatProfile | None, float]:
        profile = self.base(key)
        if profile is None:
            return None, 0.0
        level_known = isinstance(level, int) and not isinstance(level, bool) and 1 <= level <= 16
        level = int(level) if level_known else 11
        scale = LEVEL_SCALE ** (level - 11)
        scaled = replace(
            profile,
            hp=profile.hp * scale if profile.hp is not None else None,
            damage=profile.damage * scale if profile.damage is not None else None,
            dps=profile.dps * scale if profile.dps is not None else None,
            shield_hp=profile.shield_hp * scale,
            tower_damage=profile.tower_damage * scale if profile.tower_damage is not None else None,
            death_damage=profile.death_damage * scale,
        )
        form = str(form or "base").casefold()
        # This snapshot contains base-form stats. An evolved/hero form uses the
        # base profile as a fallback only and is explicitly down-weighted.
        form_confidence = 1.0 if form in ("base", "normal", "") else 0.66
        level_confidence = 1.0 if level_known else 0.72
        mixed_spawn_confidence = {
            "goblin-gang": 0.78, "rascals": 0.72, "skeleton-barrel": 0.78,
            "elixir-golem": 0.72, "golem": 0.82, "lava-hound": 0.82,
            "phoenix": 0.82, "royal-recruits": 0.86,
        }.get(profile.key, 1.0)
        return scaled, form_confidence * level_confidence * mixed_spawn_confidence


class CombatSimulator:
    """Compare a candidate deployment with the same skirmish without it."""

    DT = 0.16
    HORIZON = 3.8
    MAX_UNITS = 48
    TILE_WIDTH = 18.0
    TILE_HEIGHT = 32.0

    def __init__(self, database: CombatDatabase | None = None,
                 card_database: CardDatabase | None = None):
        self.card_database = card_database or (database.card_database if database else CardDatabase())
        self.database = database or CombatDatabase(card_database=self.card_database)
        self._baseline_state = None
        self._baseline_units: list[_Unit] = []
        self._baseline_metrics = (0.0, 0.0, 0, 0)
        self._river_y = 0.575
        # Default crop matches the bundled arena detector's normalized vertical
        # extent (roughly 0.35..0.80 of the captured game window).
        self._tower_geometry = (0.31, 0.69, 0.39, 0.76)
        self._tower_profile = CombatProfile(
            key="tower-princess", hp=3052, damage=109, dps=136,
            hit_speed=0.80, first_hit=0.35, speed_units=0,
            range_tiles=7.5, targets="Air & Ground", transport="Ground",
            count=1, kind="Tower Troop", splash_radius=0.0,
            projectile_speed=1000, deploy_time=0.0, cast_time=None,
            duration=None, radius=None, shield_hp=0.0,
            tower_damage=None, death_damage=0.0,
        )

    @classmethod
    def _distance(cls, a: _Unit, b: _Unit) -> float:
        return hypot((a.x - b.x) * cls.TILE_WIDTH, (a.y - b.y) * cls.TILE_HEIGHT)

    def _movement_waypoint(self, unit: _Unit, target: _Unit) -> tuple[float, float]:
        """Route ground units through one of the two bridge corridors.

        The normalized arena is not a full navigation mesh, but this prevents
        ground units from taking physically impossible straight paths through
        the river. Air units and buildings retain direct/no movement behavior.
        """
        if unit.profile.is_air or unit.profile.is_building:
            return target.x, target.y
        river_y = self._river_y
        if abs(unit.y - river_y) <= 0.035:
            return target.x, target.y
        source_friendly_side = unit.y >= river_y
        target_friendly_side = target.y >= river_y
        if source_friendly_side == target_friendly_side:
            return target.x, target.y
        left_x, right_x, _enemy_y, _friendly_y = self._tower_geometry
        bridge_x = left_x if target.x < (left_x + right_x) / 2.0 else right_x
        return bridge_x, river_y

    @staticmethod
    def _can_target(attacker: _Unit, target: _Unit) -> bool:
        if attacker.team == target.team or not target.alive:
            return False
        target_rule = attacker.profile.targets.casefold().replace(" ", "")
        if "buildings" in target_rule or target_rule == "building":
            return target.is_tower or target.profile.is_building
        allows_air = "air" in target_rule
        allows_ground = "ground" in target_rule
        if allows_air and allows_ground:
            return True
        if allows_air:
            return target.profile.is_air
        if allows_ground:
            return not target.profile.is_air
        return not target.profile.is_air

    @staticmethod
    def _damage_unit(target: _Unit, damage: float) -> float:
        damage = max(0.0, damage)
        absorbed = min(target.shield, damage)
        target.shield -= absorbed
        damage -= absorbed
        dealt = min(target.hp, damage)
        target.hp -= dealt
        if target.hp <= 0.0 and target.alive:
            target.alive = False
        return absorbed + dealt

    def _make_units(self, state, *, candidate: tuple[str, str, int | None, float, float] | None = None) -> list[_Unit]:
        units: list[_Unit] = []
        next_id = 1
        bounds = getattr(state, "arena_bounds", None)
        if (isinstance(bounds, (tuple, list)) and len(bounds) == 4 and
                all(isinstance(value, (int, float)) for value in bounds)):
            ax0, ay0, ax1, ay1 = (float(value) for value in bounds)
            arena_w, arena_h = max(0.1, ax1 - ax0), max(0.1, ay1 - ay0)
            left_x, right_x = ax0 + arena_w * 0.31, ax0 + arena_w * 0.69
            enemy_y, friendly_y = ay0 + arena_h * 0.09, ay0 + arena_h * 0.91
            self._river_y = ay0 + arena_h * 0.50
            self._tower_geometry = (left_x, right_x, enemy_y, friendly_y)
        else:
            self._river_y = 0.575
            self._tower_geometry = (0.31, 0.69, 0.39, 0.76)
        for team, semantic_units in (
            (1, getattr(state, "semantic_enemy_units", ())),
            (0, getattr(state, "semantic_friendly_units", ())),
        ):
            for semantic in semantic_units:
                if len(units) >= self.MAX_UNITS - 6:
                    break
                confidence = float(getattr(semantic, "confidence", 0.0))
                if confidence < 0.58:
                    continue
                key = str(getattr(semantic, "card_key", ""))
                form = str(getattr(semantic, "form", "base"))
                level = getattr(semantic, "level", None)
                profile, data_confidence = self.database.get(key, form=form, level=level)
                if profile is None or not profile.can_fight:
                    continue
                hp_ratio = getattr(semantic, "health_ratio", None)
                health_conf = float(getattr(semantic, "health_confidence", 0.0) or 0.0)
                if (not isinstance(hp_ratio, (int, float)) or
                        not 0.08 <= float(hp_ratio) <= 1.0 or health_conf < 0.55):
                    hp_ratio = 0.82
                    health_confidence = 0.62
                else:
                    hp_ratio = float(hp_ratio)
                    health_confidence = min(1.0, health_conf)
                hp = max(1.0, float(profile.hp or 1.0) * hp_ratio)
                count = max(1, min(6, profile.count))
                for index in range(count):
                    spread = (index - (count - 1) / 2.0) * 0.006
                    cooldown = profile.first_hit if profile.first_hit is not None else 0.35
                    units.append(_Unit(
                        next_id, team, key, profile,
                        max(0.03, min(0.97, float(semantic.x) + spread)),
                        max(0.03, min(0.97, float(semantic.y))),
                        hp, float(profile.hp or hp), profile.shield_hp,
                        confidence * data_confidence * health_confidence,
                        max(0.0, cooldown),
                    ))
                    next_id += 1

        if candidate is not None:
            key, form, level, x, y = candidate
            profile, data_confidence = self.database.get(key, form=form, level=level)
            if profile is not None and profile.can_fight:
                count = max(1, min(8, profile.count))
                for index in range(count):
                    spread = (index - (count - 1) / 2.0) * 0.008
                    units.append(_Unit(
                        next_id, 0, key, profile,
                        max(0.03, min(0.97, x + spread)),
                        max(0.03, min(0.97, y)),
                        float(profile.hp or 1.0), float(profile.hp or 1.0),
                        profile.shield_hp, data_confidence,
                        max(0.0, profile.first_hit if profile.first_hit is not None else 0.35),
                        deploy_delay=profile.deploy_time,
                    ))
                    next_id += 1

        # A conservative Princess Tower proxy provides a real target for
        # building-targeting win conditions and a defensive DPS source. It is
        # identical in both baseline and candidate simulations, so candidate
        # comparisons are not dominated by an arbitrary tower assumption.
        left_tower_x, right_tower_x, enemy_tower_y, friendly_tower_y = self._tower_geometry
        for team, y in ((0, friendly_tower_y), (1, enemy_tower_y)):
            for x in (left_tower_x, right_tower_x):
                units.append(_Unit(
                    next_id, team, "tower-princess", self._tower_profile,
                    x, y, 3052.0, 3052.0, 0.0, 0.70, 0.30,
                    is_tower=True,
                ))
                next_id += 1
        return units[:self.MAX_UNITS]

    def _run(self, units: list[_Unit], *, horizon_seconds: float | None = None) -> tuple[float, float, int, int]:
        units = [replace(unit) for unit in units]
        horizon = self.HORIZON if horizon_seconds is None else max(self.HORIZON, float(horizon_seconds))
        projectiles: list[_Projectile] = []
        time_now = 0.0
        damage_to_enemy = 0.0
        damage_to_friendly = 0.0
        enemy_kills = 0
        friendly_losses = 0
        while time_now <= horizon + 1e-6:
            # Resolve projectiles before selecting the next attack target.
            pending: list[_Projectile] = []
            for projectile in projectiles:
                if projectile.impact_at > time_now + 1e-6:
                    pending.append(projectile)
                    continue
                target = next((u for u in units if u.unit_id == projectile.target_id and u.alive), None)
                if target is None:
                    continue
                targets = [target]
                if projectile.splash_radius > 0.0:
                    source = next((u for u in units if u.unit_id == projectile.source_id), None)
                    if source is not None:
                        targets = [u for u in units if u.alive and u.team != projectile.source_team
                                   and self._distance(target, u) <= projectile.splash_radius]
                for victim in targets:
                    dealt = self._damage_unit(victim, projectile.damage)
                    if projectile.source_team == 0:
                        damage_to_enemy += dealt
                    else:
                        damage_to_friendly += dealt
                    if not victim.alive:
                        if victim.team == 1:
                            enemy_kills += 1
                        else:
                            friendly_losses += 1
                        death = victim.profile.death_damage
                        if death > 0:
                            for nearby in units:
                                if nearby.alive and nearby.team != victim.team and self._distance(victim, nearby) <= 1.5:
                                    death_dealt = self._damage_unit(nearby, death)
                                    if victim.team == 0:
                                        damage_to_enemy += death_dealt
                                    else:
                                        damage_to_friendly += death_dealt
                                    if not nearby.alive:
                                        if nearby.team == 1:
                                            enemy_kills += 1
                                        else:
                                            friendly_losses += 1
            projectiles = pending

            for unit in units:
                if not unit.alive or unit.deploy_delay > time_now:
                    continue
                if unit.cooldown > 0:
                    unit.cooldown = max(0.0, unit.cooldown - self.DT)
                enemies = [other for other in units if self._can_target(unit, other)]
                if not enemies:
                    continue
                target = next((other for other in enemies if other.unit_id == unit.target_id), None)
                if target is None:
                    target = min(enemies, key=lambda other: self._distance(unit, other))
                    unit.target_id = target.unit_id
                distance = self._distance(unit, target)
                reach = float(unit.profile.range_tiles or 0.5) + 0.28
                if distance > reach:
                    if not unit.profile.is_building:
                        speed = float(unit.profile.speed_units or 60.0) / 60.0 * 0.75
                        step = speed * self.DT
                        if step > 0:
                            waypoint_x, waypoint_y = self._movement_waypoint(unit, target)
                            dx = (waypoint_x - unit.x) * self.TILE_WIDTH
                            dy = (waypoint_y - unit.y) * self.TILE_HEIGHT
                            length = max(1e-6, hypot(dx, dy))
                            unit.x = max(0.02, min(0.98, unit.x + dx / length * step / self.TILE_WIDTH))
                            unit.y = max(0.02, min(0.98, unit.y + dy / length * step / self.TILE_HEIGHT))
                    continue
                if (unit.cooldown > 1e-6 or unit.profile.damage is None
                        or unit.profile.hit_speed is None or unit.profile.range_tiles is None):
                    continue
                damage = float(unit.profile.damage or 0.0)
                # Inferno ramp is modelled as a bounded three-stage beam; it
                # resets whenever the target changes or disappears.
                if unit.key in ("inferno-dragon", "inferno-tower"):
                    if unit.beam_target != target.unit_id:
                        unit.beam_target, unit.beam_time = target.unit_id, 0.0
                    multiplier = 1.0 if unit.beam_time < 1.0 else 2.5 if unit.beam_time < 2.0 else 5.0
                    damage *= multiplier
                    unit.beam_time += unit.profile.hit_speed or self.DT
                else:
                    unit.beam_target, unit.beam_time = None, 0.0
                projectile_speed = float(unit.profile.projectile_speed or 0.0)
                travel = (distance / max(1.0, projectile_speed / 100.0)) if projectile_speed > 0 else 0.0
                projectiles.append(_Projectile(
                    time_now + travel, unit.team, target.unit_id, unit.unit_id,
                    damage, unit.profile.splash_radius,
                ))
                unit.cooldown = max(self.DT, float(unit.profile.hit_speed or 1.0))
            time_now += self.DT
        return damage_to_enemy, damage_to_friendly, enemy_kills, friendly_losses

    def evaluate_deployment(self, state, card_key: str, *, form: str = "base",
                            level: int | None = None, x: float, y: float) -> CombatEvaluation:
        profile, data_confidence = self.database.get(card_key, form=form, level=level)
        if profile is None or not profile.can_fight:
            return CombatEvaluation(reason="card has no supported troop/building combat profile")
        enemies = [u for u in getattr(state, "semantic_enemy_units", ()) if u.confidence >= 0.58]
        friendlies = [u for u in getattr(state, "semantic_friendly_units", ()) if u.confidence >= 0.58]
        if not enemies:
            return CombatEvaluation(reason="no semantically identified enemy units")
        if self._baseline_state is not state:
            self._baseline_state = state
            self._baseline_units = self._make_units(state)
            self._baseline_metrics = self._run(self._baseline_units)
        baseline_units = self._baseline_units
        base_enemy, base_friendly, base_kills, base_losses = self._baseline_metrics
        candidate_units = [replace(unit) for unit in baseline_units]
        next_id = max((unit.unit_id for unit in candidate_units), default=0) + 1
        count = max(1, min(8, profile.count))
        for index in range(count):
            spread = (index - (count - 1) / 2.0) * 0.008
            candidate_units.append(_Unit(
                next_id, 0, card_key, profile,
                max(0.03, min(0.97, x + spread)), max(0.03, min(0.97, y)),
                float(profile.hp or 1.0), float(profile.hp or 1.0),
                profile.shield_hp, data_confidence,
                max(0.0, profile.first_hit if profile.first_hit is not None else 0.35),
                deploy_delay=profile.deploy_time,
            ))
            next_id += 1
        if len(candidate_units) <= len(baseline_units):
            return CombatEvaluation(reason="candidate could not be represented by combat data")
        with_enemy, with_friendly, with_kills, with_losses = self._run(candidate_units)
        delta_enemy = with_enemy - base_enemy
        delta_friendly = with_friendly - base_friendly
        delta_kills = with_kills - base_kills
        delta_losses = with_losses - base_losses
        # Positive means the candidate improved the exchange relative to holding.
        net = delta_enemy - delta_friendly + delta_kills * 260.0 - delta_losses * 300.0
        score = tanh(net / 650.0)
        semantic_confidence = sum(float(u.confidence) for u in enemies) / max(1, len(enemies))
        form_factor = data_confidence
        coverage = min(1.0, len(enemies) / 2.0)
        confidence = max(0.0, min(0.92, semantic_confidence * form_factor * (0.55 + 0.45 * coverage)))
        return CombatEvaluation(
            score=score, confidence=confidence,
            damage_to_enemy=max(0.0, delta_enemy),
            damage_to_friendly=max(0.0, delta_friendly),
            enemy_kills=max(0, delta_kills), friendly_losses=max(0, delta_losses),
            horizon_seconds=self.HORIZON,
            reason="candidate-vs-hold micro-simulation with observed semantic units",
        )

    def _evaluate_spawn_spell(self, state, card_key: str, profile: CombatProfile,
                              rule: dict[str, float | str], *, x: float, y: float,
                              data_confidence: float) -> CombatEvaluation:
        enemies = [u for u in getattr(state, "semantic_enemy_units", ()) if u.confidence >= 0.58]
        units = self._make_units(state)
        radius = float(rule.get("radius", 2.0))
        local_enemies = [unit for unit in enemies
                         if hypot((float(unit.x) - x) * self.TILE_WIDTH,
                                  (float(unit.y) - y) * self.TILE_HEIGHT) <= radius]
        left_tower_x, right_tower_x, enemy_tower_y, _friendly_tower_y = self._tower_geometry
        arena_height = (max(0.1, float(state.arena_bounds[3]) - float(state.arena_bounds[1]))
                        if getattr(state, "arena_bounds", None) is not None else 0.45)
        tower_target = (y <= enemy_tower_y + arena_height * 0.20 and
                        min(abs(x - left_tower_x), abs(x - right_tower_x)) <= 0.20)
        if not local_enemies and not tower_target:
            return CombatEvaluation(reason="spawn spell has no verified troop cluster or enemy-tower lane")
        count = max(1, min(12, int(float(rule.get("spawn_count", profile.count)))))
        duration = max(0.0, min(9.0, float(rule.get("duration", profile.deploy_time))))
        simulation_horizon = max(self.HORIZON, duration + 1.0) if card_key == "graveyard" else self.HORIZON
        baseline = self._run(units, horizon_seconds=simulation_horizon)
        next_id = max((unit.unit_id for unit in units), default=0) + 1
        for index in range(count):
            angle = 2.0 * math.pi * index / max(1, count)
            # Spread spawns in a small deterministic ring. Graveyard skeletons
            # arrive over time; one-shot barrel/delivery spawns use their cast delay.
            spread = min(0.035, radius / max(self.TILE_WIDTH, self.TILE_HEIGHT) * 0.35)
            spawn_x = max(0.03, min(0.97, x + math.cos(angle) * spread))
            spawn_y = max(0.03, min(0.97, y + math.sin(angle) * spread))
            delay = duration * (index + 1) / count if card_key == "graveyard" else profile.deploy_time
            units.append(_Unit(
                next_id, 0, card_key, profile, spawn_x, spawn_y,
                float(profile.hp or 1.0), float(profile.hp or 1.0),
                profile.shield_hp, data_confidence * 0.72,
                max(0.0, profile.first_hit if profile.first_hit is not None else 0.35),
                deploy_delay=max(0.0, float(delay)),
            ))
            next_id += 1
        with_spawn = self._run(units, horizon_seconds=simulation_horizon)
        delta_enemy = with_spawn[0] - baseline[0]
        delta_friendly = with_spawn[1] - baseline[1]
        delta_kills = with_spawn[2] - baseline[2]
        delta_losses = with_spawn[3] - baseline[3]
        impact_damage = max(0.0, float(rule.get("impact_damage", 0.0)))
        if impact_damage and (local_enemies or tower_target):
            if local_enemies:
                delta_enemy += sum(
                    min(float(self.database.get(unit.card_key, form=unit.form, level=unit.level)[0].hp or 0.0),
                        impact_damage)
                    for unit in local_enemies
                    if self.database.get(unit.card_key, form=unit.form, level=unit.level)[0] is not None
                )
            elif tower_target:
                delta_enemy += impact_damage
        # Spawn spells are designed to trade expendable summoned units for
        # tower/troop damage. Their spawned-unit losses are therefore discounted
        # relative to losing a persistent defensive troop.
        net = delta_enemy - 0.03 * delta_friendly + delta_kills * 180.0 - delta_losses * 2.0
        score = tanh(net / 650.0)
        evidence = (sum(unit.confidence for unit in local_enemies) / len(local_enemies)
                    if local_enemies else 0.66)
        confidence = max(0.0, min(0.78, data_confidence * evidence *
                                  (0.95 if tower_target else 0.88)))
        return CombatEvaluation(
            score=score, confidence=confidence,
            damage_to_enemy=max(0.0, delta_enemy),
            damage_to_friendly=max(0.0, delta_friendly),
            enemy_kills=max(0, delta_kills), friendly_losses=max(0, delta_losses),
            horizon_seconds=simulation_horizon,
            reason="spawn-spell micro-simulation with staged deployment and bridge-aware movement",
        )

    def evaluate_spell(self, state, card_key: str, *, x: float, y: float,
                       level: int | None = None) -> CombatEvaluation:
        profile, data_confidence = self.database.get(card_key, level=level)
        rule = SPELL_RULES.get(card_key)
        if profile is None or rule is None:
            return CombatEvaluation(reason="spell profile/radius is not verified")
        if rule.get("mode") == "spawn":
            return self._evaluate_spawn_spell(
                state, card_key, profile, rule, x=x, y=y,
                data_confidence=data_confidence,
            )

        # Rage and Clone are friendly-target spells; their value comes from
        # the troops they affect, not damage to enemy units.
        if card_key in ("rage", "clone"):
            friendlies = [u for u in getattr(state, "semantic_friendly_units", ()) if u.confidence >= 0.58]
            radius = float(rule["radius"])
            affected = [u for u in friendlies if hypot((float(u.x) - x) * self.TILE_WIDTH,
                                                        (float(u.y) - y) * self.TILE_HEIGHT) <= radius]
            if not affected:
                return CombatEvaluation(reason="no identified friendly unit inside spell radius")
            value = 0.0
            for unit in affected:
                unit_profile, _ = self.database.get(unit.card_key, form=unit.form, level=unit.level)
                if unit_profile is None:
                    continue
                dps = float(unit_profile.dps or 0.0)
                if not dps and unit_profile.damage and unit_profile.hit_speed:
                    dps = unit_profile.damage / unit_profile.hit_speed
                if card_key == "rage":
                    value += dps * float(rule.get("duration", 4.5)) * 0.28
                else:
                    value += max(80.0, float(unit_profile.hp or 0.0) * 0.32 + dps * 2.0)
            confidence = min(0.90, data_confidence *
                             sum(u.confidence for u in affected) / len(affected))
            return CombatEvaluation(
                score=tanh(value / 850.0), confidence=confidence,
                damage_to_enemy=0.0, damage_to_friendly=0.0,
                horizon_seconds=float(rule.get("duration", 0.0)),
                reason="semantic friendly-unit buff/clone coverage estimate",
            )

        if profile.damage is None:
            return CombatEvaluation(reason="spell damage profile is not available")
        enemies = [u for u in getattr(state, "semantic_enemy_units", ()) if u.confidence >= 0.58]
        if not enemies:
            return CombatEvaluation(reason="no semantically identified enemy units")
        radius = float(rule["radius"])
        ticks = float(rule.get("ticks", 1.0))
        base_damage = float(profile.damage) * ticks
        max_targets = int(rule.get("max_targets", 99))
        ranked = []
        for unit in enemies:
            dx = (float(unit.x) - x) * self.TILE_WIDTH
            dy = (float(unit.y) - y) * self.TILE_HEIGHT
            if card_key == "the-log":
                # The Log is a narrow lane projectile, not a circular area spell.
                distance = abs(dx) if abs(dx) <= 0.72 and abs(dy) <= 10.1 else 999.0
            else:
                distance = hypot(dx, dy)
            if distance <= radius:
                ranked.append((distance, unit))
        ranked.sort(key=lambda pair: pair[0])
        hits = ranked[:max_targets]
        if not hits:
            return CombatEvaluation(reason="no identified enemy inside spell area")
        value = 0.0
        for _distance, unit in hits:
            unit_profile, _ = self.database.get(unit.card_key, form=unit.form, level=unit.level)
            if unit_profile is None:
                continue
            hp = float(unit_profile.hp or 1.0)
            if isinstance(unit.health_ratio, (int, float)) and 0.08 <= unit.health_ratio <= 1.0:
                hp *= float(unit.health_ratio)
            multiplier = float(rule.get("building_multiplier", 1.0)) if unit_profile.is_building else 1.0
            dealt = min(hp, base_damage * multiplier)
            dps = float(unit_profile.dps or 0.0)
            control_value = 0.0
            if "stun" in rule:
                control_value += dps * float(rule["stun"]) * 0.28
            if "slow" in rule:
                control_value += dps * float(rule["slow"]) * 0.16
            if "pull" in rule:
                control_value += dps * float(rule["pull"]) * 0.18
            if card_key == "vines":
                control_value += dps * 1.8 * 0.20
            value += (dealt + control_value) * (1.0 + min(1.0, hp / 1800.0) * 0.35)
        confidence = min(0.92, data_confidence * sum(u.confidence for _d, u in hits) / len(hits))
        return CombatEvaluation(
            score=tanh(value / 850.0), confidence=confidence,
            damage_to_enemy=value, horizon_seconds=float(rule.get("duration", 0.0)),
            reason="semantic area-spell damage/control estimate",
        )

