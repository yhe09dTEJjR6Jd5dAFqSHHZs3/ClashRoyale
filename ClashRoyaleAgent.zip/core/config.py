"""Validated, atomic persistence for the user's selected workspace settings."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .win32 import key_to_vk

CONFIG_NAME = "config.json"
MAX_CONFIG_BYTES = 16_384


def load_config(workspace: Path) -> dict[str, str]:
    """Load only recognized settings; malformed or stale data safely defaults."""
    path = Path(workspace) / CONFIG_NAME
    try:
        if path.stat().st_size > MAX_CONFIG_BYTES:
            return {}
        raw: Any = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}
    if not isinstance(raw, dict):
        return {}

    result: dict[str, str] = {}
    stop_key = raw.get("stop_key")
    if isinstance(stop_key, str) and len(stop_key) <= 32 and key_to_vk(stop_key) is not None:
        result["stop_key"] = stop_key.strip().upper()

    for key in ("window_title", "window_class"):
        value = raw.get(key)
        if isinstance(value, str) and value.strip():
            result[key] = value.strip()[:512]
    return result


def save_config(workspace: Path, *, stop_key: str, window_title: str,
                window_class: str, app_version: str) -> Path:
    """Atomically save the existing UI settings inside the chosen workspace."""
    workspace = Path(workspace)
    workspace.mkdir(parents=True, exist_ok=True)
    if key_to_vk(stop_key) is None:
        raise ValueError("Invalid stop key.")
    payload = {
        "stop_key": stop_key.strip().upper(),
        "window_title": str(window_title)[:512],
        "window_class": str(window_class)[:512],
        "app_version": str(app_version)[:32],
    }
    target = workspace / CONFIG_NAME
    temp = target.with_suffix(target.suffix + ".tmp")
    try:
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, target)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass
    return target
