"""Pure Win32 UI fallback for Python installations without Tcl/Tk.

The normal interface remains Tk-based when Tcl/Tk is available.  This module
uses only ctypes and the Windows common-controls library, so Python 3.10–3.15 x64
installations that omit the optional Tk component can still run the application.
"""
from __future__ import annotations

import ctypes
import os
import queue
import tempfile
import threading
from pathlib import Path

from . import APP_VERSION
from .agent import ClashRoyaleAgent
from .blackbox import create_blackbox
from .config import load_config, save_config
from .runtime import runtime_support_error
from .tray import TrayIcon
from .win32 import (
    capture_window,
    focus_window,
    key_to_vk,
    list_game_windows,
    set_dpi_awareness,
    window_identity_matches,
    window_is_valid,
    window_process_id,
    window_process_path,
)


WM_CREATE = 0x0001
WM_DESTROY = 0x0002
WM_CLOSE = 0x0010
WM_COMMAND = 0x0111
WM_TIMER = 0x0113
WM_SETFONT = 0x0030
WM_APP_AGENT_STOPPED = 0x8001

WS_OVERLAPPED = 0x00000000
WS_CAPTION = 0x00C00000
WS_SYSMENU = 0x00080000
WS_MINIMIZEBOX = 0x00020000
WS_CHILD = 0x40000000
WS_VISIBLE = 0x10000000
WS_TABSTOP = 0x00010000
WS_BORDER = 0x00800000
ES_READONLY = 0x00000800
ES_AUTOHSCROLL = 0x00000080
CBS_DROPDOWNLIST = 0x0003
CBS_HASSTRINGS = 0x0200
WS_VSCROLL = 0x00200000

SW_HIDE = 0
SW_SHOW = 5
SW_RESTORE = 9
CW_USEDEFAULT = -2147483648
DEFAULT_GUI_FONT = 17
IDC_ARROW = 32512

CB_ADDSTRING = 0x0143
CB_SETCURSEL = 0x014E
CB_GETCURSEL = 0x0147

HKM_SETHOTKEY = 0x0401
HKM_GETHOTKEY = 0x0402
ICC_HOTKEY_CLASS = 0x00000040

ID_FOLDER = 201
ID_BROWSE = 202
ID_WINDOW = 203
ID_HOTKEY = 204
ID_START = 205
ID_BLACKBOX = 206
ID_STATUS = 207

TIMER_REFRESH = 1
TIMER_EVENTS = 2


class _MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", ctypes.c_void_p),
        ("message", ctypes.c_uint32),
        ("wParam", ctypes.c_size_t),
        ("lParam", ctypes.c_ssize_t),
        ("time", ctypes.c_uint32),
        ("pt_x", ctypes.c_long),
        ("pt_y", ctypes.c_long),
        ("lPrivate", ctypes.c_uint32),
    ]


class _WNDCLASSW(ctypes.Structure):
    pass


_CALLBACK = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)
_WNDPROC = _CALLBACK(
    ctypes.c_ssize_t, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_size_t, ctypes.c_ssize_t
)


_WNDCLASSW._fields_ = [
    ("style", ctypes.c_uint32),
    ("lpfnWndProc", _WNDPROC),
    ("cbClsExtra", ctypes.c_int),
    ("cbWndExtra", ctypes.c_int),
    ("hInstance", ctypes.c_void_p),
    ("hIcon", ctypes.c_void_p),
    ("hCursor", ctypes.c_void_p),
    ("hbrBackground", ctypes.c_void_p),
    ("lpszMenuName", ctypes.c_wchar_p),
    ("lpszClassName", ctypes.c_wchar_p),
]


class _INITCOMMONCONTROLSEX(ctypes.Structure):
    _fields_ = [("dwSize", ctypes.c_uint32), ("dwICC", ctypes.c_uint32)]


class _BROWSEINFOW(ctypes.Structure):
    _fields_ = [
        ("hwndOwner", ctypes.c_void_p),
        ("pidlRoot", ctypes.c_void_p),
        ("pszDisplayName", ctypes.POINTER(ctypes.c_wchar)),
        ("lpszTitle", ctypes.c_wchar_p),
        ("ulFlags", ctypes.c_uint32),
        ("lpfn", ctypes.c_void_p),
        ("lParam", ctypes.c_ssize_t),
        ("iImage", ctypes.c_int),
    ]


def _vk_name(vk: int) -> str:
    fixed = {
        0x08: "BACKSPACE", 0x09: "TAB", 0x0D: "ENTER", 0x10: "SHIFT",
        0x11: "CTRL", 0x12: "ALT", 0x13: "PAUSE", 0x14: "CAPS_LOCK",
        0x1B: "ESC", 0x20: "SPACE", 0x21: "PAGE_UP", 0x22: "PAGE_DOWN",
        0x23: "END", 0x24: "HOME", 0x25: "LEFT", 0x26: "UP",
        0x27: "RIGHT", 0x28: "DOWN", 0x2C: "PRINT_SCREEN", 0x2D: "INSERT",
        0x2E: "DELETE", 0x5B: "LEFT_WIN", 0x5C: "RIGHT_WIN",
        0x6A: "NUMPAD_MULTIPLY", 0x6B: "NUMPAD_ADD", 0x6D: "NUMPAD_SUBTRACT",
        0x6E: "NUMPAD_DECIMAL", 0x6F: "NUMPAD_DIVIDE",
        0xBA: "SEMICOLON", 0xBB: "EQUAL", 0xBC: "COMMA", 0xBD: "MINUS",
        0xBE: "PERIOD", 0xBF: "SLASH", 0xC0: "GRAVE", 0xDB: "BRACKETLEFT",
        0xDC: "BACKSLASH", 0xDD: "BRACKETRIGHT", 0xDE: "APOSTROPHE",
        0xA0: "LEFT_SHIFT", 0xA1: "RIGHT_SHIFT", 0xA2: "LEFT_CTRL",
        0xA3: "RIGHT_CTRL", 0xA4: "LEFT_ALT", 0xA5: "RIGHT_ALT",
    }
    if vk in fixed:
        return fixed[vk]
    if 0x30 <= vk <= 0x39 or 0x41 <= vk <= 0x5A:
        return chr(vk)
    if 0x60 <= vk <= 0x69:
        return f"NUMPAD{vk - 0x60}"
    if 0x70 <= vk <= 0x87:
        return f"F{vk - 0x6F}"
    return ""


class NativeAgentUI:
    """Small fixed-layout Windows UI with the same controls as the Tk version."""

    CLASS_NAME = "ClashRoyaleAgentNativeWindow"
    WIDTH = 740
    HEIGHT = 520

    def __init__(self) -> None:
        if os.name != "nt":
            raise OSError("Native Windows UI is only available on Windows.")
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.comctl32 = ctypes.WinDLL("comctl32", use_last_error=True)
        self.gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        self.shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        self.ole32 = ctypes.WinDLL("ole32", use_last_error=True)
        self._configure_apis()

        self.hwnd = None
        self.controls: dict[int, int] = {}
        self.font = None
        self.folder = ""
        self.stop_key = "ESC"
        self.windows = []
        self.saved_window_title = ""
        self.saved_window_class = ""
        self.agent: ClashRoyaleAgent | None = None
        self.agent_thread: threading.Thread | None = None
        self.running = False
        self.tray = TrayIcon()
        self.events: queue.Queue = queue.Queue()
        self._wndproc = _WNDPROC(self._window_proc)
        self._instance = self.kernel32.GetModuleHandleW(None)

    def _configure_apis(self) -> None:
        u = self.user32
        u.RegisterClassW.argtypes = [ctypes.POINTER(_WNDCLASSW)]
        u.RegisterClassW.restype = ctypes.c_ushort
        u.CreateWindowExW.argtypes = [
            ctypes.c_uint32, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32,
            ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
        ]
        u.CreateWindowExW.restype = ctypes.c_void_p
        u.DefWindowProcW.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_size_t, ctypes.c_ssize_t]
        u.DefWindowProcW.restype = ctypes.c_ssize_t
        u.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
        u.UpdateWindow.argtypes = [ctypes.c_void_p]
        u.DestroyWindow.argtypes = [ctypes.c_void_p]
        u.PostQuitMessage.argtypes = [ctypes.c_int]
        u.GetMessageW.argtypes = [ctypes.POINTER(_MSG), ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
        u.GetMessageW.restype = ctypes.c_int
        u.TranslateMessage.argtypes = [ctypes.POINTER(_MSG)]
        u.DispatchMessageW.argtypes = [ctypes.POINTER(_MSG)]
        u.SetTimer.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint32, ctypes.c_void_p]
        u.PostMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_size_t, ctypes.c_ssize_t]
        u.SetWindowTextW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p]
        u.GetWindowTextLengthW.argtypes = [ctypes.c_void_p]
        u.GetWindowTextLengthW.restype = ctypes.c_int
        u.GetWindowTextW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_int]
        u.SendMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_size_t, ctypes.c_ssize_t]
        u.SendMessageW.restype = ctypes.c_ssize_t
        self.gdi32.GetStockObject.argtypes = [ctypes.c_int]
        self.gdi32.GetStockObject.restype = ctypes.c_void_p
        u.LoadCursorW.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        u.LoadCursorW.restype = ctypes.c_void_p
        u.EnableWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
        u.EnableWindow.restype = ctypes.c_int
        u.MessageBoxW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32]
        u.MessageBoxW.restype = ctypes.c_int
        u.SetForegroundWindow.argtypes = [ctypes.c_void_p]
        u.BringWindowToTop.argtypes = [ctypes.c_void_p]
        self.kernel32.GetModuleHandleW.argtypes = [ctypes.c_wchar_p]
        self.kernel32.GetModuleHandleW.restype = ctypes.c_void_p

        self.comctl32.InitCommonControlsEx.argtypes = [ctypes.POINTER(_INITCOMMONCONTROLSEX)]
        self.comctl32.InitCommonControlsEx.restype = ctypes.c_int
        self.shell32.SHBrowseForFolderW.argtypes = [ctypes.POINTER(_BROWSEINFOW)]
        self.shell32.SHBrowseForFolderW.restype = ctypes.c_void_p
        self.shell32.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_wchar)]
        self.shell32.SHGetPathFromIDListW.restype = ctypes.c_int
        self.ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
        self.ole32.CoInitializeEx.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        self.ole32.CoInitializeEx.restype = ctypes.c_long
        self.ole32.CoUninitialize.argtypes = []

    def _message(self, title: str, message: str, *, error: bool = False, warning: bool = False) -> None:
        flags = 0x00000000
        flags |= 0x00000010 if error else 0x00000030 if warning else 0x00000040
        self.user32.MessageBoxW(self.hwnd, message, title, flags | 0x00010000)

    def _control(self, class_name: str, text: str, control_id: int, x: int, y: int,
                 width: int, height: int, style: int = 0, ex_style: int = 0) -> int:
        hwnd = self.user32.CreateWindowExW(
            ex_style, class_name, text, WS_CHILD | WS_VISIBLE | style,
            x, y, width, height, self.hwnd, ctypes.c_void_p(control_id), self._instance, None,
        )
        if not hwnd:
            raise OSError(ctypes.get_last_error(), f"创建控件失败：{class_name}")
        self.controls[control_id] = int(hwnd)
        if self.font:
            self.user32.SendMessageW(hwnd, WM_SETFONT, self.font, 1)
        return int(hwnd)

    def _set_text(self, control_id: int, text: str) -> None:
        hwnd = self.controls.get(control_id)
        if hwnd:
            self.user32.SetWindowTextW(hwnd, str(text))

    def _get_text(self, control_id: int) -> str:
        hwnd = self.controls.get(control_id)
        if not hwnd:
            return ""
        length = max(0, self.user32.GetWindowTextLengthW(hwnd))
        buffer = ctypes.create_unicode_buffer(length + 1)
        self.user32.GetWindowTextW(hwnd, buffer, length + 1)
        return buffer.value

    def _create_controls(self) -> None:
        self.font = self.gdi32.GetStockObject(DEFAULT_GUI_FONT)
        self._control("STATIC", "CLASH ROYALE AGENT", 101, 24, 20, 500, 32)
        self._control("STATIC", f"本地自主对战智能体  ·  不依赖云端 AI 模型  ·  v{APP_VERSION}",
                      102, 24, 55, 650, 24)

        self._control("STATIC", "工作文件夹", 103, 24, 100, 160, 22)
        self._control("EDIT", "", ID_FOLDER, 24, 126, 535, 30,
                      style=WS_BORDER | ES_READONLY | ES_AUTOHSCROLL)
        self._control("BUTTON", "选择文件夹", ID_BROWSE, 572, 125, 142, 32, style=WS_TABSTOP)

        self._control("STATIC", "游戏窗口", 104, 24, 176, 180, 22)
        combo_style = CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_VSCROLL | WS_TABSTOP
        self._control("COMBOBOX", "", ID_WINDOW, 24, 202, 690, 180, style=combo_style)

        self._control("STATIC", "停止按键", 105, 24, 253, 120, 22)
        hotkey_style = WS_BORDER | WS_TABSTOP
        hotkey = self._control("msctls_hotkey32", "", ID_HOTKEY, 24, 279, 132, 30,
                               style=hotkey_style)
        self.user32.SendMessageW(hotkey, HKM_SETHOTKEY, 0x1B, 0)
        self._control("STATIC", "默认 ESC。点击输入框，再按一个键盘按键即可更改。", 106,
                      172, 282, 520, 26)

        self._control("STATIC", "准备就绪 · 选择工作文件夹和游戏窗口", ID_STATUS,
                      24, 334, 690, 28)
        self._control("BUTTON", "启动", ID_START, 24, 376, 510, 46, style=WS_TABSTOP)
        self._control("BUTTON", "黑匣子", ID_BLACKBOX, 552, 376, 162, 46, style=WS_TABSTOP)
        self._control("STATIC", "运行期间界面隐藏；按设定的全局停止键停止并恢复界面。", 108,
                      24, 445, 690, 24)

    def _set_status(self, text: str) -> None:
        self._set_text(ID_STATUS, text)

    def _browse_folder(self) -> str:
        # The new-style Shell folder picker expects COM to be initialized on
        # the UI thread. S_FALSE also means this call owns a matching uninit.
        hr = self.ole32.CoInitializeEx(None, 0x2)  # COINIT_APARTMENTTHREADED
        owns_com = hr in (0, 1)
        try:
            display = ctypes.create_unicode_buffer(260)
            info = _BROWSEINFOW()
            info.hwndOwner = self.hwnd
            info.pszDisplayName = ctypes.cast(display, ctypes.POINTER(ctypes.c_wchar))
            info.lpszTitle = "选择 Agent 工作文件夹"
            info.ulFlags = 0x0001 | 0x0010 | 0x0040  # filesystem, edit box, new dialog style
            pidl = self.shell32.SHBrowseForFolderW(ctypes.byref(info))
            if not pidl:
                return ""
            try:
                path_buffer = ctypes.create_unicode_buffer(32768)
                if self.shell32.SHGetPathFromIDListW(pidl, path_buffer):
                    return path_buffer.value
                return ""
            finally:
                self.ole32.CoTaskMemFree(pidl)
        finally:
            if owns_com:
                self.ole32.CoUninitialize()

    def _choose_folder(self) -> None:
        chosen = self._browse_folder()
        if not chosen:
            return
        try:
            self._set_temp_directory(Path(chosen).expanduser().resolve() / "ClashRoyaleAgent" / ".tmp")
            self.folder = chosen
            self._set_text(ID_FOLDER, chosen)
            self._restore_config(Path(chosen))
            self._refresh_windows()
            self._set_status("工作文件夹已选择 · 已恢复可用的停止键和游戏窗口设置")
        except (OSError, ValueError) as exc:
            self._message("工作文件夹不可用", f"无法在所选文件夹创建运行目录：\n\n{exc}", error=True)

    @staticmethod
    def _set_temp_directory(path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)
        value = str(path.resolve())
        os.environ["TMP"] = value
        os.environ["TEMP"] = value
        os.environ["TMPDIR"] = value
        tempfile.tempdir = None

    def _restore_config(self, folder: Path) -> None:
        config = load_config(folder.expanduser().resolve() / "ClashRoyaleAgent")
        stop_key = str(config.get("stop_key", "ESC")).upper()
        vk = key_to_vk(stop_key)
        if vk is not None:
            self.stop_key = stop_key
            self.user32.SendMessageW(self.controls[ID_HOTKEY], HKM_SETHOTKEY, vk, 0)
        self.saved_window_title = str(config.get("window_title", ""))
        self.saved_window_class = str(config.get("window_class", ""))

    def _persist_config(self, window) -> None:
        if not self.folder or not Path(self.folder).is_dir():
            return
        save_config(
            Path(self.folder).expanduser().resolve() / "ClashRoyaleAgent",
            stop_key=self.stop_key,
            window_title=window.title,
            window_class=window.class_name,
            app_version=APP_VERSION,
        )
        self.saved_window_title = window.title
        self.saved_window_class = window.class_name

    def _refresh_windows(self) -> None:
        try:
            self.windows = list_game_windows()
        except Exception:
            self.windows = []
        combo = self.controls.get(ID_WINDOW)
        if not combo:
            return
        self.user32.SendMessageW(combo, 0x014B, 0, 0)  # CB_RESETCONTENT
        matching_indices = []
        for index, window in enumerate(self.windows):
            label_buffer = ctypes.create_unicode_buffer(window.label)
            self.user32.SendMessageW(
                combo, CB_ADDSTRING, 0, ctypes.cast(label_buffer, ctypes.c_void_p).value
            )
            if (self.saved_window_title and window.title == self.saved_window_title and
                    window.class_name == self.saved_window_class):
                matching_indices.append(index)
        # Restore only an exact unique identity; never guess between duplicate
        # titles/classes or silently select the first game window.
        if len(matching_indices) == 1:
            self.user32.SendMessageW(combo, CB_SETCURSEL, matching_indices[0], 0)
        self._persist_selected_config()

    def _persist_selected_config(self) -> None:
        if not self.folder:
            return
        window = self._selected_window()
        if window is None:
            return
        try:
            self._persist_config(window)
        except (OSError, ValueError):
            pass

    def _selected_window(self):
        combo = self.controls.get(ID_WINDOW)
        if not combo:
            return None
        index = int(self.user32.SendMessageW(combo, CB_GETCURSEL, 0, 0))
        return self.windows[index] if 0 <= index < len(self.windows) else None

    def _stop_key_value(self) -> tuple[str, int] | None:
        raw = int(self.user32.SendMessageW(self.controls[ID_HOTKEY], HKM_GETHOTKEY, 0, 0))
        vk = raw & 0xFF
        modifiers = (raw >> 8) & 0xFF
        if modifiers:
            return None
        name = _vk_name(vk)
        mapped = key_to_vk(name) if name else None
        return (name, mapped) if mapped is not None else None

    def _start(self) -> None:
        if not self.folder or not Path(self.folder).is_dir():
            self._set_status("尚未选择有效的工作文件夹")
            self._message("尚未选择文件夹", "请先选择 Agent 工作文件夹。", warning=True)
            return
        window = self._selected_window()
        if window is None or not window_is_valid(window.hwnd):
            self._set_status("尚未选择有效的游戏窗口")
            self._message("尚未选择游戏窗口", "请先选择一个有效的游戏窗口。", warning=True)
            self._refresh_windows()
            return
        stop = self._stop_key_value()
        if stop is None:
            self._set_status("停止按键无效，请设置单个按键")
            self._message("停止按键无效", "请设置一个不带 Ctrl/Alt/Shift 组合的有效按键。", warning=True)
            return
        self.stop_key, stop_vk = stop

        process_path = window_process_path(window.hwnd)
        process_id = window_process_id(window.hwnd)
        if not window_identity_matches(window.hwnd, window.title, window.class_name,
                                       process_path, process_id):
            self._set_status("游戏窗口身份已变化，请重新选择")
            self._message("游戏窗口已变化", "所选窗口已失效或身份发生变化，请重新选择。", warning=True)
            self._refresh_windows()
            return
        try:
            if not focus_window(window.hwnd):
                raise OSError("无法将所选游戏窗口置于前台。")
            frame = capture_window(window.hwnd)
            if frame.width < 120 or frame.height < 240:
                raise OSError("游戏窗口截图尺寸无效。")
        except Exception as exc:
            self._set_status("启动前检查失败 · 请确认游戏窗口可见且未被遮挡")
            self._message("启动前检查失败", f"Agent 尚未启动。\n\n{exc}", error=True)
            return

        workspace = Path(self.folder).expanduser().resolve() / "ClashRoyaleAgent"
        try:
            self._set_temp_directory(workspace / ".tmp")
            self._persist_config(window)
        except (OSError, ValueError) as exc:
            self._set_status("无法创建工作文件，请检查文件夹权限")
            self._message("无法创建工作文件", str(exc), error=True)
            return

        try:
            self.agent = ClashRoyaleAgent(
                hwnd=window.hwnd,
                stop_vk=stop_vk,
                stop_key_name=self.stop_key,
                workspace=workspace,
                on_stopped=self._agent_stopped_callback,
                window_title=window.title,
                window_class=window.class_name,
                selected_process_path=process_path,
                selected_process_id=process_id,
            )
            self.agent_thread = threading.Thread(
                target=self.agent.run, name="ClashRoyaleAgent", daemon=False
            )
            self.running = True
            self.user32.EnableWindow(self.controls[ID_START], False)
            self._set_status(f"正在启动停止键监听 · 就绪后运行 · 按 {self.stop_key} 停止")
            self.tray.show(self.hwnd, self.stop_key)
            self.user32.ShowWindow(self.hwnd, SW_HIDE)
            self.agent_thread.start()
        except Exception as exc:
            self.running = False
            self.tray.remove()
            if self.agent is not None:
                for handler in list(self.agent.logger.handlers):
                    try:
                        handler.flush()
                        handler.close()
                    except Exception:
                        pass
                    self.agent.logger.removeHandler(handler)
            self.user32.EnableWindow(self.controls[ID_START], True)
            self.user32.ShowWindow(self.hwnd, SW_RESTORE)
            self._set_status("启动失败 · 请检查工作文件夹")
            self._message("Agent 启动失败", str(exc), error=True)

    def _agent_stopped_callback(self, summary: dict) -> None:
        self.events.put(summary)
        if self.hwnd:
            self.user32.PostMessageW(self.hwnd, WM_APP_AGENT_STOPPED, 0, 0)

    def _agent_stopped(self) -> None:
        try:
            summary = self.events.get_nowait()
        except queue.Empty:
            return
        self.tray.remove()
        self.running = False
        if self.agent_thread is not None and self.agent_thread.is_alive():
            self.agent_thread.join(timeout=0.5)
        self.user32.EnableWindow(self.controls[ID_START], True)
        self.user32.ShowWindow(self.hwnd, SW_RESTORE)
        self.user32.BringWindowToTop(self.hwnd)
        self.user32.SetForegroundWindow(self.hwnd)
        recent_rate = summary.get("recent_recognized_win_rate")
        rate_text = f" · 已识别结果近期胜率 {recent_rate:.0%}" if isinstance(recent_rate, (int, float)) else ""
        status = (
            f"已停止 · 操作 {summary.get('actions', 0)} 次 · 胜/负/平 "
            f"{summary.get('wins', 0)}/{summary.get('losses', 0)}/{summary.get('draws', 0)}"
            f"{rate_text} · 学习 {summary.get('learn_count', 0)} 次"
        )
        error = str(summary.get("last_error") or "").strip()
        if error and not summary.get("actions"):
            status = f"未开始或提前结束 · {error[:140]}"
        self._set_status(status)
        self._refresh_windows()

    def _blackbox(self) -> None:
        if not self.folder or not Path(self.folder).is_dir():
            self._message("尚未选择文件夹", "请先选择工作文件夹，再创建黑匣子。", warning=True)
            return
        workspace = Path(self.folder).expanduser().resolve() / "ClashRoyaleAgent"
        try:
            workspace.mkdir(parents=True, exist_ok=True)
            archive = create_blackbox(workspace)
            size_kb = archive.stat().st_size / 1024.0
            self._message("黑匣子已创建", f"已在桌面创建诊断压缩包：\n{archive}\n\n大小：{size_kb:.1f} KB")
        except Exception as exc:
            self._set_status("黑匣子创建失败 · 请检查桌面和工作文件夹权限")
            self._message("黑匣子创建失败", str(exc), error=True)

    def _window_proc(self, hwnd, message, wparam, lparam):
        if message == WM_CREATE:
            try:
                self.hwnd = hwnd
                self._create_controls()
                self._refresh_windows()
                self.user32.SetTimer(hwnd, TIMER_REFRESH, 1800, None)
                self.user32.SetTimer(hwnd, TIMER_EVENTS, 200, None)
            except Exception as exc:
                self.user32.MessageBoxW(hwnd, str(exc), "界面初始化失败", 0x10)
                self.user32.DestroyWindow(hwnd)
            return 0
        if message == WM_COMMAND:
            control_id = wparam & 0xFFFF
            notification = (wparam >> 16) & 0xFFFF
            if control_id == ID_BROWSE and notification == 0:
                self._choose_folder()
            elif control_id == ID_START and notification == 0:
                self._start()
            elif control_id == ID_BLACKBOX and notification == 0:
                self._blackbox()
            elif control_id == ID_WINDOW and notification == 1:
                self._persist_selected_config()
            elif control_id == ID_HOTKEY and notification == 0x0300:
                stop = self._stop_key_value()
                if stop is not None:
                    self.stop_key = stop[0]
                    self._persist_selected_config()
                    self._set_status(f"停止按键已设置为 {self.stop_key}")
                else:
                    self._set_status("停止按键只支持单个按键，不支持 Ctrl/Alt/Shift 组合")
            return 0
        if message == WM_TIMER:
            if wparam == TIMER_REFRESH and not self.running:
                self._refresh_windows()
            elif wparam == TIMER_EVENTS:
                self._agent_stopped()
            return 0
        if message == WM_APP_AGENT_STOPPED:
            self._agent_stopped()
            return 0
        if message == WM_CLOSE:
            if self.running:
                # No pause/stop button exists while running; the global stop key
                # is the only user-initiated stop path.
                return 0
            self.user32.DestroyWindow(hwnd)
            return 0
        if message == WM_DESTROY:
            self.tray.remove()
            self.user32.PostQuitMessage(0)
            return 0
        return self.user32.DefWindowProcW(hwnd, message, wparam, lparam)

    def run(self) -> None:
        controls = _INITCOMMONCONTROLSEX(ctypes.sizeof(_INITCOMMONCONTROLSEX), ICC_HOTKEY_CLASS)
        self.comctl32.InitCommonControlsEx(ctypes.byref(controls))
        class_def = _WNDCLASSW(
            0, self._wndproc, 0, 0, self._instance, None,
            self.user32.LoadCursorW(None, ctypes.c_void_p(IDC_ARROW)), ctypes.c_void_p(6),
            None, self.CLASS_NAME,
        )
        if not self.user32.RegisterClassW(ctypes.byref(class_def)):
            error = ctypes.get_last_error()
            if error != 1410:  # ERROR_CLASS_ALREADY_EXISTS
                raise OSError(error, "无法注册 Windows 主窗口类。")
        style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX
        self.hwnd = self.user32.CreateWindowExW(
            0, self.CLASS_NAME, f"Clash Royale Agent v{APP_VERSION}", style,
            CW_USEDEFAULT, CW_USEDEFAULT, self.WIDTH, self.HEIGHT,
            None, None, self._instance, None,
        )
        if not self.hwnd:
            raise OSError(ctypes.get_last_error(), "无法创建 Windows 主窗口。")
        self.user32.ShowWindow(self.hwnd, SW_SHOW)
        self.user32.UpdateWindow(self.hwnd)
        message = _MSG()
        while True:
            result = self.user32.GetMessageW(ctypes.byref(message), None, 0, 0)
            if result <= 0:
                if result < 0:
                    raise OSError(ctypes.get_last_error(), "Windows 消息循环失败。")
                break
            self.user32.TranslateMessage(ctypes.byref(message))
            self.user32.DispatchMessageW(ctypes.byref(message))


def launch_native(error_message: str | None = None) -> None:
    if os.name != "nt":
        raise OSError("Clash Royale Agent requires Windows 11 x64.")
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.MessageBoxW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint32]
    user32.MessageBoxW.restype = ctypes.c_int
    error = error_message or runtime_support_error()
    if error:
        title = "运行环境不受支持"
        user32.MessageBoxW(None, error, title, 0x10)
        return
    set_dpi_awareness()
    NativeAgentUI().run()
