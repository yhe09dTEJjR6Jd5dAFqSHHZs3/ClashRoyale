"""Workspace-scoped temporary storage helpers shared by both UIs."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path


WORKSPACE_NAME = "ClashRoyaleAgent"
TEMP_DIRECTORY_NAME = ".tmp"


def app_workspace(selected_folder: str | Path) -> Path:
    """Resolve the application data directory beneath the selected folder."""
    root = Path(selected_folder).expanduser().resolve()
    if not root.is_dir():
        raise NotADirectoryError(f"Selected work folder does not exist: {root}")
    return root / WORKSPACE_NAME


def set_workspace_temp(workspace: str | Path) -> Path:
    """Route Python and child-process temporary files into the selected workspace."""
    path = (Path(workspace).expanduser().resolve() / TEMP_DIRECTORY_NAME)
    path.mkdir(parents=True, exist_ok=True)
    value = str(path)
    os.environ["TMP"] = value
    os.environ["TEMP"] = value
    os.environ["TMPDIR"] = value
    # tempfile caches its first result; invalidate it after updating the env.
    tempfile.tempdir = value
    return path
