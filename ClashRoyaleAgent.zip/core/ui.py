"""Minimal Chinese UI containing only the controls specified in the brief."""
from __future__ import annotations

import os
import queue
import sys
import threading
import tempfile
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception:  # Tkinter/Tcl is optional in many official Python installers.
    tk = None
    filedialog = messagebox = ttk = None

from . import APP_VERSION
from .agent import ClashRoyaleAgent
from .blackbox import create_blackbox
from .config import load_config, save_config
from .runtime import runtime_support_error
from .tray import TrayIcon
from .win32 import (capture_window, focus_window, key_to_vk, keysym_to_key_name,
                    list_game_windows, set_dpi_awareness, window_identity_matches,
                    window_is_valid, window_process_path, window_process_id)


BG = "#0b1020"
PANEL = "#121a2e"
PANEL_2 = "#18233b"
TEXT = "#edf2ff"
MUTED = "#9aa8c7"
ACCENT = "#f4b942"
ACCENT_HOVER = "#ffd36b"


class AgentUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"Clash Royale Agent v{APP_VERSION}")
        screen_width = max(600, self.root.winfo_screenwidth())
        screen_height = max(460, self.root.winfo_screenheight())
        initial_width = max(600, min(760, screen_width - 48))
        initial_height = max(460, min(570, screen_height - 96))
        self.root.geometry(f"{initial_width}x{initial_height}")
        self.root.minsize(min(680, initial_width), min(500, initial_height))
        self.root.resizable(True, True)
        self.root.configure(bg=BG)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        self.folder_var = tk.StringVar(value="")
        self.window_var = tk.StringVar(value="")
        self.stop_key_var = tk.StringVar(value="ESC")
        self.status_var = tk.StringVar(value="准备就绪 · 选择工作文件夹和游戏窗口")
        self.window_map = {}
        self.saved_window_title = ""
        self.saved_window_class = ""
        self.agent_thread: threading.Thread | None = None
        self.agent: ClashRoyaleAgent | None = None
        self.running = False
        self.tray = TrayIcon()
        self._agent_events: queue.Queue = queue.Queue()
        self._build_styles()
        self._build_ui()
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = max(0, (screen_width - width) // 2)
        y = max(0, (screen_height - height) // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        self._refresh_windows()
        self.root.after(1800, self._periodic_refresh)
        self.root.after(200, self._poll_agent_events)

    def _build_styles(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TCombobox", fieldbackground=PANEL_2, background=PANEL_2,
                        foreground=TEXT, arrowcolor=ACCENT, bordercolor="#2b3855",
                        lightcolor="#2b3855", darkcolor="#2b3855", padding=8)
        style.map("TCombobox", fieldbackground=[("readonly", PANEL_2)],
                  foreground=[("readonly", TEXT)], selectbackground=[("readonly", PANEL_2)],
                  selectforeground=[("readonly", TEXT)])

    def _build_ui(self) -> None:
        outer = tk.Frame(self.root, bg=BG, padx=28, pady=24)
        outer.pack(fill="both", expand=True)

        header = tk.Frame(outer, bg=BG)
        header.pack(fill="x", pady=(0, 20))
        tk.Label(header, text="CR", bg=ACCENT, fg="#182033", font=("Segoe UI", 16, "bold"),
                 width=3, height=1).pack(side="left", padx=(0, 12))
        title_box = tk.Frame(header, bg=BG)
        title_box.pack(side="left", fill="x", expand=True)
        tk.Label(title_box, text="CLASH ROYALE AGENT", bg=BG, fg=TEXT,
                 font=("Segoe UI", 17, "bold")).pack(anchor="w")
        tk.Label(title_box, text="本地自主对战智能体  ·  不依赖云端 AI 模型",
                 bg=BG, fg=MUTED, font=("Microsoft YaHei UI", 9)).pack(anchor="w", pady=(2, 0))
        tk.Label(header, text=f"v{APP_VERSION}", bg=BG, fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="right", anchor="n")

        panel = tk.Frame(outer, bg=PANEL, padx=22, pady=20,
                         highlightthickness=1, highlightbackground="#263451")
        panel.pack(fill="both", expand=True)

        self._section_label(panel, "运行环境", "01")
        self._field_label(panel, "工作文件夹")
        folder_row = tk.Frame(panel, bg=PANEL)
        folder_row.pack(fill="x", pady=(6, 16))
        self.folder_entry = tk.Entry(folder_row, textvariable=self.folder_var, state="readonly",
                                     readonlybackground=PANEL_2, fg=TEXT, insertbackground=TEXT,
                                     relief="flat", font=("Segoe UI", 10), bd=0)
        self.folder_entry.pack(side="left", fill="x", expand=True, ipady=11, padx=(0, 10))
        self._small_button(folder_row, "选择文件夹", self._choose_folder).pack(side="right")

        self._field_label(panel, "游戏窗口")
        self.window_combo = ttk.Combobox(panel, textvariable=self.window_var, state="readonly",
                                         font=("Microsoft YaHei UI", 10), height=8)
        self.window_combo.pack(fill="x", pady=(6, 16), ipady=5)
        self.window_combo.bind("<<ComboboxSelected>>", self._on_window_selected)

        self._section_label(panel, "停止控制", "02")
        self._field_label(panel, "停止按键")
        key_row = tk.Frame(panel, bg=PANEL)
        key_row.pack(fill="x", pady=(6, 8))
        self.key_entry = tk.Entry(key_row, textvariable=self.stop_key_var, readonlybackground=PANEL_2,
                                  fg=ACCENT, insertbackground=TEXT, relief="flat", bd=0,
                                  font=("Segoe UI", 11, "bold"), justify="center", width=14)
        self.key_entry.pack(side="left", ipady=9)
        self.key_entry.bind("<KeyPress>", self._capture_key)
        self.key_entry.bind("<Button-1>", lambda _event: self.key_entry.focus_set())
        tk.Label(key_row, text="点击输入框，再按下你想使用的键盘按键（默认 ESC）",
                 bg=PANEL, fg=MUTED, font=("Microsoft YaHei UI", 9)).pack(side="left", padx=12)

        divider = tk.Frame(panel, bg="#263451", height=1)
        divider.pack(fill="x", pady=(15, 16))

        buttons = tk.Frame(panel, bg=PANEL)
        buttons.pack(fill="x")
        self.start_button = tk.Button(buttons, text="启动", command=self._start,
                                      bg=ACCENT, fg="#182033", activebackground=ACCENT_HOVER,
                                      activeforeground="#182033", relief="flat", bd=0,
                                      font=("Microsoft YaHei UI", 12, "bold"), cursor="hand2",
                                      padx=26, pady=11)
        self.start_button.pack(side="left", fill="x", expand=True, padx=(0, 10))
        self.blackbox_button = tk.Button(buttons, text="黑匣子", command=self._blackbox,
                                         bg=PANEL_2, fg=TEXT, activebackground="#243451",
                                         activeforeground=TEXT, relief="flat", bd=0,
                                         font=("Microsoft YaHei UI", 11, "bold"), cursor="hand2",
                                         padx=20, pady=11)
        self.blackbox_button.pack(side="right")

        status = tk.Frame(outer, bg=BG)
        status.pack(fill="x", pady=(14, 0))
        self.status_dot = tk.Label(status, text="●", bg=BG, fg="#6fd6a5", font=("Segoe UI", 10))
        self.status_dot.pack(side="left", padx=(2, 8))
        tk.Label(status, textvariable=self.status_var, bg=BG, fg=MUTED,
                 font=("Microsoft YaHei UI", 9), anchor="w").pack(side="left", fill="x", expand=True)

        tk.Label(outer, text="自动识别并处理可确认的游戏界面；无法确认的界面不会盲目点击。运行期间按设定按键停止。",
                 bg=BG, fg="#71809f", font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(10, 0))

    def _set_status(self, message: str, level: str = "ready") -> None:
        colors = {
            "ready": "#6fd6a5",
            "running": "#79aaff",
            "warning": ACCENT,
            "error": "#ff7185",
        }
        self.status_var.set(str(message))
        self.status_dot.configure(fg=colors.get(level, ACCENT))

    @staticmethod
    def _section_label(parent, title: str, number: str) -> None:
        row = tk.Frame(parent, bg=PANEL)
        row.pack(fill="x", pady=(0, 12))
        tk.Label(row, text=number, bg="#293858", fg=ACCENT,
                 font=("Segoe UI", 9, "bold"), padx=8, pady=3).pack(side="left")
        tk.Label(row, text=title, bg=PANEL, fg=TEXT,
                 font=("Microsoft YaHei UI", 11, "bold")).pack(side="left", padx=9)

    @staticmethod
    def _field_label(parent, text: str) -> None:
        tk.Label(parent, text=text, bg=PANEL, fg="#cbd5eb",
                 font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w")

    @staticmethod
    def _small_button(parent, text: str, command) -> tk.Button:
        return tk.Button(parent, text=text, command=command, bg=PANEL_2, fg=TEXT,
                         activebackground="#243451", activeforeground=TEXT,
                         relief="flat", bd=0, font=("Microsoft YaHei UI", 9),
                         cursor="hand2", padx=15, pady=9)

    def _choose_folder(self) -> None:
        chosen = filedialog.askdirectory(title="选择 Agent 工作文件夹", mustexist=True)
        if chosen:
            try:
                self._set_workspace_temp(Path(chosen).expanduser().resolve() / "ClashRoyaleAgent" / ".tmp")
            except OSError as exc:
                messagebox.showerror("工作文件夹不可用", f"无法在所选文件夹创建运行目录：\n\n{exc}", parent=self.root)
                return
            self.folder_var.set(chosen)
            self.window_var.set("")
            self._restore_workspace_config(Path(chosen))
            self._refresh_windows()
            self._set_status("工作文件夹已选择 · 已恢复可用的停止键和游戏窗口设置", "warning")

    @staticmethod
    def _set_workspace_temp(path: Path) -> None:
        """Keep Python temporary files inside the user-selected workspace."""
        path.mkdir(parents=True, exist_ok=True)
        value = str(path.resolve())
        os.environ["TMP"] = value
        os.environ["TEMP"] = value
        os.environ["TMPDIR"] = value
        tempfile.tempdir = None

    def _restore_workspace_config(self, folder: Path) -> None:
        config = load_config(Path(folder).expanduser().resolve() / "ClashRoyaleAgent")
        stop_key = config.get("stop_key", "ESC")
        if key_to_vk(stop_key) is not None:
            self.stop_key_var.set(stop_key)
        self.saved_window_title = config.get("window_title", "")
        self.saved_window_class = config.get("window_class", "")

    def _persist_config(self) -> None:
        folder = self.folder_var.get().strip()
        if not folder or not Path(folder).is_dir():
            return
        selected = self.window_map.get(self.window_var.get())
        title = selected.title if selected else self.saved_window_title
        class_name = selected.class_name if selected else self.saved_window_class
        try:
            save_config(
                Path(folder).expanduser().resolve() / "ClashRoyaleAgent",
                stop_key=self.stop_key_var.get().strip().upper(),
                window_title=title,
                window_class=class_name,
                app_version=APP_VERSION,
            )
        except (OSError, ValueError):
            # Persistence is best-effort while editing; Start performs a hard check.
            pass

    def _on_window_selected(self, _event=None) -> None:
        selected = self.window_map.get(self.window_var.get())
        if selected:
            self.saved_window_title = selected.title
            self.saved_window_class = selected.class_name
            self._persist_config()
            if self.folder_var.get().strip() and Path(self.folder_var.get()).is_dir():
                self._set_status("工作文件夹和游戏窗口已就绪", "ready")
            else:
                self._set_status("游戏窗口已选择 · 还需选择工作文件夹", "warning")

    def _capture_key(self, event):
        name = keysym_to_key_name(event.keysym)
        if key_to_vk(name) is None:
            self._set_status("该按键暂不支持，请选择其他键盘按键", "warning")
            return "break"
        self.stop_key_var.set(name)
        self._set_status(f"停止按键已设置为 {name}", "ready" if self.folder_var.get().strip() else "warning")
        self._persist_config()
        return "break"

    def _refresh_windows(self) -> None:
        try:
            windows = list_game_windows()
            old = self.window_var.get()
            self.window_map = {window.label: window for window in windows}
            labels = list(self.window_map.keys())
            self.window_combo["values"] = labels
            if old in self.window_map:
                self.window_var.set(old)
            else:
                # Restore only an exact title/class match; never guess among windows.
                matches = [
                    window for window in windows
                    if self.saved_window_title
                    and window.title == self.saved_window_title
                    and (not self.saved_window_class or window.class_name == self.saved_window_class)
                ]
                if len(matches) == 1:
                    self.window_var.set(matches[0].label)
                else:
                    self.window_var.set("")
        except Exception:
            self.window_combo["values"] = []
            self.window_var.set("")

    def _periodic_refresh(self) -> None:
        if not self.running:
            current = self.window_var.get()
            self._refresh_windows()
            if current and self.window_var.get() != current:
                self._set_status("游戏窗口列表已更新，请确认选择的窗口", "warning")
        self.root.after(1800, self._periodic_refresh)

    def _poll_agent_events(self) -> None:
        try:
            summary = self._agent_events.get_nowait()
        except queue.Empty:
            pass
        else:
            self._agent_stopped(summary)
        self.root.after(200, self._poll_agent_events)

    def _start(self) -> None:
        folder = self.folder_var.get().strip()
        window = self.window_map.get(self.window_var.get())
        key_name = self.stop_key_var.get().strip().upper()
        stop_vk = key_to_vk(key_name)
        if not folder or not Path(folder).is_dir():
            self._set_status("尚未选择有效的工作文件夹", "error")
            messagebox.showwarning("尚未选择文件夹", "请先选择 Agent 工作文件夹。", parent=self.root)
            return
        if window is None or not window_is_valid(window.hwnd):
            self._set_status("尚未选择有效的游戏窗口", "error")
            messagebox.showwarning("尚未选择游戏窗口", "请先选择一个有效的游戏窗口。", parent=self.root)
            self._refresh_windows()
            return
        if stop_vk is None:
            self._set_status("停止按键无效，请重新设置", "error")
            messagebox.showwarning("停止按键无效", "请点击停止按键输入框，再按一个有效键（例如 ESC、F8、A 或 SPACE）。", parent=self.root)
            return

        selected_process_path = window_process_path(window.hwnd)
        selected_process_id = window_process_id(window.hwnd)
        if not window_identity_matches(
                window.hwnd, window.title, window.class_name,
                selected_process_path, selected_process_id):
            self._set_status("游戏窗口身份已变化，请重新选择", "error")
            messagebox.showwarning("游戏窗口已变化", "所选窗口已失效或身份发生变化，请重新选择游戏窗口。", parent=self.root)
            self._refresh_windows()
            return
        try:
            if not focus_window(window.hwnd):
                raise OSError("无法将所选游戏窗口置于前台。")
            frame = capture_window(window.hwnd)
            if frame.width < 120 or frame.height < 240:
                raise OSError("游戏窗口截图尺寸无效。")
        except Exception as exc:
            self._set_status("启动前检查失败 · 请确认游戏窗口可见且未被遮挡", "error")
            messagebox.showerror(
                "启动前检查失败",
                f"无法可靠读取所选游戏画面，Agent 尚未启动。\n\n{exc}",
                parent=self.root,
            )
            return

        workspace = Path(folder).expanduser().resolve() / "ClashRoyaleAgent"
        try:
            self._set_workspace_temp(workspace / ".tmp")
            save_config(
                workspace,
                stop_key=key_name,
                window_title=window.title,
                window_class=window.class_name,
                app_version=APP_VERSION,
            )
            self.saved_window_title = window.title
            self.saved_window_class = window.class_name
        except (OSError, ValueError) as exc:
            self._set_status("无法创建工作文件，请检查文件夹权限", "error")
            messagebox.showerror("无法创建工作文件", str(exc), parent=self.root)
            return

        self.running = True
        self.start_button.configure(state="disabled")
        self._set_status(f"正在启动停止键监听 · 就绪后运行 · 按 {key_name} 停止", "running")
        try:
            self.agent = ClashRoyaleAgent(
                hwnd=window.hwnd,
                stop_vk=stop_vk,
                stop_key_name=key_name,
                workspace=workspace,
                on_stopped=lambda summary: self._agent_events.put(summary),
                window_title=window.title,
                window_class=window.class_name,
                selected_process_path=selected_process_path,
                selected_process_id=selected_process_id,
            )
            self.agent_thread = threading.Thread(
                target=self.agent.run, name="ClashRoyaleAgent", daemon=False
            )
            # A status-only tray icon keeps the hidden run discoverable; it
            # does not expose a second stop or pause path.
            self.tray.show(self.root.winfo_id(), key_name)
            self.root.withdraw()
            self.agent_thread.start()
        except Exception as exc:
            self.running = False
            self.tray.remove()
            if self.agent is not None:
                for handler in list(self.agent.logger.handlers):
                    try:
                        handler.flush()
                        handler.close()
                    except Exception:
                        pass
                    self.agent.logger.removeHandler(handler)
            self.start_button.configure(state="normal")
            self.root.deiconify()
            self._set_status("启动失败 · 请检查工作文件夹", "error")
            messagebox.showerror("Agent 启动失败", str(exc), parent=self.root)

    def _agent_stopped(self, summary: dict) -> None:
        self.tray.remove()
        self.running = False
        if self.agent_thread is not None and self.agent_thread.is_alive():
            self.agent_thread.join(timeout=0.5)
        self.start_button.configure(state="normal")
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()
        recent_rate = summary.get("recent_recognized_win_rate")
        rate_text = f" · 已识别结果近期胜率 {recent_rate:.0%}" if isinstance(recent_rate, (int, float)) else ""
        status_text = (
            f"已停止 · 操作 {summary.get('actions', 0)} 次 · 胜/负/平 "
            f"{summary.get('wins', 0)}/{summary.get('losses', 0)}/{summary.get('draws', 0)}"
            f"{rate_text} · 学习 {summary.get('learn_count', 0)} 次"
        )
        error = str(summary.get("last_error") or "").strip()
        if error and not summary.get("actions"):
            status_text = f"未开始或提前结束 · {error[:140]}"
        self._set_status(status_text, "warning" if error else "ready")
        self._refresh_windows()

    def _blackbox(self) -> None:
        folder = self.folder_var.get().strip()
        if not folder or not Path(folder).is_dir():
            messagebox.showwarning("尚未选择文件夹", "请先选择工作文件夹，再创建黑匣子。", parent=self.root)
            return
        workspace = Path(folder).expanduser().resolve() / "ClashRoyaleAgent"
        try:
            workspace.mkdir(parents=True, exist_ok=True)
            archive = create_blackbox(workspace)
            size_kb = archive.stat().st_size / 1024.0
            messagebox.showinfo("黑匣子已创建", f"已在桌面创建诊断压缩包：\n{archive}\n\n大小：{size_kb:.1f} KB", parent=self.root)
        except Exception as exc:
            self._set_status("黑匣子创建失败 · 请检查桌面和工作文件夹权限", "error")
            messagebox.showerror("黑匣子创建失败", str(exc), parent=self.root)

    def _on_close(self) -> None:
        if self.running:
            # There is intentionally no pause/stop control in the running UI.
            return
        self.tray.remove()
        self.root.destroy()


def launch() -> None:
    if os.name != "nt":
        if tk is None:
            print("Clash Royale Agent requires Windows 11 x64.", file=sys.stderr)
            return
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("系统不受支持", "Clash Royale Agent 需要 Windows 11 x64。", parent=root)
        root.destroy()
        return

    # Must be set before any HWND is created to avoid mixed-DPI geometry.
    set_dpi_awareness()
    error = runtime_support_error()
    if error:
        # The native MessageBox works even when Tk/Tcl is absent or broken.
        from .native_ui import launch_native
        launch_native(error)
        return
    if tk is None:
        from .native_ui import launch_native
        launch_native()
        return
    try:
        root = tk.Tk()
    except Exception:
        # Tkinter may import successfully even when the Tcl/Tk runtime is not
        # installed. Fall back to the dependency-free native Windows controls.
        from .native_ui import launch_native
        launch_native()
        return
    AgentUI(root)
    root.mainloop()
