"""Non-interactive Windows notification-area status icon.

The tray icon communicates the hidden Agent's current stage and names the
configured stop key. It deliberately exposes no pause/stop menu or click action.
"""
from __future__ import annotations

import ctypes
import os


NIM_ADD = 0x00000000
NIM_MODIFY = 0x00000001
NIM_DELETE = 0x00000002
NIF_ICON = 0x00000002
NIF_TIP = 0x00000004
IDI_APPLICATION = 32512


class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_uint32),
        ("Data2", ctypes.c_uint16),
        ("Data3", ctypes.c_uint16),
        ("Data4", ctypes.c_ubyte * 8),
    ]


class _NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [
        ("cbSize", ctypes.c_uint32),
        ("hWnd", ctypes.c_void_p),
        ("uID", ctypes.c_uint32),
        ("uFlags", ctypes.c_uint32),
        ("uCallbackMessage", ctypes.c_uint32),
        ("hIcon", ctypes.c_void_p),
        ("szTip", ctypes.c_wchar * 128),
        ("dwState", ctypes.c_uint32),
        ("dwStateMask", ctypes.c_uint32),
        ("szInfo", ctypes.c_wchar * 256),
        ("uTimeoutOrVersion", ctypes.c_uint32),
        ("szInfoTitle", ctypes.c_wchar * 64),
        ("dwInfoFlags", ctypes.c_uint32),
        ("guidItem", _GUID),
        ("hBalloonIcon", ctypes.c_void_p),
    ]


def format_tooltip(stop_key: str, status: str = "运行中") -> str:
    key = " ".join(str(stop_key or "ESC").split())[:16]
    return f"Clash Royale Agent · {status} · 按 {key} 停止"[:127]


class TrayIcon:
    """Small status-only shell icon; failure never blocks Agent startup."""

    def __init__(self):
        self._data: _NOTIFYICONDATAW | None = None
        self._shell32 = None
        self._added = False

    def show(self, hwnd: int, stop_key: str) -> bool:
        if os.name != "nt" or not hwnd:
            return False
        try:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            shell32 = ctypes.WinDLL("shell32", use_last_error=True)
            user32.LoadIconW.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            user32.LoadIconW.restype = ctypes.c_void_p
            shell32.Shell_NotifyIconW.argtypes = [
                ctypes.c_uint32, ctypes.POINTER(_NOTIFYICONDATAW)
            ]
            shell32.Shell_NotifyIconW.restype = ctypes.c_int
            icon = user32.LoadIconW(None, ctypes.c_void_p(IDI_APPLICATION))
            if not icon:
                return False
            data = _NOTIFYICONDATAW()
            data.cbSize = ctypes.sizeof(_NOTIFYICONDATAW)
            data.hWnd = ctypes.c_void_p(int(hwnd))
            data.uID = 1
            data.uFlags = NIF_ICON | NIF_TIP
            data.hIcon = icon
            data.szTip = format_tooltip(stop_key)
            self._data = data
            self._shell32 = shell32
            if self._added:
                result = shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(data))
            else:
                result = shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(data))
            self._added = bool(result)
            return self._added
        except Exception:
            self._data = None
            self._shell32 = None
            self._added = False
            return False

    def update(self, stop_key: str, status: str = "运行中") -> bool:
        if not self._added or self._data is None or self._shell32 is None:
            return False
        try:
            self._data.uFlags = NIF_TIP
            self._data.szTip = format_tooltip(stop_key, status)
            return bool(self._shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(self._data)))
        except Exception:
            return False

    def remove(self) -> None:
        if self._added and self._data is not None and self._shell32 is not None:
            try:
                self._shell32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(self._data))
            except Exception:
                pass
        self._added = False
        self._data = None
        self._shell32 = None
