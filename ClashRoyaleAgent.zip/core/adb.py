"""Optional Android Debug Bridge integration for emulator I/O and UI semantics.

The bridge is deliberately fail-closed: it is enabled only when the selected
window's installation exposes an ADB executable and exactly one online virtual
Android device is attached.  It never selects a physical device or guesses
between multiple emulators.  UIAutomator text is consumed in memory only; no
screenshots, XML dumps, or temporary files are written to disk.
"""
from __future__ import annotations

import ctypes
import os
import re
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET
import zlib
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Iterable

from .vision import GameState, NavigationTarget, Scene
from .win32 import Frame, window_process_path


_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
_BOUNDS_RE = re.compile(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]")
_MAX_PNG_PIXELS = 32_000_000
_MAX_PNG_RAW_BYTES = 128 * 1024 * 1024


@dataclass(frozen=True)
class AccessibilityLabel:
    text: str
    description: str
    ancestor_text: str
    clickable: bool
    enabled: bool
    bounds: tuple[int, int, int, int] | None
    target_bounds: tuple[int, int, int, int] | None
    target_clickable: bool
    target_enabled: bool

    @property
    def value(self) -> str:
        return f"{self.text} {self.description}".strip().lower()


def _parse_bounds(value: str) -> tuple[int, int, int, int] | None:
    match = _BOUNDS_RE.fullmatch(str(value or "").strip())
    if not match:
        return None
    x1, y1, x2, y2 = (int(part) for part in match.groups())
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


def parse_uiautomator_xml(payload: bytes | str) -> list[AccessibilityLabel]:
    """Parse useful labels and their nearest clickable ancestor bounds."""
    if isinstance(payload, bytes):
        source = payload.decode("utf-8", errors="replace")
    else:
        source = str(payload)
    start = source.find("<hierarchy")
    end = source.rfind("</hierarchy>")
    if start < 0 or end < start:
        return []
    source = source[start:end + len("</hierarchy>")]
    try:
        root = ET.fromstring(source)
    except ET.ParseError:
        return []

    labels: list[AccessibilityLabel] = []

    def walk(element: ET.Element, ancestors: tuple[dict, ...]) -> None:
        attrs = element.attrib
        text = attrs.get("text", "").strip()
        description = attrs.get("content-desc", "").strip()
        current = {
            "clickable": attrs.get("clickable", "false").lower() == "true",
            "enabled": attrs.get("enabled", "true").lower() != "false",
            "bounds": _parse_bounds(attrs.get("bounds", "")),
            "text": text,
            "description": description,
        }
        if text or description:
            clickable_chain = [item for item in (*ancestors, current) if item["clickable"]]
            target = clickable_chain[-1] if clickable_chain else current
            labels.append(AccessibilityLabel(
                text=text[:160],
                description=description[:160],
                ancestor_text=" ".join((item.get("text", "") + " " + item.get("description", "")).strip()
                                       for item in ancestors if item.get("text") or item.get("description"))[:320],
                clickable=current["clickable"],
                enabled=current["enabled"],
                bounds=current["bounds"],
                target_bounds=target["bounds"],
                target_clickable=bool(clickable_chain),
                target_enabled=all(item["enabled"] for item in clickable_chain) if clickable_chain else current["enabled"],
            ))
        next_ancestors = (*ancestors, current)
        for child in list(element):
            walk(child, next_ancestors)

    walk(root, ())
    return labels[:2048]


def _png_paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c




def _decode_png_with_gdiplus(payload: bytes, width: int, height: int,
                             max_width: int) -> tuple[Frame, tuple[int, int]]:
    """Decode and downsample PNG through Windows GDI+ when available.

    GDI+ performs PNG filtering, color conversion, and resize in native code.
    The pure-Python decoder below remains the portable fallback and is used by
    tests/non-Windows hosts. No files or third-party packages are required.
    """
    if os.name != "nt":
        raise OSError("GDI+ is available only on Windows.")

    class GdiplusStartupInput(ctypes.Structure):
        _fields_ = [
            ("GdiplusVersion", ctypes.c_uint32),
            ("DebugEventCallback", ctypes.c_void_p),
            ("SuppressBackgroundThread", ctypes.c_int),
            ("SuppressExternalCodecs", ctypes.c_int),
        ]

    class Rect(ctypes.Structure):
        _fields_ = [("X", ctypes.c_int), ("Y", ctypes.c_int),
                    ("Width", ctypes.c_int), ("Height", ctypes.c_int)]

    class BitmapData(ctypes.Structure):
        _fields_ = [("Width", ctypes.c_uint32), ("Height", ctypes.c_uint32),
                    ("Stride", ctypes.c_int32), ("PixelFormat", ctypes.c_int32),
                    ("Scan0", ctypes.c_void_p), ("Reserved", ctypes.c_void_p)]

    gdiplus = ctypes.WinDLL("gdiplus", use_last_error=True)
    shlwapi = ctypes.WinDLL("shlwapi", use_last_error=True)
    gdiplus.GdiplusStartup.argtypes = [ctypes.POINTER(ctypes.c_size_t),
                                       ctypes.POINTER(GdiplusStartupInput), ctypes.c_void_p]
    gdiplus.GdiplusStartup.restype = ctypes.c_int
    gdiplus.GdiplusShutdown.argtypes = [ctypes.c_size_t]
    gdiplus.GdiplusShutdown.restype = None
    gdiplus.GdipLoadImageFromStream.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    gdiplus.GdipLoadImageFromStream.restype = ctypes.c_int
    gdiplus.GdipGetImageGraphicsContext.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    gdiplus.GdipGetImageGraphicsContext.restype = ctypes.c_int
    gdiplus.GdipSetInterpolationMode.argtypes = [ctypes.c_void_p, ctypes.c_int]
    gdiplus.GdipSetInterpolationMode.restype = ctypes.c_int
    gdiplus.GdipDrawImageRectI.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int,
                                           ctypes.c_int, ctypes.c_int, ctypes.c_int]
    gdiplus.GdipDrawImageRectI.restype = ctypes.c_int
    gdiplus.GdipDeleteGraphics.argtypes = [ctypes.c_void_p]
    gdiplus.GdipDeleteGraphics.restype = ctypes.c_int
    gdiplus.GdipCreateBitmapFromScan0.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                                  ctypes.c_int, ctypes.c_void_p,
                                                  ctypes.POINTER(ctypes.c_void_p)]
    gdiplus.GdipCreateBitmapFromScan0.restype = ctypes.c_int
    gdiplus.GdipBitmapLockBits.argtypes = [ctypes.c_void_p, ctypes.POINTER(Rect), ctypes.c_uint32,
                                           ctypes.c_int, ctypes.POINTER(BitmapData)]
    gdiplus.GdipBitmapLockBits.restype = ctypes.c_int
    gdiplus.GdipBitmapUnlockBits.argtypes = [ctypes.c_void_p, ctypes.POINTER(BitmapData)]
    gdiplus.GdipBitmapUnlockBits.restype = ctypes.c_int
    gdiplus.GdipDisposeImage.argtypes = [ctypes.c_void_p]
    gdiplus.GdipDisposeImage.restype = ctypes.c_int
    shlwapi.SHCreateMemStream.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    shlwapi.SHCreateMemStream.restype = ctypes.c_void_p

    startup = GdiplusStartupInput(1, None, 0, 0)
    token = ctypes.c_size_t()
    status = gdiplus.GdiplusStartup(ctypes.byref(token), ctypes.byref(startup), None)
    if status != 0:
        raise OSError(f"GDI+ startup failed ({status}).")

    stream = image = scaled = graphics = None
    bitmap_data = BitmapData()
    locked = False
    try:
        source_buffer = ctypes.create_string_buffer(payload)
        stream = shlwapi.SHCreateMemStream(source_buffer, len(payload))
        if not stream:
            raise OSError("Could not create an in-memory PNG stream.")
        image = ctypes.c_void_p()
        status = gdiplus.GdipLoadImageFromStream(stream, ctypes.byref(image))
        if status != 0 or not image.value:
            raise OSError(f"GDI+ PNG decode failed ({status}).")

        out_width = min(width, max(120, int(max_width)))
        out_height = max(1, round(height * out_width / width))
        scaled = ctypes.c_void_p()
        # PixelFormat32bppARGB; on little-endian Windows its byte layout is BGRA.
        pixel_format_32bpp_argb = 0x0026200A
        status = gdiplus.GdipCreateBitmapFromScan0(
            out_width, out_height, 0, pixel_format_32bpp_argb, None, ctypes.byref(scaled)
        )
        if status != 0 or not scaled.value:
            raise OSError(f"GDI+ output bitmap allocation failed ({status}).")
        graphics = ctypes.c_void_p()
        status = gdiplus.GdipGetImageGraphicsContext(scaled, ctypes.byref(graphics))
        if status != 0 or not graphics.value:
            raise OSError(f"GDI+ graphics context creation failed ({status}).")
        # Nearest-neighbour preserves the small color regions used by the
        # deterministic recognizer and is substantially faster than smoothing.
        status = gdiplus.GdipSetInterpolationMode(graphics, 5)
        if status != 0:
            raise OSError(f"GDI+ interpolation setup failed ({status}).")
        status = gdiplus.GdipDrawImageRectI(graphics, image, 0, 0, out_width, out_height)
        if status != 0:
            raise OSError(f"GDI+ image resize failed ({status}).")
        gdiplus.GdipDeleteGraphics(graphics)
        graphics = None

        rect = Rect(0, 0, out_width, out_height)
        status = gdiplus.GdipBitmapLockBits(scaled, ctypes.byref(rect), 1,
                                            pixel_format_32bpp_argb, ctypes.byref(bitmap_data))
        if status != 0 or not bitmap_data.Scan0:
            raise OSError(f"GDI+ bitmap lock failed ({status}).")
        locked = True
        row_bytes = out_width * 4
        stride = int(bitmap_data.Stride)
        output = bytearray(out_height * row_bytes)
        base = int(bitmap_data.Scan0)
        for row in range(out_height):
            offset = row * stride if stride >= 0 else (out_height - 1 - row) * (-stride)
            output[row * row_bytes:(row + 1) * row_bytes] = ctypes.string_at(base + offset, row_bytes)
        return Frame(out_width, out_height, bytes(output)), (width, height)
    finally:
        if locked and scaled:
            try:
                gdiplus.GdipBitmapUnlockBits(scaled, ctypes.byref(bitmap_data))
            except Exception:
                pass
        if graphics:
            try:
                gdiplus.GdipDeleteGraphics(graphics)
            except Exception:
                pass
        for handle in (scaled, image):
            if handle:
                try:
                    gdiplus.GdipDisposeImage(handle)
                except Exception:
                    pass
        if stream:
            try:
                vtable = ctypes.cast(stream, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
                release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtable[2])
                release(stream)
            except Exception:
                pass
        gdiplus.GdiplusShutdown(token)


def decode_android_png(payload: bytes, max_width: int = 420) -> tuple[Frame, tuple[int, int]]:
    """Decode the 8-bit, non-interlaced PNG format emitted by Android screencap."""
    if not payload.startswith(_PNG_SIGNATURE):
        raise ValueError("ADB screencap did not return a PNG image.")
    offset = len(_PNG_SIGNATURE)
    width = height = bit_depth = color_type = interlace = None
    compressed = bytearray()
    while offset + 12 <= len(payload):
        length = int.from_bytes(payload[offset:offset + 4], "big")
        kind = payload[offset + 4:offset + 8]
        start = offset + 8
        end = start + length
        if end + 4 > len(payload):
            raise ValueError("Truncated PNG chunk.")
        chunk = payload[start:end]
        if kind == b"IHDR":
            if length != 13:
                raise ValueError("Invalid PNG header.")
            width = int.from_bytes(chunk[0:4], "big")
            height = int.from_bytes(chunk[4:8], "big")
            bit_depth, color_type = chunk[8], chunk[9]
            interlace = chunk[12]
        elif kind == b"IDAT":
            compressed.extend(chunk)
        elif kind == b"IEND":
            break
        offset = end + 4

    if (not width or not height or width > 8192 or height > 16384 or
            width * height > _MAX_PNG_PIXELS):
        raise ValueError("PNG dimensions are invalid or excessive.")
    if bit_depth != 8 or color_type not in (2, 6) or interlace != 0:
        raise ValueError("Unsupported Android PNG pixel format.")
    channels = 3 if color_type == 2 else 4
    stride = width * channels
    expected_raw_size = height * (stride + 1)
    if expected_raw_size > _MAX_PNG_RAW_BYTES:
        raise ValueError("PNG decompressed image exceeds the safety limit.")

    # Windows uses GDI+ to decode and resize in native code. If it is unavailable
    # or rejects a valid-but-unusual stream, fall back to the portable decoder.
    if os.name == "nt":
        try:
            return _decode_png_with_gdiplus(payload, width, height, max_width)
        except Exception:
            pass

    decompressor = zlib.decompressobj()
    raw = decompressor.decompress(bytes(compressed), expected_raw_size + 1)
    if len(raw) != expected_raw_size or decompressor.unconsumed_tail or not decompressor.eof:
        raise ValueError("PNG decompressed size does not match its dimensions.")

    decoded = bytearray(height * stride)
    src = 0
    for y in range(height):
        filter_type = raw[src]
        src += 1
        row_start = y * stride
        prev_start = row_start - stride
        if filter_type == 0:
            # The None filter is common for Android screenshots; copy whole rows
            # in C rather than iterating over every channel in Python.
            decoded[row_start:row_start + stride] = raw[src:src + stride]
            src += stride
            continue
        if filter_type not in (1, 2, 3, 4):
            raise ValueError("Unsupported PNG filter.")
        for x in range(stride):
            value = raw[src + x]
            left = decoded[row_start + x - channels] if x >= channels else 0
            up = decoded[prev_start + x] if y else 0
            upper_left = decoded[prev_start + x - channels] if y and x >= channels else 0
            if filter_type == 1:
                value = (value + left) & 0xFF
            elif filter_type == 2:
                value = (value + up) & 0xFF
            elif filter_type == 3:
                value = (value + ((left + up) // 2)) & 0xFF
            else:
                value = (value + _png_paeth(left, up, upper_left)) & 0xFF
            decoded[row_start + x] = value
        src += stride

    out_width = min(width, max(120, int(max_width)))
    out_height = max(1, round(height * out_width / width))
    bgra = bytearray(out_width * out_height * 4)
    # Precompute the nearest-neighbour map once; this removes repeated division
    # from the hottest per-pixel loop in the portable fallback.
    x_offsets = [min(width - 1, int(ox * width / out_width)) * channels
                 for ox in range(out_width)]
    y_offsets = [min(height - 1, int(oy * height / out_height)) * stride
                 for oy in range(out_height)]
    for oy, source_row in enumerate(y_offsets):
        target_row = oy * out_width * 4
        for ox, x_offset in enumerate(x_offsets):
            si = source_row + x_offset
            di = target_row + ox * 4
            bgra[di] = decoded[si + 2]
            bgra[di + 1] = decoded[si + 1]
            bgra[di + 2] = decoded[si]
            bgra[di + 3] = 255
    return Frame(out_width, out_height, bytes(bgra)), (width, height)


def _normal(value: str) -> str:
    return " ".join(str(value or "").lower().replace("\u3000", " ").split())


def _contains(value: str, terms: Iterable[str]) -> bool:
    return any(term in value for term in terms)


def _ladder_status_from_text(value: str) -> bool | None:
    """Return explicit ladder availability without matching 'locked' in 'unlocked'."""
    text = _normal(value)
    if not text:
        return None
    # Negative phrases take precedence over positive substrings.
    if (re.search(r"\b(?:not|never)\s+(?:yet\s+)?unlocked\b", text) or
            any(term in text for term in ("未解锁", "尚未解锁", "未开放", "尚未开放", "已锁定", "锁定"))):
        return False
    if (re.search(r"\bunlocked\b", text) or
            any(term in text for term in ("已解锁", "已开放", "已开启"))):
        return True
    # 'Unlock'/'解锁' is an action label (usually a locked-state CTA), not proof
    # that the mode is available. It is only treated as locked in ladder context.
    if re.search(r"\bunlock\b", text) or "解锁" in text:
        return False
    if re.search(r"\blocked\b", text):
        return False
    return None


LADDER_TERMS = ("trophy road", "ladder", "ranked", "天梯", "奖杯之路", "奖杯路")
JOURNEY_TERMS = ("path of legends", "royal journey", "皇室征程", "征程")
DECK_TERMS = ("your deck", "battle deck", "deck", "卡组", "卡牌")
BATTLE_TERMS = ("battle", "fight", "对战", "战斗", "开始对局", "开始战斗")
CONTINUE_TERMS = ("continue", "next battle", "continue battle", "继续", "下一场", "继续游戏")
RESULT_WIN_TERMS = ("victory", "you win", "winner", "胜利", "获胜")
RESULT_LOSS_TERMS = ("defeat", "you lose", "败北", "失败")
RESULT_DRAW_TERMS = ("draw", "平局", "平手")
MATCH_TERMS = ("searching for opponents", "finding opponent", "matchmaking", "正在寻找对手", "匹配中")
LOADING_TERMS = ("loading", "connecting", "正在加载", "连接中")


def enrich_state_with_accessibility(state: GameState, labels: list[AccessibilityLabel],
                                    screen_width: int, screen_height: int) -> GameState:
    """Add semantic scene/result/navigation evidence when Android exposes it."""
    if not labels or screen_width <= 0 or screen_height <= 0:
        return state

    all_text = " | ".join(label.value for label in labels if label.value)
    targets = {item.name: item for item in state.targets}

    def target_for(name: str, terms: tuple[str, ...], *, require_clickable: bool = True) -> NavigationTarget | None:
        matches = [label for label in labels
                   if _contains(label.value + " " + label.ancestor_text.lower(), terms)]
        for label in matches:
            context = (label.value + " " + label.ancestor_text).lower()
            if name in ("mode_entry", "start_match") and "pass" in context:
                continue
            bounds = label.target_bounds or label.bounds
            if bounds is None or (require_clickable and not label.target_clickable):
                continue
            if require_clickable and not label.target_enabled:
                continue
            x1, y1, x2, y2 = bounds
            cx = (x1 + x2) / (2.0 * screen_width)
            cy = (y1 + y2) / (2.0 * screen_height)
            if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0):
                continue
            targets[name] = NavigationTarget(name, cx, cy, 0.98 if label.target_clickable else 0.88)
            return targets[name]
        return None

    scene = state.scene
    result = state.result
    result_confidence = state.result_confidence
    ladder_unlocked = state.ladder_unlocked

    if _contains(all_text, RESULT_WIN_TERMS):
        scene, result, result_confidence = Scene.RESULT, "win", 0.99
    elif _contains(all_text, RESULT_LOSS_TERMS):
        scene, result, result_confidence = Scene.RESULT, "loss", 0.99
    elif _contains(all_text, RESULT_DRAW_TERMS):
        scene, result, result_confidence = Scene.RESULT, "draw", 0.99
    elif _contains(all_text, MATCH_TERMS):
        scene = Scene.MATCHMAKING
    elif _contains(all_text, LOADING_TERMS):
        scene = Scene.LOADING

    has_ladder = _contains(all_text, LADDER_TERMS)
    has_journey = _contains(all_text, JOURNEY_TERMS)
    if scene in (Scene.UNKNOWN, Scene.HOME) and has_ladder and has_journey:
        scene = Scene.MODE_SELECT
    elif scene in (Scene.UNKNOWN, Scene.HOME) and _contains(all_text, ("your deck", "battle deck", "卡组")):
        scene = Scene.DECK
    elif scene is Scene.UNKNOWN and _contains(all_text, ("battle", "play", "对战", "战斗")) and _contains(all_text, ("cards", "shop", "部落", "卡牌")):
        scene = Scene.HOME

    if scene is Scene.MODE_SELECT:
        ladder = target_for("ladder", LADDER_TERMS)
        journey = target_for("journey", JOURNEY_TERMS)
        # Include descendant labels whose clickable ancestor is the Trophy Road
        # control, e.g. a separate 'Unlocked' or 'Unlock at ...' badge.
        ladder_labels = [label for label in labels
                         if _contains(label.value, LADDER_TERMS) or
                         _contains(label.ancestor_text.lower(), LADDER_TERMS)]
        if ladder_labels:
            explicit_statuses = [
                _ladder_status_from_text(label.value + " " + label.ancestor_text)
                for label in ladder_labels
            ]
            if False in explicit_statuses:
                ladder_unlocked = False
            elif True in explicit_statuses:
                ladder_unlocked = True
            elif any(label.target_clickable and not label.target_enabled for label in ladder_labels):
                ladder_unlocked = False
            elif any(label.target_clickable and label.target_enabled for label in ladder_labels) and ladder is not None:
                ladder_unlocked = True
        target_for("start_match", ("battle now", "start battle", "battle", "fight", "开始对局", "开始战斗"))
    elif scene is Scene.HOME:
        target_for("deck_entry", DECK_TERMS)
        target_for("mode_entry", BATTLE_TERMS)
    elif scene is Scene.DECK:
        target_for("deck_back", ("battle", "home", "返回", "主界面", "对战"))
    elif scene is Scene.RESULT:
        target_for("result_continue", CONTINUE_TERMS)

    return replace(state, scene=scene,
                   battle_detected=(state.battle_detected if scene is Scene.BATTLE else False),
                   scene_confidence=max(state.scene_confidence, 0.96 if scene is not state.scene else state.scene_confidence),
                   result=result, result_confidence=result_confidence,
                   ladder_unlocked=ladder_unlocked,
                   targets=tuple(targets.values()))


class AdbBridge:
    """A single, verified virtual Android device connected through local ADB."""

    def __init__(self, adb_path: Path, serial: str, screen_width: int = 0, screen_height: int = 0):
        self.adb_path = str(adb_path)
        self.serial = serial
        self.screen_width = int(screen_width)
        self.screen_height = int(screen_height)

    @staticmethod
    def _creation_flags() -> int:
        return getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0

    def _run(self, args: list[str], timeout: float = 2.5,
             stop_event=None) -> subprocess.CompletedProcess:
        """Run ADB with short polling so the configured stop key interrupts I/O."""
        command = [self.adb_path, *args]
        if stop_event is not None and stop_event.is_set():
            return subprocess.CompletedProcess(command, 130, b"", b"cancelled by stop key")
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=self._creation_flags(),
        )
        deadline = time.monotonic() + max(0.05, timeout)
        while True:
            if stop_event is not None and stop_event.is_set():
                try:
                    process.terminate()
                except OSError:
                    pass
                try:
                    stdout, stderr = process.communicate(timeout=0.30)
                except subprocess.TimeoutExpired:
                    process.kill()
                    stdout, stderr = process.communicate()
                return subprocess.CompletedProcess(command, 130, stdout, stderr or b"cancelled by stop key")
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                process.kill()
                stdout, stderr = process.communicate()
                raise subprocess.TimeoutExpired(command, timeout, output=stdout, stderr=stderr)
            try:
                stdout, stderr = process.communicate(timeout=min(0.05, remaining))
                return subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
            except subprocess.TimeoutExpired:
                continue

    @classmethod
    def _candidate_paths(cls, hwnd: int) -> list[Path]:
        candidates: list[Path] = []
        process_path = window_process_path(hwnd)
        if process_path:
            parent = process_path.parent
            candidates.extend(parent / name for name in ("adb.exe", "HD-Adb.exe", "nox_adb.exe"))
            candidates.extend((parent.parent / "adb.exe", parent.parent / "HD-Adb.exe"))
        for command in ("adb.exe", "adb", "HD-Adb.exe", "nox_adb.exe"):
            located = shutil.which(command)
            if located:
                candidates.append(Path(located))
        env = os.environ
        for key in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
            value = env.get(key)
            if value:
                candidates.append(Path(value) / "platform-tools" / "adb.exe")
        local = Path(env.get("LOCALAPPDATA", ""))
        program_files = Path(env.get("ProgramFiles", r"C:\Program Files"))
        candidates.extend((
            local / "Android" / "Sdk" / "platform-tools" / "adb.exe",
            program_files / "BlueStacks_nxt" / "HD-Adb.exe",
            program_files / "BlueStacks" / "HD-Adb.exe",
            program_files / "LDPlayer" / "LDPlayer9" / "adb.exe",
            program_files / "Nox" / "bin" / "nox_adb.exe",
            program_files / "Microvirt" / "MEmu" / "adb.exe",
            program_files / "Netease" / "MuMuPlayer-12.0" / "shell" / "adb.exe",
            program_files / "MuMuPlayer-12.0" / "shell" / "adb.exe",
        ))
        unique: list[Path] = []
        seen: set[str] = set()
        for path in candidates:
            key = str(path).lower()
            if key not in seen and path.is_file():
                seen.add(key)
                unique.append(path)
        return unique

    @classmethod
    def for_window(cls, hwnd: int, stop_event=None) -> "AdbBridge | None":
        """Attach only to the selected emulator's local ADB or Android Emulator device."""
        process_path = window_process_path(hwnd)
        if process_path is None:
            return None
        trusted_dirs = {str(process_path.parent).lower(), str(process_path.parent.parent).lower()}
        android_emulator_process = any(token in process_path.name.lower()
                                       for token in ("emulator", "qemu"))
        for path in cls._candidate_paths(hwnd):
            if stop_event is not None and stop_event.is_set():
                return None
            # A global ADB may control an unrelated device. Only accept it for
            # the standard Android Emulator process; vendor emulators must expose
            # an ADB binary in their own installation tree.
            if str(path.parent).lower() not in trusted_dirs and not android_emulator_process:
                continue
            probe = cls(path, "")
            try:
                device_result = probe._run(["devices", "-l"], timeout=2.0, stop_event=stop_event)
                if device_result.returncode != 0:
                    continue
                devices = device_result.stdout.decode("utf-8", "replace")
            except (OSError, subprocess.TimeoutExpired):
                continue
            online = []
            for line in devices.splitlines():
                parts = line.split()
                if len(parts) >= 2 and parts[1] == "device" and parts[0] != "List":
                    online.append(parts[0])
            if len(online) != 1:
                continue
            serial = online[0]
            probe.serial = serial
            try:
                props = []
                for prop in ("ro.kernel.qemu", "ro.boot.qemu", "ro.product.model",
                             "ro.product.brand", "ro.product.device"):
                    if stop_event is not None and stop_event.is_set():
                        return None
                    result = probe._run(["-s", serial, "shell", "getprop", prop],
                                        timeout=1.0, stop_event=stop_event)
                    if result.returncode != 0:
                        props.append("")
                    else:
                        props.append(result.stdout.decode("utf-8", "replace").strip().lower())
                identity = " ".join(props).lower()
                virtual = serial.startswith("emulator-") or "1" in props[:2]
                virtual = virtual or any(token in identity for token in
                                         ("emulator", "bluestacks", "ldplayer", "nox", "mumu", "memu"))
                if not virtual:
                    continue
                # Vendor ADB must come from the selected emulator's installation
                # tree (checked above); the device itself must independently
                # identify as virtual. Brand/model strings are not reliable
                # across emulator images, so qemu/serial properties are used.
                if android_emulator_process and not (serial.startswith("emulator-") or
                                                     "1" in props[:2] or "qemu" in identity):
                    continue
                size_result = probe._run(["-s", serial, "shell", "wm", "size"],
                                         timeout=1.5, stop_event=stop_event)
                if size_result.returncode != 0:
                    continue
                size_text = size_result.stdout.decode("utf-8", "replace")
                match = re.search(r"(?:Physical|Override) size:\s*(\d+)x(\d+)", size_text)
                if not match:
                    continue
                probe.screen_width, probe.screen_height = int(match.group(1)), int(match.group(2))
                if probe.screen_width < 100 or probe.screen_height < 100:
                    continue
                return probe
            except (OSError, subprocess.TimeoutExpired):
                continue
        return None

    def capture_frame(self, max_width: int = 420, stop_event=None) -> Frame:
        result = self._run(["-s", self.serial, "exec-out", "screencap", "-p"],
                           timeout=4.0, stop_event=stop_event)
        if result.returncode != 0:
            message = result.stderr.decode("utf-8", "replace")[-300:]
            raise OSError(f"ADB screencap failed: {message}")
        frame, native_size = decode_android_png(result.stdout, max_width=max_width)
        self.screen_width, self.screen_height = native_size
        return frame

    def tap_ratio(self, x_ratio: float, y_ratio: float, stop_event=None) -> bool:
        if stop_event is not None and stop_event.is_set():
            return False
        if not (0.0 <= x_ratio <= 1.0 and 0.0 <= y_ratio <= 1.0):
            raise ValueError("Click ratios must be between 0 and 1.")
        if self.screen_width <= 0 or self.screen_height <= 0:
            raise OSError("ADB device screen dimensions are not known yet.")
        x = max(0, min(self.screen_width - 1, round(x_ratio * (self.screen_width - 1))))
        y = max(0, min(self.screen_height - 1, round(y_ratio * (self.screen_height - 1))))
        result = self._run(["-s", self.serial, "shell", "input", "tap", str(x), str(y)],
                           timeout=2.0, stop_event=stop_event)
        if result.returncode != 0:
            raise OSError(result.stderr.decode("utf-8", "replace")[-300:] or "ADB tap failed.")
        return not (stop_event is not None and stop_event.is_set())

    def swipe_ratio(self, x1: float, y1: float, x2: float, y2: float,
                    stop_event=None, duration_ms: int = 180) -> bool:
        if stop_event is not None and stop_event.is_set():
            return False
        for value in (x1, y1, x2, y2):
            if not 0.0 <= value <= 1.0:
                raise ValueError("Swipe ratios must be between 0 and 1.")
        if self.screen_width <= 0 or self.screen_height <= 0:
            raise OSError("ADB device screen dimensions are not known yet.")
        sx = round(x1 * (self.screen_width - 1))
        sy = round(y1 * (self.screen_height - 1))
        ex = round(x2 * (self.screen_width - 1))
        ey = round(y2 * (self.screen_height - 1))
        duration_ms = max(80, min(600, int(duration_ms)))
        result = self._run(["-s", self.serial, "shell", "input", "swipe",
                            str(sx), str(sy), str(ex), str(ey), str(duration_ms)],
                           timeout=2.0, stop_event=stop_event)
        if result.returncode != 0:
            raise OSError(result.stderr.decode("utf-8", "replace")[-300:] or "ADB swipe failed.")
        return not (stop_event is not None and stop_event.is_set())

    def read_ui_labels(self, stop_event=None) -> list[AccessibilityLabel]:
        """Read UIAutomator's stdout pipe; no XML file is created on the device."""
        result = self._run(["-s", self.serial, "shell", "uiautomator", "dump",
                            "--compressed", "/dev/stdout"], timeout=2.5,
                           stop_event=stop_event)
        if result.returncode != 0:
            return []
        output = result.stdout + b"\n" + result.stderr
        return parse_uiautomator_xml(output)
