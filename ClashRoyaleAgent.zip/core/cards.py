"""Bundled Clash Royale card metadata and deterministic semantic lookup.

The catalog contains card names and public game metadata only. It contains no
pretrained weights, image classifier, win-rate dataset, or remote dependency.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
import unicodedata


def normalize_card_name(value: str) -> str:
    """Normalize English/Chinese card labels without transliteration dependencies."""
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return "".join(ch for ch in text if ch.isalnum())


@dataclass(frozen=True)
class CardRecord:
    key: str
    name_en: str
    name_zh: str
    name_zh_tw: str
    card_type: str
    rarity: str
    elixir_cost: int | None
    official_id: int | None
    has_evolution: bool
    evolution_cycles: int | None
    has_hero: bool
    hero_ability_name: str
    hero_ability_cost: int | None
    is_champion: bool
    champion_ability_name: str
    champion_ability_cost: int | None

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(
            value for value in (self.name_en, self.name_zh, self.name_zh_tw) if value
        ))

    @property
    def available_forms(self) -> tuple[str, ...]:
        forms = ["base"]
        if self.has_evolution:
            forms.append("evolution")
        if self.has_hero:
            forms.append("hero")
        if self.is_champion:
            forms.append("champion")
        return tuple(forms)


@dataclass(frozen=True)
class CardRecognition:
    card_key: str
    name: str
    form: str
    level: int | None
    elite_level: bool
    confidence: float
    variant_confidence: float = 0.0
    bounds: tuple[int, int, int, int] | None = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("card recognition confidence must be between 0 and 1")
        if not 0.0 <= self.variant_confidence <= 1.0:
            raise ValueError("variant confidence must be between 0 and 1")
        if self.level is not None and not 1 <= self.level <= 16:
            raise ValueError("card level must be between 1 and 16")


# These tags are hand-curated game-role hints, not scraped meta or learned labels.
# They are intentionally broad and are only used after the card name is recognized.
_ROLE_KEYS = {
    "win_condition": {
        "hog-rider", "royal-giant", "giant", "goblin-barrel", "balloon",
        "royal-hogs", "graveyard", "x-bow", "mortar", "ram-rider", "golem",
        "lava-hound", "goblin-giant", "goblin-drill", "miner", "wall-breakers",
        "battle-ram", "elixir-golem", "skeleton-barrel", "electro-giant",
    },
    "tank": {
        "giant", "golem", "lava-hound", "goblin-giant", "electro-giant",
        "elixir-golem", "royal-giant", "mega-knight", "giant-skeleton",
        "rune-giant", "minion-giant",
    },
    "tank_killer": {
        "mini-pekka", "pekka", "inferno-tower", "inferno-dragon", "hunter",
        "sparky", "mighty-miner", "prince", "barbarians", "elite-barbarians",
        "lumberjack", "executioner", "cannon", "tesla",
    },
    "air_defense": {
        "archers", "minions", "spear-goblins", "electro-spirit", "skeleton-dragons",
        "fire-spirit", "bats", "musketeer", "mega-minion", "wizard",
        "flying-machine", "dart-goblin", "zappies", "baby-dragon", "witch",
        "hunter", "electro-dragon", "executioner", "electro-wizard",
        "inferno-dragon", "princess", "phoenix", "ice-wizard", "magic-archer",
        "night-witch", "mother-witch", "archer-queen", "little-prince",
        "firecracker", "three-musketeers",
    },
    "swarm": {
        "skeletons", "goblins", "spear-goblins", "bats", "barbarians",
        "royal-recruits", "goblin-gang", "minion-horde", "skeleton-army",
        "guards", "wall-breakers",
    },
    "support": {
        "archers", "musketeer", "wizard", "witch", "baby-dragon", "executioner",
        "electro-dragon", "magic-archer", "princess", "ice-wizard", "firecracker",
        "mother-witch", "archer-queen", "little-prince", "monk", "phoenix",
    },
    "ranged": {
        "archers", "spear-goblins", "minions", "musketeer", "wizard",
        "flying-machine", "dart-goblin", "zappies", "three-musketeers",
        "baby-dragon", "witch", "hunter", "electro-dragon", "executioner",
        "princess", "ice-wizard", "magic-archer", "mother-witch", "archer-queen",
        "little-prince", "firecracker", "cannon", "mortar", "x-bow",
    },
    "melee": {
        "knight", "goblins", "barbarians", "mini-pekka", "valkyrie",
        "hog-rider", "giant", "pekka", "dark-prince", "prince", "bandit",
        "lumberjack", "mega-knight", "miner", "mighty-miner", "monk",
    },
}


class CardDatabase:
    """Read-only, local catalog for every card/form in the bundled data snapshot."""

    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path is not None else (
            Path(__file__).resolve().parents[1] / "data" / "cards.tsv"
        )
        self._by_key: dict[str, CardRecord] = {}
        self._by_name: dict[str, CardRecord] = {}
        self.load_error = ""
        self._load()

    @staticmethod
    def _optional_int(value: str) -> int | None:
        value = str(value or "").strip()
        return int(value) if value.isdigit() else None

    def _load(self) -> None:
        try:
            lines = self.path.read_text(encoding="utf-8-sig").splitlines()
            if len(lines) > 512:
                raise ValueError("card catalog exceeds the 512-row safety limit")
            records: dict[str, CardRecord] = {}
            names: dict[str, CardRecord] = {}
            for line_number, line in enumerate(lines, 1):
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                parts = line.split("|")
                if len(parts) > 16:
                    raise ValueError(f"too many fields on card row {line_number}")
                parts.extend([""] * (16 - len(parts)))
                (key, name_en, name_zh, name_zh_tw, card_type, rarity, cost,
                 official_id, evo, evo_cycles, hero, hero_ability, hero_cost,
                 champion, champion_ability, champion_cost) = parts
                key = key.strip().lower()
                name_en = name_en.strip()
                if not key or not name_en or key in records:
                    raise ValueError(f"invalid or duplicate card row {line_number}")
                record = CardRecord(
                    key=key,
                    name_en=name_en,
                    name_zh=name_zh.strip(),
                    name_zh_tw=name_zh_tw.strip(),
                    card_type=card_type.strip(),
                    rarity=rarity.strip(),
                    elixir_cost=self._optional_int(cost),
                    official_id=self._optional_int(official_id),
                    has_evolution=evo.strip() == "1",
                    evolution_cycles=self._optional_int(evo_cycles),
                    has_hero=hero.strip() == "1",
                    hero_ability_name=hero_ability.strip(),
                    hero_ability_cost=self._optional_int(hero_cost),
                    is_champion=champion.strip() == "1",
                    champion_ability_name=champion_ability.strip(),
                    champion_ability_cost=self._optional_int(champion_cost),
                )
                records[key] = record
                for label in record.names:
                    normalized = normalize_card_name(label)
                    if normalized:
                        names.setdefault(normalized, record)
            if len(records) < 100:
                raise ValueError("bundled card catalog is incomplete")
            self._by_key = records
            self._by_name = names
            self.load_error = ""
        except (OSError, UnicodeError, ValueError) as exc:
            self._by_key = {}
            self._by_name = {}
            self.load_error = str(exc)[:300]

    def __len__(self) -> int:
        return len(self._by_key)

    @property
    def cards(self) -> tuple[CardRecord, ...]:
        return tuple(self._by_key.values())

    @property
    def evolution_count(self) -> int:
        return sum(record.has_evolution for record in self._by_key.values())

    @property
    def hero_count(self) -> int:
        return sum(record.has_hero for record in self._by_key.values())

    @property
    def champion_count(self) -> int:
        return sum(record.is_champion for record in self._by_key.values())

    def get(self, key: str) -> CardRecord | None:
        return self._by_key.get(str(key or "").strip().lower())

    def find(self, name: str) -> CardRecord | None:
        value = str(name or "").strip()
        if not value:
            return None
        normalized = normalize_card_name(value)
        if normalized in self._by_name:
            return self._by_name[normalized]
        # Strip common English and Chinese form/level prefixes, but never use
        # a fuzzy substring match that could confuse similar card names.
        for prefix in (
            "evolution", "evo", "hero", "champion", "level", "lvl", "lv",
            "進化", "进化", "英雄", "冠軍", "冠军",
        ):
            normalized_prefix = normalize_card_name(prefix)
            if normalized.startswith(normalized_prefix) and len(normalized) > len(normalized_prefix):
                candidate = normalized[len(normalized_prefix):]
                if candidate in self._by_name:
                    return self._by_name[candidate]
        cleaned = re.sub(
            r"^(?:evo(?:lution)?|hero|champion|level|lvl|lv)\s*\d*\s*",
            "", value, flags=re.IGNORECASE,
        )
        return self._by_name.get(normalize_card_name(cleaned))

    def roles_for(self, card: CardRecord | str) -> tuple[str, ...]:
        record = (self.get(card) or self.find(card)) if isinstance(card, str) else card
        if record is None:
            return ()
        roles = set()
        if record.card_type.casefold() == "spell":
            roles.add("spell")
        if record.card_type.casefold() == "building":
            roles.add("building")
        for role, keys in _ROLE_KEYS.items():
            if record.key in keys:
                roles.add(role)
        if record.elixir_cost is not None and record.elixir_cost <= 2:
            roles.add("cycle")
        if record.card_type.casefold() == "troop" and record.key not in _ROLE_KEYS["ranged"]:
            roles.add("melee")
        return tuple(role for role in (
            "win_condition", "spell", "air_defense", "building", "tank_killer",
            "swarm", "support", "cycle", "tank", "ranged", "melee",
        ) if role in roles)

    def resolve(self, name: str, *, level: int | None = None,
                evolution_marker: bool = False, hero_marker: bool = False,
                elite_marker: bool = False, confidence: float = 1.0,
                marker_confidence: float = 0.0,
                bounds: tuple[int, int, int, int] | None = None) -> CardRecognition | None:
        record = self.find(name)
        if record is None:
            return None
        if level is not None and not 1 <= int(level) <= 16:
            level = None
        form = "base"
        if evolution_marker and record.has_evolution:
            form = "evolution"
        elif hero_marker and record.has_hero:
            form = "hero"
        elif record.is_champion:
            form = "champion"
        return CardRecognition(
            card_key=record.key,
            name=record.name_en,
            form=form,
            level=level,
            elite_level=bool((level is not None and level >= 15) or elite_marker),
            confidence=max(0.0, min(1.0, float(confidence))),
            variant_confidence=max(0.0, min(1.0, float(marker_confidence))),
            bounds=bounds,
        )
