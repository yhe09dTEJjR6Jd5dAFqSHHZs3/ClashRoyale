"""DXGI Desktop Duplication screenshot fallback (Windows 11 x64, stdlib only).

The normal capture order remains GDI -> bounded WM_PRINTCLIENT -> DXGI. DXGI
captures the selected window's visible client rectangle from its owning monitor;
the caller still performs foreground/occlusion validation before and after capture.
"""
from __future__ import annotations

import ctypes
import os
import threading
from dataclasses import dataclass

from .win32 import Frame


HRESULT = ctypes.c_long
UINT = ctypes.c_uint32
ULONG = ctypes.c_ulong
_WINFUNCTYPE = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)

DXGI_ERROR_NOT_FOUND = 0x887A0002
DXGI_ERROR_ACCESS_LOST = 0x887A0026
DXGI_ERROR_WAIT_TIMEOUT = 0x887A0027
DXGI_FORMAT_B8G8R8A8_UNORM = 87
DXGI_FORMAT_B8G8R8A8_UNORM_SRGB = 91
D3D11_USAGE_STAGING = 3
D3D11_CPU_ACCESS_READ = 0x20000
D3D11_MAP_READ = 1
D3D11_SDK_VERSION = 7
D3D_DRIVER_TYPE_UNKNOWN = 0
D3D_FEATURE_LEVELS = (0xB100, 0xB000, 0xA100, 0xA000)


class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
        ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8),
    ]


def _guid(value: str) -> _GUID:
    import uuid
    parsed = uuid.UUID(value)
    data = parsed.bytes_le
    return _GUID(
        int.from_bytes(data[0:4], "little"),
        int.from_bytes(data[4:6], "little"),
        int.from_bytes(data[6:8], "little"),
        (ctypes.c_ubyte * 8).from_buffer_copy(data[8:16]),
    )


IID_IDXGIFACTORY1 = _guid("770aae78-f26f-4dba-a829-253c83d1b387")
IID_IDXGIOUTPUT1 = _guid("00cddea8-939b-4b83-a8fc-2e9a1bbfd6c3")
IID_ID3D11TEXTURE2D = _guid("6f15aaf2-d208-4e89-9ab4-489535d34f9c")


class _RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_int32), ("top", ctypes.c_int32),
        ("right", ctypes.c_int32), ("bottom", ctypes.c_int32),
    ]


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_int32), ("y", ctypes.c_int32)]


class _DXGI_OUTPUT_DESC(ctypes.Structure):
    _fields_ = [
        ("DeviceName", ctypes.c_wchar * 32),
        ("DesktopCoordinates", _RECT),
        ("AttachedToDesktop", ctypes.c_int32),
        ("Rotation", UINT),
        ("Monitor", ctypes.c_void_p),
    ]


class _SAMPLE_DESC(ctypes.Structure):
    _fields_ = [("Count", UINT), ("Quality", UINT)]


class _D3D11_TEXTURE2D_DESC(ctypes.Structure):
    _fields_ = [
        ("Width", UINT), ("Height", UINT), ("MipLevels", UINT),
        ("ArraySize", UINT), ("Format", UINT), ("SampleDesc", _SAMPLE_DESC),
        ("Usage", UINT), ("BindFlags", UINT), ("CPUAccessFlags", UINT),
        ("MiscFlags", UINT),
    ]


class _D3D11_MAPPED_SUBRESOURCE(ctypes.Structure):
    _fields_ = [
        ("pData", ctypes.c_void_p), ("RowPitch", UINT), ("DepthPitch", UINT),
    ]


class _LARGE_INTEGER(ctypes.Structure):
    _fields_ = [("QuadPart", ctypes.c_int64)]


class _DXGI_OUTDUPL_POINTER_POSITION(ctypes.Structure):
    _fields_ = [("Position", _POINT), ("Visible", ctypes.c_int32)]


class _DXGI_OUTDUPL_FRAME_INFO(ctypes.Structure):
    _fields_ = [
        ("LastPresentTime", _LARGE_INTEGER),
        ("LastMouseUpdateTime", _LARGE_INTEGER),
        ("AccumulatedFrames", UINT),
        ("RectsCoalesced", ctypes.c_int32),
        ("ProtectedContentMaskedOut", ctypes.c_int32),
        ("PointerPosition", _DXGI_OUTDUPL_POINTER_POSITION),
        ("TotalMetadataBufferSize", UINT),
        ("PointerShapeBufferSize", UINT),
    ]


def _com_call(pointer, index: int, restype, argtypes, *args):
    if not pointer:
        raise OSError("DXGI COM interface pointer is null.")
    vtable = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
    address = vtable[index]
    if not address:
        raise OSError(f"DXGI COM method {index} is unavailable.")
    prototype = _WINFUNCTYPE(restype, ctypes.c_void_p, *argtypes)
    return prototype(address)(pointer, *args)


def _release(pointer) -> None:
    if pointer:
        try:
            _com_call(pointer, 2, ULONG, ())
        except Exception:
            pass


def _query_interface(pointer, iid: _GUID):
    output = ctypes.c_void_p()
    hr = _com_call(
        pointer, 0, HRESULT,
        (ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)),
        ctypes.byref(iid), ctypes.byref(output),
    )
    _check_hresult(hr, "QueryInterface")
    return output


def _check_hresult(hr, operation: str) -> None:
    value = int(hr) & 0xFFFFFFFF
    if value & 0x80000000:
        raise OSError(f"{operation} failed (HRESULT 0x{value:08X}).")


def _create_d3d_device(adapter):
    d3d11 = ctypes.WinDLL("d3d11.dll", use_last_error=True)
    create = d3d11.D3D11CreateDevice
    create.argtypes = [
        ctypes.c_void_p, UINT, ctypes.c_void_p, UINT, ctypes.POINTER(UINT), UINT,
        UINT, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(UINT),
        ctypes.POINTER(ctypes.c_void_p),
    ]
    create.restype = HRESULT
    levels = (UINT * len(D3D_FEATURE_LEVELS))(*D3D_FEATURE_LEVELS)
    device = ctypes.c_void_p()
    context = ctypes.c_void_p()
    selected = UINT()
    hr = create(
        adapter, D3D_DRIVER_TYPE_UNKNOWN, None, 0, levels,
        len(D3D_FEATURE_LEVELS), D3D11_SDK_VERSION,
        ctypes.byref(device), ctypes.byref(selected), ctypes.byref(context),
    )
    if (int(hr) & 0xFFFFFFFF) == 0x80070057:
        fallback = (UINT * 3)(0xB000, 0xA100, 0xA000)
        hr = create(
            adapter, D3D_DRIVER_TYPE_UNKNOWN, None, 0, fallback, 3,
            D3D11_SDK_VERSION, ctypes.byref(device), ctypes.byref(selected),
            ctypes.byref(context),
        )
    _check_hresult(hr, "D3D11CreateDevice")
    return device, context


@dataclass
class _DuplicationSession:
    monitor: int
    desktop: tuple[int, int, int, int]
    rotation: int
    device: ctypes.c_void_p
    context: ctypes.c_void_p
    duplication: ctypes.c_void_p
    staging: ctypes.c_void_p | None = None
    staging_size: tuple[int, int, int] | None = None

    def close(self) -> None:
        if self.staging:
            _release(self.staging)
            self.staging = None
        _release(self.duplication)
        _release(self.context)
        _release(self.device)
        self.duplication = self.context = self.device = None

    def _ensure_staging(self, source_desc: _D3D11_TEXTURE2D_DESC) -> None:
        size = (int(source_desc.Width), int(source_desc.Height), int(source_desc.Format))
        if self.staging is not None and self.staging_size == size:
            return
        if self.staging:
            _release(self.staging)
            self.staging = None
        if source_desc.Format not in (DXGI_FORMAT_B8G8R8A8_UNORM, DXGI_FORMAT_B8G8R8A8_UNORM_SRGB):
            raise OSError(f"Unsupported DXGI desktop pixel format {source_desc.Format}.")
        desc = _D3D11_TEXTURE2D_DESC()
        desc.Width = source_desc.Width
        desc.Height = source_desc.Height
        desc.MipLevels = 1
        desc.ArraySize = 1
        desc.Format = source_desc.Format
        desc.SampleDesc.Count = 1
        desc.SampleDesc.Quality = 0
        desc.Usage = D3D11_USAGE_STAGING
        desc.BindFlags = 0
        desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ
        desc.MiscFlags = 0
        staging = ctypes.c_void_p()
        hr = _com_call(
            self.device, 5, HRESULT,
            (ctypes.POINTER(_D3D11_TEXTURE2D_DESC), ctypes.c_void_p,
             ctypes.POINTER(ctypes.c_void_p)),
            ctypes.byref(desc), None, ctypes.byref(staging),
        )
        _check_hresult(hr, "ID3D11Device.CreateTexture2D(staging)")
        self.staging = staging
        self.staging_size = size

    def capture(self, hwnd: int, max_width: int, timeout_ms: int = 120) -> Frame:
        if self.rotation not in (0, 1):
            raise OSError("DXGI fallback currently requires an unrotated desktop output.")
        frame_info = _DXGI_OUTDUPL_FRAME_INFO()
        resource = ctypes.c_void_p()
        hr = _com_call(
            self.duplication, 8, HRESULT,
            (UINT, ctypes.POINTER(_DXGI_OUTDUPL_FRAME_INFO), ctypes.POINTER(ctypes.c_void_p)),
            UINT(max(0, min(500, timeout_ms))), ctypes.byref(frame_info),
            ctypes.byref(resource),
        )
        value = int(hr) & 0xFFFFFFFF
        if value == DXGI_ERROR_WAIT_TIMEOUT:
            raise OSError("DXGI Desktop Duplication timed out waiting for a fresh frame.")
        if value == DXGI_ERROR_ACCESS_LOST:
            raise OSError("DXGI Desktop Duplication access was lost; the session must be recreated.")
        _check_hresult(hr, "IDXGIOutputDuplication.AcquireNextFrame")

        texture = ctypes.c_void_p()
        mapped = _D3D11_MAPPED_SUBRESOURCE()
        mapped_ok = False
        frame_acquired = True
        try:
            texture = _query_interface(resource, IID_ID3D11TEXTURE2D)
            source_desc = _D3D11_TEXTURE2D_DESC()
            _com_call(texture, 10, None, (ctypes.POINTER(_D3D11_TEXTURE2D_DESC),),
                      ctypes.byref(source_desc))
            self._ensure_staging(source_desc)
            _com_call(self.context, 47, None, (ctypes.c_void_p, ctypes.c_void_p),
                      self.staging, texture)
            hr = _com_call(
                self.context, 14, HRESULT,
                (ctypes.c_void_p, UINT, UINT, UINT,
                 ctypes.POINTER(_D3D11_MAPPED_SUBRESOURCE)),
                self.staging, UINT(0), UINT(D3D11_MAP_READ), UINT(0),
                ctypes.byref(mapped),
            )
            _check_hresult(hr, "ID3D11DeviceContext.Map")
            mapped_ok = True
            if not mapped.pData or mapped.RowPitch < source_desc.Width * 4:
                raise OSError("DXGI staging surface has an invalid row pitch.")
            return _crop_desktop_frame(
                hwnd, self.desktop, int(source_desc.Width), int(source_desc.Height),
                int(mapped.RowPitch), mapped.pData, max_width,
            )
        finally:
            if mapped_ok:
                try:
                    _com_call(self.context, 15, None, (ctypes.c_void_p, UINT),
                              self.staging, UINT(0))
                except Exception:
                    pass
            if texture:
                _release(texture)
            if resource:
                _release(resource)
            if frame_acquired:
                try:
                    _com_call(self.duplication, 14, HRESULT, ())
                except Exception:
                    pass


def _crop_desktop_frame(hwnd: int, desktop: tuple[int, int, int, int],
                        texture_width: int, texture_height: int, row_pitch: int,
                        pixels, max_width: int) -> Frame:
    user32 = ctypes.WinDLL("user32.dll", use_last_error=True)
    user32.GetClientRect.argtypes = [ctypes.c_void_p, ctypes.POINTER(_RECT)]
    user32.GetClientRect.restype = ctypes.c_int
    user32.ClientToScreen.argtypes = [ctypes.c_void_p, ctypes.POINTER(_POINT)]
    user32.ClientToScreen.restype = ctypes.c_int
    client = _RECT()
    if not user32.GetClientRect(ctypes.c_void_p(hwnd), ctypes.byref(client)):
        raise OSError("GetClientRect failed during DXGI crop.")
    top_left = _POINT(client.left, client.top)
    bottom_right = _POINT(client.right, client.bottom)
    if (not user32.ClientToScreen(ctypes.c_void_p(hwnd), ctypes.byref(top_left)) or
            not user32.ClientToScreen(ctypes.c_void_p(hwnd), ctypes.byref(bottom_right))):
        raise OSError("ClientToScreen failed during DXGI crop.")
    left, top, right, bottom = desktop
    x0, y0 = top_left.x - left, top_left.y - top
    x1, y1 = bottom_right.x - left, bottom_right.y - top
    if not (0 <= x0 < x1 <= texture_width and 0 <= y0 < y1 <= texture_height):
        raise OSError("Selected window client area is not fully inside the duplicated DXGI output.")
    width, height = x1 - x0, y1 - y0
    if width * height > 32_000_000:
        raise OSError("DXGI crop dimensions exceed the safety limit.")
    out_width = min(max(120, int(max_width)), width)
    out_height = max(1, int(height * out_width / width))
    raw = ctypes.string_at(pixels, row_pitch * texture_height)
    output = bytearray(out_width * out_height * 4)
    x_offsets = [x0 + min(width - 1, int(x * width / out_width)) for x in range(out_width)]
    for oy in range(out_height):
        sy = y0 + min(height - 1, int(oy * height / out_height))
        source_row = sy * row_pitch
        target_row = oy * out_width * 4
        for ox, sx in enumerate(x_offsets):
            si = source_row + sx * 4
            di = target_row + ox * 4
            output[di:di + 4] = raw[si:si + 4]
    return Frame(out_width, out_height, bytes(output), hwnd)


_SESSIONS: dict[int, _DuplicationSession] = {}
_SESSION_LOCK = threading.Lock()


def _create_session(hwnd: int) -> _DuplicationSession:
    if os.name != "nt":
        raise OSError("DXGI Desktop Duplication is available only on Windows.")
    user32 = ctypes.WinDLL("user32.dll", use_last_error=True)
    user32.MonitorFromWindow.argtypes = [ctypes.c_void_p, UINT]
    user32.MonitorFromWindow.restype = ctypes.c_void_p
    monitor = int(user32.MonitorFromWindow(ctypes.c_void_p(hwnd), UINT(2)) or 0)
    if not monitor:
        raise OSError("MonitorFromWindow could not resolve the selected window's monitor.")

    dxgi = ctypes.WinDLL("dxgi.dll", use_last_error=True)
    create_factory = dxgi.CreateDXGIFactory1
    create_factory.argtypes = [ctypes.POINTER(_GUID), ctypes.POINTER(ctypes.c_void_p)]
    create_factory.restype = HRESULT
    factory = ctypes.c_void_p()
    hr = create_factory(ctypes.byref(IID_IDXGIFACTORY1), ctypes.byref(factory))
    _check_hresult(hr, "CreateDXGIFactory1")

    selected = None
    try:
        for adapter_index in range(16):
            adapter = ctypes.c_void_p()
            hr = _com_call(
                factory, 12, HRESULT,
                (UINT, ctypes.POINTER(ctypes.c_void_p)),
                UINT(adapter_index), ctypes.byref(adapter),
            )
            if (int(hr) & 0xFFFFFFFF) == DXGI_ERROR_NOT_FOUND:
                break
            _check_hresult(hr, "IDXGIFactory1.EnumAdapters1")
            try:
                for output_index in range(16):
                    output = ctypes.c_void_p()
                    hr = _com_call(
                        adapter, 7, HRESULT,
                        (UINT, ctypes.POINTER(ctypes.c_void_p)),
                        UINT(output_index), ctypes.byref(output),
                    )
                    if (int(hr) & 0xFFFFFFFF) == DXGI_ERROR_NOT_FOUND:
                        break
                    _check_hresult(hr, "IDXGIAdapter.EnumOutputs")
                    try:
                        desc = _DXGI_OUTPUT_DESC()
                        hr = _com_call(output, 7, HRESULT,
                                       (ctypes.POINTER(_DXGI_OUTPUT_DESC),),
                                       ctypes.byref(desc))
                        _check_hresult(hr, "IDXGIOutput.GetDesc")
                        if int(desc.Monitor or 0) != monitor or not desc.AttachedToDesktop:
                            continue
                        output1 = _query_interface(output, IID_IDXGIOUTPUT1)
                        device = context = duplication = None
                        try:
                            device, context = _create_d3d_device(adapter)
                            duplication = ctypes.c_void_p()
                            hr = _com_call(
                                output1, 20, HRESULT,
                                (ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)),
                                device, ctypes.byref(duplication),
                            )
                            _check_hresult(hr, "IDXGIOutput1.DuplicateOutput")
                            coords = desc.DesktopCoordinates
                            selected = _DuplicationSession(
                                monitor=monitor,
                                desktop=(coords.left, coords.top, coords.right, coords.bottom),
                                rotation=int(desc.Rotation), device=device,
                                context=context, duplication=duplication,
                            )
                            device = context = duplication = None
                            return selected
                        finally:
                            _release(duplication)
                            _release(context)
                            _release(device)
                            _release(output1)
                    finally:
                        _release(output)
            finally:
                _release(adapter)
    finally:
        _release(factory)
    raise OSError("No DXGI output duplication interface matches the selected window monitor.")


def capture_window_dxgi(hwnd: int, max_width: int = 420) -> Frame:
    """Capture the visible client area via DXGI; raises if this backend is unavailable."""
    if os.name != "nt":
        raise OSError("DXGI Desktop Duplication requires Windows 11.")
    user32 = ctypes.WinDLL("user32.dll", use_last_error=True)
    user32.MonitorFromWindow.argtypes = [ctypes.c_void_p, UINT]
    user32.MonitorFromWindow.restype = ctypes.c_void_p
    monitor = int(user32.MonitorFromWindow(ctypes.c_void_p(hwnd), UINT(2)) or 0)
    if not monitor:
        raise OSError("Selected window has no desktop monitor.")
    with _SESSION_LOCK:
        session = _SESSIONS.get(monitor)
        if session is None:
            session = _create_session(hwnd)
            _SESSIONS[monitor] = session
    try:
        return session.capture(hwnd, max_width)
    except OSError as exc:
        # ACCESS_LOST means Windows recreated the output surface. Drop the old
        # COM chain; the next capture will build a fresh duplication session.
        if "access was lost" in str(exc).casefold():
            with _SESSION_LOCK:
                stale = _SESSIONS.pop(monitor, None)
            if stale:
                stale.close()
        raise
