"""Hardened, dependency-free Win32 window capture and input helpers.

Input is deliberately fail-closed: the selected game window must be the foreground
window and the target points must belong to it before a screenshot or click is
allowed.  This prevents clicks leaking into unrelated desktop applications.
"""
from __future__ import annotations

import ctypes
import os
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class WindowInfo:
    hwnd: int
    title: str
    class_name: str
    x: int
    y: int
    width: int
    height: int

    @property
    def label(self) -> str:
        return f"{self.title}  ·  {self.width}×{self.height}  ·  {self.hwnd:x}"


class Frame:
    __slots__ = ("width", "height", "bgra", "captured_at", "source_hwnd")

    def __init__(self, width: int, height: int, bgra: bytes, source_hwnd: int = 0):
        if width <= 0 or height <= 0 or len(bgra) < width * height * 4:
            raise ValueError("Invalid BGRA frame dimensions or buffer length.")
        self.width = width
        self.height = height
        self.bgra = bgra
        self.captured_at = time.monotonic()
        self.source_hwnd = int(source_hwnd)


def _require_windows() -> None:
    if os.name != "nt":
        raise OSError("This application requires Windows 11 x64.")


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32),
        ("biHeight", ctypes.c_int32), ("biPlanes", ctypes.c_uint16),
        ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32),
        ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_int32),
        ("biYPelsPerMeter", ctypes.c_int32), ("biClrUsed", ctypes.c_uint32),
        ("biClrImportant", ctypes.c_uint32),
    ]


class _RGBQUAD(ctypes.Structure):
    _fields_ = [("rgbBlue", ctypes.c_ubyte), ("rgbGreen", ctypes.c_ubyte),
                ("rgbRed", ctypes.c_ubyte), ("rgbReserved", ctypes.c_ubyte)]


class _BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", _BITMAPINFOHEADER), ("bmiColors", _RGBQUAD * 1)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long), ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_uint32), ("dwFlags", ctypes.c_uint32),
        ("time", ctypes.c_uint32), ("dwExtraInfo", ctypes.c_size_t),
    ]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", _MOUSEINPUT)]


class _INPUT(ctypes.Structure):
    _anonymous_ = ("union",)
    _fields_ = [("type", ctypes.c_uint32), ("union", _INPUTUNION)]


class _FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", ctypes.c_uint32), ("dwHighDateTime", ctypes.c_uint32)]


class _PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_uint32), ("PageFaultCount", ctypes.c_uint32),
        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def set_dpi_awareness(user32=None) -> bool:
    """Enable Per-Monitor DPI Awareness V2 before creating UI or capture handles."""
    if os.name != "nt":
        return False
    try:
        if user32 is None:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
        context = getattr(user32, "SetProcessDpiAwarenessContext", None)
        if context is not None:
            context.argtypes = [ctypes.c_void_p]
            context.restype = ctypes.c_int
            if context(ctypes.c_void_p(-4)):
                return True
    except Exception:
        pass
    try:
        shcore = ctypes.WinDLL("shcore", use_last_error=True)
        shcore.SetProcessDpiAwareness.argtypes = [ctypes.c_int]
        shcore.SetProcessDpiAwareness.restype = ctypes.c_long
        if shcore.SetProcessDpiAwareness(2) == 0:
            return True
    except Exception:
        pass
    try:
        if user32 is None:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
        return bool(user32.SetProcessDPIAware())
    except Exception:
        return False


@lru_cache(maxsize=1)
def _apis():
    _require_windows()
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    handle, uint, integer, boolean = ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_int

    user32.GetDC.argtypes = [handle]
    user32.GetDC.restype = handle
    user32.SendMessageTimeoutW.argtypes = [
        handle, uint, ctypes.c_size_t, ctypes.c_ssize_t, uint, uint,
        ctypes.POINTER(ctypes.c_size_t),
    ]
    user32.SendMessageTimeoutW.restype = ctypes.c_size_t
    user32.ReleaseDC.argtypes = [handle, handle]
    user32.ReleaseDC.restype = integer
    user32.GetClientRect.argtypes = [handle, ctypes.POINTER(_RECT)]
    user32.GetClientRect.restype = boolean
    user32.ClientToScreen.argtypes = [handle, ctypes.POINTER(_POINT)]
    user32.ClientToScreen.restype = boolean
    user32.IsWindow.argtypes = [handle]
    user32.IsWindow.restype = boolean
    user32.IsWindowVisible.argtypes = [handle]
    user32.IsWindowVisible.restype = boolean
    user32.IsIconic.argtypes = [handle]
    user32.IsIconic.restype = boolean
    user32.GetForegroundWindow.argtypes = []
    user32.GetForegroundWindow.restype = handle
    user32.GetWindowRect.argtypes = [handle, ctypes.POINTER(_RECT)]
    user32.GetWindowRect.restype = boolean
    user32.GetAncestor.argtypes = [handle, uint]
    user32.GetAncestor.restype = handle
    user32.WindowFromPoint.argtypes = [_POINT]
    user32.WindowFromPoint.restype = handle
    user32.GetWindowTextLengthW.argtypes = [handle]
    user32.GetWindowTextLengthW.restype = integer
    user32.GetWindowTextW.argtypes = [handle, ctypes.c_wchar_p, integer]
    user32.GetWindowTextW.restype = integer
    user32.GetClassNameW.argtypes = [handle, ctypes.c_wchar_p, integer]
    user32.GetClassNameW.restype = integer
    user32.ShowWindow.argtypes = [handle, integer]
    user32.ShowWindow.restype = boolean
    user32.BringWindowToTop.argtypes = [handle]
    user32.BringWindowToTop.restype = boolean
    user32.SetForegroundWindow.argtypes = [handle]
    user32.SetForegroundWindow.restype = boolean
    user32.SetCursorPos.argtypes = [integer, integer]
    user32.SetCursorPos.restype = boolean
    user32.mouse_event.argtypes = [uint, uint, uint, uint, ctypes.c_size_t]
    user32.mouse_event.restype = None
    user32.SendInput.argtypes = [uint, ctypes.POINTER(_INPUT), integer]
    user32.SendInput.restype = uint
    user32.GetAsyncKeyState.argtypes = [integer]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.GetWindowThreadProcessId.argtypes = [handle, ctypes.POINTER(ctypes.c_uint32)]
    user32.GetWindowThreadProcessId.restype = uint

    # Per-monitor-v2 DPI awareness is requested before creating UI/capture handles.
    set_dpi_awareness(user32=user32)

    gdi32.CreateCompatibleDC.argtypes = [handle]
    gdi32.CreateCompatibleDC.restype = handle
    gdi32.CreateCompatibleBitmap.argtypes = [handle, integer, integer]
    gdi32.CreateCompatibleBitmap.restype = handle
    gdi32.SelectObject.argtypes = [handle, handle]
    gdi32.SelectObject.restype = handle
    gdi32.SetStretchBltMode.argtypes = [handle, integer]
    gdi32.SetStretchBltMode.restype = integer
    gdi32.StretchBlt.argtypes = [handle, integer, integer, integer, integer,
                                 handle, integer, integer, integer, integer, uint]
    gdi32.StretchBlt.restype = boolean
    gdi32.GetDIBits.argtypes = [handle, handle, uint, uint, ctypes.c_void_p,
                                ctypes.POINTER(_BITMAPINFO), uint]
    gdi32.GetDIBits.restype = integer
    gdi32.DeleteObject.argtypes = [handle]
    gdi32.DeleteObject.restype = boolean
    gdi32.DeleteDC.argtypes = [handle]
    gdi32.DeleteDC.restype = boolean
    return user32, gdi32


def _root_window(user32, hwnd: int) -> int:
    GA_ROOT = 2
    root = user32.GetAncestor(ctypes.c_void_p(hwnd), GA_ROOT)
    return int(root or hwnd)


def _get_client_rect(hwnd: int) -> tuple[int, int, int, int]:
    user32, _ = _apis()
    h = ctypes.c_void_p(hwnd)
    rect = _RECT()
    if not user32.GetClientRect(h, ctypes.byref(rect)):
        raise OSError("Cannot read game-window client area.")
    point = _POINT(0, 0)
    if not user32.ClientToScreen(h, ctypes.byref(point)):
        raise OSError("Cannot locate game-window client area on screen.")
    width, height = int(rect.right - rect.left), int(rect.bottom - rect.top)
    if width < 100 or height < 100:
        raise OSError("Game window is too small or minimized.")
    return int(point.x), int(point.y), width, height


def window_exists(hwnd: int) -> bool:
    """Check that the selected visible window still exists, including minimized windows."""
    try:
        user32, _ = _apis()
        h = ctypes.c_void_p(hwnd)
        return bool(user32.IsWindow(h) and user32.IsWindowVisible(h))
    except Exception:
        return False


def window_identity_matches(hwnd: int, title: str = "", class_name: str = "",
                            process_path: Path | None = None,
                            process_id: int | None = None) -> bool:
    """Verify that an HWND still belongs to the exact user-selected window.

    HWND values are recycled by Windows. Existence alone is therefore not an
    identity check and must never authorize input after a window is destroyed.
    """
    if not window_exists(hwnd):
        return False
    try:
        user32, _ = _apis()
        h = ctypes.c_void_p(hwnd)
        if title:
            length = int(user32.GetWindowTextLengthW(h))
            title_buf = ctypes.create_unicode_buffer(min(max(length + 1, 2), 1024))
            user32.GetWindowTextW(h, title_buf, len(title_buf))
            if title_buf.value.strip() != str(title).strip():
                return False
        if class_name:
            class_buf = ctypes.create_unicode_buffer(512)
            user32.GetClassNameW(h, class_buf, len(class_buf))
            if class_buf.value != str(class_name):
                return False
        if process_path is not None:
            actual = window_process_path(hwnd)
            if actual is None:
                return False
            expected_key = os.path.normcase(os.path.normpath(str(process_path))).casefold()
            actual_key = os.path.normcase(os.path.normpath(str(actual))).casefold()
            if expected_key != actual_key:
                return False
        if process_id is not None and window_process_id(hwnd) != int(process_id):
            return False
        return True
    except Exception:
        return False


def window_is_valid(hwnd: int) -> bool:
    """True when the selected window exists, is visible, and is not minimized."""
    try:
        user32, _ = _apis()
        h = ctypes.c_void_p(hwnd)
        return bool(user32.IsWindow(h) and user32.IsWindowVisible(h) and not user32.IsIconic(h))
    except Exception:
        return False


def window_process_path(hwnd: int) -> Optional[Path]:
    """Return the executable path owning a selected top-level window, if accessible."""
    if os.name != "nt":
        return None
    try:
        user32, _ = _apis()
        pid = ctypes.c_uint32()
        if not user32.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid)) or not pid.value:
            return None
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.QueryFullProcessImageNameW.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                                         ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_uint32)]
        kernel32.QueryFullProcessImageNameW.restype = ctypes.c_int
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_int
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid.value)
        if not handle:
            return None
        try:
            buffer = ctypes.create_unicode_buffer(32768)
            length = ctypes.c_uint32(len(buffer))
            if not kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(length)):
                return None
            return Path(buffer.value)
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return None


def window_process_id(hwnd: int) -> int | None:
    """Return the owning process ID for a top-level window, if accessible."""
    if os.name != "nt":
        return None
    try:
        user32, _ = _apis()
        pid = ctypes.c_uint32()
        if not user32.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid)):
            return None
        return int(pid.value) if pid.value else None
    except Exception:
        return None


def window_is_foreground(hwnd: int) -> bool:
    """True only when the selected top-level game window is the active foreground window."""
    try:
        user32, _ = _apis()
        if not window_is_valid(hwnd):
            return False
        foreground = int(user32.GetForegroundWindow() or 0)
        return foreground == _root_window(user32, hwnd)
    except Exception:
        return False


def window_is_interactive(hwnd: int, check_occlusion: bool = True) -> bool:
    """Verify foreground ownership and that representative client points are unobscured."""
    try:
        user32, _ = _apis()
        if not window_is_foreground(hwnd):
            return False
        if not check_occlusion:
            return True
        x, y, width, height = _get_client_rect(hwnd)
        root = _root_window(user32, hwnd)
        # A denser grid covers arena, navigation, and card-hand regions. Every
        # sample must resolve to the selected window or one of its child windows.
        # A 5x5 interior grid covers the card hand, navigation tabs, arena and
        # edge controls.  This is intentionally stricter than a few center points.
        samples = tuple((rx, ry) for ry in (0.06, 0.28, 0.50, 0.72, 0.94)
                        for rx in (0.06, 0.28, 0.50, 0.72, 0.94))
        for rx, ry in samples:
            point = _POINT(x + int(width * rx), y + int(height * ry))
            child = int(user32.WindowFromPoint(point) or 0)
            if not child or _root_window(user32, child) != root:
                return False
        return True
    except Exception:
        return False


def process_metrics() -> dict[str, float] | None:
    """Return current-process CPU time and memory without external packages."""
    if os.name != "nt":
        return None
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        kernel32.GetCurrentProcess.argtypes = []
        kernel32.GetCurrentProcess.restype = ctypes.c_void_p
        handle = kernel32.GetCurrentProcess()
        kernel32.GetProcessTimes.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(_FILETIME), ctypes.POINTER(_FILETIME),
            ctypes.POINTER(_FILETIME), ctypes.POINTER(_FILETIME),
        ]
        kernel32.GetProcessTimes.restype = ctypes.c_int
        creation, exit_time, kernel, user = _FILETIME(), _FILETIME(), _FILETIME(), _FILETIME()
        if not kernel32.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(exit_time),
                                        ctypes.byref(kernel), ctypes.byref(user)):
            return None
        counters = _PROCESS_MEMORY_COUNTERS()
        counters.cb = ctypes.sizeof(_PROCESS_MEMORY_COUNTERS)
        psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p,
                                               ctypes.POINTER(_PROCESS_MEMORY_COUNTERS),
                                               ctypes.c_uint32]
        psapi.GetProcessMemoryInfo.restype = ctypes.c_int
        if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
            return None
        kernel_ticks = (int(kernel.dwHighDateTime) << 32) | int(kernel.dwLowDateTime)
        user_ticks = (int(user.dwHighDateTime) << 32) | int(user.dwLowDateTime)
        return {
            "cpu_seconds": (kernel_ticks + user_ticks) / 10_000_000.0,
            "working_set_bytes": float(counters.WorkingSetSize),
            "commit_charge_bytes": float(counters.PagefileUsage),
        }
    except Exception:
        return None


def is_android_emulator_window(hwnd: int, title: str = "", class_name: str = "",
                               process_path: Path | None = None) -> bool:
    """Return true only for a clearly identified Android emulator process/window."""
    tokens = ("bluestacks", "hd-player", "ldplayer", "dnplayer", "nox", "mumu",
              "mumuplayer", "memu", "genymotion", "android emulator", "emulator.exe",
              "qemu", "腾讯手游助手", "雷电")
    text = f"{title} {class_name}"
    if process_path is not None:
        text += " " + Path(process_path).as_posix()
    folded = text.casefold()
    if any(token in folded for token in tokens):
        return True
    # A generic Android class name alone is not enough to trigger ADB discovery.
    return False


def list_game_windows() -> list[WindowInfo]:
    """Return visible, plausible game windows; the user must choose explicitly.

    Native Windows/Google Play Games clients are not required to expose an
    Android-emulator title or portrait aspect ratio.  Prefer an explicit
    Clash Royale / Google Play Games title, then known emulator titles, while
    retaining other suitably-sized windows for manually selected game clients.
    """
    user32, _ = _apis()
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)
    user32.EnumWindows.argtypes = [callback_type, ctypes.c_void_p]
    user32.EnumWindows.restype = ctypes.c_int
    found: list[WindowInfo] = []
    emulator_tokens = (
        "android", "emulator", "bluestacks", "blue stacks", "ldplayer", "雷电",
        "夜神", "mumu", "逍遥", "腾讯手游助手", "手游助手", "memu", "genymotion", "nox",
    )
    game_tokens = ("clash royale", "clashroyale", "google play games", "play games")

    def enum_proc(hwnd, _lparam):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                return 1
            length = int(user32.GetWindowTextLengthW(hwnd))
            if length <= 0:
                return 1
            title_buf = ctypes.create_unicode_buffer(min(length + 1, 512))
            user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
            title = title_buf.value.strip()
            if not title or "clash royale agent" in title.casefold():
                return 1
            class_buf = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, class_buf, len(class_buf))
            class_name = class_buf.value
            try:
                x, y, width, height = _get_client_rect(int(hwnd))
            except Exception:
                return 1
            # Portrait mobile windows and landscape native game windows are both
            # valid.  Very small utility/dialog windows are intentionally omitted.
            if width < 320 or height < 260 or width * height < 140_000:
                return 1
            found.append(WindowInfo(int(hwnd), title, class_name, x, y, width, height))
        except Exception:
            pass
        return 1

    user32.EnumWindows(callback_type(enum_proc), 0)
    def rank(window: WindowInfo) -> tuple[int, int, int, str]:
        text = (window.title + " " + window.class_name).casefold()
        if any(token in text for token in game_tokens):
            priority = 0
        elif any(token in text for token in emulator_tokens):
            priority = 1
        else:
            priority = 2
        # Keep the explicit game candidates at the top; dimensions are only a
        # stable presentation order, never an automatic selection criterion.
        return priority, -window.width * window.height, -window.height, window.title.casefold()
    found.sort(key=rank)
    likely = [window for window in found if rank(window)[0] < 2]
    return likely or found


# Backward-compatible alias for older integrations; new UI and runtime code use
# the generic game-window API and do not require an emulator.
list_emulator_windows = list_game_windows


def focus_window(hwnd: int, stop_event=None) -> bool:
    """Bring the selected game window forward, while remaining stop-key responsive."""
    if stop_event is not None and stop_event.is_set():
        return False
    user32, _ = _apis()
    if not window_is_valid(hwnd):
        return False
    SW_RESTORE = 9
    h = ctypes.c_void_p(hwnd)
    user32.ShowWindow(h, SW_RESTORE)
    user32.BringWindowToTop(h)
    user32.SetForegroundWindow(h)
    deadline = time.monotonic() + 0.6
    while time.monotonic() < deadline:
        if stop_event is not None and stop_event.is_set():
            return False
        if window_is_foreground(hwnd):
            return True
        if stop_event is not None:
            stop_event.wait(0.025)
        else:
            time.sleep(0.025)
    return not (stop_event is not None and stop_event.is_set()) and window_is_foreground(hwnd)


def _capture_frame_usable(frame: Frame) -> bool:
    """Reject empty/near-black captures before they can drive game input."""
    pixels = frame.width * frame.height
    step = max(1, pixels // 4096)
    data = memoryview(frame.bgra)
    sampled = dark = 0
    first = None
    same = 0
    for pixel in range(0, pixels, step):
        offset = pixel * 4
        color = (data[offset], data[offset + 1], data[offset + 2])
        if first is None:
            first = color
        if color == first:
            same += 1
        if max(color) <= 8:
            dark += 1
        sampled += 1
    if sampled == 0:
        return False
    # A GPU/window capture failure commonly returns an all-black buffer.  A
    # loading transition can also be dark; waiting is safer than acting on it.
    if dark / sampled >= 0.995:
        return False
    if same / sampled >= 0.999 and first is not None and max(first) <= 16:
        return False
    return True


def _capture_screen_gdi(hwnd: int, max_width: int) -> Frame:
    user32, gdi32 = _apis()
    x, y, width, height = _get_client_rect(hwnd)
    out_width = min(max(120, int(max_width)), width)
    out_height = max(1, int(height * out_width / width))

    SRCCOPY, CAPTUREBLT, DIB_RGB_COLORS, HALFTONE = 0x00CC0020, 0x40000000, 0, 4
    screen_dc = user32.GetDC(None)
    if not screen_dc:
        raise OSError("Cannot access the Windows desktop surface.")
    memory_dc = None
    bitmap = None
    old_object = None
    try:
        memory_dc = gdi32.CreateCompatibleDC(screen_dc)
        bitmap = gdi32.CreateCompatibleBitmap(screen_dc, out_width, out_height)
        if not memory_dc or not bitmap:
            raise OSError("Cannot allocate screenshot buffer.")
        old_object = gdi32.SelectObject(memory_dc, bitmap)
        gdi32.SetStretchBltMode(memory_dc, HALFTONE)
        ok = gdi32.StretchBlt(memory_dc, 0, 0, out_width, out_height,
                              screen_dc, x, y, width, height, SRCCOPY | CAPTUREBLT)
        if not ok:
            raise OSError("GDI screenshot capture failed.")
        gdi32.SelectObject(memory_dc, old_object)
        old_object = None

        info = _BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
        info.bmiHeader.biWidth = out_width
        info.bmiHeader.biHeight = -out_height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        info.bmiHeader.biSizeImage = out_width * out_height * 4
        buffer = ctypes.create_string_buffer(out_width * out_height * 4)
        lines = gdi32.GetDIBits(memory_dc, bitmap, 0, out_height, buffer,
                                ctypes.byref(info), DIB_RGB_COLORS)
        if lines != out_height:
            raise OSError("Could not read screenshot pixels.")
        if not window_is_interactive(hwnd):
            raise OSError("游戏窗口在截图期间失去前台焦点；已丢弃截图。")
        return Frame(out_width, out_height, buffer.raw, hwnd)
    finally:
        if memory_dc and old_object:
            try:
                gdi32.SelectObject(memory_dc, old_object)
            except Exception:
                pass
        if bitmap:
            gdi32.DeleteObject(bitmap)
        if memory_dc:
            gdi32.DeleteDC(memory_dc)
        user32.ReleaseDC(None, screen_dc)


def _capture_wm_printclient(hwnd: int, max_width: int) -> Frame:
    """Bounded WM_PRINTCLIENT fallback for blank/unavailable desktop GDI surfaces."""
    user32, gdi32 = _apis()
    _x, _y, width, height = _get_client_rect(hwnd)
    if width * height > 32_000_000:
        raise OSError("WM_PRINTCLIENT fallback dimensions exceed the safety limit.")
    screen_dc = user32.GetDC(None)
    if not screen_dc:
        raise OSError("Cannot access a compatible display context for PrintWindow.")
    memory_dc = None
    bitmap = None
    old_object = None
    try:
        memory_dc = gdi32.CreateCompatibleDC(screen_dc)
        bitmap = gdi32.CreateCompatibleBitmap(screen_dc, width, height)
        if not memory_dc or not bitmap:
            raise OSError("Cannot allocate WM_PRINTCLIENT fallback buffer.")
        old_object = gdi32.SelectObject(memory_dc, bitmap)
        # Ask the selected window to paint its client content, but bound the
        # synchronous message to 800 ms so a hung game window cannot stall the
        # stop-key-responsive Agent loop indefinitely. Some GPU windows ignore
        # WM_PRINTCLIENT; that simply makes this fallback fail closed.
        WM_PRINTCLIENT = 0x0318
        PRF_CLIENT, PRF_ERASEBKGND, PRF_CHILDREN = 0x00000004, 0x00000008, 0x00000010
        SMTO_ABORTIFHUNG = 0x0002
        result = ctypes.c_size_t()
        sent = user32.SendMessageTimeoutW(
            ctypes.c_void_p(hwnd), WM_PRINTCLIENT, ctypes.c_size_t(memory_dc),
            ctypes.c_ssize_t(PRF_CLIENT | PRF_ERASEBKGND | PRF_CHILDREN),
            SMTO_ABORTIFHUNG, 800, ctypes.byref(result),
        )
        if not sent:
            raise OSError("Bounded WM_PRINTCLIENT fallback failed or timed out.")
        gdi32.SelectObject(memory_dc, old_object)
        old_object = None

        info = _BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
        info.bmiHeader.biWidth = width
        info.bmiHeader.biHeight = -height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        info.bmiHeader.biSizeImage = width * height * 4
        buffer = ctypes.create_string_buffer(width * height * 4)
        lines = gdi32.GetDIBits(memory_dc, bitmap, 0, height, buffer,
                                ctypes.byref(info), 0)
        if lines != height:
            raise OSError("Could not read WM_PRINTCLIENT fallback pixels.")
        if not window_is_interactive(hwnd):
            raise OSError("游戏窗口在 WM_PRINTCLIENT 截图期间失去前台焦点；已丢弃截图。")

        out_width = min(max(120, int(max_width)), width)
        out_height = max(1, int(height * out_width / width))
        source = memoryview(buffer.raw)
        output = bytearray(out_width * out_height * 4)
        x_offsets = [min(width - 1, int(x * width / out_width)) * 4
                     for x in range(out_width)]
        for oy in range(out_height):
            sy = min(height - 1, int(oy * height / out_height))
            source_row = sy * width * 4
            target_row = oy * out_width * 4
            for ox, sx in enumerate(x_offsets):
                si, di = source_row + sx, target_row + ox * 4
                output[di:di + 4] = source[si:si + 4]
        return Frame(out_width, out_height, bytes(output), hwnd)
    finally:
        if memory_dc and old_object:
            try:
                gdi32.SelectObject(memory_dc, old_object)
            except Exception:
                pass
        if bitmap:
            gdi32.DeleteObject(bitmap)
        if memory_dc:
            gdi32.DeleteDC(memory_dc)
        user32.ReleaseDC(None, screen_dc)


def capture_window(hwnd: int, max_width: int = 420) -> Frame:
    """Capture the selected foreground client area with a validated fallback.

    GDI remains the fast path.  If it errors or returns an empty/black surface,
    a bounded WM_PRINTCLIENT fallback is tried in memory. Neither backend is allowed to return a
    frame to the policy unless the selected window remains foreground and the
    resulting pixels contain usable visual information.
    """
    if not window_is_interactive(hwnd):
        raise OSError("游戏窗口未处于前台或窗口被遮挡；已跳过截图和操作。")

    gdi_error = None
    try:
        frame = _capture_screen_gdi(hwnd, max_width)
        if _capture_frame_usable(frame):
            return frame
        gdi_error = OSError("GDI returned an empty or near-black frame.")
    except Exception as exc:
        gdi_error = exc

    if not window_is_interactive(hwnd):
        raise OSError("游戏窗口在 GDI 截图失败后失去前台焦点；已跳过备用截图。") from gdi_error
    wm_error = None
    try:
        frame = _capture_wm_printclient(hwnd, max_width)
        if _capture_frame_usable(frame):
            return frame
        wm_error = OSError("WM_PRINTCLIENT returned an empty or near-black frame.")
    except Exception as fallback_error:
        wm_error = fallback_error

    if not window_is_interactive(hwnd):
        raise OSError("游戏窗口在 WM_PRINTCLIENT 失败后失去前台焦点；已跳过 DXGI 备用截图。") from wm_error
    dxgi_error = None
    try:
        # Desktop Duplication is deliberately last: it is more expensive than
        # GDI/WM_PRINTCLIENT and captures the monitor before cropping the exact
        # visible client area of the already-validated selected window.
        from .dxgi import capture_window_dxgi
        frame = capture_window_dxgi(hwnd, max_width)
        if not window_is_interactive(hwnd):
            raise OSError("游戏窗口在 DXGI 截图期间失去前台焦点；已丢弃截图。")
        if _capture_frame_usable(frame):
            return frame
        dxgi_error = OSError("DXGI Desktop Duplication returned an empty or near-black frame.")
    except Exception as fallback_error:
        dxgi_error = fallback_error
    raise OSError(
        f"GDI 截图不可用（{gdi_error}）；WM_PRINTCLIENT 备用截图不可用（{wm_error}）；"
        f"DXGI 备用截图也不可用（{dxgi_error}）。"
    ) from dxgi_error


def scroll_window(hwnd: int, x_ratio: float = 0.50, y_ratio: float = 0.56,
                  delta: int = -120, stop_event=None) -> bool:
    """Send one wheel step to a visible selected game window.

    This is used only by the card-catalog scanner after a high-confidence card
    collection screen has been recognized.  It never sends a click or keypress.
    """
    if stop_event is not None and stop_event.is_set():
        return False
    if not window_is_valid(hwnd) or not window_is_foreground(hwnd):
        return False
    if not window_is_interactive(hwnd):
        return False
    if not (-1.0 <= float(x_ratio) <= 2.0 and -1.0 <= float(y_ratio) <= 2.0):
        return False
    user32, _ = _apis()
    x, y, width, height = _get_client_rect(hwnd)
    point = _POINT(int(width * max(0.0, min(1.0, float(x_ratio)))),
                   int(height * max(0.0, min(1.0, float(y_ratio)))))
    if not user32.ClientToScreen(ctypes.c_void_p(hwnd), ctypes.byref(point)):
        return False
    if stop_event is not None and stop_event.is_set():
        return False
    if not user32.SetCursorPos(int(point.x), int(point.y)):
        return False
    if stop_event is not None and stop_event.is_set():
        return False
    MOUSEEVENTF_WHEEL = 0x0800
    amount = max(-1200, min(1200, int(delta)))
    user32.mouse_event(MOUSEEVENTF_WHEEL, 0, 0, ctypes.c_uint32(amount).value, 0)
    return not (stop_event is not None and stop_event.is_set())


def click_ratio(hwnd: int, x_ratio: float, y_ratio: float, stop_event=None) -> bool:
    """Safely click a normalized client coordinate; return False if cancelled."""
    if stop_event is not None and stop_event.is_set():
        return False
    if not window_is_interactive(hwnd):
        raise OSError("游戏窗口未处于前台或目标位置被遮挡；已拒绝鼠标点击。")
    if not (0.0 <= x_ratio <= 1.0 and 0.0 <= y_ratio <= 1.0):
        raise ValueError("Click ratios must be between 0 and 1.")
    user32, _ = _apis()
    x, y, width, height = _get_client_rect(hwnd)
    sx = x + max(0, min(width - 1, int(width * x_ratio)))
    sy = y + max(0, min(height - 1, int(height * y_ratio)))
    if not user32.SetCursorPos(sx, sy):
        raise OSError("Could not move the mouse to the game window.")
    time.sleep(0.012)
    if stop_event is not None and stop_event.is_set():
        return False
    if not window_is_interactive(hwnd):
        raise OSError("游戏窗口在点击前失去前台焦点；已拒绝输入。")
    target = int(user32.WindowFromPoint(_POINT(sx, sy)) or 0)
    root = _root_window(user32, hwnd)
    if not target or _root_window(user32, target) != root:
        raise OSError("点击坐标被其他窗口遮挡；已拒绝输入。")
    INPUT_MOUSE = 0
    MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
    down = _INPUT(type=INPUT_MOUSE, mi=_MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTDOWN, 0, 0))
    up = _INPUT(type=INPUT_MOUSE, mi=_MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTUP, 0, 0))
    if user32.SendInput(1, ctypes.byref(down), ctypes.sizeof(_INPUT)) != 1:
        raise OSError("Windows SendInput rejected the mouse-down event.")
    try:
        time.sleep(0.025)
    finally:
        # Always release the button even if the configured stop key is pressed.
        user32.SendInput(1, ctypes.byref(up), ctypes.sizeof(_INPUT))
    return not (stop_event is not None and stop_event.is_set())


_KEY_VKS = {
    "ESC": 0x1B, "ESCAPE": 0x1B, "SPACE": 0x20, "SPACEBAR": 0x20,
    "ENTER": 0x0D, "RETURN": 0x0D, "TAB": 0x09, "BACKSPACE": 0x08,
    "DELETE": 0x2E, "INSERT": 0x2D, "HOME": 0x24, "END": 0x23,
    "PAGE_UP": 0x21, "PAGE_DOWN": 0x22, "UP": 0x26, "DOWN": 0x28,
    "LEFT": 0x25, "RIGHT": 0x27, "CAPS_LOCK": 0x14, "PAUSE": 0x13,
    "PRINT_SCREEN": 0x2C, "SCROLL_LOCK": 0x91, "NUM_LOCK": 0x90,
    "SHIFT": 0x10, "CTRL": 0x11, "CONTROL": 0x11, "ALT": 0x12,
    "LEFT_SHIFT": 0xA0, "RIGHT_SHIFT": 0xA1, "LEFT_CTRL": 0xA2,
    "RIGHT_CTRL": 0xA3, "LEFT_ALT": 0xA4, "RIGHT_ALT": 0xA5,
    "WIN": 0x5B, "LEFT_WIN": 0x5B, "RIGHT_WIN": 0x5C,
    "APPS": 0x5D, "NUMPAD_ADD": 0x6B, "NUMPAD_SUBTRACT": 0x6D,
    "NUMPAD_MULTIPLY": 0x6A, "NUMPAD_DIVIDE": 0x6F, "NUMPAD_DECIMAL": 0x6E,
    "OEM_1": 0xBA, "OEM_PLUS": 0xBB, "OEM_COMMA": 0xBC,
    "OEM_MINUS": 0xBD, "OEM_PERIOD": 0xBE, "OEM_2": 0xBF,
    "OEM_3": 0xC0, "OEM_4": 0xDB, "OEM_5": 0xDC,
    "OEM_6": 0xDD, "OEM_7": 0xDE, "OEM_8": 0xDF, "OEM_102": 0xE2,
    "SEMICOLON": 0xBA, "EQUAL": 0xBB, "COMMA": 0xBC,
    "MINUS": 0xBD, "PERIOD": 0xBE, "SLASH": 0xBF,
    "GRAVE": 0xC0, "BRACKETLEFT": 0xDB, "BACKSLASH": 0xDC,
    "BRACKETRIGHT": 0xDD, "APOSTROPHE": 0xDE,
}


_PUNCTUATION_KEYS = {
    ";": "SEMICOLON", "=": "EQUAL", ",": "COMMA", "-": "MINUS",
    ".": "PERIOD", "/": "SLASH", "`": "GRAVE", "[": "BRACKETLEFT",
    "\\": "BACKSLASH", "]": "BRACKETRIGHT", "'": "APOSTROPHE",
}


_TK_KEYSYM_ALIASES = {
    "Escape": "ESC", "space": "SPACE", "Return": "ENTER", "BackSpace": "BACKSPACE",
    "Prior": "PAGE_UP", "Next": "PAGE_DOWN", "Print": "PRINT_SCREEN",
    "Caps_Lock": "CAPS_LOCK", "Scroll_Lock": "SCROLL_LOCK", "Num_Lock": "NUM_LOCK",
    "Control_L": "LEFT_CTRL", "Control_R": "RIGHT_CTRL",
    "Shift_L": "LEFT_SHIFT", "Shift_R": "RIGHT_SHIFT",
    "Alt_L": "LEFT_ALT", "Alt_R": "RIGHT_ALT",
    "Left": "LEFT", "Right": "RIGHT", "Up": "UP", "Down": "DOWN",
    "KP_Enter": "ENTER", "KP_Add": "NUMPAD_ADD", "KP_Subtract": "NUMPAD_SUBTRACT",
    "KP_Multiply": "NUMPAD_MULTIPLY", "KP_Divide": "NUMPAD_DIVIDE",
    "KP_Decimal": "NUMPAD_DECIMAL", "KP_Separator": "NUMPAD_DECIMAL",
    "KP_Equal": "OEM_PLUS", "KP_Insert": "NUMPAD0", "KP_End": "NUMPAD1",
    "KP_Down": "NUMPAD2", "KP_Next": "NUMPAD3", "KP_Left": "NUMPAD4",
    "KP_Begin": "NUMPAD5", "KP_Right": "NUMPAD6", "KP_Home": "NUMPAD7",
    "KP_Up": "NUMPAD8", "KP_Prior": "NUMPAD9",
    "semicolon": "SEMICOLON", "equal": "EQUAL", "comma": "COMMA",
    "minus": "MINUS", "period": "PERIOD", "slash": "SLASH",
    "grave": "GRAVE", "bracketleft": "BRACKETLEFT",
    "backslash": "BACKSLASH", "bracketright": "BRACKETRIGHT",
    "apostrophe": "APOSTROPHE",
}


def keysym_to_key_name(keysym: str) -> str:
    """Normalize Tk keysyms without collapsing keypad digits into top-row digits."""
    raw = str(keysym).strip()
    if raw in _PUNCTUATION_KEYS:
        return _PUNCTUATION_KEYS[raw]
    if raw in _TK_KEYSYM_ALIASES:
        return _TK_KEYSYM_ALIASES[raw]
    if raw.startswith("KP_") and len(raw) == 4 and raw[-1].isdigit():
        return f"NUMPAD{raw[-1]}"
    return raw.upper()


def key_to_vk(name: str) -> Optional[int]:
    raw = str(name).strip()
    if raw in _PUNCTUATION_KEYS:
        raw = _PUNCTUATION_KEYS[raw]
    key = raw.upper().replace(" ", "_").replace("-", "_")
    if key in _KEY_VKS:
        return _KEY_VKS[key]
    if len(key) == 1 and ("A" <= key <= "Z" or "0" <= key <= "9"):
        return ord(key)
    for prefix in ("NUMPAD", "KP_"):
        if key.startswith(prefix) and key[len(prefix):].isdigit():
            number = int(key[len(prefix):])
            if 0 <= number <= 9:
                return 0x60 + number
    if key.startswith("F") and key[1:].isdigit():
        number = int(key[1:])
        if 1 <= number <= 24:
            return 0x70 + number - 1
    return None


def is_key_down(vk: int) -> bool:
    user32, _ = _apis()
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


class _KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", ctypes.c_uint32),
        ("scanCode", ctypes.c_uint32),
        ("flags", ctypes.c_uint32),
        ("time", ctypes.c_uint32),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class _MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", ctypes.c_void_p),
        ("message", ctypes.c_uint32),
        ("wParam", ctypes.c_size_t),
        ("lParam", ctypes.c_ssize_t),
        ("time", ctypes.c_uint32),
        ("pt", _POINT),
        ("lPrivate", ctypes.c_uint32),
    ]


def _stop_key_matches(configured_vk: int, event_vk: int) -> bool:
    """Match generic modifier keys against either physical side."""
    aliases = {
        0x10: (0x10, 0xA0, 0xA1),  # SHIFT
        0x11: (0x11, 0xA2, 0xA3),  # CTRL
        0x12: (0x12, 0xA4, 0xA5),  # ALT
    }
    return event_vk in aliases.get(configured_vk, (configured_vk,))


def _signal_stop_monitor_ready(ready_event, armed: bool) -> None:
    """Signal startup readiness only after the configured key is released."""
    if ready_event is not None and armed:
        ready_event.set()


def _stop_key_event_transition(configured_vk: int, event_vk: int, message: int,
                               armed: bool) -> tuple[bool, bool, bool]:
    """Return (matched, next_armed, trigger_stop) for a low-level key event.

    WM_KEYDOWN/WM_SYSKEYDOWN are 0x0100/0x0104; key-up messages are
    0x0101/0x0105.  Matched key events are reserved for the Agent stop control
    and are swallowed by the hook so e.g. ESC cannot also activate a game menu.
    """
    if not _stop_key_matches(configured_vk, event_vk):
        return False, armed, False
    if message in (0x0101, 0x0105):
        return True, True, False
    if message in (0x0100, 0x0104):
        return True, False, bool(armed)
    return False, armed, False


def watch_global_key(vk: int, stop_event, *, idle_poll_seconds: float = 0.010,
                     ready_event=None) -> bool:
    """Wait for a physical global key-down using WH_KEYBOARD_LL.

    The hook reserves and suppresses the configured key so it cannot also
    trigger a game action (notably ESC opening a game menu). It is installed on
    a dedicated Agent thread with its own message pump, so a short key tap
    cannot fall between polling samples. A key already held when the hook
    starts must first be released and pressed again.

    Returns True only when the configured key caused the stop event. Raises on
    unsupported platforms or hook setup failures; the Agent must fail closed
    rather than run without a key that can be reliably intercepted.
    """
    _require_windows()
    if stop_event.is_set():
        return False
    if not isinstance(vk, int) or not 1 <= vk <= 0xFF:
        raise ValueError("A valid Windows virtual-key code is required.")

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    hook_proc_type = ctypes.WINFUNCTYPE(
        ctypes.c_ssize_t, ctypes.c_int, ctypes.c_size_t, ctypes.c_void_p
    )
    user32.SetWindowsHookExW.argtypes = [
        ctypes.c_int, hook_proc_type, ctypes.c_void_p, ctypes.c_uint32
    ]
    user32.SetWindowsHookExW.restype = ctypes.c_void_p
    user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
    user32.UnhookWindowsHookEx.restype = ctypes.c_int
    user32.CallNextHookEx.argtypes = [
        ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t, ctypes.c_void_p
    ]
    user32.CallNextHookEx.restype = ctypes.c_ssize_t
    user32.PeekMessageW.argtypes = [
        ctypes.POINTER(_MSG), ctypes.c_void_p, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_uint32,
    ]
    user32.PeekMessageW.restype = ctypes.c_int
    user32.TranslateMessage.argtypes = [ctypes.POINTER(_MSG)]
    user32.TranslateMessage.restype = ctypes.c_int
    user32.DispatchMessageW.argtypes = [ctypes.POINTER(_MSG)]
    user32.DispatchMessageW.restype = ctypes.c_ssize_t
    user32.PostThreadMessageW.argtypes = [
        ctypes.c_uint32, ctypes.c_uint32, ctypes.c_size_t, ctypes.c_ssize_t
    ]
    user32.PostThreadMessageW.restype = ctypes.c_int
    kernel32.GetModuleHandleW.argtypes = [ctypes.c_wchar_p]
    kernel32.GetModuleHandleW.restype = ctypes.c_void_p
    kernel32.GetCurrentThreadId.argtypes = []
    kernel32.GetCurrentThreadId.restype = ctypes.c_uint32

    # Create this thread's message queue before PostThreadMessageW can be used.
    message = _MSG()
    PM_NOREMOVE = 0x0000
    PM_REMOVE = 0x0001
    WM_QUIT = 0x0012
    WM_KEYDOWN = 0x0100
    WM_KEYUP = 0x0101
    WM_SYSKEYDOWN = 0x0104
    WM_SYSKEYUP = 0x0105
    HC_ACTION = 0
    user32.PeekMessageW(ctypes.byref(message), None, 0, 0, PM_NOREMOVE)

    thread_id = int(kernel32.GetCurrentThreadId())
    try:
        armed = not is_key_down(vk)
    except Exception:
        # Do not mistake a key held during startup for a fresh stop request.
        armed = False
    hook_handle = ctypes.c_void_p()
    # Do not tell the Agent it is safe to start while the stop key is already
    # held. In that case the first key-up event arms the monitor and signals
    # readiness from the hook callback below.

    def hook_callback(code, wparam, lparam):
        nonlocal armed
        if code == HC_ACTION and lparam:
            try:
                key = ctypes.cast(lparam, ctypes.POINTER(_KBDLLHOOKSTRUCT)).contents
                matched, next_armed, trigger = _stop_key_event_transition(
                    vk, int(key.vkCode), int(wparam), armed
                )
                was_armed = armed
                armed = next_armed
                if armed and not was_armed:
                    _signal_stop_monitor_ready(ready_event, armed)
                if trigger:
                    stop_event.set()
                    user32.PostThreadMessageW(thread_id, WM_QUIT, 0, 0)
                if matched:
                    # A matching key is consumed; it must not leak into the
                    # selected game window after requesting an Agent stop.
                    return 1
            except Exception:
                # A callback must never prevent the system's next hook from running.
                pass
        return user32.CallNextHookEx(hook_handle, code, wparam, lparam)

    callback = hook_proc_type(hook_callback)
    hook = user32.SetWindowsHookExW(
        13, callback, kernel32.GetModuleHandleW(None), 0
    )
    if not hook:
        error = ctypes.get_last_error()
        raise OSError(error, "Could not install the global keyboard stop hook.")
    hook_handle = ctypes.c_void_p(hook)
    # Close the small race between the initial key-state sample and hook
    # installation: if the user released the key in that interval, the key-up
    # may have occurred before the hook was active. Re-sample after install.
    if not stop_event.is_set():
        try:
            armed = not is_key_down(vk)
        except Exception:
            # A failed re-sample is ambiguous; fail closed until a key-up.
            armed = False
    _signal_stop_monitor_ready(ready_event, armed)
    try:
        while not stop_event.is_set():
            while user32.PeekMessageW(ctypes.byref(message), None, 0, 0, PM_REMOVE):
                if message.message == WM_QUIT:
                    return bool(stop_event.is_set())
                user32.TranslateMessage(ctypes.byref(message))
                user32.DispatchMessageW(ctypes.byref(message))
            stop_event.wait(max(0.001, min(0.050, float(idle_poll_seconds))))
        return False
    finally:
        user32.UnhookWindowsHookEx(hook_handle)
