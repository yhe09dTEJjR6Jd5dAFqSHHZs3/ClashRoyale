"""Hardened, dependency-free Win32 window capture and input helpers.

Input is deliberately fail-closed: the selected emulator must be the foreground
window and the target points must belong to it before a screenshot or click is
allowed.  This prevents clicks leaking into unrelated desktop applications.
"""
from __future__ import annotations

import ctypes
import os
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class WindowInfo:
    hwnd: int
    title: str
    class_name: str
    x: int
    y: int
    width: int
    height: int

    @property
    def label(self) -> str:
        return f"{self.title}  ·  {self.width}×{self.height}  ·  {self.hwnd:x}"


class Frame:
    __slots__ = ("width", "height", "bgra", "captured_at", "source_hwnd")

    def __init__(self, width: int, height: int, bgra: bytes, source_hwnd: int = 0):
        if width <= 0 or height <= 0 or len(bgra) < width * height * 4:
            raise ValueError("Invalid BGRA frame dimensions or buffer length.")
        self.width = width
        self.height = height
        self.bgra = bgra
        self.captured_at = time.monotonic()
        self.source_hwnd = int(source_hwnd)


def _require_windows() -> None:
    if os.name != "nt":
        raise OSError("This application requires Windows 11 x64.")


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32),
        ("biHeight", ctypes.c_int32), ("biPlanes", ctypes.c_uint16),
        ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32),
        ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_int32),
        ("biYPelsPerMeter", ctypes.c_int32), ("biClrUsed", ctypes.c_uint32),
        ("biClrImportant", ctypes.c_uint32),
    ]


class _RGBQUAD(ctypes.Structure):
    _fields_ = [("rgbBlue", ctypes.c_ubyte), ("rgbGreen", ctypes.c_ubyte),
                ("rgbRed", ctypes.c_ubyte), ("rgbReserved", ctypes.c_ubyte)]


class _BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", _BITMAPINFOHEADER), ("bmiColors", _RGBQUAD * 1)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long), ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_uint32), ("dwFlags", ctypes.c_uint32),
        ("time", ctypes.c_uint32), ("dwExtraInfo", ctypes.c_size_t),
    ]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", _MOUSEINPUT)]


class _INPUT(ctypes.Structure):
    _anonymous_ = ("union",)
    _fields_ = [("type", ctypes.c_uint32), ("union", _INPUTUNION)]


class _FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", ctypes.c_uint32), ("dwHighDateTime", ctypes.c_uint32)]


class _PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_uint32), ("PageFaultCount", ctypes.c_uint32),
        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def set_dpi_awareness(user32=None) -> bool:
    """Enable Per-Monitor DPI Awareness V2 before creating UI or capture handles."""
    if os.name != "nt":
        return False
    try:
        if user32 is None:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
        context = getattr(user32, "SetProcessDpiAwarenessContext", None)
        if context is not None:
            context.argtypes = [ctypes.c_void_p]
            context.restype = ctypes.c_int
            if context(ctypes.c_void_p(-4)):
                return True
    except Exception:
        pass
    try:
        shcore = ctypes.WinDLL("shcore", use_last_error=True)
        shcore.SetProcessDpiAwareness.argtypes = [ctypes.c_int]
        shcore.SetProcessDpiAwareness.restype = ctypes.c_long
        if shcore.SetProcessDpiAwareness(2) == 0:
            return True
    except Exception:
        pass
    try:
        if user32 is None:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
        return bool(user32.SetProcessDPIAware())
    except Exception:
        return False


@lru_cache(maxsize=1)
def _apis():
    _require_windows()
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    handle, uint, integer, boolean = ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_int

    user32.GetDC.argtypes = [handle]
    user32.GetDC.restype = handle
    user32.ReleaseDC.argtypes = [handle, handle]
    user32.ReleaseDC.restype = integer
    user32.GetClientRect.argtypes = [handle, ctypes.POINTER(_RECT)]
    user32.GetClientRect.restype = boolean
    user32.ClientToScreen.argtypes = [handle, ctypes.POINTER(_POINT)]
    user32.ClientToScreen.restype = boolean
    user32.IsWindow.argtypes = [handle]
    user32.IsWindow.restype = boolean
    user32.IsWindowVisible.argtypes = [handle]
    user32.IsWindowVisible.restype = boolean
    user32.IsIconic.argtypes = [handle]
    user32.IsIconic.restype = boolean
    user32.GetForegroundWindow.argtypes = []
    user32.GetForegroundWindow.restype = handle
    user32.GetWindowRect.argtypes = [handle, ctypes.POINTER(_RECT)]
    user32.GetWindowRect.restype = boolean
    user32.GetAncestor.argtypes = [handle, uint]
    user32.GetAncestor.restype = handle
    user32.WindowFromPoint.argtypes = [_POINT]
    user32.WindowFromPoint.restype = handle
    user32.GetWindowTextLengthW.argtypes = [handle]
    user32.GetWindowTextLengthW.restype = integer
    user32.GetWindowTextW.argtypes = [handle, ctypes.c_wchar_p, integer]
    user32.GetWindowTextW.restype = integer
    user32.GetClassNameW.argtypes = [handle, ctypes.c_wchar_p, integer]
    user32.GetClassNameW.restype = integer
    user32.ShowWindow.argtypes = [handle, integer]
    user32.ShowWindow.restype = boolean
    user32.BringWindowToTop.argtypes = [handle]
    user32.BringWindowToTop.restype = boolean
    user32.SetForegroundWindow.argtypes = [handle]
    user32.SetForegroundWindow.restype = boolean
    user32.SetCursorPos.argtypes = [integer, integer]
    user32.SetCursorPos.restype = boolean
    user32.mouse_event.argtypes = [uint, uint, uint, uint, ctypes.c_size_t]
    user32.mouse_event.restype = None
    user32.SendInput.argtypes = [uint, ctypes.POINTER(_INPUT), integer]
    user32.SendInput.restype = uint
    user32.GetAsyncKeyState.argtypes = [integer]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.GetWindowThreadProcessId.argtypes = [handle, ctypes.POINTER(ctypes.c_uint32)]
    user32.GetWindowThreadProcessId.restype = uint

    # Per-monitor-v2 DPI awareness is requested before creating UI/capture handles.
    set_dpi_awareness(user32=user32)

    gdi32.CreateCompatibleDC.argtypes = [handle]
    gdi32.CreateCompatibleDC.restype = handle
    gdi32.CreateCompatibleBitmap.argtypes = [handle, integer, integer]
    gdi32.CreateCompatibleBitmap.restype = handle
    gdi32.SelectObject.argtypes = [handle, handle]
    gdi32.SelectObject.restype = handle
    gdi32.SetStretchBltMode.argtypes = [handle, integer]
    gdi32.SetStretchBltMode.restype = integer
    gdi32.StretchBlt.argtypes = [handle, integer, integer, integer, integer,
                                 handle, integer, integer, integer, integer, uint]
    gdi32.StretchBlt.restype = boolean
    gdi32.GetDIBits.argtypes = [handle, handle, uint, uint, ctypes.c_void_p,
                                ctypes.POINTER(_BITMAPINFO), uint]
    gdi32.GetDIBits.restype = integer
    gdi32.DeleteObject.argtypes = [handle]
    gdi32.DeleteObject.restype = boolean
    gdi32.DeleteDC.argtypes = [handle]
    gdi32.DeleteDC.restype = boolean
    return user32, gdi32


def _root_window(user32, hwnd: int) -> int:
    GA_ROOT = 2
    root = user32.GetAncestor(ctypes.c_void_p(hwnd), GA_ROOT)
    return int(root or hwnd)


def _get_client_rect(hwnd: int) -> tuple[int, int, int, int]:
    user32, _ = _apis()
    h = ctypes.c_void_p(hwnd)
    rect = _RECT()
    if not user32.GetClientRect(h, ctypes.byref(rect)):
        raise OSError("Cannot read emulator client area.")
    point = _POINT(0, 0)
    if not user32.ClientToScreen(h, ctypes.byref(point)):
        raise OSError("Cannot locate emulator client area on screen.")
    width, height = int(rect.right - rect.left), int(rect.bottom - rect.top)
    if width < 100 or height < 100:
        raise OSError("Emulator window is too small or minimized.")
    return int(point.x), int(point.y), width, height


def window_exists(hwnd: int) -> bool:
    """Check that the selected visible window still exists, including minimized windows."""
    try:
        user32, _ = _apis()
        h = ctypes.c_void_p(hwnd)
        return bool(user32.IsWindow(h) and user32.IsWindowVisible(h))
    except Exception:
        return False


def window_is_valid(hwnd: int) -> bool:
    """True when the selected window exists, is visible, and is not minimized."""
    try:
        user32, _ = _apis()
        h = ctypes.c_void_p(hwnd)
        return bool(user32.IsWindow(h) and user32.IsWindowVisible(h) and not user32.IsIconic(h))
    except Exception:
        return False


def window_process_path(hwnd: int) -> Optional[Path]:
    """Return the executable path owning a selected top-level window, if accessible."""
    if os.name != "nt":
        return None
    try:
        user32, _ = _apis()
        pid = ctypes.c_uint32()
        if not user32.GetWindowThreadProcessId(ctypes.c_void_p(hwnd), ctypes.byref(pid)) or not pid.value:
            return None
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.QueryFullProcessImageNameW.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                                         ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_uint32)]
        kernel32.QueryFullProcessImageNameW.restype = ctypes.c_int
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_int
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid.value)
        if not handle:
            return None
        try:
            buffer = ctypes.create_unicode_buffer(32768)
            length = ctypes.c_uint32(len(buffer))
            if not kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(length)):
                return None
            return Path(buffer.value)
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return None


def window_is_foreground(hwnd: int) -> bool:
    """True only when the selected top-level emulator is the active foreground window."""
    try:
        user32, _ = _apis()
        if not window_is_valid(hwnd):
            return False
        foreground = int(user32.GetForegroundWindow() or 0)
        return foreground == _root_window(user32, hwnd)
    except Exception:
        return False


def window_is_interactive(hwnd: int, check_occlusion: bool = True) -> bool:
    """Verify foreground ownership and that representative client points are unobscured."""
    try:
        user32, _ = _apis()
        if not window_is_foreground(hwnd):
            return False
        if not check_occlusion:
            return True
        x, y, width, height = _get_client_rect(hwnd)
        root = _root_window(user32, hwnd)
        # A denser grid covers arena, navigation, and card-hand regions. Every
        # sample must resolve to the selected window or one of its child windows.
        # A 5x5 interior grid covers the card hand, navigation tabs, arena and
        # edge controls.  This is intentionally stricter than a few center points.
        samples = tuple((rx, ry) for ry in (0.06, 0.28, 0.50, 0.72, 0.94)
                        for rx in (0.06, 0.28, 0.50, 0.72, 0.94))
        for rx, ry in samples:
            point = _POINT(x + int(width * rx), y + int(height * ry))
            child = int(user32.WindowFromPoint(point) or 0)
            if not child or _root_window(user32, child) != root:
                return False
        return True
    except Exception:
        return False


def process_metrics() -> dict[str, float] | None:
    """Return current-process CPU time and memory without external packages."""
    if os.name != "nt":
        return None
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        kernel32.GetCurrentProcess.argtypes = []
        kernel32.GetCurrentProcess.restype = ctypes.c_void_p
        handle = kernel32.GetCurrentProcess()
        kernel32.GetProcessTimes.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(_FILETIME), ctypes.POINTER(_FILETIME),
            ctypes.POINTER(_FILETIME), ctypes.POINTER(_FILETIME),
        ]
        kernel32.GetProcessTimes.restype = ctypes.c_int
        creation, exit_time, kernel, user = _FILETIME(), _FILETIME(), _FILETIME(), _FILETIME()
        if not kernel32.GetProcessTimes(handle, ctypes.byref(creation), ctypes.byref(exit_time),
                                        ctypes.byref(kernel), ctypes.byref(user)):
            return None
        counters = _PROCESS_MEMORY_COUNTERS()
        counters.cb = ctypes.sizeof(_PROCESS_MEMORY_COUNTERS)
        psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p,
                                               ctypes.POINTER(_PROCESS_MEMORY_COUNTERS),
                                               ctypes.c_uint32]
        psapi.GetProcessMemoryInfo.restype = ctypes.c_int
        if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
            return None
        kernel_ticks = (int(kernel.dwHighDateTime) << 32) | int(kernel.dwLowDateTime)
        user_ticks = (int(user.dwHighDateTime) << 32) | int(user.dwLowDateTime)
        return {
            "cpu_seconds": (kernel_ticks + user_ticks) / 10_000_000.0,
            "working_set_bytes": float(counters.WorkingSetSize),
            "commit_charge_bytes": float(counters.PagefileUsage),
        }
    except Exception:
        return None


def list_emulator_windows() -> list[WindowInfo]:
    """Return likely Android emulator windows; never auto-select one for the user."""
    user32, _ = _apis()
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p)
    user32.EnumWindows.argtypes = [callback_type, ctypes.c_void_p]
    user32.EnumWindows.restype = ctypes.c_int
    found: list[WindowInfo] = []
    tokens = (
        "android", "emulator", "bluestacks", "blue stacks", "ldplayer", "雷电",
        "夜神", "mumu", "逍遥", "腾讯手游助手", "手游助手", "memu", "genymotion", "nox",
    )

    def enum_proc(hwnd, _lparam):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                return 1
            length = int(user32.GetWindowTextLengthW(hwnd))
            if length <= 0:
                return 1
            title_buf = ctypes.create_unicode_buffer(min(length + 1, 512))
            user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
            title = title_buf.value.strip()
            if not title or "clash royale agent" in title.lower():
                return 1
            class_buf = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, class_buf, len(class_buf))
            try:
                x, y, width, height = _get_client_rect(int(hwnd))
            except Exception:
                return 1
            if width < 280 or height < 360:
                return 1
            found.append(WindowInfo(int(hwnd), title, class_buf.value, x, y, width, height))
        except Exception:
            pass
        return 1

    user32.EnumWindows(callback_type(enum_proc), 0)
    known = [w for w in found if any(t in (w.title + " " + w.class_name).lower() for t in tokens)]
    candidates = known if known else [w for w in found if w.height >= w.width * 0.9]
    candidates.sort(key=lambda w: (0 if w.height >= w.width else 1, -w.height, w.title.lower()))
    return candidates


def focus_window(hwnd: int, stop_event=None) -> bool:
    """Bring the selected emulator forward, while remaining stop-key responsive."""
    if stop_event is not None and stop_event.is_set():
        return False
    user32, _ = _apis()
    if not window_is_valid(hwnd):
        return False
    SW_RESTORE = 9
    h = ctypes.c_void_p(hwnd)
    user32.ShowWindow(h, SW_RESTORE)
    user32.BringWindowToTop(h)
    user32.SetForegroundWindow(h)
    deadline = time.monotonic() + 0.6
    while time.monotonic() < deadline:
        if stop_event is not None and stop_event.is_set():
            return False
        if window_is_foreground(hwnd):
            return True
        if stop_event is not None:
            stop_event.wait(0.025)
        else:
            time.sleep(0.025)
    return not (stop_event is not None and stop_event.is_set()) and window_is_foreground(hwnd)


def capture_window(hwnd: int, max_width: int = 420) -> Frame:
    """Capture the selected foreground client area; refuse hidden/covered windows."""
    if not window_is_interactive(hwnd):
        raise OSError("模拟器未处于前台或窗口被遮挡；已跳过截图和操作。")
    user32, gdi32 = _apis()
    x, y, width, height = _get_client_rect(hwnd)
    out_width = min(max_width, width)
    out_height = max(1, int(height * out_width / width))

    SRCCOPY, CAPTUREBLT, DIB_RGB_COLORS, HALFTONE = 0x00CC0020, 0x40000000, 0, 4
    screen_dc = user32.GetDC(None)
    if not screen_dc:
        raise OSError("Cannot access the Windows desktop surface.")
    memory_dc = None
    bitmap = None
    old_object = None
    try:
        memory_dc = gdi32.CreateCompatibleDC(screen_dc)
        bitmap = gdi32.CreateCompatibleBitmap(screen_dc, out_width, out_height)
        if not memory_dc or not bitmap:
            raise OSError("Cannot allocate screenshot buffer.")
        old_object = gdi32.SelectObject(memory_dc, bitmap)
        gdi32.SetStretchBltMode(memory_dc, HALFTONE)
        ok = gdi32.StretchBlt(memory_dc, 0, 0, out_width, out_height,
                              screen_dc, x, y, width, height, SRCCOPY | CAPTUREBLT)
        if not ok:
            raise OSError("GDI screenshot capture failed.")
        gdi32.SelectObject(memory_dc, old_object)
        old_object = None

        info = _BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(_BITMAPINFOHEADER)
        info.bmiHeader.biWidth = out_width
        info.bmiHeader.biHeight = -out_height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        info.bmiHeader.biSizeImage = out_width * out_height * 4
        buffer = ctypes.create_string_buffer(out_width * out_height * 4)
        lines = gdi32.GetDIBits(memory_dc, bitmap, 0, out_height, buffer,
                                ctypes.byref(info), DIB_RGB_COLORS)
        if lines != out_height:
            raise OSError("Could not read screenshot pixels.")
        if not window_is_interactive(hwnd):
            raise OSError("模拟器在截图期间失去前台焦点；已丢弃截图。")
        return Frame(out_width, out_height, buffer.raw, hwnd)
    finally:
        if memory_dc and old_object:
            try:
                gdi32.SelectObject(memory_dc, old_object)
            except Exception:
                pass
        if bitmap:
            gdi32.DeleteObject(bitmap)
        if memory_dc:
            gdi32.DeleteDC(memory_dc)
        user32.ReleaseDC(None, screen_dc)


def click_ratio(hwnd: int, x_ratio: float, y_ratio: float, stop_event=None) -> bool:
    """Safely click a normalized client coordinate; return False if cancelled."""
    if stop_event is not None and stop_event.is_set():
        return False
    if not window_is_interactive(hwnd):
        raise OSError("模拟器未处于前台或目标位置被遮挡；已拒绝鼠标点击。")
    if not (0.0 <= x_ratio <= 1.0 and 0.0 <= y_ratio <= 1.0):
        raise ValueError("Click ratios must be between 0 and 1.")
    user32, _ = _apis()
    x, y, width, height = _get_client_rect(hwnd)
    sx = x + max(0, min(width - 1, int(width * x_ratio)))
    sy = y + max(0, min(height - 1, int(height * y_ratio)))
    if not user32.SetCursorPos(sx, sy):
        raise OSError("Could not move the mouse to the emulator.")
    time.sleep(0.012)
    if stop_event is not None and stop_event.is_set():
        return False
    if not window_is_interactive(hwnd):
        raise OSError("模拟器在点击前失去前台焦点；已拒绝输入。")
    target = int(user32.WindowFromPoint(_POINT(sx, sy)) or 0)
    root = _root_window(user32, hwnd)
    if not target or _root_window(user32, target) != root:
        raise OSError("点击坐标被其他窗口遮挡；已拒绝输入。")
    INPUT_MOUSE = 0
    MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
    down = _INPUT(type=INPUT_MOUSE, mi=_MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTDOWN, 0, 0))
    up = _INPUT(type=INPUT_MOUSE, mi=_MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTUP, 0, 0))
    if user32.SendInput(1, ctypes.byref(down), ctypes.sizeof(_INPUT)) != 1:
        raise OSError("Windows SendInput rejected the mouse-down event.")
    try:
        time.sleep(0.025)
    finally:
        # Always release the button even if the configured stop key is pressed.
        user32.SendInput(1, ctypes.byref(up), ctypes.sizeof(_INPUT))
    return not (stop_event is not None and stop_event.is_set())


_KEY_VKS = {
    "ESC": 0x1B, "ESCAPE": 0x1B, "SPACE": 0x20, "SPACEBAR": 0x20,
    "ENTER": 0x0D, "RETURN": 0x0D, "TAB": 0x09, "BACKSPACE": 0x08,
    "DELETE": 0x2E, "INSERT": 0x2D, "HOME": 0x24, "END": 0x23,
    "PAGE_UP": 0x21, "PAGE_DOWN": 0x22, "UP": 0x26, "DOWN": 0x28,
    "LEFT": 0x25, "RIGHT": 0x27, "CAPS_LOCK": 0x14, "PAUSE": 0x13,
    "PRINT_SCREEN": 0x2C, "SCROLL_LOCK": 0x91, "NUM_LOCK": 0x90,
    "SHIFT": 0x10, "CTRL": 0x11, "CONTROL": 0x11, "ALT": 0x12,
    "LEFT_SHIFT": 0xA0, "RIGHT_SHIFT": 0xA1, "LEFT_CTRL": 0xA2,
    "RIGHT_CTRL": 0xA3, "LEFT_ALT": 0xA4, "RIGHT_ALT": 0xA5,
    "WIN": 0x5B, "LEFT_WIN": 0x5B, "RIGHT_WIN": 0x5C,
    "APPS": 0x5D, "NUMPAD_ADD": 0x6B, "NUMPAD_SUBTRACT": 0x6D,
    "NUMPAD_MULTIPLY": 0x6A, "NUMPAD_DIVIDE": 0x6F, "NUMPAD_DECIMAL": 0x6E,
    "OEM_1": 0xBA, "OEM_PLUS": 0xBB, "OEM_COMMA": 0xBC,
    "OEM_MINUS": 0xBD, "OEM_PERIOD": 0xBE, "OEM_2": 0xBF,
    "OEM_3": 0xC0, "OEM_4": 0xDB, "OEM_5": 0xDC,
    "OEM_6": 0xDD, "OEM_7": 0xDE, "OEM_8": 0xDF, "OEM_102": 0xE2,
    "SEMICOLON": 0xBA, "EQUAL": 0xBB, "COMMA": 0xBC,
    "MINUS": 0xBD, "PERIOD": 0xBE, "SLASH": 0xBF,
    "GRAVE": 0xC0, "BRACKETLEFT": 0xDB, "BACKSLASH": 0xDC,
    "BRACKETRIGHT": 0xDD, "APOSTROPHE": 0xDE,
}


_PUNCTUATION_KEYS = {
    ";": "SEMICOLON", "=": "EQUAL", ",": "COMMA", "-": "MINUS",
    ".": "PERIOD", "/": "SLASH", "`": "GRAVE", "[": "BRACKETLEFT",
    "\\": "BACKSLASH", "]": "BRACKETRIGHT", "'": "APOSTROPHE",
}


_TK_KEYSYM_ALIASES = {
    "Escape": "ESC", "space": "SPACE", "Return": "ENTER", "BackSpace": "BACKSPACE",
    "Prior": "PAGE_UP", "Next": "PAGE_DOWN", "Print": "PRINT_SCREEN",
    "Caps_Lock": "CAPS_LOCK", "Scroll_Lock": "SCROLL_LOCK", "Num_Lock": "NUM_LOCK",
    "Control_L": "LEFT_CTRL", "Control_R": "RIGHT_CTRL",
    "Shift_L": "LEFT_SHIFT", "Shift_R": "RIGHT_SHIFT",
    "Alt_L": "LEFT_ALT", "Alt_R": "RIGHT_ALT",
    "Left": "LEFT", "Right": "RIGHT", "Up": "UP", "Down": "DOWN",
    "KP_Enter": "ENTER", "KP_Add": "NUMPAD_ADD", "KP_Subtract": "NUMPAD_SUBTRACT",
    "KP_Multiply": "NUMPAD_MULTIPLY", "KP_Divide": "NUMPAD_DIVIDE",
    "KP_Decimal": "NUMPAD_DECIMAL", "KP_Separator": "NUMPAD_DECIMAL",
    "KP_Equal": "OEM_PLUS", "KP_Insert": "NUMPAD0", "KP_End": "NUMPAD1",
    "KP_Down": "NUMPAD2", "KP_Next": "NUMPAD3", "KP_Left": "NUMPAD4",
    "KP_Begin": "NUMPAD5", "KP_Right": "NUMPAD6", "KP_Home": "NUMPAD7",
    "KP_Up": "NUMPAD8", "KP_Prior": "NUMPAD9",
    "semicolon": "SEMICOLON", "equal": "EQUAL", "comma": "COMMA",
    "minus": "MINUS", "period": "PERIOD", "slash": "SLASH",
    "grave": "GRAVE", "bracketleft": "BRACKETLEFT",
    "backslash": "BACKSLASH", "bracketright": "BRACKETRIGHT",
    "apostrophe": "APOSTROPHE",
}


def keysym_to_key_name(keysym: str) -> str:
    """Normalize Tk keysyms without collapsing keypad digits into top-row digits."""
    raw = str(keysym).strip()
    if raw in _PUNCTUATION_KEYS:
        return _PUNCTUATION_KEYS[raw]
    if raw in _TK_KEYSYM_ALIASES:
        return _TK_KEYSYM_ALIASES[raw]
    if raw.startswith("KP_") and len(raw) == 4 and raw[-1].isdigit():
        return f"NUMPAD{raw[-1]}"
    return raw.upper()


def key_to_vk(name: str) -> Optional[int]:
    raw = str(name).strip()
    if raw in _PUNCTUATION_KEYS:
        raw = _PUNCTUATION_KEYS[raw]
    key = raw.upper().replace(" ", "_").replace("-", "_")
    if key in _KEY_VKS:
        return _KEY_VKS[key]
    if len(key) == 1 and ("A" <= key <= "Z" or "0" <= key <= "9"):
        return ord(key)
    for prefix in ("NUMPAD", "KP_"):
        if key.startswith(prefix) and key[len(prefix):].isdigit():
            number = int(key[len(prefix):])
            if 0 <= number <= 9:
                return 0x60 + number
    if key.startswith("F") and key[1:].isdigit():
        number = int(key[1:])
        if 1 <= number <= 24:
            return 0x70 + number - 1
    return None


def is_key_down(vk: int) -> bool:
    user32, _ = _apis()
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)
