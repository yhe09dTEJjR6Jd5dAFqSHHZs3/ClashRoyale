"""Autonomous, local card-image catalog acquisition from the live game UI.

The scanner never invents card labels: a visual sample is accepted only after
an exact bundled-name OCR match, a valid card tile crop, and repeated stable
observations.  All data is written into the user-selected workspace.
"""
from __future__ import annotations

from dataclasses import dataclass
import time

from .cards import CardDatabase
from .deck_manager import DeckManager
from .offline_ocr import OCRSnapshot
from .vision import GameState, Scene, card_signature_for_bounds, crop_frame_to_viewport
from .win32 import Frame


@dataclass(frozen=True)
class CatalogScanStep:
    action: str = "wait"
    done: bool = False
    complete: bool = False
    coverage: int = 0
    expected: int = 0
    samples: int = 0
    scrolls: int = 0
    reason: str = ""


class CardCatalogScanner:
    """Build a verified multi-view visual catalog by reading card collection tiles."""

    MIN_OCR_CONFIDENCE = 0.82
    MIN_VISUAL_SCORE = 0.12
    REQUIRED_STABLE_FRAMES = 3
    MAX_SCROLLS = 36
    MAX_SECONDS = 75.0
    MAX_IDLE_FRAMES = 480
    MAX_NO_NEW_PAGES = 3

    def __init__(self, card_database: CardDatabase, deck_manager: DeckManager):
        self.card_database = card_database
        self.deck_manager = deck_manager
        self.started_at: float | None = None
        self.done = False
        self.complete = False
        self.reason = ""
        self.scrolls = 0
        self.scroll_failures = 0
        self.idle_frames = 0
        self.no_new_pages = 0
        self._pending: dict[tuple[str, str], list[tuple[str, tuple[float, ...], float]]] = {}
        self._seen_card_keys: set[str] = set()
        self._candidate_page: tuple[str, ...] | None = None
        self._candidate_frames = 0
        self._last_committed_scroll_count = -1
        self._scroll_requested = False
        self._accepted_forms: set[tuple[str, str]] = set()
        self._conflicts = 0
        self._catalog_dirty = False

    @property
    def expected_count(self) -> int:
        return len(self.card_database)

    @property
    def playable_count(self) -> int:
        return sum(1 for record in self.card_database.cards
                   if record.card_type.casefold() != "tower troop")

    def _catalog_identities(self) -> set[tuple[str, str]]:
        identities = set()
        for metadata in self.deck_manager.catalog.values():
            key = metadata.get("card_key")
            if not isinstance(key, str) or not key:
                continue
            record = self.card_database.get(key)
            if record is None:
                continue
            form = str(metadata.get("form") or "base")
            required_form = "champion" if record.is_champion else "base"
            if form == required_form:
                identities.add((key, required_form))
        return identities

    @property
    def coverage(self) -> int:
        return len({key for key, _form in self._catalog_identities()})

    @property
    def sample_count(self) -> int:
        return sum(1 for metadata in self.deck_manager.catalog.values()
                   if metadata.get("source") == "runtime_ocr_visual_scan")

    @property
    def bundled_image_count(self) -> int:
        return sum(1 for metadata in self.deck_manager.catalog.values()
                   if metadata.get("source") == "bundled_card_image")

    @property
    def should_scan(self) -> bool:
        # The normal collection list contains the 123 playable cards. Tower
        # troops are counted in total completeness when their tiles are exposed.
        return not self.done and self.coverage < self.playable_count

    def status(self) -> dict:
        return {
            "coverage": self.coverage,
            "expected": self.expected_count,
            "playable_expected": self.playable_count,
            "bundled_image_references": self.bundled_image_count,
            "samples": self.sample_count,
            "scrolls": self.scrolls,
            "scroll_failures": self.scroll_failures,
            "complete": self.coverage >= self.expected_count,
            "done": self.done,
            "reason": self.reason,
            "variant_forms": len({(m.get("card_key"), m.get("form"))
                                   for m in self.deck_manager.catalog.values()
                                   if m.get("source") == "runtime_ocr_visual_scan" and
                                   m.get("form") not in (None, "base", "champion")}),
            "bundled_variant_forms": len({(m.get("card_key"), m.get("form"))
                                           for m in self.deck_manager.catalog.values()
                                           if m.get("source") == "bundled_card_image" and
                                           m.get("form") not in (None, "base", "champion")}),
            "conflicts": self._conflicts,
        }

    @staticmethod
    def _hamming(left: str, right: str) -> int:
        try:
            return (int(left, 16) ^ int(right, 16)).bit_count()
        except (TypeError, ValueError):
            return 64

    @staticmethod
    def _descriptor_distance(left: tuple[float, ...], right: tuple[float, ...]) -> float:
        if not left or len(left) != len(right):
            return 1.0
        return sum(abs(a - b) for a, b in zip(left, right)) / len(left)

    @staticmethod
    def _viewport_origin(frame: Frame, state: GameState) -> tuple[int, int]:
        left, top, _right, _bottom = state.viewport
        return max(0, int(frame.width * left)), max(0, int(frame.height * top))

    @classmethod
    def _tile_bounds(cls, frame: Frame, state: GameState,
                     label_bounds: tuple[int, int, int, int]) -> tuple[int, int, int, int] | None:
        """Estimate the art crop immediately above a recognized collection label."""
        x0, y0, x1, y1 = label_bounds
        origin_x, origin_y = cls._viewport_origin(frame, state)
        left, top, right, bottom = state.viewport
        viewport_width = max(1, int(frame.width * (right - left)))
        viewport_height = max(1, int(frame.height * (bottom - top)))
        local_x0, local_y0 = x0 - origin_x, y0 - origin_y
        local_x1, local_y1 = x1 - origin_x, y1 - origin_y
        if (local_x1 <= local_x0 or local_y1 <= local_y0 or
                local_y0 < viewport_height * 0.12 or local_y0 > viewport_height * 0.94):
            return None
        center_x = (local_x0 + local_x1) // 2
        crop_width = max(20, int(viewport_width * 0.13))
        crop_height = max(28, int(viewport_height * 0.12))
        label_height = max(1, local_y1 - local_y0)
        art_bottom = max(0, local_y0 - max(1, int(label_height * 0.18)))
        art_top = max(0, art_bottom - crop_height)
        if art_bottom - art_top < crop_height * 0.65:
            return None
        crop_left = max(0, center_x - crop_width // 2)
        crop_right = min(viewport_width, crop_left + crop_width)
        crop_left = max(0, crop_right - crop_width)
        if crop_right - crop_left < crop_width * 0.70:
            return None
        return crop_left, art_top, crop_right, art_bottom

    def _observe_card(self, frame: Frame, viewport_frame: Frame, state: GameState,
                      item) -> bool:
        if (item.confidence < self.MIN_OCR_CONFIDENCE or item.bounds is None):
            return False
        record = self.card_database.get(item.card_key)
        if record is None:
            return False
        form = item.form if item.form in record.available_forms else "base"
        bounds = self._tile_bounds(frame, state, item.bounds)
        if bounds is None:
            return False
        visual_score, fingerprint, descriptor = card_signature_for_bounds(viewport_frame, bounds)
        if (not fingerprint or len(descriptor) != 131 or
                visual_score < self.MIN_VISUAL_SCORE):
            return False
        identity = (record.key, form)
        pending = self._pending.setdefault(identity, [])
        sample = (fingerprint, descriptor, float(item.confidence))
        if pending:
            previous_fp, previous_desc, _previous_conf = pending[-1]
            if (self._hamming(previous_fp, fingerprint) > 24 or
                    self._descriptor_distance(previous_desc, descriptor) > 0.18):
                pending[:] = [sample]
            else:
                pending.append(sample)
        else:
            pending.append(sample)
        if len(pending) > self.REQUIRED_STABLE_FRAMES:
            del pending[:-self.REQUIRED_STABLE_FRAMES]
        if len(pending) < self.REQUIRED_STABLE_FRAMES:
            return True
        # Use the medoid fingerprint and average descriptor of three adjacent
        # frames. This rejects transient text matches and animated one-frame art.
        candidates = [entry[0] for entry in pending]
        medoid = min(candidates, key=lambda candidate: sum(
            self._hamming(candidate, other) for other in candidates
        ))
        descriptors = [entry[1] for entry in pending]
        averaged = tuple(round(sum(values) / len(values), 5)
                         for values in zip(*descriptors))
        confidence = min(entry[2] for entry in pending)
        added = self.deck_manager.add_catalog_sample(
            record.key, form, medoid, averaged, confidence, persist=False
        )
        if added:
            self._accepted_forms.add(identity)
            self._catalog_dirty = True
        elif medoid not in self.deck_manager.catalog:
            self._conflicts += 1
        return True

    def observe(self, frame: Frame | None, snapshot: OCRSnapshot | None,
                state: GameState, *, now: float | None = None) -> CatalogScanStep:
        if self.done:
            if self._catalog_dirty:
                self.deck_manager.save_catalog()
                self._catalog_dirty = False
            status = self.status()
            return CatalogScanStep(done=True, complete=status["complete"],
                                   coverage=status["coverage"], expected=status["expected"],
                                   samples=status["samples"], scrolls=self.scrolls,
                                   reason=self.reason)
        if state.scene is not Scene.DECK or state.scene_confidence < 0.78:
            return CatalogScanStep(coverage=self.coverage, expected=self.expected_count,
                                   samples=self.sample_count, scrolls=self.scrolls)
        now = time.monotonic() if now is None else float(now)
        if self.started_at is None:
            self.started_at = now
        if now - self.started_at >= self.MAX_SECONDS:
            self.done = True
            self.reason = "scan time limit reached"
        elif self.scrolls >= self.MAX_SCROLLS:
            self.done = True
            self.reason = "scroll limit reached"
        if self.done:
            if self._catalog_dirty:
                self.deck_manager.save_catalog()
                self._catalog_dirty = False
            status = self.status()
            return CatalogScanStep(done=True, complete=status["complete"],
                                   coverage=status["coverage"], expected=status["expected"],
                                   samples=status["samples"], scrolls=self.scrolls,
                                   reason=self.reason)
        if frame is None or snapshot is None or not snapshot.available:
            self.idle_frames += 1
        else:
            viewport_frame = crop_frame_to_viewport(frame, state.viewport)
            visible_keys: set[str] = set()
            for item in snapshot.cards:
                if item.confidence >= self.MIN_OCR_CONFIDENCE:
                    visible_keys.add(item.card_key)
                    self._observe_card(frame, viewport_frame, state, item)
            if visible_keys:
                self.idle_frames = 0
            else:
                self.idle_frames += 1
            page = tuple(sorted(visible_keys))
            if page == self._candidate_page:
                self._candidate_frames += 1
            else:
                self._candidate_page = page
                self._candidate_frames = 1
            if (self._candidate_frames >= self.REQUIRED_STABLE_FRAMES and
                    self._last_committed_scroll_count != self.scrolls):
                new_keys = visible_keys - self._seen_card_keys
                if self.scrolls > 0:
                    if new_keys:
                        self.no_new_pages = 0
                    else:
                        self.no_new_pages += 1
                self._seen_card_keys.update(visible_keys)
                self._last_committed_scroll_count = self.scrolls
                if self._catalog_dirty:
                    self.deck_manager.save_catalog()
                    self._catalog_dirty = False
                if self.coverage >= self.expected_count:
                    self.done = True
                    self.complete = True
                    self.reason = "all bundled card identities have stable visual samples"
                elif self.scrolls > 0 and self.no_new_pages >= self.MAX_NO_NEW_PAGES:
                    self.done = True
                    self.reason = "collection reached a stable end or OCR exposed no new cards"
                elif visible_keys and not self._scroll_requested:
                    self._scroll_requested = True
                    return CatalogScanStep(
                        action="scroll", coverage=self.coverage,
                        expected=self.expected_count, samples=self.sample_count,
                        scrolls=self.scrolls,
                    )
        if self.idle_frames >= self.MAX_IDLE_FRAMES:
            self.done = True
            self.reason = "no high-confidence card labels were exposed by the game UI"
        if self.done:
            if self._catalog_dirty:
                self.deck_manager.save_catalog()
                self._catalog_dirty = False
            status = self.status()
            return CatalogScanStep(done=True, complete=status["complete"],
                                   coverage=status["coverage"], expected=status["expected"],
                                   samples=status["samples"], scrolls=self.scrolls,
                                   reason=self.reason)
        return CatalogScanStep(coverage=self.coverage, expected=self.expected_count,
                               samples=self.sample_count, scrolls=self.scrolls)

    def mark_skipped(self, reason: str) -> None:
        if self._catalog_dirty:
            self.deck_manager.save_catalog()
            self._catalog_dirty = False
        self.done = True
        self.reason = str(reason or "catalog scan skipped")[:160]

    def mark_scrolled(self, success: bool) -> None:
        if not self._scroll_requested or self.done:
            return
        self.scrolls += 1
        if not success:
            self.scroll_failures += 1
        self._scroll_requested = False
        self._candidate_page = None
        self._candidate_frames = 0
        if self.scroll_failures >= 4:
            self.done = True
            self.reason = "game window rejected repeated collection scroll input"
