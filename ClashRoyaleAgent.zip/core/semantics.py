"""Self-supervised, model-free semantic recognition for deployed arena units.

Visual identities are learned only from an Agent deployment whose card identity
was already verified in the player's hand.  The same local appearance prototype
is then matched against friendly and enemy tracks.  No pretrained model, remote
service, card-art substitution, or unverified identity guess is used.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import time
from typing import Iterable

from .cards import CardDatabase
from .combat import CombatDatabase
from .vision import GameState, Scene, SemanticUnit


PROFILE_VERSION = 1
MAX_FILE_BYTES = 1_000_000
MAX_PROTOTYPES = 256
MAX_PENDING = 12
DESCRIPTOR_SIZE = 48
MIN_SAMPLES_FOR_MATCH = 3


@dataclass
class _Prototype:
    card_key: str
    form: str
    mean: list[float]
    variance: list[float]
    samples: int
    aspect_ratio: float
    log_area: float
    updated_at: int


@dataclass(frozen=True)
class _PendingLabel:
    card_key: str
    form: str
    x: float
    y: float
    timestamp: float
    level: int | None
    existing_track_ids: frozenset[int]


class SemanticBattleRecognizer:
    """Learn visual prototypes from confirmed friendly deployments, then match."""

    def __init__(self, profile_path: Path, card_database: CardDatabase | None = None,
                 combat_database: CombatDatabase | None = None):
        self.profile_path = Path(profile_path)
        self.card_database = card_database or CardDatabase()
        self.combat_database = combat_database or CombatDatabase(card_database=self.card_database)
        self.prototypes: dict[tuple[str, str], _Prototype] = {}
        self.pending: list[_PendingLabel] = []
        self._labelled_track_ids: set[int] = set()
        self._last_summary: dict = {}
        self.load_status = "new"
        self._load()

    @staticmethod
    def _valid_vector(value) -> bool:
        return (isinstance(value, list) and len(value) == DESCRIPTOR_SIZE and
                all(isinstance(x, (int, float)) and not isinstance(x, bool) and
                    math.isfinite(float(x)) and 0.0 <= float(x) <= 1.0 for x in value))

    def _load(self) -> None:
        try:
            if self.profile_path.stat().st_size > MAX_FILE_BYTES:
                self.load_status = "oversize"
                return
            raw = json.loads(self.profile_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError, TypeError):
            self.load_status = "invalid"
            return
        if not isinstance(raw, dict) or raw.get("version") != PROFILE_VERSION:
            self.load_status = "unsupported"
            return
        items = raw.get("prototypes")
        if not isinstance(items, list) or len(items) > MAX_PROTOTYPES:
            self.load_status = "invalid"
            return
        loaded: dict[tuple[str, str], _Prototype] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            key, form = item.get("card_key"), item.get("form", "base")
            if (not isinstance(key, str) or self.card_database.get(key) is None or
                    form not in ("base", "evolution", "hero", "champion")):
                continue
            mean, variance = item.get("mean"), item.get("variance")
            if not self._valid_vector(mean) or not self._valid_vector(variance):
                continue
            samples = item.get("samples")
            ratio, log_area = item.get("aspect_ratio"), item.get("log_area")
            if (not isinstance(samples, int) or isinstance(samples, bool) or not 1 <= samples <= 100_000 or
                    not isinstance(ratio, (int, float)) or not 0.05 <= float(ratio) <= 20.0 or
                    not isinstance(log_area, (int, float)) or not -30.0 <= float(log_area) <= 0.0):
                continue
            loaded[(key, form)] = _Prototype(
                key, form, [float(x) for x in mean], [float(x) for x in variance],
                samples, float(ratio), float(log_area),
                int(item.get("updated_at", 0)) if isinstance(item.get("updated_at", 0), int) else 0,
            )
        self.prototypes = loaded
        self.load_status = "loaded" if loaded else "empty"

    def arm_deployment(self, card_key: str, form: str, x: float, y: float,
                       *, level: int | None = None, now: float | None = None,
                       existing_track_ids: Iterable[int] = ()) -> bool:
        """Label only a newly spawned friendly track after a verified card action.

        ``existing_track_ids`` is captured from the pre-deployment frame.  The
        track birth time is also checked during learning, so a pre-existing
        object cannot acquire the new card's label merely by being nearby.
        """
        record = self.card_database.get(card_key)
        if record is None or form not in ("base", "evolution", "hero", "champion"):
            return False
        if record.card_type.casefold() not in ("troop", "building"):
            return False
        profile = self.combat_database.base(card_key)
        if profile is None or profile.kind.casefold() not in ("troop", "building"):
            return False
        try:
            x_value, y_value = float(x), float(y)
            timestamp = time.monotonic() if now is None else float(now)
            existing = frozenset(int(value) for value in existing_track_ids)
        except (TypeError, ValueError, OverflowError):
            return False
        if (not math.isfinite(x_value) or not math.isfinite(y_value) or
                not math.isfinite(timestamp) or
                not (0.02 <= x_value <= 0.98 and 0.02 <= y_value <= 0.98)):
            return False
        self.pending.append(_PendingLabel(
            card_key, form, x_value, y_value, timestamp,
            int(level) if isinstance(level, int) and not isinstance(level, bool) and 1 <= level <= 16 else None,
            existing,
        ))
        if len(self.pending) > MAX_PENDING:
            del self.pending[:-MAX_PENDING]
        return True

    @staticmethod
    def _descriptor_distance(left: tuple[float, ...], right: list[float]) -> float:
        if len(left) != DESCRIPTOR_SIZE or len(right) != DESCRIPTOR_SIZE:
            return 1.0
        return sum(abs(float(a) - float(b)) for a, b in zip(left, right)) / DESCRIPTOR_SIZE

    def _add_sample(self, card_key: str, form: str, track) -> bool:
        descriptor = tuple(getattr(track, "appearance", ()) or ())
        if (len(descriptor) != DESCRIPTOR_SIZE or
                not all(isinstance(value, (int, float)) and math.isfinite(float(value))
                        and 0.0 <= float(value) <= 1.0 for value in descriptor)):
            return False
        ratio = max(0.05, min(20.0, float(track.width) / max(1e-4, float(track.height))))
        area = max(1e-7, min(0.1, float(track.area)))
        log_area = math.log(area)
        identity = (card_key, form)
        prototype = self.prototypes.get(identity)
        if prototype is None:
            if len(self.prototypes) >= MAX_PROTOTYPES:
                oldest = min(self.prototypes.values(), key=lambda item: item.updated_at)
                self.prototypes.pop((oldest.card_key, oldest.form), None)
            self.prototypes[identity] = _Prototype(
                card_key, form, [float(x) for x in descriptor], [0.0] * DESCRIPTOR_SIZE,
                1, ratio, log_area, int(time.time()),
            )
            return True
        n = min(100_000, prototype.samples)
        rate = 1.0 / min(20.0, n + 1.0)
        for index, value in enumerate(descriptor):
            delta = float(value) - prototype.mean[index]
            prototype.mean[index] += rate * delta
            prototype.variance[index] = (1.0 - rate) * prototype.variance[index] + rate * delta * delta
        prototype.aspect_ratio = 0.92 * prototype.aspect_ratio + 0.08 * ratio
        prototype.log_area = 0.92 * prototype.log_area + 0.08 * log_area
        prototype.samples = min(100_000, prototype.samples + 1)
        prototype.updated_at = int(time.time())
        return True

    def _learn_pending(self, state: GameState, now: float) -> int:
        learned = 0
        tracks = state.friendly_tracks
        remaining: list[_PendingLabel] = []
        for pending in self.pending:
            age = now - pending.timestamp
            if age > 1.8:
                continue
            if age < 0.04:
                remaining.append(pending)
                continue
            candidates = []
            for track in tracks:
                if (track.track_id in pending.existing_track_ids or
                        track.track_id in self._labelled_track_ids or not track.appearance or
                        len(track.appearance) != DESCRIPTOR_SIZE):
                    continue
                # ClusterTrack.age_seconds is elapsed time since the track was
                # first created (including short occlusions).  Requiring both a
                # post-action first-seen time and a post-action last observation
                # prevents an old nearby unit from being relabelled as this play.
                try:
                    first_seen = float(track.last_seen) - max(0.0, float(track.age_seconds))
                    last_seen = float(track.last_seen)
                    confidence = float(track.confidence)
                    area = float(track.area)
                except (TypeError, ValueError, OverflowError):
                    continue
                if (not math.isfinite(first_seen) or not math.isfinite(last_seen) or
                        not math.isfinite(confidence) or not math.isfinite(area) or
                        first_seen < pending.timestamp - 0.025 or
                        last_seen < pending.timestamp + 0.04):
                    continue
                distance = math.hypot((track.x - pending.x) * 1.15, track.y - pending.y)
                if distance <= 0.145 and confidence >= 0.22:
                    # If a later verified play at nearly the same location could
                    # also explain this spawn, do not let the earlier pending
                    # action steal the new track's identity.
                    claimed_by_later_action = False
                    for later in self.pending:
                        if later.timestamp <= pending.timestamp or later.timestamp > now:
                            continue
                        later_distance = math.hypot(
                            (track.x - later.x) * 1.15, track.y - later.y
                        )
                        if (first_seen >= later.timestamp - 0.025 and
                                later_distance <= 0.145 and
                                later_distance <= distance + 0.012):
                            claimed_by_later_action = True
                            break
                    if claimed_by_later_action:
                        continue
                    score = distance - min(0.025, area * 3.0) - min(0.02, confidence * 0.02)
                    candidates.append((score, track))
            if not candidates:
                remaining.append(pending)
                continue
            candidates.sort(key=lambda item: item[0])
            # Two similarly plausible new tracks (e.g. a split/swarm spawn) do
            # not provide a safe identity label. Keep the pending action briefly
            # so later frames can disambiguate; otherwise discard it on timeout.
            if (len(candidates) > 1 and
                    candidates[1][0] - candidates[0][0] < 0.018):
                remaining.append(pending)
                continue
            track = candidates[0][1]
            if not self._add_sample(pending.card_key, pending.form, track):
                remaining.append(pending)
                continue
            self._labelled_track_ids.add(track.track_id)
            learned += 1
        self.pending = remaining
        if len(self._labelled_track_ids) > 1024:
            self._labelled_track_ids = set(sorted(self._labelled_track_ids)[-512:])
        return learned

    def _learn_ocr_grounded_enemy(self, state: GameState) -> int:
        """Use a high-confidence, spatially adjacent OCR card label as a label.

        This permits learning an opponent unit even when the Agent has not yet
        deployed that card itself. A card name elsewhere on the screen is never
        sufficient: its label box must be close to a tracked enemy spawn.
        """
        learned = 0
        width, height = max(1, state.frame_width), max(1, state.frame_height)
        for track in state.enemy_tracks:
            if track.track_id in self._labelled_track_ids or not track.appearance:
                continue
            best = None
            for item in state.recognized_cards:
                if item.confidence < 0.92 or item.bounds is None:
                    continue
                x0, y0, x1, y1 = item.bounds
                if y0 / height > 0.48:
                    continue
                record = self.card_database.get(item.card_key)
                profile = self.combat_database.base(item.card_key)
                if (record is None or record.card_type.casefold() not in ("troop", "building")
                        or profile is None or profile.kind.casefold() not in ("troop", "building")):
                    continue
                cx, cy = (x0 + x1) / (2.0 * width), (y0 + y1) / (2.0 * height)
                distance = math.hypot((track.x - cx) * 1.15, track.y - cy)
                if distance <= 0.115 and (best is None or distance < best[0]):
                    best = (distance, item)
            if best is None:
                continue
            item = best[1]
            if self._add_sample(item.card_key, item.form, track):
                self._labelled_track_ids.add(track.track_id)
                learned += 1
        return learned

    def _match_track(self, track, team: str) -> SemanticUnit | None:
        descriptor = tuple(getattr(track, "appearance", ()) or ())
        if len(descriptor) != DESCRIPTOR_SIZE:
            return None
        ratio = max(0.05, min(20.0, float(track.width) / max(1e-4, float(track.height))))
        log_area = math.log(max(1e-7, min(0.1, float(track.area))))
        ranked: list[tuple[float, _Prototype]] = []
        for prototype in self.prototypes.values():
            if prototype.samples < MIN_SAMPLES_FOR_MATCH:
                continue
            distance = self._descriptor_distance(descriptor, prototype.mean)
            texture_similarity = math.exp(-distance * 8.0)
            ratio_delta = abs(math.log(ratio / max(0.05, prototype.aspect_ratio)))
            shape_similarity = math.exp(-ratio_delta * 0.70)
            area_delta = abs(log_area - prototype.log_area)
            area_similarity = math.exp(-min(5.0, area_delta) * 0.12)
            score = 0.72 * texture_similarity + 0.20 * shape_similarity + 0.08 * area_similarity
            # More samples make the prototype less likely to be a one-frame accident.
            score *= min(1.0, 0.78 + prototype.samples * 0.035)
            ranked.append((score, prototype))
        if not ranked:
            return None
        ranked.sort(key=lambda item: item[0], reverse=True)
        best_score, best = ranked[0]
        second_score = ranked[1][0] if len(ranked) > 1 else 0.0
        margin = best_score - second_score
        if best_score < 0.745 or (len(ranked) > 1 and margin < 0.035):
            return None
        confidence = min(0.92, best_score * float(track.confidence) *
                         min(1.0, 0.70 + best.samples * 0.05))
        if track.observations < 2:
            confidence *= 0.82
        if confidence < 0.58:
            return None
        return SemanticUnit(
            track_id=track.track_id, team=team,
            card_key=best.card_key, form=best.form,
            confidence=max(0.0, min(0.92, confidence)),
            x=track.x, y=track.y, vx=track.vx, vy=track.vy,
            area=track.area, observations=track.observations,
            health_ratio=track.health_ratio,
            health_confidence=track.health_confidence,
            roles=self.card_database.roles_for(best.card_key),
        )

    def observe(self, state: GameState, *, now: float | None = None) -> GameState:
        now = time.monotonic() if now is None else float(now)
        if state.scene not in (Scene.BATTLE, Scene.UNKNOWN) or not state.battle_detected:
            self.pending.clear()
            self._last_summary = {"prototypes": len(self.prototypes), "learned": 0,
                                  "enemy_units": 0, "friendly_units": 0}
            return state.__class__(**{
                **state.__dict__, "semantic_enemy_units": (), "semantic_friendly_units": (),
            })
        learned = self._learn_pending(state, now)
        learned += self._learn_ocr_grounded_enemy(state)
        enemy = tuple(unit for track in state.enemy_tracks
                      if (unit := self._match_track(track, "enemy")) is not None)
        friendly = tuple(unit for track in state.friendly_tracks
                         if (unit := self._match_track(track, "friendly")) is not None)
        self._last_summary = {
            "prototypes": len(self.prototypes), "learned": learned,
            "enemy_units": len(enemy), "friendly_units": len(friendly),
            "pending": len(self.pending),
        }
        return state.__class__(**{
            **state.__dict__, "semantic_enemy_units": enemy,
            "semantic_friendly_units": friendly,
        })

    def save(self) -> None:
        self.profile_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": PROFILE_VERSION,
            "prototypes": [
                {
                    "card_key": item.card_key, "form": item.form,
                    "mean": item.mean, "variance": item.variance,
                    "samples": item.samples, "aspect_ratio": item.aspect_ratio,
                    "log_area": item.log_area, "updated_at": item.updated_at,
                }
                for item in sorted(self.prototypes.values(),
                                   key=lambda value: (value.card_key, value.form))
            ],
        }
        temp = self.profile_path.with_suffix(self.profile_path.suffix + ".tmp")
        try:
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.profile_path)
        finally:
            try:
                if temp.exists():
                    temp.unlink()
            except OSError:
                pass

    def summary(self) -> dict:
        return dict(self._last_summary)
