"""Local, model-free Clash Royale automation package."""

APP_VERSION = "0.27.0"
# Runtime uses only the Python standard library.
