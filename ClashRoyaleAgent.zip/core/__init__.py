"""Local, model-free Clash Royale automation package."""

APP_VERSION = "0.16.0"
# Runtime uses only the Python standard library.
