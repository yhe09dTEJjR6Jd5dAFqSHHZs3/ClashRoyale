"""Local, model-free Clash Royale automation package."""

APP_VERSION = "0.7.0"
