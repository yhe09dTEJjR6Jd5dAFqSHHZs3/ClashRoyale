"""Shared, truthful stop-status formatting for both Windows UI backends."""
from __future__ import annotations


def format_stop_summary(summary: dict) -> tuple[str, str]:
    """Return a concise status line and severity for a completed Agent run."""
    summary = summary if isinstance(summary, dict) else {}
    reason = str(summary.get("stop_reason") or "unknown")
    stop_key = str(summary.get("stop_key") or "停止键")[:24]
    actions = int(summary.get("actions") or 0)
    wins = int(summary.get("wins") or 0)
    losses = int(summary.get("losses") or 0)
    draws = int(summary.get("draws") or 0)
    verified = int(summary.get("verified_actions") or 0)
    if reason == "user_stop":
        prefix = f"已按 {stop_key} 停止"
    elif reason == "safety_failure":
        prefix = "安全故障停止"
    elif reason == "runtime_error":
        prefix = "运行异常停止"
    else:
        prefix = "Agent 已停止"
    pieces = [prefix, f"操作 {actions} 次（验证 {verified} 次）",
              f"胜/负/平 {wins}/{losses}/{draws}"]
    monitor = str(summary.get("stop_monitor") or "unknown")
    pieces.append("停止键监听正常" if monitor == "global_hook" else
                  "停止键监听故障" if monitor == "failed" else "停止键监听状态未知")
    try:
        frame_age = max(0.0, float(summary.get("seconds_since_last_frame", 0.0)))
    except (TypeError, ValueError):
        frame_age = 0.0
    if frame_age >= 2.0:
        pieces.append(f"最后画面 {frame_age:.1f}s 前")
    error = str(summary.get("last_error") or "").strip()
    capture_issue = str(summary.get("last_capture_issue") or "").strip()
    detail = error or capture_issue
    if detail:
        pieces.append(f"最近故障：{detail[:110]}")
    severity = "error" if reason == "safety_failure" or monitor == "failed" else (
        "warning" if detail or reason == "runtime_error" else "ready"
    )
    return " · ".join(pieces)[:320], severity
