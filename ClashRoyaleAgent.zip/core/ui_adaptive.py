"""Geometry-first, model-free adaptation to changing Clash Royale layouts.

The detector looks for repeated card rectangles, stacked mode panels, bottom
navigation, and the battle hand using edge geometry rather than fixed screen
coordinates or fixed card artwork.  It deliberately emits candidates only;
semantic labels/unlock state still have to be verified by OCR/accessibility.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from math import isfinite

from .win32 import Frame


@dataclass(frozen=True)
class AdaptiveUIEvidence:
    card_grid_confidence: float = 0.0
    card_grid_columns: tuple[tuple[float, float], ...] = ()
    card_grid_rows: tuple[float, ...] = ()
    bottom_nav_confidence: float = 0.0
    mode_panel_centers: tuple[float, ...] = ()
    ladder_lock_confidence: float = 0.0
    home_cta: tuple[float, float, float, float, float] | None = None
    loading_confidence: float = 0.0
    arena_bounds: tuple[float, float, float, float] | None = None
    hand_slots: tuple[tuple[float, float, float, float], ...] = ()
    elixir_bounds: tuple[float, float, float, float] | None = None


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    if not isfinite(value):
        return low
    return max(low, min(high, value))


def _luma(data: memoryview, offset: int) -> float:
    b, g, r = data[offset], data[offset + 1], data[offset + 2]
    return 0.114 * b + 0.587 * g + 0.299 * r


def _detect_ladder_lock_marker(frame: Frame, panel_center_y: float) -> float:
    """Find a padlock-shaped gold marker inside the visually detected ladder panel.

    This is deliberately a one-way signal: a clear lock can establish that the
    ladder is locked, but the absence of a lock never proves that it is unlocked.
    The search window is anchored to the detected panel row rather than a fixed
    pixel location, and requires both a compact gold body and a dark keyhole.
    """
    if not 0.68 <= panel_center_y <= 0.99:
        return 0.0
    width, height = frame.width, frame.height
    x0 = max(0, int(width * 0.58))
    x1 = min(width, int(width * 0.99))
    y0 = max(0, int((panel_center_y - 0.12) * height))
    y1 = min(height, int((panel_center_y + 0.12) * height))
    step = 2
    grid_w = max(1, (x1 - x0 + step - 1) // step)
    grid_h = max(1, (y1 - y0 + step - 1) // step)
    data = memoryview(frame.bgra)
    mask = bytearray(grid_w * grid_h)
    for gy in range(grid_h):
        py = min(y1 - 1, y0 + gy * step)
        row = py * width * 4
        base = gy * grid_w
        for gx in range(grid_w):
            px = min(x1 - 1, x0 + gx * step)
            offset = row + px * 4
            b, g, r = data[offset], data[offset + 1], data[offset + 2]
            if r >= 155 and g >= 82 and b <= 145 and r > g * 1.08 and g > b * 1.12:
                mask[base + gx] = 1

    seen = bytearray(len(mask))
    best = 0.0
    for start, active in enumerate(mask):
        if not active or seen[start]:
            continue
        queue = deque([start])
        seen[start] = 1
        min_x = max_x = start % grid_w
        min_y = max_y = start // grid_w
        count = 0
        while queue:
            current = queue.popleft()
            gx, gy = current % grid_w, current // grid_w
            count += 1
            min_x, max_x = min(min_x, gx), max(max_x, gx)
            min_y, max_y = min(min_y, gy), max(max_y, gy)
            for nx, ny in ((gx - 1, gy), (gx + 1, gy), (gx, gy - 1), (gx, gy + 1)):
                if 0 <= nx < grid_w and 0 <= ny < grid_h:
                    neighbor = ny * grid_w + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        queue.append(neighbor)

        box_w = (max_x - min_x + 1) * step
        box_h = (max_y - min_y + 1) * step
        box_area = box_w * box_h
        if box_h <= 0:
            continue
        aspect = box_w / box_h
        area_fraction = box_area / max(1.0, width * height)
        fill = count * step * step / max(1.0, box_area)
        if not (0.48 <= aspect <= 1.22 and 0.0010 <= area_fraction <= 0.025 and fill >= 0.36):
            continue

        dark = total = 0
        px0, px1 = x0 + min_x * step, min(x1, x0 + (max_x + 1) * step)
        py0, py1 = y0 + min_y * step, min(y1, y0 + (max_y + 1) * step)
        for py in range(py0, py1, step):
            row = py * width * 4
            for px in range(px0, px1, step):
                offset = row + px * 4
                b, g, r = data[offset], data[offset + 1], data[offset + 2]
                total += 1
                if max(r, g, b) <= 88:
                    dark += 1
        keyhole_ratio = dark / max(1, total)
        if keyhole_ratio < 0.025:
            continue
        score = _clamp(0.54 * fill + 0.46 * min(1.0, keyhole_ratio / 0.075))
        best = max(best, score)
    return best


def _edge_profile(frame: Frame, axis: str,
                  region: tuple[float, float, float, float]) -> tuple[list[float], int, int]:
    """Return a sampled mean luminance-edge profile in normalized coordinates."""
    w, h = frame.width, frame.height
    x0, y0, x1, y1 = region
    data = memoryview(frame.bgra)
    if axis == "vertical":
        start = max(1, min(w - 1, int(w * x0)))
        end = max(start + 1, min(w, int(w * x1)))
        top = max(0, min(h - 1, int(h * y0)))
        bottom = max(top + 1, min(h, int(h * y1)))
        # Sampling every 3–6 pixels can skip a one-pixel card boundary in
        # wide layouts. The hand detector needs both sides of each slot, so
        # sample each x coordinate; the bounded vertical sampling keeps cost
        # modest even for 4K captures.
        x_step = 1
        y_step = max(2, h // 160)
        profile = [0.0] * w
        for x in range(start, end, x_step):
            total = count = 0.0
            for y in range(top, bottom, y_step):
                current = (y * w + x) * 4
                previous = current - 4
                total += abs(_luma(data, current) - _luma(data, previous))
                count += 1.0
            if count:
                profile[x] = total / count
        return profile, start, end

    start = max(1, min(h - 1, int(h * y0)))
    end = max(start + 1, min(h, int(h * y1)))
    left = max(0, min(w - 1, int(w * x0)))
    right = max(left + 1, min(w, int(w * x1)))
    y_step = max(1, h // 320)
    x_step = max(2, w // 160)
    profile = [0.0] * h
    for y in range(start, end, y_step):
        total = count = 0.0
        row = y * w * 4
        previous_row = row - w * 4
        for x in range(left, right, x_step):
            current = row + x * 4
            previous = previous_row + x * 4
            total += abs(_luma(data, current) - _luma(data, previous))
            count += 1.0
        if count:
            profile[y] = total / count
    return profile, start, end


def _profile_peaks(profile: list[float], start: int, end: int,
                   total_size: int, *, minimum_gap: float = 0.018,
                   percentile: float = 0.86, threshold_floor: float = 12.0,
                   mean_multiplier: float = 1.48) -> list[tuple[float, float]]:
    values = [profile[index] for index in range(start, min(end, len(profile)))
              if profile[index] > 0.0]
    if len(values) < 2:
        return []
    ordered = sorted(values)
    percentile_index = min(len(ordered) - 1, int((len(ordered) - 1) * percentile))
    mean = sum(values) / len(values)
    threshold = max(threshold_floor, ordered[percentile_index], mean * mean_multiplier)
    candidates: list[tuple[int, float]] = []
    for index in range(max(start + 1, 1), min(end - 1, len(profile) - 1)):
        value = profile[index]
        if value >= threshold and value >= profile[index - 1] and value >= profile[index + 1]:
            candidates.append((index, value))
    minimum_distance = max(2, int(total_size * minimum_gap))
    selected: list[tuple[int, float]] = []
    for candidate in sorted(candidates, key=lambda item: item[1], reverse=True):
        if all(abs(candidate[0] - old[0]) >= minimum_distance for old in selected):
            selected.append(candidate)
    selected.sort(key=lambda item: item[0])
    return [(index / max(1, total_size), value) for index, value in selected]


def _regular_edge_pairs(peaks: list[tuple[float, float]], *,
                        min_width: float, max_width: float,
                        min_spacing: float, max_spacing: float,
                        min_count: int = 3) -> tuple[tuple[float, float], ...]:
    """Find repeated rectangles, allowing weaker decorative edges inside tiles."""
    pairs: list[tuple[float, float, float]] = []
    for left_index, (left, left_strength) in enumerate(peaks):
        for right, right_strength in peaks[left_index + 1:]:
            width = right - left
            if width > max_width:
                break
            if min_width <= width <= max_width:
                pairs.append((left, right, min(left_strength, right_strength)))
    if not pairs:
        return ()
    pairs.sort(key=lambda item: (item[0], item[1]))

    def quality(chain: list[tuple[float, float, float]]) -> tuple:
        widths = [right - left for left, right, _strength in chain]
        starts = [left for left, _right, _strength in chain]
        gaps = [starts[index + 1] - starts[index] for index in range(len(starts) - 1)]
        width_spread = max(widths) - min(widths) if widths else 1.0
        gap_spread = max(gaps) - min(gaps) if gaps else 1.0
        strength = sum(item[2] for item in chain) / max(1, len(chain))
        return (len(chain), -width_spread, -gap_spread, strength)

    best: list[tuple[float, float, float]] = []
    paths: list[list[tuple[float, float, float]]] = [[item] for item in pairs]
    for index, item in enumerate(pairs):
        for previous_index in range(index):
            previous = pairs[previous_index]
            if not (min_spacing <= item[0] - previous[0] <= max_spacing):
                continue
            if item[0] <= previous[1] + 0.008:
                continue
            if abs((item[1] - item[0]) - (previous[1] - previous[0])) > 0.085:
                continue
            candidate = paths[previous_index] + [item]
            if quality(candidate) > quality(paths[index]):
                paths[index] = candidate
        if quality(paths[index]) > quality(best):
            best = paths[index]
    if len(best) < min_count:
        return ()
    return tuple((item[0], item[1]) for item in best[:4])


def _longest_regular_peak_sequence(peaks: list[tuple[float, float]], *,
                                   min_gap: float, max_gap: float,
                                   minimum_count: int = 3) -> tuple[float, ...]:
    if not peaks:
        return ()
    ordered = sorted(peaks, key=lambda item: item[0])
    best: tuple[tuple[int, float, float], list[tuple[float, float]]] | None = None
    for first_index in range(len(ordered)):
        chains: list[list[tuple[float, float]]] = [[ordered[first_index]]]
        for next_index in range(first_index + 1, len(ordered)):
            item = ordered[next_index]
            candidates = [chain for chain in chains
                          if min_gap <= item[0] - chain[-1][0] <= max_gap]
            if candidates:
                # Favor a regular row pitch over a single unusually strong edge.
                parent = min(candidates, key=lambda chain: (
                    max((chain[i + 1][0] - chain[i][0] for i in range(len(chain) - 1)), default=0.0)
                    - min((chain[i + 1][0] - chain[i][0] for i in range(len(chain) - 1)), default=0.0),
                    -sum(value for _position, value in chain),
                ))
                chains.append(parent + [item])
        for chain in chains:
            if len(chain) < minimum_count:
                continue
            gaps = [chain[i + 1][0] - chain[i][0] for i in range(len(chain) - 1)]
            spread = max(gaps) - min(gaps) if gaps else 1.0
            strength = sum(value for _position, value in chain) / len(chain)
            score = (len(chain), -spread, strength)
            if best is None or score > best[0]:
                best = (score, chain)
    if best is None:
        return ()
    return tuple(item[0] for item in best[1])


def _bottom_navigation(frame: Frame) -> float:
    vertical, start, end = _edge_profile(frame, "vertical", (0.02, 0.895, 0.98, 0.999))
    peaks = _profile_peaks(vertical, start, end, frame.width,
                           minimum_gap=0.075, percentile=0.88)
    horizontal, y_start, y_end = _edge_profile(frame, "horizontal", (0.02, 0.89, 0.98, 0.99))
    row_peaks = _profile_peaks(horizontal, y_start, y_end, frame.height,
                               minimum_gap=0.012, percentile=0.88)
    positions = [x for x, _value in peaks if 0.04 <= x <= 0.96]
    divider_count = len(positions)
    if (divider_count < 3 or len(row_peaks) < 2 or min(positions) > 0.25
            or max(positions) < 0.80):
        return 0.0
    strength = sum(value for _, value in peaks) / max(1, len(peaks))
    return _clamp(0.22 + min(0.52, divider_count * 0.11) + min(0.24, strength / 150.0))


def _mean_luminance(frame: Frame) -> float:
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    sx, sy = max(1, w // 60), max(1, h // 90)
    total = count = 0.0
    for y in range(sy // 2, h, sy):
        row = y * w * 4
        for x in range(sx // 2, w, sx):
            total += _luma(data, row + x * 4)
            count += 1.0
    return total / max(1.0, count)


def _arena_bounds(frame: Frame) -> tuple[float, float, float, float] | None:
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    x0, x1 = int(w * 0.04), int(w * 0.96)
    y0, y1 = int(h * 0.12), int(h * 0.83)
    sx, sy = max(2, w // 160), max(2, h // 160)
    row_hits = [0] * (y1 - y0)
    row_total = [0] * (y1 - y0)
    col_hits = [0] * (x1 - x0)
    col_total = [0] * (x1 - x0)
    max_row = max_col = 0.0
    for y in range(y0, y1, sy):
        row = y * w * 4
        for x in range(x0, x1, sx):
            i = row + x * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            is_green = g > 58 and g > r * 1.12 and g > b * 1.04
            yi, xi = y - y0, x - x0
            row_total[yi] += 1
            col_total[xi] += 1
            if is_green:
                row_hits[yi] += 1
                col_hits[xi] += 1
    row_ratio = [row_hits[i] / max(1, row_total[i]) for i in range(len(row_hits))]
    col_ratio = [col_hits[i] / max(1, col_total[i]) for i in range(len(col_hits))]
    max_row = max(row_ratio, default=0.0)
    max_col = max(col_ratio, default=0.0)
    if max_row < 0.055 or max_col < 0.045:
        return None

    def extent(values: list[float], offset: int, stride: int, threshold: float) -> tuple[int, int] | None:
        active = [i for i, value in enumerate(values) if value >= threshold]
        if len(active) < 3:
            return None
        # Use the dominant contiguous band; tolerate a few small holes caused by
        # towers, river effects, shadows, or future decorative overlays.
        runs: list[list[int]] = []
        for index in active:
            if not runs or index - runs[-1][-1] > max(3, int(0.025 * len(values))):
                runs.append([index])
            else:
                runs[-1].append(index)
        run = max(runs, key=len)
        if len(run) < max(3, int(len(values) * 0.12)):
            return None
        return offset + run[0], offset + run[-1] + 1

    rows = extent(row_ratio, y0, sy, max(0.035, max_row * 0.24))
    cols = extent(col_ratio, x0, sx, max(0.030, max_col * 0.24))
    if rows is None or cols is None:
        return None
    left, right = cols
    top, bottom = rows
    if (right - left) < w * 0.48 or (bottom - top) < h * 0.30:
        return None
    return (_clamp(left / w), _clamp(top / h), _clamp(right / w), _clamp(bottom / h))


def _detect_hand_slots(frame: Frame) -> tuple[tuple[float, float, float, float], ...]:
    vertical, x_start, x_end = _edge_profile(frame, "vertical", (0.02, 0.72, 0.98, 0.995))
    x_peaks = _profile_peaks(vertical, x_start, x_end, frame.width,
                             minimum_gap=0.012, percentile=0.20,
                             threshold_floor=7.0, mean_multiplier=0.40)
    columns = _regular_edge_pairs(
        x_peaks, min_width=0.065, max_width=0.205,
        min_spacing=0.14, max_spacing=0.29, min_count=3,
    )
    if len(columns) < 3:
        return ()
    horizontal, y_start, y_end = _edge_profile(frame, "horizontal", (0.02, 0.72, 0.98, 0.995))
    y_peaks = _profile_peaks(horizontal, y_start, y_end, frame.height,
                             minimum_gap=0.012, percentile=0.20,
                             threshold_floor=7.0, mean_multiplier=0.40)
    y_pairs = []
    for index, (top, top_strength) in enumerate(y_peaks):
        for bottom, bottom_strength in y_peaks[index + 1:]:
            height = bottom - top
            if 0.07 <= height <= 0.23 and top >= 0.80 and bottom >= 0.90:
                y_pairs.append((top, bottom, min(top_strength, bottom_strength)))
    if not y_pairs:
        return ()
    # If the purple elixir bar sits very close to the card tops, its lower edge
    # can be stronger than the actual hand boundary. Prefer the lower (card-top)
    # candidate among otherwise valid hand-height pairs.
    top, bottom, _strength = max(y_pairs, key=lambda item: (item[0], item[2], item[1] - item[0]))
    slots = []
    for left, right in columns[:4]:
        slots.append((
            _clamp(left - 0.008), _clamp(top - 0.008),
            _clamp(right + 0.008), _clamp(bottom + 0.008),
        ))
    if len(slots) != 4:
        return ()
    return tuple(slots)


def detect_ui_evidence(frame: Frame, *,
                       gold_components: tuple[tuple[float, float, float, float, float], ...] | list = (),
                       green_ratio: float = 0.0,
                       battle_hint: bool = False) -> AdaptiveUIEvidence:
    """Detect reusable UI geometry for this frame without external models."""
    # The saturated green arena is a high-confidence battle anchor. In this
    # common case the expensive menu-grid probes are unnecessary; only locate
    # the arena, hand, and elixir strip.
    if battle_hint and green_ratio > 0.30:
        arena = _arena_bounds(frame)
        hand_slots = _detect_hand_slots(frame)
        elixir_bounds = None
        if len(hand_slots) == 4:
            left = min(item[0] for item in hand_slots)
            right = max(item[2] for item in hand_slots)
            hand_top = min(item[1] for item in hand_slots)
            bar_margin = (right - left) * 0.035
            elixir_bounds = (
                _clamp(left + bar_margin), _clamp(hand_top - 0.048),
                _clamp(right - bar_margin), _clamp(hand_top - 0.012),
            )
        return AdaptiveUIEvidence(
            arena_bounds=arena, hand_slots=hand_slots, elixir_bounds=elixir_bounds,
        )

    vertical, x_start, x_end = _edge_profile(frame, "vertical", (0.01, 0.10, 0.99, 0.88))
    horizontal, y_start, y_end = _edge_profile(frame, "horizontal", (0.01, 0.10, 0.99, 0.92))
    x_peaks = _profile_peaks(vertical, x_start, x_end, frame.width,
                             minimum_gap=0.012, percentile=0.84)
    y_peaks = _profile_peaks(horizontal, y_start, y_end, frame.height,
                             minimum_gap=0.012, percentile=0.86)
    columns = _regular_edge_pairs(
        x_peaks, min_width=0.14, max_width=0.27,
        min_spacing=0.17, max_spacing=0.29, min_count=3,
    )
    rows = _longest_regular_peak_sequence(
        y_peaks, min_gap=0.12, max_gap=0.25, minimum_count=3,
    )
    card_grid_confidence = 0.0
    widths = [right - left for left, right in columns]
    starts = [left for left, _right in columns]
    width_spread = (max(widths) - min(widths)) if widths else 1.0
    spacings = [starts[index + 1] - starts[index] for index in range(len(starts) - 1)]
    spacing_spread = (max(spacings) - min(spacings)) if spacings else 1.0
    if (len(columns) >= 3 and len(rows) >= 3 and green_ratio < 0.14
            and width_spread <= 0.065 and spacing_spread <= 0.075):
        card_grid_confidence = _clamp(0.50 + 0.10 * min(4, len(columns))
                                      + 0.07 * min(4, len(rows)))
    nav_confidence = _bottom_navigation(frame)

    # Four-column collection grids have stable geometric repetition even when
    # every card illustration and every frame color is replaced by an update.
    mode_centers: tuple[float, ...] = ()
    left_panel_edge = any(x <= 0.08 for x, _value in x_peaks)
    right_panel_edge = any(x >= 0.92 for x, _value in x_peaks)
    if (card_grid_confidence < 0.55 and nav_confidence < 0.45 and len(rows) >= 4
            and left_panel_edge and right_panel_edge):
        # The first detected horizontal edge can be the bottom of the top
        # navigation/header strip, not the first mode card. Ignore intervals
        # that begin too high and select the first actual panel-sized interval.
        panel_centers = [
            (rows[index] + rows[index + 1]) / 2.0
            for index in range(len(rows) - 1)
            if rows[index] >= 0.24 and 0.10 <= rows[index + 1] - rows[index] <= 0.24
        ]
        if panel_centers:
            mode_centers = (panel_centers[0], _clamp((rows[-1] + 0.985) / 2.0))

    ladder_lock_confidence = (
        _detect_ladder_lock_marker(frame, mode_centers[1])
        if len(mode_centers) >= 2 else 0.0
    )

    home_cta = None
    for component in gold_components:
        cx, cy, bw, bh, confidence = component
        if (0.34 <= cx <= 0.66 and 0.70 <= cy <= 0.91 and
                0.25 <= bw <= 0.62 and 0.025 <= bh <= 0.18 and confidence >= 0.72):
            home_cta = component
            break

    loading_confidence = 0.0
    if (nav_confidence < 0.42 and card_grid_confidence < 0.55 and not mode_centers
            and home_cta is None):
        bottom_profile, bottom_start, bottom_end = _edge_profile(
            frame, "horizontal", (0.05, 0.945, 0.95, 0.999),
        )
        bottom_peaks = _profile_peaks(bottom_profile, bottom_start, bottom_end,
                                      frame.height, minimum_gap=0.006, percentile=0.72)
        bottom_progress_strength = max((value for _, value in bottom_peaks), default=0.0)
        mean_luma = _mean_luminance(frame)
        if bottom_progress_strength >= 27.0 and mean_luma > 55.0:
            loading_confidence = _clamp(0.62 + (bottom_progress_strength - 27.0) / 100.0)
        elif mean_luma < 30.0:
            # A near-black startup/logo frame is loading only when it contains
            # a coherent central mark; a truly blank capture remains UNKNOWN.
            center_vertical, a, b = _edge_profile(frame, "vertical", (0.18, 0.25, 0.82, 0.75))
            center_edges = sum(center_vertical[a:b]) / max(1, b - a)
            if center_edges > 1.0:
                loading_confidence = _clamp(0.62 + (center_edges - 1.0) / 30.0)

    arena = _arena_bounds(frame) if battle_hint else None
    hand_slots: tuple[tuple[float, float, float, float], ...] = ()
    elixir_bounds = None
    if battle_hint and card_grid_confidence < 0.55:
        hand_slots = _detect_hand_slots(frame)
        if len(hand_slots) == 4:
            left = min(item[0] for item in hand_slots)
            right = max(item[2] for item in hand_slots)
            hand_top = min(item[1] for item in hand_slots)
            bar_margin = (right - left) * 0.035
            elixir_bounds = (
                _clamp(left + bar_margin), _clamp(hand_top - 0.048),
                _clamp(right - bar_margin), _clamp(hand_top - 0.012),
            )

    return AdaptiveUIEvidence(
        card_grid_confidence=card_grid_confidence,
        card_grid_columns=columns,
        card_grid_rows=rows,
        bottom_nav_confidence=nav_confidence,
        mode_panel_centers=mode_centers,
        ladder_lock_confidence=ladder_lock_confidence,
        home_cta=home_cta,
        loading_confidence=loading_confidence,
        arena_bounds=arena,
        hand_slots=hand_slots,
        elixir_bounds=elixir_bounds,
    )
