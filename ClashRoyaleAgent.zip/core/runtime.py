"""Centralized host compatibility checks for every application entry point."""
from __future__ import annotations

import os
import platform
import struct
import sys
from typing import Iterable


MIN_PYTHON = (3, 10)
MIN_WINDOWS_BUILD = 22_000


def runtime_support_error(
    *,
    python_version: Iterable[int] | None = None,
    pointer_size: int | None = None,
    os_name: str | None = None,
    windows_build: int | None = None,
    machine: str | None = None,
) -> str | None:
    """Return a localized error when the host is outside the supported matrix.

    Keyword overrides make the policy testable on non-Windows CI.  The shipped
    launcher and both UI implementations call this same function so their
    accepted Python versions cannot drift apart again.
    """
    version = tuple(python_version if python_version is not None else sys.version_info[:3])
    if len(version) < 2 or version[:2] < MIN_PYTHON:
        return "需要 64 位 Python 3.10 或更高版本。请安装 Python x64。"

    bits = struct.calcsize("P") if pointer_size is None else int(pointer_size)
    if bits != 8:
        return "检测到 32 位 Python；本程序必须使用 64 位 Python。"

    host_os = os.name if os_name is None else str(os_name)
    if host_os != "nt":
        return "本程序仅支持 Windows 11 x64。"
    architecture = platform.machine() if machine is None else str(machine)
    if architecture.casefold() not in ("amd64", "x86_64"):
        return "本程序仅支持 AMD64/x64 处理器架构。"

    build = windows_build
    if build is None:
        try:
            build = int(sys.getwindowsversion().build)
        except (AttributeError, OSError, TypeError, ValueError):
            build = None
    if build is not None and int(build) < MIN_WINDOWS_BUILD:
        return "本程序需要 Windows 11（内部版本 22000 或更高）。"
    return None
