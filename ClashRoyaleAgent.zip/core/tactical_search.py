"""Bounded multi-turn tactical search with opponent-response scenarios.

The search works only with verified hand cards, observed elixir, local card
roles, and the current opponent-deck posterior. It never invents a card draw or
an opponent elixir value. Future draws are outside the visible-information
horizon, so the search explores up to three distinct cards from the current
four-card hand and explicitly reports its depth/coverage.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import time


@dataclass(frozen=True)
class SearchAction:
    card: int
    lane: int
    features: list[float]
    base_score: float
    card_key: str
    form: str
    level: int | None
    cost: float | None
    roles: tuple[str, ...]


@dataclass(frozen=True)
class SearchResult:
    action: SearchAction
    score: float
    depth: int
    nodes: int
    opponent_branches: int
    elapsed_ms: float
    principal_variation: tuple[tuple[str, int], ...]


@dataclass(frozen=True)
class _Node:
    available: tuple[int, ...]
    elixir: float
    threats: tuple[float, float]
    supports: tuple[float, float]
    elapsed: float
    match_elapsed: float
    score: float
    first: SearchAction
    path: tuple[tuple[str, int], ...]
    last_card: str
    last_lane: int
    depth: int


class TacticalSearch:
    """Small, deterministic beam search; hard node limits protect frame time."""

    MAX_DEPTH = 3
    BEAM_WIDTH = 12
    MAX_NODES = 220
    MAX_SEARCH_MS = 22.0
    ACTION_INTERVAL = 1.35
    DISCOUNT = 0.72

    _SPELL_COUNTERS = {
        "arrows", "zap", "giant-snowball", "fireball", "rocket", "the-log",
        "poison", "lightning", "tornado", "goblin-curse", "void", "vines",
    }
    _TANK_KILLERS = {
        "mini-pekka", "pekka", "inferno-tower", "inferno-dragon", "hunter",
        "sparky", "mighty-miner", "prince", "barbarians", "elite-barbarians",
        "lumberjack", "executioner", "cannon", "tesla",
    }
    _BUILDINGS = {
        "cannon", "mortar", "tesla", "goblin-cage", "goblin-hut", "tombstone",
        "bomb-tower", "inferno-tower", "barbarian-hut", "elixir-collector",
        "x-bow", "goblin-drill", "furnace",
    }
    _AIR_COUNTERS = {
        "musketeer", "archers", "minions", "mega-minion", "inferno-dragon",
        "hunter", "electro-wizard", "firecracker", "archer-queen",
    }

    def __init__(self):
        self.last_result: SearchResult | None = None
        self.calls = 0
        self.last_summary: dict[str, object] = {
            "depth": 0, "nodes": 0, "opponent_branches": 0,
            "elapsed_ms": 0.0, "principal_variation": [],
            "calls": 0, "budget_exhausted": False,
        }

    @staticmethod
    def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
        if not math.isfinite(float(value)):
            return low
        return max(low, min(high, float(value)))

    @staticmethod
    def _finite_cost(value) -> float | None:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            value = float(value)
            if math.isfinite(value) and 0.0 <= value <= 10.0:
                return value
        return None

    def _counter_affordable(self, keys, state, card_database=None) -> bool:
        keys = tuple(keys)
        if not keys:
            return False
        confidence = self._clamp(getattr(state, "opponent_elixir_confidence", 0.0))
        if confidence < 0.55 or card_database is None:
            return True
        upper = self._finite_cost(getattr(state, "opponent_elixir_upper", None))
        if upper is None:
            return True
        # Allow a small regeneration cushion for a response that lands shortly
        # after the current frame. If any candidate is affordable, retain risk.
        available = min(10.0, upper + 0.5)
        for key in keys:
            record = card_database.get(str(key))
            if record is None:
                return True
            if record.elixir_cost is not None:
                minimum_cost = float(record.elixir_cost)
            elif record.elixir_cost_options:
                minimum_cost = min(float(value) for value in record.elixir_cost_options)
            else:
                return True
            if available + 1e-6 >= minimum_cost:
                return True
        return False

    def _counter_risk(self, action: SearchAction, state, card_database=None) -> tuple[float, int]:
        decks = tuple(getattr(state, "opponent_deck_candidates", ()) or ())
        probabilities = tuple(getattr(state, "opponent_deck_candidate_confidences", ()) or ())
        confirmed = set(getattr(state, "opponent_deck_confirmed", ()) or ())
        if not decks and confirmed:
            decks = (tuple(confirmed),)
            probabilities = (1.0,)
        if not decks:
            return 0.0, 0
        confidence = self._clamp(getattr(state, "opponent_deck_confidence", 0.0))
        roles = set(action.roles)
        if not roles:
            return 0.0, len(decks)
        weighted = 0.0
        worst = 0.0
        total_weight = 0.0
        for index, deck in enumerate(decks[:8]):
            deck_keys = set(str(key) for key in deck)
            weight = (float(probabilities[index]) if index < len(probabilities)
                      and self._finite_cost(probabilities[index]) is not None else 0.0)
            if weight <= 0.0:
                weight = 1.0 / min(8, len(decks))
            risk = 0.0
            spell_counters = deck_keys & self._SPELL_COUNTERS
            tank_killers = deck_keys & self._TANK_KILLERS
            buildings = deck_keys & self._BUILDINGS
            if ("swarm" in roles and
                    self._counter_affordable(spell_counters, state, card_database)):
                risk += 0.075
            if ("tank" in roles and
                    self._counter_affordable(tank_killers, state, card_database)):
                risk += 0.095
            if ("win_condition" in roles and
                    self._counter_affordable(buildings, state, card_database)):
                risk += 0.060
            if action.card_key in ("hog-rider", "ram-rider", "battle-ram", "royal-hogs"):
                if self._counter_affordable(deck_keys & self._BUILDINGS, state, card_database):
                    risk += 0.035
            if action.card_key in ("balloon", "lava-hound", "skeleton-barrel"):
                if self._counter_affordable(deck_keys & self._AIR_COUNTERS, state, card_database):
                    risk += 0.045
            weighted += risk * weight
            total_weight += weight
            worst = max(worst, risk)
        expected = weighted / max(1e-6, total_weight)
        # Expected response plus a bounded minimax term. A weak posterior cannot
        # make a speculative counter dominate a directly observed battlefield.
        posterior_factor = 0.20 + 0.80 * confidence
        return min(0.16, (0.68 * expected + 0.32 * worst) * posterior_factor), len(decks)

    def _future_score(self, action: SearchAction, node: _Node, memory=None) -> float:
        lane = action.lane
        urgency = self._clamp(node.threats[lane] - 0.34 * node.supports[lane])
        roles = set(action.roles)
        score = 0.0
        defensive = roles & {"building", "tank_killer", "swarm", "melee", "air_defense"}
        offensive = roles & {"win_condition", "tank", "support", "ranged"}
        if urgency >= 0.14 and defensive:
            score += 0.075 + 0.13 * urgency
        elif offensive:
            score += 0.045 + 0.055 * (1.0 - urgency)
        if "spell" in roles:
            score += 0.025 if urgency >= 0.24 else -0.035
        if "cycle" in roles and node.elixir < 4.5:
            score += 0.025
        cost = action.cost if action.cost is not None else 4.5
        score -= cost * (0.010 + max(0.0, 5.0 - node.elixir) * 0.004)
        if memory is not None and action.card_key and node.last_card:
            score += memory.bonus_from(node.last_card, node.last_lane, action.card_key, lane)
        return max(-0.22, min(0.24, score))

    def _advance(self, node: _Node, action: SearchAction, utility: float,
                 counter_risk: float, *, first: SearchAction | None = None) -> _Node:
        lane = action.lane
        threats = list(node.threats)
        supports = list(node.supports)
        roles = set(action.roles)
        urgency = self._clamp(threats[lane] - 0.34 * supports[lane])
        if roles & {"building", "tank_killer", "swarm", "melee", "air_defense"}:
            reduction = min(0.16, 0.025 + 0.11 * urgency)
            threats[lane] = self._clamp(threats[lane] - reduction)
            supports[lane] = self._clamp(supports[lane] + 0.025)
        if roles & {"win_condition", "tank", "support", "ranged"}:
            supports[lane] = self._clamp(supports[lane] + 0.045)
        if "spell" in roles and threats[lane] > 0.15:
            threats[lane] = self._clamp(threats[lane] - min(0.10, 0.035 + 0.06 * urgency))
        supports[lane] = self._clamp(supports[lane] * (1.0 - min(0.25, counter_risk * 1.6)))

        cost = action.cost if action.cost is not None else 4.5
        now = node.elapsed + self.ACTION_INTERVAL
        # Clash Royale's normal regeneration is approximately one elixir per
        # 2.8 s; the common double-elixir phase is modelled after 120 s. Modes
        # with special elixir rules are intentionally not guessed.
        match_elapsed = node.match_elapsed + self.ACTION_INTERVAL
        double_elixir = match_elapsed >= 120.0
        regen_rate = 1.0 / (1.4 if double_elixir else 2.8)
        elixir = min(10.0, max(0.0, node.elixir - cost) + self.ACTION_INTERVAL * regen_rate)
        path = node.path + ((action.card_key or f"slot-{action.card + 1}", lane),)
        return _Node(
            available=tuple(index for index in node.available if index != action.card),
            elixir=elixir,
            threats=(threats[0], threats[1]),
            supports=(supports[0], supports[1]),
            elapsed=now,
            match_elapsed=match_elapsed,
            score=node.score + (self.DISCOUNT ** node.depth) * (utility - counter_risk),
            first=first or node.first,
            path=path,
            last_card=action.card_key,
            last_lane=action.lane,
            depth=node.depth + 1,
        )

    def choose(self, state, candidates: list[SearchAction], *, card_database,
               tactical_memory=None, elapsed_seconds: float = 0.0,
               time_budget_ms: float | None = None) -> SearchResult | None:
        started = time.perf_counter()
        self.calls += 1
        self.last_result = None
        budget_ms = self.MAX_SEARCH_MS if time_budget_ms is None else max(
            0.0, min(float(self.MAX_SEARCH_MS), float(time_budget_ms))
        )
        self.last_summary = {"depth": 0, "nodes": 0, "opponent_branches": 0,
                             "elapsed_ms": 0.0, "principal_variation": [],
                             "calls": self.calls, "budget_ms": round(budget_ms, 3),
                             "budget_exhausted": False}
        if not candidates:
            return None
        available = tuple(sorted({item.card for item in candidates}))
        by_card_lane = {(item.card, item.lane): item for item in candidates}
        base_actions = tuple(candidates)
        root_nodes: list[_Node] = []
        opponent_branches = 0
        for action in base_actions:
            cost = action.cost
            if cost is None or state.elixir + 0.10 < cost:
                continue
            if tactical_memory is not None and action.card_key:
                sequence_bonus = tactical_memory.bonus(action.card_key, action.lane)
            else:
                sequence_bonus = 0.0
            counter_risk, branches = self._counter_risk(action, state, card_database)
            opponent_branches += branches
            root = _Node(
                available=available,
                elixir=float(state.elixir),
                threats=(float(state.left_threat), float(state.right_threat)),
                supports=(float(state.left_support), float(state.right_support)),
                elapsed=0.0,
                match_elapsed=max(0.0, float(elapsed_seconds)),
                score=0.0,
                first=action,
                path=(),
                last_card="",
                last_lane=action.lane,
                depth=0,
            )
            # Root score is the full current policy score. The search adds only
            # the local sequence bonus and the posterior counter-response risk.
            root_nodes.append(self._advance(
                root, action, action.base_score + sequence_bonus,
                counter_risk, first=action,
            ))
        if not root_nodes:
            self.last_summary["elapsed_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
            self.last_summary["nodes"] = 0
            return None

        # The deadline starts before root evaluation, so candidate scoring and
        # the iterative search share the same caller-supplied overall budget.
        deadline = started + budget_ms / 1000.0
        budget_exhausted = False
        nodes = root_nodes
        best_nodes = list(root_nodes)
        expanded = len(root_nodes)
        completed_depth = 1
        for depth in range(1, self.MAX_DEPTH):
            expanded_nodes: list[_Node] = []
            for node in nodes:
                if expanded >= self.MAX_NODES or time.perf_counter() >= deadline:
                    budget_exhausted = time.perf_counter() >= deadline
                    break
                for card in node.available:
                    if time.perf_counter() >= deadline:
                        budget_exhausted = True
                        break
                    # The root candidate table contains the current visible
                    # hand. Each played slot is removed; unknown replacement
                    # draws are never fabricated.
                    action_template = next((item for item in base_actions if item.card == card), None)
                    if action_template is None:
                        continue
                    cost = action_template.cost
                    if cost is None or node.elixir + 0.05 < cost:
                        continue
                    for lane in (0, 1):
                        if expanded >= self.MAX_NODES or time.perf_counter() >= deadline:
                            budget_exhausted = time.perf_counter() >= deadline
                            break
                        action = by_card_lane.get((card, lane))
                        if action is None:
                            action = SearchAction(
                                card=card, lane=lane, features=action_template.features,
                                base_score=action_template.base_score,
                                card_key=action_template.card_key, form=action_template.form,
                                level=action_template.level, cost=cost,
                                roles=action_template.roles,
                            )
                        utility = self._future_score(action, node, tactical_memory)
                        counter_risk, branches = self._counter_risk(action, state, card_database)
                        opponent_branches += branches
                        expanded_nodes.append(self._advance(
                            node, action, utility, counter_risk, first=node.first,
                        ))
                        expanded += 1
            if not expanded_nodes:
                break
            expanded_nodes.sort(key=lambda item: (
                item.score + 0.014 * item.elixir - 0.055 * max(item.threats),
                item.depth,
            ), reverse=True)
            nodes = expanded_nodes[:self.BEAM_WIDTH]
            best_nodes.extend(nodes)
            completed_depth = depth + 1

        def terminal_value(node: _Node) -> float:
            # Preserve reserve elixir and penalize a lane still under pressure.
            return node.score + 0.012 * node.elixir - 0.045 * max(node.threats)

        winner = max(best_nodes, key=terminal_value)
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        result = SearchResult(
            action=winner.first, score=terminal_value(winner),
            depth=winner.depth, nodes=expanded,
            opponent_branches=opponent_branches,
            elapsed_ms=round(elapsed_ms, 3),
            principal_variation=winner.path,
        )
        self.last_result = result
        self.last_summary = {
            "depth": result.depth,
            "nodes": result.nodes,
            "opponent_branches": result.opponent_branches,
            "elapsed_ms": result.elapsed_ms,
            "budget_ms": round(budget_ms, 3),
            "principal_variation": [
                {"card": card, "lane": "left" if lane == 0 else "right"}
                for card, lane in result.principal_variation
            ],
            "beam_width": self.BEAM_WIDTH,
            "visible_hand_only": True,
            "calls": self.calls,
            "budget_ms": round(budget_ms, 3),
            "budget_exhausted": budget_exhausted,
        }
        return result
