"""Long-running autonomous loop; the configured global key is the only normal stop."""
from __future__ import annotations

import json
import logging
import logging.handlers
import os
import platform
import threading
import time
from collections import Counter, deque
from pathlib import Path
from typing import Callable

from . import APP_VERSION
from .adb import AdbBridge, enrich_state_with_accessibility
from .deck_manager import DeckManager
from .navigation import FlowAction, GameFlow
from .policy import LocalLearner
from .vision import GameState, analyze_frame
from .win32 import (capture_window, click_ratio, focus_window, is_key_down,
                    process_metrics, list_emulator_windows, window_exists, window_is_foreground,
                    window_is_interactive, window_is_valid, window_process_path)


class ClashRoyaleAgent:
    SAVE_INTERVAL_UPDATES = 8

    def __init__(self, hwnd: int, stop_vk: int, stop_key_name: str,
                 workspace: Path, on_stopped: Callable[[dict], None],
                 window_title: str = "", window_class: str = "",
                 selected_process_path: Path | None = None):
        self.hwnd = int(hwnd)
        self.window_title = str(window_title)[:512]
        self.window_class = str(window_class)[:256]
        self.selected_process_path = Path(selected_process_path) if selected_process_path else None
        self.stop_vk = int(stop_vk)
        self.stop_key_name = stop_key_name
        self.workspace = Path(workspace)
        self.on_stopped = on_stopped
        self.stop_event = threading.Event()
        self.started_at = time.monotonic()
        self.match_started_at: float | None = None
        self.last_match_duration = 0.0
        self.action_count = 0
        self.verified_actions = 0
        self.navigation_count = 0
        self.battle_frames = 0
        self.frame_count = 0
        self._battle_active = False
        self.last_error = ""
        self.last_action_at = 0.0
        self.last_profile_save_at = time.monotonic()
        self.last_scene_log_at = 0.0
        self.last_saved_learn_count = 0
        self._fallback_stop_watch = False
        self._fallback_stop_armed = False
        self._stop_watcher: threading.Thread | None = None
        self.scene_counts: Counter[str] = Counter()
        self.stage_counts: Counter[str] = Counter()
        self.capture_ms: deque[float] = deque(maxlen=256)
        self.vision_ms: deque[float] = deque(maxlen=256)
        self.decision_ms: deque[float] = deque(maxlen=256)
        self.policy_ms: deque[float] = deque(maxlen=256)
        self.input_ms: deque[float] = deque(maxlen=256)
        self.cycle_ms: deque[float] = deque(maxlen=256)
        self.processing_seconds = 0.0
        self.card_ms: deque[float] = deque(maxlen=256)
        self.initial_process_metrics = process_metrics()
        self.logger = logging.getLogger(f"ClashRoyaleAgent.{id(self)}")
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False
        self.learner = LocalLearner(self.workspace / "model.json")
        self.deck_manager = DeckManager(
            self.workspace / "card_profiles.json",
            catalog_path=self.workspace / "card_catalog.json",
        )
        # ADB discovery runs on the Agent thread, never on the Tk UI thread.
        self.adb = None
        self.last_accessibility_at = 0.0
        self.last_accessibility_scene = ""
        self.adb_retry_at = 0.0
        self.adb_retry_delay = 2.0
        self.last_window_refresh_at = 0.0
        self.last_decision_log_at = 0.0
        self.last_saved_learn_count = self.learner.learn_count
        self.flow = GameFlow()
        self._setup_logging()

    def _setup_logging(self) -> None:
        self.workspace.mkdir(parents=True, exist_ok=True)
        handler = logging.handlers.RotatingFileHandler(
            self.workspace / "agent.log", maxBytes=420_000, backupCount=1, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        self.logger.addHandler(handler)
        self.logger.info("Agent started. Stop key=%s.", self.stop_key_name)
        self.logger.info("Local learner status=%s, previous updates=%d",
                         self.learner.load_status, self.learner.learn_count)
        self.logger.info("Local card profiles loaded=%d; verified catalog entries=%d; no third-party model is used.",
                         len(self.deck_manager.profiles), len(self.deck_manager.catalog))
        self.logger.info("Input/capture backend discovery pending.")

    def _watch_stop_key(self) -> None:
        # A key held while Start is clicked is not treated as a press. The watcher
        # arms only after it observes the configured key released.
        armed = False
        consecutive_errors = 0
        while not self.stop_event.is_set():
            try:
                down = is_key_down(self.stop_vk)
                consecutive_errors = 0
            except Exception as exc:
                consecutive_errors += 1
                self.last_error = f"Stop-key watcher: {exc}"[:500]
                self.logger.exception("Stop-key polling failed; retrying.")
                if consecutive_errors >= 3:
                    self._fallback_stop_watch = True
                    return
                self.stop_event.wait(0.5)
                continue
            if not down:
                armed = True
            elif armed:
                self.logger.info("Configured stop key pressed (%s).", self.stop_key_name)
                self.stop_event.set()
                return
            self.stop_event.wait(0.020)

    def _fallback_stop_check(self) -> None:
        if self.stop_event.is_set():
            return
        try:
            down = is_key_down(self.stop_vk)
        except Exception as exc:
            self.last_error = f"Fallback stop-key polling: {exc}"[:500]
            return
        if not down:
            self._fallback_stop_armed = True
        elif self._fallback_stop_armed:
            self.logger.info("Configured stop key pressed (%s) via fallback watcher.", self.stop_key_name)
            self.stop_event.set()

    def _wait(self, seconds: float) -> None:
        deadline = time.monotonic() + max(0.0, seconds)
        while not self.stop_event.is_set():
            watcher = self._stop_watcher
            if self._fallback_stop_watch or (watcher is not None and not watcher.is_alive()):
                self._fallback_stop_check()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            self.stop_event.wait(min(0.020, remaining))

    def _refresh_selected_window(self) -> bool:
        """Rebind only to one exact title/class/process match after HWND recreation."""
        if window_exists(self.hwnd):
            return True
        now = time.monotonic()
        if now - self.last_window_refresh_at < 2.0:
            self._wait(0.25)
            return False
        self.last_window_refresh_at = now
        try:
            candidates = list_emulator_windows()
        except Exception as exc:
            self.last_error = f"Window refresh failed: {exc}"[:500]
            self.logger.exception("Could not refresh the selected emulator window.")
            self._wait(0.5)
            return False
        matches = [item for item in candidates
                   if self.window_title and item.title == self.window_title
                   and (not self.window_class or item.class_name == self.window_class)]
        if self.selected_process_path is not None:
            expected = self.selected_process_path.as_posix().casefold()
            matches = [item for item in matches
                       if (path := window_process_path(item.hwnd)) is not None
                       and path.as_posix().casefold() == expected]
        if len(matches) != 1:
            if now - self.last_scene_log_at > 10.0:
                self.logger.warning("Selected emulator window is unavailable; exact rebind matches=%d. No other window will be selected.",
                                    len(matches))
                self.last_scene_log_at = now
            self._wait(0.5)
            return False
        previous = self.hwnd
        self.hwnd = matches[0].hwnd
        self.adb = None
        self.adb_retry_at = 0.0
        self.adb_retry_delay = 2.0
        self.logger.info("Selected emulator window was recreated; rebound exact identity hwnd=%x -> %x.",
                         previous, self.hwnd)
        return True

    def _ensure_adb(self) -> None:
        if self.adb is not None or self.stop_event.is_set():
            return
        now = time.monotonic()
        if now < self.adb_retry_at:
            return
        try:
            bridge = AdbBridge.for_window(self.hwnd, self.stop_event)
        except Exception as exc:
            bridge = None
            self.logger.warning("ADB discovery failed; Win32 remains available when visible: %s", exc)
        if bridge is not None:
            self.adb = bridge
            self.adb_retry_delay = 2.0
            self.adb_retry_at = 0.0
            self.logger.info("ADB backend connected to a verified virtual device (%s).", bridge.serial)
        else:
            self.adb_retry_at = now + self.adb_retry_delay
            self.adb_retry_delay = min(30.0, self.adb_retry_delay * 1.7)

    def _capture_state(self) -> GameState | None:
        if not self._refresh_selected_window():
            return None
        self._ensure_adb()
        frame = None
        capture_elapsed = 0.0
        if self.adb is not None:
            # Prefer fast GDI while the selected window is foreground and fully
            # visible; fall back to device screencap if the desktop surface is
            # temporarily occluded or minimized.
            if window_is_valid(self.hwnd) and window_is_interactive(self.hwnd):
                started = time.perf_counter()
                try:
                    frame = capture_window(self.hwnd)
                except Exception as exc:
                    self.logger.debug("GDI capture unavailable; trying verified ADB screencap: %s", exc)
                capture_elapsed = time.perf_counter() - started
            if frame is None and not self.stop_event.is_set():
                try:
                    started = time.perf_counter()
                    frame = self.adb.capture_frame(stop_event=self.stop_event)
                    capture_elapsed = time.perf_counter() - started
                except Exception as exc:
                    if not self.stop_event.is_set():
                        self.last_error = f"ADB capture failed: {exc}"[:500]
                        self.logger.exception("ADB capture failed; scheduling reconnection.")
                        self.adb = None
                        self.adb_retry_at = time.monotonic() + self.adb_retry_delay
                        self.adb_retry_delay = min(30.0, self.adb_retry_delay * 1.7)

        if frame is None:
            if self.stop_event.is_set():
                return None
            if not window_is_valid(self.hwnd):
                self._wait(0.35)
                return None
            if not window_is_foreground(self.hwnd):
                focus_window(self.hwnd, self.stop_event)
                self._wait(0.12)
                if not window_is_foreground(self.hwnd):
                    return None
            if not window_is_interactive(self.hwnd):
                self.logger.debug("Selected emulator is obscured; waiting without sending input.")
                self._wait(0.30)
                return None
            started = time.perf_counter()
            frame = capture_window(self.hwnd)
            capture_elapsed = time.perf_counter() - started

        self.capture_ms.append(capture_elapsed * 1000.0)

        started = time.perf_counter()
        state = analyze_frame(frame)
        vision_elapsed = time.perf_counter() - started
        self.vision_ms.append(vision_elapsed * 1000.0)
        started = time.perf_counter()
        state = self.deck_manager.observe(state)
        card_elapsed = time.perf_counter() - started
        self.card_ms.append(card_elapsed * 1000.0)

        # Android's built-in UIAutomator can expose real button labels/bounds on
        # some emulators. Poll only on menu/result screens; Unity-rendered UI may
        # expose no nodes, in which case the visual recognizer remains authoritative.
        now = time.monotonic()
        if (self.adb is not None and state.scene.value in
                ("home", "deck", "mode_select", "result", "unknown", "matchmaking", "loading")
                and now - self.last_accessibility_at >= 3.0):
            self.last_accessibility_at = now
            try:
                labels = self.adb.read_ui_labels(stop_event=self.stop_event)
                if labels:
                    state = enrich_state_with_accessibility(
                        state, labels, self.adb.screen_width, self.adb.screen_height
                    )
                    self.last_accessibility_scene = state.scene.value
            except Exception as exc:
                self.logger.debug("UIAutomator semantic enrichment unavailable: %s", exc)

        self.processing_seconds += capture_elapsed + vision_elapsed + card_elapsed
        self.scene_counts[state.scene.value] += 1
        self.frame_count += 1
        return state

    def _click_ratio(self, x: float, y: float) -> bool:
        if self.stop_event.is_set():
            return False
        if self.adb is not None:
            try:
                return self.adb.tap_ratio(x, y, self.stop_event)
            except Exception as exc:
                self.last_error = f"ADB tap failed: {exc}"[:500]
                self.logger.exception("ADB tap failed; this action was not replayed through another backend.")
                self.adb = None
                self.adb_retry_at = time.monotonic() + self.adb_retry_delay
                self.adb_retry_delay = min(30.0, self.adb_retry_delay * 1.7)
                return False
        return click_ratio(self.hwnd, x, y, self.stop_event)


    @staticmethod
    def _reward(before: GameState, after: GameState, lane: int) -> tuple[float, float]:
        """Return a small, quality-gated reward from a same-lane visual change.

        Threat/support are color-area proxies, not unit or tower semantics. They
        are therefore used only for low-weight immediate updates when both
        observations are strong, the selected lane changes materially, and the
        other lane is comparatively stable. Terminal match labels remain the
        primary learning signal.
        """
        if (not before.battle_detected or not after.battle_detected or
                before.frame_width != after.frame_width or
                before.frame_height != after.frame_height):
            return 0.0, 0.0
        quality = min(before.confidence, after.confidence,
                      before.scene_confidence, after.scene_confidence,
                      before.elixir_confidence, after.elixir_confidence)
        if quality < 0.65:
            return 0.0, 0.0

        if lane == 0:
            enemy_delta = before.left_threat - after.left_threat
            support_delta = after.left_support - before.left_support
            other_enemy_delta = before.right_threat - after.right_threat
            other_support_delta = after.right_support - before.right_support
        else:
            enemy_delta = before.right_threat - after.right_threat
            support_delta = after.right_support - before.right_support
            other_enemy_delta = before.left_threat - after.left_threat
            other_support_delta = after.left_support - before.left_support

        signal = abs(enemy_delta) + abs(support_delta)
        other_signal = abs(other_enemy_delta) + abs(other_support_delta)
        if signal < 0.12:
            return 0.0, 0.0
        specificity = signal / (signal + other_signal + 0.05)
        magnitude = min(1.0, signal / 0.35)
        # Confidence is capped at 0.55 so proxy feedback can never outweigh a
        # well-recognized win/loss. The learner applies another 0.45 weight.
        confidence = max(0.0, min(0.55, quality * 0.58 * magnitude * specificity * 0.90))
        reward = max(-1.0, min(1.0, enemy_delta * 0.65 + support_delta * 0.25))
        return reward, confidence

    @staticmethod
    def _deployment_point(state: GameState, card: int, lane: int) -> tuple[float, float]:
        """Choose a conservative role-aware deployment point from verified metadata."""
        roles = set(state.card_roles[card]) if card < len(state.card_roles) else set()
        lane_x = 0.30 if lane == 0 else 0.70
        threat = state.left_threat if lane == 0 else state.right_threat
        lane_enemy_clusters = [item for item in state.enemy_clusters
                               if (item.x < 0.5) == (lane == 0)]
        if "building" in roles:
            # Buildings are more useful near the middle for cross-lane pulling.
            return 0.50, 0.675
        if "spell" in roles:
            # Prefer an observed enemy-colored cluster over a blind lane center.
            if lane_enemy_clusters:
                target = max(lane_enemy_clusters, key=lambda item: item.area * item.confidence)
                return (max(0.12, min(0.88, target.x)),
                        max(0.30, min(0.58, target.y)))
            return lane_x, 0.485 if threat >= 0.18 else 0.535
        if roles & {"tank_killer", "swarm", "air_defense", "melee"} and threat >= 0.12:
            if lane_enemy_clusters:
                target = max(lane_enemy_clusters, key=lambda item: item.y * item.confidence)
                return (max(0.12, min(0.88, target.x)),
                        max(0.60, min(0.78, target.y + 0.075)))
            return lane_x, 0.715
        if "win_condition" in roles:
            return lane_x, 0.625
        if roles & {"tank", "support", "ranged"}:
            return lane_x, 0.655 if threat < 0.18 else 0.695
        if "cycle" in roles:
            return lane_x, 0.685
        return lane_x, 0.635 if threat < 0.25 else 0.695

    def _execute(self, card: int, lane: int, state: GameState) -> bool:
        if self.stop_event.is_set() or not 0 <= card < 4 or lane not in (0, 1):
            return False
        cost = state.card_costs[card] if card < len(state.card_costs) else None
        if cost is not None and state.elixir + 0.10 < cost:
            return False
        if not state.card_ready[card]:
            return False
        if state.card_ready_confidence[card] < 0.62 or state.elixir_confidence < 0.45:
            return False
        card_x = (0.20, 0.40, 0.60, 0.80)[card]
        card_y = 0.915
        deploy_x, deploy_y = self._deployment_point(state, card, lane)
        if not self._click_ratio(card_x, card_y):
            return False
        self._wait(0.10)
        if self.stop_event.is_set():
            return False
        return self._click_ratio(deploy_x, deploy_y)

    @staticmethod
    def _percentile(values: deque[float], percentile: float) -> float:
        if not values:
            return 0.0
        ordered = sorted(values)
        index = min(len(ordered) - 1, max(0, int(round((len(ordered) - 1) * percentile))))
        return round(ordered[index], 2)

    def _save_learner_if_due(self, force: bool = False) -> None:
        delta = self.learner.learn_count - self.last_saved_learn_count
        if force or delta >= self.SAVE_INTERVAL_UPDATES:
            self.learner.save()
            self.last_saved_learn_count = self.learner.learn_count
            self.logger.info("Local model saved at learn_count=%d.", self.last_saved_learn_count)

    def _save_profiles_if_due(self, force: bool = False) -> None:
        now = time.monotonic()
        if force or now - self.last_profile_save_at >= 30.0:
            self.deck_manager.save()
            self.last_profile_save_at = now

    def _save_summary(self) -> dict:
        duration = max(0.0, time.monotonic() - self.started_at)
        processing_fps = self.frame_count / max(0.001, self.processing_seconds)
        loop_fps = self.frame_count / max(0.1, duration)
        current_process_metrics = process_metrics()
        cpu_percent_one_core = None
        cpu_percent_all_cores = None
        if self.initial_process_metrics and current_process_metrics:
            cpu_delta = max(0.0, current_process_metrics["cpu_seconds"] -
                            self.initial_process_metrics["cpu_seconds"])
            cpu_percent_one_core = round(100.0 * cpu_delta / max(0.1, duration), 2)
            cpu_percent_all_cores = round(cpu_percent_one_core / max(1, os.cpu_count() or 1), 2)
        summary = {
            "app_version": APP_VERSION,
            "duration_seconds": round(duration, 1),
            "match_duration_seconds": round(max(0.0, time.monotonic() - self.match_started_at), 1)
            if self.match_started_at is not None else round(self.last_match_duration, 1),
            "frame_count": self.frame_count,
            "loop_fps": round(loop_fps, 2),
            "processing_fps": round(processing_fps, 2),
            "effective_fps": round(loop_fps, 2),  # compatibility alias; now explicitly wall-clock FPS
            "actions": self.action_count,
            "verified_actions": self.verified_actions,
            "navigation_actions": self.navigation_count,
            "battle_frames": self.battle_frames,
            "learn_count": self.learner.learn_count,
            "episode_count": self.learner.episode_count,
            "unlabeled_episodes": self.learner.unlabeled_episodes,
            "recent_recognized_win_rate": round(self.learner.recent_win_rate, 4)
            if self.learner.recent_win_rate is not None else None,
            "result_label_coverage": round(
                self.learner.episode_count / max(1, self.learner.episode_count + self.learner.unlabeled_episodes), 4
            ) if (self.learner.episode_count + self.learner.unlabeled_episodes) else None,
            "wins": self.learner.wins,
            "losses": self.learner.losses,
            "draws": self.learner.draws,
            "mean_reward": round(self.learner.reward_sum / max(1, self.learner.learn_count), 5),
            "recognized_win_rate": round(self.learner.wins / max(1, self.learner.episode_count), 4),
            "input_backend": "adb" if self.adb is not None else "win32",
            "card_profiles": len(self.deck_manager.profiles),
            "catalogued_cards": sum(1 for profile in self.deck_manager.profiles.values()
                                    if self.deck_manager.metadata_for_profile(profile) is not None),
            "stop_key": self.stop_key_name,
            "last_error": self.last_error,
            "scene_counts": dict(self.scene_counts),
            "flow_stages": dict(self.stage_counts),
            "process_usage": {
                "cpu_percent_one_core": cpu_percent_one_core,
                "cpu_percent_all_cores": cpu_percent_all_cores,
                "working_set_mb": round(current_process_metrics["working_set_bytes"] / (1024 * 1024), 2)
                if current_process_metrics else None,
                "commit_charge_mb": round(current_process_metrics["commit_charge_bytes"] / (1024 * 1024), 2)
                if current_process_metrics else None,
            },
            "latency_ms": {
                "capture_p50": self._percentile(self.capture_ms, 0.50),
                "capture_p95": self._percentile(self.capture_ms, 0.95),
                "vision_p50": self._percentile(self.vision_ms, 0.50),
                "vision_p95": self._percentile(self.vision_ms, 0.95),
                "card_profile_p50": self._percentile(self.card_ms, 0.50),
                "card_profile_p95": self._percentile(self.card_ms, 0.95),
                "decision_p50": self._percentile(self.decision_ms, 0.50),
                "decision_p95": self._percentile(self.decision_ms, 0.95),
                "policy_p50": self._percentile(self.policy_ms, 0.50),
                "policy_p95": self._percentile(self.policy_ms, 0.95),
                "input_p50": self._percentile(self.input_ms, 0.50),
                "input_p95": self._percentile(self.input_ms, 0.95),
                "cycle_p50": self._percentile(self.cycle_ms, 0.50),
                "cycle_p95": self._percentile(self.cycle_ms, 0.95),
            },
            "learner_load_status": self.learner.load_status,
            "platform": platform.system() + " " + platform.release(),
        }
        try:
            target = self.workspace / "run_summary.json"
            temp = target.with_suffix(".json.tmp")
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(summary, stream, ensure_ascii=False, indent=2)
                stream.flush()
                os.fsync(stream.fileno())
            temp.replace(target)
        except OSError:
            self.logger.exception("Could not write run summary.")
        return summary

    def _handle_navigation(self, decision: FlowDecision, state: GameState | None = None) -> bool:
        action = decision.action
        target = decision.target
        if target is None or target.confidence < self.flow.MIN_NAV_CONFIDENCE:
            return False
        if self.stop_event.is_set():
            return False
        self.logger.info("Navigation action=%s confidence=%.2f reason=%s",
                         action.value, target.confidence, decision.reason)
        started = time.perf_counter()
        if self._click_ratio(target.x, target.y):
            self.input_ms.append((time.perf_counter() - started) * 1000.0)
            self.navigation_count += 1
            self.flow.mark_action_completed(action)
            if action is FlowAction.CONTINUE_RESULT and self._battle_active:
                # Only explicit result labels train the model. An unlabelled
                # result is counted separately instead of being silently treated
                # as a win/loss or used as a biased sample.
                self.learner.abort_episode(unknown_result=True)
                self._save_learner_if_due(force=True)
                self._battle_active = False
                if self.match_started_at is not None:
                    self.last_match_duration = max(0.0, time.monotonic() - self.match_started_at)
                self.match_started_at = None
            self._wait(0.45)
            return True
        self.input_ms.append((time.perf_counter() - started) * 1000.0)
        return False

    @staticmethod
    def _action_cooldown(state: GameState) -> float:
        pressure = max(state.left_threat, state.right_threat)
        if pressure >= 0.34:
            return 0.58
        if pressure >= 0.18:
            return 0.78
        if state.elixir >= 8.5:
            return 0.90
        return 1.12

    @staticmethod
    def _post_action_wait(state: GameState) -> float:
        return 0.36 if max(state.left_threat, state.right_threat) >= 0.30 else 0.55

    def run(self) -> None:
        watcher: threading.Thread | None = None
        try:
            # Thread construction/startup is also guarded: a resource error here
            # must not strand the hidden UI. The loop retains a polled fallback.
            try:
                watcher = threading.Thread(target=self._watch_stop_key,
                                           name="StopKeyWatcher", daemon=False)
                self._stop_watcher = watcher
                watcher.start()
            except Exception as exc:
                self._fallback_stop_watch = True
                self.last_error = f"Stop-key watcher thread unavailable: {exc}"[:500]
                self.logger.exception("Dedicated stop-key thread unavailable; using in-loop polling.")
            try:
                self.logger.info("Agent loop started; ambiguous screens are never clicked.")
            except Exception as exc:
                self.last_error = f"Startup logging failed: {exc}"[:500]

            # Capture performs ADB discovery and foreground focus as needed.
            # Keeping all initialization inside the recoverable cycle prevents
            # a transient startup error from ending a run before the stop key.
            while not self.stop_event.is_set():
                cycle_started = time.perf_counter()
                try:
                    if (self._fallback_stop_watch or
                            (watcher is not None and not watcher.is_alive())):
                        self._fallback_stop_watch = True
                        self._fallback_stop_check()
                        if self.stop_event.is_set():
                            break
                    state = self._capture_state()
                    if state is None:
                        self._wait(0.08)
                        continue
                    self._save_profiles_if_due()

                    if state.result in ("win", "loss", "draw") and state.result_confidence >= 0.86:
                        completed = self.learner.finish_episode(state.result, state.result_confidence)
                        self._battle_active = False
                        if self.match_started_at is not None:
                            self.last_match_duration = max(0.0, time.monotonic() - self.match_started_at)
                        self.match_started_at = None
                        if completed:
                            self.logger.info("Recognized result=%s; terminal reward applied to %d actions.",
                                             state.result, completed)
                            self._save_learner_if_due(force=True)

                    decision_started = time.perf_counter()
                    # The existing deck is user-owned and remains unchanged.
                    # Only the explicitly requested mode/match navigation runs.
                    flow = self.flow.update(state)
                    decision_elapsed = time.perf_counter() - decision_started
                    self.decision_ms.append(decision_elapsed * 1000.0)
                    self.processing_seconds += decision_elapsed
                    self.stage_counts[flow.stage.value] += 1

                    if flow.action is FlowAction.PLAY:
                        if not self._battle_active:
                            self.learner.begin_episode()
                            self._battle_active = True
                            self.match_started_at = time.monotonic()
                            self.last_action_at = 0.0
                        self.battle_frames += 1
                        if min(state.confidence, state.scene_confidence) < 0.62:
                            self._wait(0.18)
                            continue
                        now = time.monotonic()
                        if now - self.last_action_at < self._action_cooldown(state):
                            self._wait(0.05)
                            continue
                        if state.elixir_confidence < 0.45 or state.elixir < 1.0:
                            self._wait(0.22)
                            continue
                        policy_started = time.perf_counter()
                        elapsed = max(0.0, now - (self.match_started_at or now))
                        choice = self.learner.choose(state, elapsed)
                        policy_elapsed = time.perf_counter() - policy_started
                        self.policy_ms.append(policy_elapsed * 1000.0)
                        self.processing_seconds += policy_elapsed
                        if choice is None:
                            self._wait(0.22)
                            continue
                        card, lane, features = choice
                        if self.stop_event.is_set():
                            break
                        input_started = time.perf_counter()
                        executed = self._execute(card, lane, state)
                        self.input_ms.append((time.perf_counter() - input_started) * 1000.0)
                        if not executed:
                            self._wait(0.12)
                            continue
                        self.action_count += 1
                        self.last_action_at = time.monotonic()
                        if now - self.last_decision_log_at >= 2.0:
                            card_name = state.card_names[card] if card < len(state.card_names) else ""
                            card_roles = state.card_roles[card] if card < len(state.card_roles) else ()
                            self.logger.info(
                                "Decision: card_slot=%d name=%s roles=%s lane=%s elixir=%.1f threats=(%.2f,%.2f) cooldown=%.2fs",
                                card + 1, card_name or "unidentified", ",".join(card_roles) or "unknown",
                                "left" if lane == 0 else "right", state.elixir,
                                state.left_threat, state.right_threat, self._action_cooldown(state),
                            )
                            self.last_decision_log_at = time.monotonic()
                        self._wait(self._post_action_wait(state))
                        if self.stop_event.is_set():
                            break
                        after = self._capture_state()
                        if after is not None and after.battle_detected:
                            elixir_drop = (state.elixir_confidence >= 0.55 and
                                           after.elixir_confidence >= 0.55 and
                                           state.elixir - after.elixir >= 0.35)
                            old_fp = state.card_fingerprints[card]
                            new_fp = after.card_fingerprints[card]
                            card_changed = bool(old_fp and new_fp and old_fp != new_fp)
                            verified = elixir_drop or card_changed
                            if verified:
                                self.verified_actions += 1
                                self.learner.record_action(
                                    card, lane, features,
                                    confidence=min(state.confidence, state.scene_confidence,
                                                   max(0.0, state.elixir_confidence)),
                                )
                                reward, confidence = self._reward(state, after, lane)
                                if confidence >= 0.25:
                                    self.learner.update(card, lane, features, reward, confidence)
                                self._save_learner_if_due()
                                self.logger.info(
                                    "Verified action #%d: card_slot=%d lane=%s elixir=%.1f->%.1f",
                                    self.verified_actions, card + 1,
                                    "left" if lane == 0 else "right", state.elixir, after.elixir,
                                )
                            else:
                                self.logger.warning("Input was sent but game-state change was not verified; sample discarded.")
                        continue

                    if flow.action not in (FlowAction.WAIT, FlowAction.PLAY):
                        self._handle_navigation(flow, state)
                        continue

                    if flow.action is FlowAction.WAIT:
                        now = time.monotonic()
                        if now - self.last_scene_log_at > 15.0:
                            self.logger.info("Waiting safely: scene=%s confidence=%.2f reason=%s",
                                             state.scene.value, state.scene_confidence, flow.reason)
                            self.last_scene_log_at = now
                        self._wait(0.30)
                except Exception as exc:
                    self.last_error = str(exc)[:500]
                    self.logger.exception("Recoverable loop error; Agent remains active.")
                    self._wait(0.55)
                finally:
                    elapsed_cycle = (time.perf_counter() - cycle_started) * 1000.0
                    self.cycle_ms.append(elapsed_cycle)
        finally:
            # Normal operation exits only after the configured stop key. Every
            # cleanup step is isolated so a disk/log/metrics failure cannot
            # prevent the UI restoration callback from being delivered.
            summary: dict = {
                "app_version": APP_VERSION, "actions": self.action_count,
                "verified_actions": self.verified_actions,
                "wins": self.learner.wins, "losses": self.learner.losses,
                "draws": self.learner.draws, "learn_count": self.learner.learn_count,
                "last_error": self.last_error,
            }
            try:
                try:
                    self.learner.abort_episode()
                except Exception:
                    self.logger.exception("Could not close the active learning episode.")
                try:
                    self._save_learner_if_due(force=True)
                except Exception:
                    self.logger.exception("Could not save the local learner state.")
                try:
                    self._save_profiles_if_due(force=True)
                except Exception:
                    self.logger.exception("Could not save local card profiles.")
                self.stop_event.set()
                if watcher is not None and watcher.is_alive():
                    watcher.join(timeout=1.5)
                try:
                    summary = self._save_summary()
                except Exception as exc:
                    self.last_error = f"Summary generation failed: {exc}"[:500]
                    summary["last_error"] = self.last_error
                    self.logger.exception("Could not generate the final run summary.")
                try:
                    self.logger.info("Agent stopped. Summary=%s", summary)
                except Exception:
                    pass
            finally:
                for handler in list(self.logger.handlers):
                    try:
                        handler.flush()
                        handler.close()
                    except Exception:
                        pass
                    self.logger.removeHandler(handler)
                try:
                    self.on_stopped(summary)
                except Exception:
                    pass
