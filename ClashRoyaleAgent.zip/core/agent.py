"""Long-running autonomous loop; the configured global key is the only normal stop."""
from __future__ import annotations

import json
import logging
import logging.handlers
import os
import platform
import threading
import time
from collections import Counter, deque
from pathlib import Path
from typing import Callable

from . import APP_VERSION
from .adb import AdbBridge, enrich_state_with_accessibility
from .cards import CardDatabase
from .card_catalog import CardCatalogScanner
from .deck_manager import DeckManager
from .episode import MatchExitDetector
from .navigation import FlowAction, FlowDecision, FlowStage, GameFlow
from .offline_ocr import OCRSnapshot, OfflineOCR
from .opponent import OpponentCycleTracker
from .policy import LocalLearner
from .planner import plan_deployment
from .tracking import TemporalBattleTracker
from .vision import GameState, Scene, analyze_frame
from .win32 import (capture_window, click_ratio, focus_window, scroll_window,
                    process_metrics, list_game_windows, is_android_emulator_window,
                    watch_global_key, window_is_foreground, window_is_interactive,
                    window_is_valid, window_process_path, window_process_id,
                    window_identity_matches)


class ClashRoyaleAgent:
    SAVE_INTERVAL_UPDATES = 8

    def __init__(self, hwnd: int, stop_vk: int, stop_key_name: str,
                 workspace: Path, on_stopped: Callable[[dict], None],
                 window_title: str = "", window_class: str = "",
                 selected_process_path: Path | None = None,
                 selected_process_id: int | None = None):
        self.hwnd = int(hwnd)
        self.window_title = str(window_title)[:512]
        self.window_class = str(window_class)[:256]
        self.selected_process_path = Path(selected_process_path) if selected_process_path else None
        self.selected_process_id = (int(selected_process_id) if selected_process_id is not None
                                     else window_process_id(self.hwnd))
        self._selected_is_emulator = is_android_emulator_window(
            self.hwnd, self.window_title, self.window_class, self.selected_process_path
        )
        self.stop_vk = int(stop_vk)
        self.stop_key_name = stop_key_name
        self.workspace = Path(workspace)
        self.on_stopped = on_stopped
        self.stop_event = threading.Event()
        self.started_at = time.monotonic()
        self.match_started_at: float | None = None
        self.last_match_duration = 0.0
        self.action_count = 0
        self.hold_count = 0
        self.verified_actions = 0
        self.navigation_count = 0
        self.battle_frames = 0
        self.frame_count = 0
        self._battle_active = False
        self.episode_exit_detector = MatchExitDetector()
        self.last_error = ""
        self.last_action_at = 0.0
        self.last_profile_save_at = time.monotonic()
        self.last_scene_log_at = 0.0
        self.last_saved_learn_count = 0
        self._stop_watcher: threading.Thread | None = None
        self.scene_counts: Counter[str] = Counter()
        self.stage_counts: Counter[str] = Counter()
        self.capture_ms: deque[float] = deque(maxlen=256)
        self.adb_discovery_ms: deque[float] = deque(maxlen=128)
        self.accessibility_ms: deque[float] = deque(maxlen=128)
        self.vision_ms: deque[float] = deque(maxlen=256)
        self.decision_ms: deque[float] = deque(maxlen=256)
        self.policy_ms: deque[float] = deque(maxlen=256)
        self.input_ms: deque[float] = deque(maxlen=256)
        self.cycle_ms: deque[float] = deque(maxlen=256)
        self.processing_seconds = 0.0
        self.card_ms: deque[float] = deque(maxlen=256)
        self.initial_process_metrics = process_metrics()
        self.logger = logging.getLogger(f"ClashRoyaleAgent.{id(self)}")
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False
        self.learner = LocalLearner(self.workspace / "model.json")
        self.card_database = CardDatabase()
        self.ocr = OfflineOCR(self.card_database)
        self._ocr_warmup_thread: threading.Thread | None = None
        self.ocr_ms: deque[float] = deque(maxlen=256)
        self.ocr_calls = 0
        self.ocr_recognized_lines = 0
        self.ocr_recognized_cards = 0
        self.ocr_last_confidence = 0.0
        self.deck_manager = DeckManager(
            self.workspace / "card_profiles.json",
            catalog_path=self.workspace / "card_catalog.json",
            card_database=self.card_database,
            bundled_catalog_path=Path(__file__).resolve().parents[1] / "data" / "card_visual_catalog.json",
        )
        self.card_catalog_scanner = CardCatalogScanner(self.card_database, self.deck_manager)
        self._catalog_scan_attempted = False
        self._catalog_scan_open_requested = False
        self._catalog_scan_home_wait_since: float | None = None
        self._catalog_scan_open_requested_at = 0.0
        self._last_frame = None
        self._last_ocr_snapshot = OCRSnapshot(available=self.ocr.available)
        self._last_ocr_at = 0.0
        # ADB discovery and UIAutomator reads run on bounded daemon workers so
        # subprocess timeouts cannot stall the real-time capture/policy loop.
        self.adb = None
        self._adb_discovery_lock = threading.Lock()
        self._adb_discovery_running = False
        self._adb_discovery_thread: threading.Thread | None = None
        self.last_accessibility_at = 0.0
        self.last_accessibility_scene = ""
        self._accessibility_lock = threading.Lock()
        self._accessibility_thread: threading.Thread | None = None
        self._accessibility_labels = ()
        self._accessibility_size = (0, 0)
        self._accessibility_ready_at = 0.0
        self._accessibility_request_scene = ""
        self.adb_retry_at = 0.0
        self.adb_retry_delay = 2.0
        self.last_window_refresh_at = 0.0
        self.last_decision_log_at = 0.0
        self.last_saved_learn_count = self.learner.learn_count
        self.flow = GameFlow()
        self.tracker = TemporalBattleTracker()
        self.opponent_tracker = OpponentCycleTracker(self.card_database)
        self.tracking_ms: deque[float] = deque(maxlen=256)
        self.stop_monitor_ready = threading.Event()
        self.stop_monitor_error = ""
        self.startup_error = ""
        # Runtime health counters distinguish a safe wait from a stalled I/O
        # path. They are diagnostic only: recovery never issues blind input.
        self.capture_miss_streak = 0
        self.capture_miss_total = 0
        self.max_capture_miss_streak = 0
        self.recovery_count = 0
        self.last_recovery_at = 0.0
        self.last_successful_frame_at = self.started_at
        self.unknown_scene_since: float | None = None
        self.last_health_log_at = 0.0
        self._setup_logging()

    def _setup_logging(self) -> None:
        self.workspace.mkdir(parents=True, exist_ok=True)
        handler = logging.handlers.RotatingFileHandler(
            self.workspace / "agent.log", maxBytes=420_000, backupCount=1, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        self.logger.addHandler(handler)
        self.logger.info("Agent started. Stop key=%s.", self.stop_key_name)
        self.logger.info("Local learner status=%s, previous updates=%d",
                         self.learner.load_status, self.learner.learn_count)
        self.logger.info(
            "Bundled card database=%d cards (evolutions=%d, heroes=%d, champions=%d); "
            "local profiles=%d; verified visual catalog entries=%d; no third-party AI model is used.",
            len(self.card_database), self.card_database.evolution_count,
            self.card_database.hero_count, self.card_database.champion_count,
            len(self.deck_manager.profiles), len(self.deck_manager.catalog),
        )
        self.logger.info(
            "Offline OCR backend=%s; templates are generated in memory from installed Windows fonts.",
            "GDI-template" if self.ocr.available else "unavailable on this host",
        )
        self.logger.info("Input/capture backend discovery pending; direct Win32 capture/input is primary.")
        self.logger.info(
            "Card visual catalog coverage=%d/%d; bundled image references=%d; "
            "runtime OCR samples=%d. Collection-page scanning is skipped when the "
            "packaged catalog already covers every card.",
            self.card_catalog_scanner.coverage, self.card_catalog_scanner.expected_count,
            self.card_catalog_scanner.bundled_image_count,
            self.card_catalog_scanner.sample_count,
        )

    def _stop_monitor_failed(self, reason: str) -> None:
        """Fail closed if the only user stop path is no longer reliable."""
        if self.stop_event.is_set():
            return
        message = f"停止按键全局监听不可用，Agent 已安全停止：{reason}"[:500]
        self.startup_error = self.startup_error or message
        self.stop_monitor_error = message
        self.last_error = message
        self.logger.error(message)
        self.stop_event.set()

    def _watch_stop_key(self) -> None:
        """Install the event-driven global hook; never downgrade to polling."""
        if self.stop_event.is_set():
            return
        try:
            triggered = watch_global_key(
                self.stop_vk, self.stop_event, ready_event=self.stop_monitor_ready
            )
            if triggered or self.stop_event.is_set():
                self.logger.info("Configured stop key pressed (%s).", self.stop_key_name)
            else:
                raise RuntimeError("global keyboard hook exited before the configured key was pressed")
        except Exception as exc:
            self._stop_monitor_failed(str(exc))
            self.logger.exception("Global stop-key hook failed; autonomous input is disabled.")

    def _wait(self, seconds: float) -> None:
        deadline = time.monotonic() + max(0.0, seconds)
        while not self.stop_event.is_set():
            watcher = self._stop_watcher
            if watcher is not None and not watcher.is_alive():
                self._stop_monitor_failed("监听线程意外退出")
                return
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            self.stop_event.wait(min(0.050, remaining))

    def _update_runtime_health(self, state: GameState | None) -> None:
        """Track stalls and perform bounded, input-free recovery actions."""
        now = time.monotonic()
        if state is None:
            if self.stop_event.is_set():
                return
            self.capture_miss_streak += 1
            self.capture_miss_total += 1
            self.max_capture_miss_streak = max(
                self.max_capture_miss_streak, self.capture_miss_streak
            )
            if self.capture_miss_streak in (5, 20, 60):
                self.logger.warning(
                    "Capture has produced no usable frame for %d consecutive cycles; "
                    "the Agent is waiting without sending input.",
                    self.capture_miss_streak,
                )
            if (self.capture_miss_streak >= 20 and
                    now - self.last_recovery_at >= 20.0):
                self._recover_capture_path(now)
            return

        if self.capture_miss_streak:
            self.logger.info(
                "Capture recovered after %d missed cycles.", self.capture_miss_streak
            )
            self.capture_miss_streak = 0
        self.last_successful_frame_at = now

        if state.scene.value == "unknown":
            if self.unknown_scene_since is None:
                self.unknown_scene_since = now
            elif (now - self.unknown_scene_since >= 45.0 and
                  now - self.last_recovery_at >= 30.0):
                self._recover_ambiguous_scene(now)
        else:
            self.unknown_scene_since = None

    def _close_unlabeled_episode(self, reason: str) -> None:
        """Close a confirmed match boundary without manufacturing an outcome."""
        if not self._battle_active:
            self.episode_exit_detector.reset()
            return
        self.learner.abort_episode(unknown_result=True)
        self._battle_active = False
        if self.match_started_at is not None:
            self.last_match_duration = max(0.0, time.monotonic() - self.match_started_at)
        self.match_started_at = None
        self.episode_exit_detector.reset()
        self.tracker.reset()
        self.opponent_tracker.reset()
        self._save_learner_if_due(force=True)
        self.logger.warning(
            "Match episode closed without a verified win/loss/draw label (%s); "
            "the episode was counted as unlabeled and did not train on an invented result.",
            reason,
        )

    def _recover_capture_path(self, now: float) -> None:
        """Reset stale perception/ADB state without changing game state."""
        if self.stop_event.is_set():
            return
        self.last_recovery_at = now
        self.recovery_count += 1
        self.tracker.reset()
        self.last_accessibility_at = 0.0
        # Keep a healthy ADB bridge across desktop focus/occlusion changes. Only
        # discard it when the exact originally selected window identity is gone.
        if (self.adb is not None and not window_identity_matches(
                    self.hwnd, self.window_title, self.window_class,
                    self.selected_process_path, self.selected_process_id
                )):
            self.adb = None
            with self._accessibility_lock:
                self._accessibility_labels = ()
                self._accessibility_ready_at = 0.0
                self._accessibility_request_scene = ""
            self.adb_retry_at = now
            self.adb_retry_delay = 2.0
        self.logger.warning(
            "Input-free capture recovery #%d completed; ADB remains bound to the "
            "exact selected game-window identity when available.", self.recovery_count
        )

    def _recover_ambiguous_scene(self, now: float) -> None:
        """Refresh semantic evidence after a prolonged unknown-screen period."""
        if self.stop_event.is_set():
            return
        self.last_recovery_at = now
        self.recovery_count += 1
        self.last_accessibility_at = 0.0
        self.tracker.reset()
        self.logger.warning(
            "Scene has remained unknown for at least 45 seconds; refreshed "
            "accessibility/perception state. No navigation click will be guessed."
        )

    def _refresh_selected_window(self) -> bool:
        """Rebind only to the original process and exact selected window identity."""
        if window_identity_matches(
                self.hwnd, self.window_title, self.window_class,
                self.selected_process_path, self.selected_process_id):
            return True
        now = time.monotonic()
        if now - self.last_window_refresh_at < 2.0:
            self._wait(0.25)
            return False
        self.last_window_refresh_at = now
        try:
            candidates = list_game_windows()
        except Exception as exc:
            self.last_error = f"Window refresh failed: {exc}"[:500]
            self.logger.exception("Could not refresh the selected game window.")
            self._wait(0.5)
            return False
        matches = [item for item in candidates
                   if self.window_title and item.title == self.window_title
                   and (not self.window_class or item.class_name == self.window_class)]
        if self.selected_process_id is not None:
            matches = [item for item in matches
                       if window_process_id(item.hwnd) == self.selected_process_id]
        if self.selected_process_path is not None:
            expected = self.selected_process_path.as_posix().casefold()
            matches = [item for item in matches
                       if (path := window_process_path(item.hwnd)) is not None
                       and path.as_posix().casefold() == expected]
        if len(matches) != 1:
            if now - self.last_scene_log_at > 10.0:
                self.logger.warning("Selected game window is unavailable; exact rebind matches=%d. No other window will be selected.",
                                    len(matches))
                self.last_scene_log_at = now
            self._wait(0.5)
            return False
        previous = self.hwnd
        self.hwnd = matches[0].hwnd
        self.adb = None
        self._selected_is_emulator = is_android_emulator_window(
            self.hwnd, self.window_title, self.window_class, self.selected_process_path
        )
        with self._accessibility_lock:
            self._accessibility_labels = ()
            self._accessibility_ready_at = 0.0
            self._accessibility_request_scene = ""
        self.adb_retry_at = 0.0
        self.adb_retry_delay = 2.0
        self.logger.info("Selected game window was recreated; rebound exact identity hwnd=%x -> %x.",
                         previous, self.hwnd)
        return True

    def _ensure_adb(self, reference_frame=None) -> None:
        """Discover a screenshot-matched ADB device without blocking the Agent loop."""
        if self.adb is not None or self.stop_event.is_set() or reference_frame is None:
            return
        now = time.monotonic()
        if now < self.adb_retry_at:
            return
        with self._adb_discovery_lock:
            if self._adb_discovery_running or self.adb is not None or self.stop_event.is_set():
                return
            self._adb_discovery_running = True

        def discover() -> None:
            started = time.perf_counter()
            bridge = None
            try:
                bridge = AdbBridge.for_window(
                    self.hwnd, self.stop_event, state_dir=self.workspace,
                    reference_frame=reference_frame,
                )
            except Exception as exc:
                self.logger.warning("ADB discovery failed; Win32 remains available when visible: %s", exc)
            finally:
                elapsed = time.perf_counter() - started
                self.adb_discovery_ms.append(elapsed * 1000.0)
                self.processing_seconds += elapsed
                identity_ok = bool(
                    bridge is not None and not self.stop_event.is_set() and
                    window_identity_matches(
                        self.hwnd, self.window_title, self.window_class,
                        self.selected_process_path, self.selected_process_id
                    )
                )
                with self._adb_discovery_lock:
                    if identity_ok and not self.stop_event.is_set():
                        self.adb = bridge
                        self.adb_retry_delay = 2.0
                        self.adb_retry_at = 0.0
                    elif not self.stop_event.is_set():
                        self.adb_retry_at = time.monotonic() + self.adb_retry_delay
                        self.adb_retry_delay = min(30.0, self.adb_retry_delay * 1.7)
                    self._adb_discovery_running = False
                if identity_ok and not self.stop_event.is_set():
                    self.logger.info("ADB backend connected to a screenshot-verified virtual device (%s).",
                                     bridge.serial)

        try:
            worker = threading.Thread(target=discover, name="AdbDiscovery", daemon=True)
            self._adb_discovery_thread = worker
            worker.start()
        except Exception as exc:
            with self._adb_discovery_lock:
                self._adb_discovery_running = False
            self.adb_retry_at = now + self.adb_retry_delay
            self.adb_retry_delay = min(30.0, self.adb_retry_delay * 1.7)
            self.logger.warning("Could not start asynchronous ADB discovery: %s", exc)

    def _request_accessibility(self, scene: Scene) -> None:
        """Poll UIAutomator asynchronously and cache only fresh in-memory labels."""
        bridge = self.adb
        if bridge is None or self.stop_event.is_set():
            return
        now = time.monotonic()
        if now - self.last_accessibility_at < 3.0:
            return
        worker = self._accessibility_thread
        if worker is not None and worker.is_alive():
            return
        self.last_accessibility_at = now
        request_scene = scene.value

        def read_labels() -> None:
            started = time.perf_counter()
            labels = ()
            try:
                labels = tuple(bridge.read_ui_labels(stop_event=self.stop_event))
            except Exception as exc:
                self.logger.debug("UIAutomator semantic enrichment unavailable: %s", exc)
            finally:
                elapsed = time.perf_counter() - started
                self.accessibility_ms.append(elapsed * 1000.0)
                self.processing_seconds += elapsed
                with self._accessibility_lock:
                    if bridge is self.adb and not self.stop_event.is_set():
                        self._accessibility_labels = labels
                        self._accessibility_size = (bridge.screen_width, bridge.screen_height)
                        self._accessibility_ready_at = time.monotonic()
                        self._accessibility_request_scene = request_scene

        try:
            worker = threading.Thread(target=read_labels, name="UiAutomatorReader", daemon=True)
            self._accessibility_thread = worker
            worker.start()
        except Exception as exc:
            self.logger.debug("Could not start asynchronous UIAutomator reader: %s", exc)

    def _apply_cached_accessibility(self, state: GameState) -> GameState:
        with self._accessibility_lock:
            labels = self._accessibility_labels
            width, height = self._accessibility_size
            ready_at = self._accessibility_ready_at
            request_scene = self._accessibility_request_scene
        if (not labels or width <= 0 or height <= 0 or
                time.monotonic() - ready_at > 4.5 or
                request_scene != state.scene.value):
            return state
        enriched = enrich_state_with_accessibility(state, list(labels), width, height)
        if enriched.scene is not state.scene:
            self.last_accessibility_scene = enriched.scene.value
        return enriched

    def _capture_state(self) -> GameState | None:
        if not self._refresh_selected_window():
            return None
        frame = None
        capture_elapsed = 0.0
        # ADB is not trusted merely because it reports one virtual device. Its
        # screenshot must first match the selected visible window frame.
        # Reuse that GDI frame for this cycle to avoid a duplicate capture.
        if window_is_valid(self.hwnd):
            started = time.perf_counter()
            try:
                # capture_window performs the occlusion check itself.  Avoid a
                # second 5x5 WindowFromPoint scan in the hot path.
                frame = capture_window(self.hwnd)
            except Exception as exc:
                self.logger.debug("GDI capture unavailable: %s", exc)
            capture_elapsed += time.perf_counter() - started
        if (frame is not None and self.adb is None and self._selected_is_emulator
                and not self.stop_event.is_set()):
            self._ensure_adb(frame)
        if frame is None and self.adb is not None and not self.stop_event.is_set():
            # Once ADB has been bound by a screenshot match to this exact
            # emulator process, it is an optional background capture path.
            # Foreground/occlusion checks apply only to desktop mouse input.
            started = time.perf_counter()
            frame = self._capture_bound_adb_frame()
            capture_elapsed += time.perf_counter() - started

        if frame is None:
            if self.stop_event.is_set():
                return None
            if not window_is_valid(self.hwnd):
                self._wait(0.35)
                return None
            if not window_is_foreground(self.hwnd):
                focus_window(self.hwnd, self.stop_event)
                self._wait(0.12)
                if not window_is_foreground(self.hwnd):
                    return None
            if not window_is_interactive(self.hwnd):
                self.logger.debug("Selected game window is obscured; waiting without sending input.")
                self._wait(0.30)
                return None
            started = time.perf_counter()
            frame = capture_window(self.hwnd)
            capture_elapsed += time.perf_counter() - started

        self.capture_ms.append(capture_elapsed * 1000.0)
        if self.stop_event.is_set():
            return None
        self._last_frame = frame

        started = time.perf_counter()
        state = analyze_frame(frame)
        if self.stop_event.is_set():
            return None
        vision_elapsed = time.perf_counter() - started
        self.vision_ms.append(vision_elapsed * 1000.0)

        # OCR is fully local and confidence-gated. Run it periodically so the
        # template matcher cannot dominate the real-time battle loop.
        ocr_elapsed = 0.0
        ocr_due = (self.frame_count % 2 == 0 if state.scene is not Scene.BATTLE
                   else self.frame_count % 4 == 0)
        if self.ocr.available and self.ocr.ready and ocr_due:
            started = time.perf_counter()
            try:
                snapshot = self.ocr.recognize(frame, self.stop_event)
                if not self.stop_event.is_set():
                    state = self.ocr.enrich_state(state, frame, snapshot)
                    self._last_ocr_snapshot = snapshot
                    self._last_ocr_at = time.monotonic()
                    self.ocr_calls += 1
                    self.ocr_recognized_lines += len(snapshot.lines)
                    self.ocr_recognized_cards += len(snapshot.cards)
                    self.ocr_last_confidence = snapshot.confidence
            except Exception as exc:
                self.logger.debug("Offline OCR skipped this frame: %s", exc)
            ocr_elapsed = time.perf_counter() - started
            self.ocr_ms.append(ocr_elapsed * 1000.0)
        if self.stop_event.is_set():
            return None

        started = time.perf_counter()
        state = self.tracker.update(state)
        state = self.opponent_tracker.observe(state)
        tracking_elapsed = time.perf_counter() - started
        self.tracking_ms.append(tracking_elapsed * 1000.0)
        started = time.perf_counter()
        state = self.deck_manager.observe(state)
        card_elapsed = time.perf_counter() - started
        self.card_ms.append(card_elapsed * 1000.0)
        if self.stop_event.is_set():
            return None

        # UIAutomator can take seconds or be unsupported by a Unity-rendered
        # screen. Poll in the background and apply only fresh labels from the
        # same visually classified scene, so stale text cannot authorize clicks.
        if (not self.stop_event.is_set() and state.scene.value in
                ("home", "deck", "mode_select", "result", "unknown", "matchmaking", "loading", "recovery")):
            self._request_accessibility(state.scene)
            state = self._apply_cached_accessibility(state)

        self.processing_seconds += capture_elapsed + vision_elapsed + tracking_elapsed + card_elapsed + ocr_elapsed
        self.scene_counts[state.scene.value] += 1
        self.frame_count += 1
        return state

    def _capture_bound_adb_frame(self):
        """Capture the already screenshot-verified device without foreground gating."""
        bridge = self.adb
        if bridge is None or self.stop_event.is_set():
            return None
        if not window_identity_matches(
                self.hwnd, self.window_title, self.window_class,
                self.selected_process_path, self.selected_process_id):
            self.logger.warning(
                "ADB capture suppressed because the selected emulator process identity changed."
            )
            self.adb = None
            return None
        try:
            return bridge.capture_frame(stop_event=self.stop_event)
        except Exception as exc:
            if not self.stop_event.is_set():
                self.last_error = f"ADB capture failed: {exc}"[:500]
                self.logger.exception("ADB capture failed; scheduling reconnection.")
                self.adb = None
                self.adb_retry_at = time.monotonic() + self.adb_retry_delay
                self.adb_retry_delay = min(30.0, self.adb_retry_delay * 1.7)
            return None

    def _click_ratio(self, x: float, y: float, *, state: GameState | None = None,
                     screen_space: bool = False) -> bool:
        if self.stop_event.is_set():
            return False
        if state is not None and not screen_space:
            left, top, right, bottom = state.viewport
            x = left + x * (right - left)
            y = top + y * (bottom - top)
        if self.adb is not None:
            # ADB input is intentionally allowed while a verified emulator is behind
            # another desktop window. The exact original process/window identity
            # remains mandatory, so a stale or recreated window cannot receive taps.
            if not window_identity_matches(
                    self.hwnd, self.window_title, self.window_class,
                    self.selected_process_path, self.selected_process_id):
                self.logger.warning("ADB input suppressed because the selected emulator process identity changed.")
                self.adb = None
                return False
            try:
                return self.adb.tap_ratio(x, y, self.stop_event)
            except Exception as exc:
                self.last_error = f"ADB tap failed: {exc}"[:500]
                self.logger.exception("ADB tap failed; this action was not replayed through another backend.")
                self.adb = None
                self.adb_retry_at = time.monotonic() + self.adb_retry_delay
                self.adb_retry_delay = min(30.0, self.adb_retry_delay * 1.7)
                return False
        return click_ratio(self.hwnd, x, y, self.stop_event)


    @staticmethod
    def _reward(before: GameState, after: GameState, lane: int) -> tuple[float, float]:
        """Return a small, quality-gated reward from a same-lane visual change.

        Threat/support are color-area proxies, not unit or tower semantics. They
        are therefore used only for low-weight immediate updates when both
        observations are strong, the selected lane changes materially, and the
        other lane is comparatively stable. Terminal match labels remain the
        primary learning signal.
        """
        if (not before.battle_detected or not after.battle_detected or
                before.frame_width != after.frame_width or
                before.frame_height != after.frame_height or
                before.viewport != after.viewport):
            return 0.0, 0.0
        quality = min(before.confidence, after.confidence,
                      before.scene_confidence, after.scene_confidence,
                      before.elixir_confidence, after.elixir_confidence)
        if quality < 0.65:
            return 0.0, 0.0

        if lane == 0:
            enemy_delta = before.left_threat - after.left_threat
            support_delta = after.left_support - before.left_support
            other_enemy_delta = before.right_threat - after.right_threat
            other_support_delta = after.right_support - before.right_support
        else:
            enemy_delta = before.right_threat - after.right_threat
            support_delta = after.right_support - before.right_support
            other_enemy_delta = before.left_threat - after.left_threat
            other_support_delta = after.left_support - before.left_support

        signal = abs(enemy_delta) + abs(support_delta)
        other_signal = abs(other_enemy_delta) + abs(other_support_delta)
        if signal < 0.12:
            return 0.0, 0.0
        specificity = signal / (signal + other_signal + 0.05)
        magnitude = min(1.0, signal / 0.35)
        # Confidence is capped at 0.55 so proxy feedback can never outweigh a
        # well-recognized win/loss. The learner applies another 0.45 weight.
        confidence = max(0.0, min(0.55, quality * 0.58 * magnitude * specificity * 0.90))
        reward = max(-1.0, min(1.0, enemy_delta * 0.65 + support_delta * 0.25))
        return reward, confidence

    @staticmethod
    def _deployment_point(state: GameState, card: int, lane: int) -> tuple[float, float]:
        """Return the best role-aware placement found by the local grid planner."""
        plan = plan_deployment(state, card, lane)
        return plan.x, plan.y

    @staticmethod
    def _card_selection_confirmed(before: GameState, after: GameState, card: int) -> bool:
        """Require a slot-local visual change before sending a deployment tap.

        The comparison is deliberately relative to the other three hand slots,
        so global animation/lighting changes are not mistaken for a selection.
        It does not infer a card name or semantic role.
        """
        if (not 0 <= card < 4 or not after.battle_detected or
                after.scene_confidence < 0.55 or
                before.frame_width != after.frame_width or
                before.frame_height != after.frame_height or
                before.viewport != after.viewport or
                before.elixir - after.elixir > 0.45):
            return False
        if len(before.card_descriptors) < 4 or len(after.card_descriptors) < 4:
            return False
        deltas = []
        for index in range(4):
            left, right = before.card_descriptors[index], after.card_descriptors[index]
            if not left or not right or len(left) != len(right):
                return False
            deltas.append(sum(abs(a - b) for a, b in zip(left, right)) / len(left))
        selected_delta = deltas[card]
        others = sorted(deltas[index] for index in range(4) if index != card)
        baseline = others[1]
        fingerprint_changed = (
            bool(before.card_fingerprints[card]) and
            bool(after.card_fingerprints[card]) and
            before.card_fingerprints[card] != after.card_fingerprints[card]
        )
        return selected_delta >= 0.006 and (
            selected_delta >= baseline * 1.20 or (fingerprint_changed and selected_delta >= 0.004)
        )

    def _execute(self, card: int, lane: int, state: GameState) -> bool:
        if self.stop_event.is_set() or not 0 <= card < 4 or lane not in (0, 1):
            return False
        cost = state.card_costs[card] if card < len(state.card_costs) else None
        if cost is not None and state.elixir + 0.10 < cost:
            return False
        if not state.card_ready[card]:
            return False
        if state.card_ready_confidence[card] < 0.62 or state.elixir_confidence < 0.45:
            return False
        if len(state.card_bounds) >= 4:
            x0, y0, x1, y1 = state.card_bounds[card]
            card_x, card_y = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        else:
            card_x = (0.20, 0.40, 0.60, 0.80)[card]
            card_y = 0.915
        plan = plan_deployment(state, card, lane)
        if "spell" in set(state.card_roles[card]) and plan.confidence < 0.30:
            self.logger.debug("Spell deployment suppressed: %s", plan.reason)
            return False
        deploy_x, deploy_y = plan.x, plan.y
        if not self._click_ratio(card_x, card_y, state=state):
            return False
        self._wait(0.10)
        if self.stop_event.is_set():
            return False
        selected_state = self._capture_state()
        if selected_state is None or not self._card_selection_confirmed(state, selected_state, card):
            self.logger.debug("Card selection was not visually confirmed; deployment tap suppressed.")
            return False
        if self.stop_event.is_set():
            return False
        self.logger.debug("Placement plan: x=%.3f y=%.3f score=%.3f confidence=%.3f reason=%s",
                          plan.x, plan.y, plan.score, plan.confidence, plan.reason)
        return self._click_ratio(deploy_x, deploy_y, state=selected_state)

    @staticmethod
    def _percentile(values: deque[float], percentile: float) -> float:
        if not values:
            return 0.0
        ordered = sorted(values)
        index = min(len(ordered) - 1, max(0, int(round((len(ordered) - 1) * percentile))))
        return round(ordered[index], 2)

    def _save_learner_if_due(self, force: bool = False) -> None:
        delta = self.learner.learn_count - self.last_saved_learn_count
        if force or delta >= self.SAVE_INTERVAL_UPDATES:
            self.learner.save()
            self.last_saved_learn_count = self.learner.learn_count
            self.logger.info("Local model saved at learn_count=%d.", self.last_saved_learn_count)

    def _save_profiles_if_due(self, force: bool = False) -> None:
        now = time.monotonic()
        if force or now - self.last_profile_save_at >= 30.0:
            self.deck_manager.save()
            self.last_profile_save_at = now

    def _save_summary(self) -> dict:
        duration = max(0.0, time.monotonic() - self.started_at)
        processing_fps = self.frame_count / max(0.001, self.processing_seconds)
        loop_fps = self.frame_count / max(0.1, duration)
        current_process_metrics = process_metrics()
        cpu_percent_one_core = None
        cpu_percent_all_cores = None
        if self.initial_process_metrics and current_process_metrics:
            cpu_delta = max(0.0, current_process_metrics["cpu_seconds"] -
                            self.initial_process_metrics["cpu_seconds"])
            cpu_percent_one_core = round(100.0 * cpu_delta / max(0.1, duration), 2)
            cpu_percent_all_cores = round(cpu_percent_one_core / max(1, os.cpu_count() or 1), 2)
        summary = {
            "app_version": APP_VERSION,
            "duration_seconds": round(duration, 1),
            "match_duration_seconds": round(max(0.0, time.monotonic() - self.match_started_at), 1)
            if self.match_started_at is not None else round(self.last_match_duration, 1),
            "frame_count": self.frame_count,
            "loop_fps": round(loop_fps, 2),
            "processing_fps": round(processing_fps, 2),
            "measured_processing_seconds": round(self.processing_seconds, 3),
            "effective_fps": round(loop_fps, 2),  # compatibility alias; now explicitly wall-clock FPS
            "actions": self.action_count,
            "policy_holds": self.hold_count,
            "verified_actions": self.verified_actions,
            "navigation_actions": self.navigation_count,
            "battle_frames": self.battle_frames,
            "learn_count": self.learner.learn_count,
            "episode_count": self.learner.episode_count,
            "unlabeled_episodes": self.learner.unlabeled_episodes,
            "recent_recognized_win_rate": round(self.learner.recent_win_rate, 4)
            if self.learner.recent_win_rate is not None else None,
            "result_label_coverage": round(
                self.learner.episode_count / max(1, self.learner.episode_count + self.learner.unlabeled_episodes), 4
            ) if (self.learner.episode_count + self.learner.unlabeled_episodes) else None,
            "wins": self.learner.wins,
            "losses": self.learner.losses,
            "draws": self.learner.draws,
            "mean_reward": round(self.learner.reward_sum / max(1, self.learner.learn_count), 5),
            "recognized_win_rate": round(self.learner.wins / max(1, self.learner.episode_count), 4),
            "input_backend": "adb" if self.adb is not None else "win32",
            "card_profiles": len(self.deck_manager.profiles),
            "catalogued_cards": sum(1 for profile in self.deck_manager.profiles.values()
                                    if self.deck_manager.metadata_for_profile(profile) is not None),
            "card_adaptation": {
                "unknown_visual_profiles": self.deck_manager.unknown_visual_profiles,
                "runtime_catalog_samples": self.deck_manager.runtime_catalog_samples,
                "new_icons_learned_from_verified_names": True,
                "unknown_cards_remain_semantically_unclassified": True,
            },
            "card_database": {
                "cards": len(self.card_database),
                "evolutions": self.card_database.evolution_count,
                "heroes": self.card_database.hero_count,
                "champions": self.card_database.champion_count,
                "load_error": self.card_database.load_error,
            },
            "offline_ocr": {
                "available": self.ocr.available,
                "ready": self.ocr.ready,
                "template_count": self.ocr.template_count,
                "calls": self.ocr_calls,
                "recognized_lines": self.ocr_recognized_lines,
                "recognized_cards": self.ocr_recognized_cards,
                "last_confidence": round(self.ocr_last_confidence, 4),
                "backend": "windows-gdi-template" if self.ocr.available else "unavailable",
            },
            "opponent_cycle": self.opponent_tracker.summary(),
            "stop_key": self.stop_key_name,
            "stop_monitor": ("failed" if self.stop_monitor_error else
                             "global_hook" if self.stop_monitor_ready.is_set() else "not_ready"),
            "stop_monitor_error": self.stop_monitor_error,
            "stop_monitor_ready": self.stop_monitor_ready.is_set(),
            "capture_miss_total": self.capture_miss_total,
            "max_capture_miss_streak": self.max_capture_miss_streak,
            "recovery_count": self.recovery_count,
            "capture_miss_streak_at_stop": self.capture_miss_streak,
            "seconds_since_last_frame": round(
                max(0.0, time.monotonic() - self.last_successful_frame_at), 2
            ),
            "unknown_scene_seconds": round(
                max(0.0, time.monotonic() - self.unknown_scene_since), 2
            ) if self.unknown_scene_since is not None else 0.0,
            "last_error": self.last_error,
            "scene_counts": dict(self.scene_counts),
            "flow_stages": dict(self.stage_counts),
            "process_usage": {
                "cpu_percent_one_core": cpu_percent_one_core,
                "cpu_percent_all_cores": cpu_percent_all_cores,
                "working_set_mb": round(current_process_metrics["working_set_bytes"] / (1024 * 1024), 2)
                if current_process_metrics else None,
                "commit_charge_mb": round(current_process_metrics["commit_charge_bytes"] / (1024 * 1024), 2)
                if current_process_metrics else None,
            },
            "latency_ms": {
                "capture_p50": self._percentile(self.capture_ms, 0.50),
                "capture_p95": self._percentile(self.capture_ms, 0.95),
                "adb_discovery_p50": self._percentile(self.adb_discovery_ms, 0.50),
                "adb_discovery_p95": self._percentile(self.adb_discovery_ms, 0.95),
                "accessibility_p50": self._percentile(self.accessibility_ms, 0.50),
                "accessibility_p95": self._percentile(self.accessibility_ms, 0.95),
                "vision_p50": self._percentile(self.vision_ms, 0.50),
                "vision_p95": self._percentile(self.vision_ms, 0.95),
                "ocr_p50": self._percentile(self.ocr_ms, 0.50),
                "ocr_p95": self._percentile(self.ocr_ms, 0.95),
                "tracking_p50": self._percentile(self.tracking_ms, 0.50),
                "tracking_p95": self._percentile(self.tracking_ms, 0.95),
                "card_profile_p50": self._percentile(self.card_ms, 0.50),
                "card_profile_p95": self._percentile(self.card_ms, 0.95),
                "decision_p50": self._percentile(self.decision_ms, 0.50),
                "decision_p95": self._percentile(self.decision_ms, 0.95),
                "policy_p50": self._percentile(self.policy_ms, 0.50),
                "policy_p95": self._percentile(self.policy_ms, 0.95),
                "input_p50": self._percentile(self.input_ms, 0.50),
                "input_p95": self._percentile(self.input_ms, 0.95),
                "cycle_p50": self._percentile(self.cycle_ms, 0.50),
                "cycle_p95": self._percentile(self.cycle_ms, 0.95),
            },
            "learner_load_status": self.learner.load_status,
            "platform": platform.system() + " " + platform.release(),
        }
        try:
            target = self.workspace / "run_summary.json"
            temp = target.with_suffix(".json.tmp")
            with temp.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(summary, stream, ensure_ascii=False, indent=2)
                stream.flush()
                os.fsync(stream.fileno())
            temp.replace(target)
        except OSError:
            self.logger.exception("Could not write run summary.")
        return summary

    def _handle_navigation(self, decision: FlowDecision, state: GameState | None = None) -> bool:
        action = decision.action
        target = decision.target
        if target is None or target.confidence < self.flow.MIN_NAV_CONFIDENCE:
            return False
        if self.stop_event.is_set():
            return False
        self.logger.info("Navigation action=%s confidence=%.2f reason=%s",
                         action.value, target.confidence, decision.reason)
        started = time.perf_counter()
        if self._click_ratio(target.x, target.y, state=state,
                             screen_space=target.screen_space):
            self.input_ms.append((time.perf_counter() - started) * 1000.0)
            self.navigation_count += 1
            self.flow.mark_action_completed(action)
            if action is FlowAction.CONTINUE_RESULT and self._battle_active:
                # Only explicit result labels train the model. An unlabelled
                # result is counted separately instead of being silently treated
                # as a win/loss or used as a biased sample.
                self.learner.abort_episode(unknown_result=True)
                self._save_learner_if_due(force=True)
                self._battle_active = False
                if self.match_started_at is not None:
                    self.last_match_duration = max(0.0, time.monotonic() - self.match_started_at)
                self.match_started_at = None
            self._wait(0.45)
            return True
        self.input_ms.append((time.perf_counter() - started) * 1000.0)
        return False

    @staticmethod
    def _action_cooldown(state: GameState) -> float:
        pressure = max(state.left_threat, state.right_threat)
        if pressure >= 0.34:
            return 0.58
        if pressure >= 0.18:
            return 0.78
        if state.elixir >= 8.5:
            return 0.90
        return 1.12

    @staticmethod
    def _post_action_wait(state: GameState) -> float:
        return 0.36 if max(state.left_threat, state.right_threat) >= 0.30 else 0.55

    def run(self) -> None:
        watcher: threading.Thread | None = None
        try:
            # Thread construction/startup is guarded: a resource error must not
            # strand the hidden UI or allow operation without a reliable stop key.
            try:
                watcher = threading.Thread(target=self._watch_stop_key,
                                           name="StopKeyWatcher", daemon=False)
                self._stop_watcher = watcher
                watcher.start()
            except Exception as exc:
                # Never begin autonomous input without a dedicated stop monitor.
                self.startup_error = f"无法启动停止按键监听线程：{exc}"[:500]
                self.stop_monitor_error = self.startup_error
                self.last_error = self.startup_error
                self.stop_event.set()
                self.logger.exception("Stop-key monitor could not be started; refusing to operate without a reliable stop path.")

            if watcher is not None and not self.stop_event.is_set():
                ready_deadline = time.monotonic() + 10.0
                while (not self.stop_monitor_ready.is_set() and not self.stop_event.is_set()
                       and watcher.is_alive() and time.monotonic() < ready_deadline):
                    self.stop_event.wait(0.01)
                if not self.stop_monitor_ready.is_set() and not self.stop_event.is_set():
                    self.startup_error = "停止按键监听未能在 10 秒内就绪；Agent 未执行任何游戏操作。请松开停止键后重新启动。"
                    self.stop_monitor_error = self.startup_error
                    self.last_error = self.startup_error
                    self.logger.error(self.startup_error)
                    self.stop_event.set()

            if self.ocr.available and not self.stop_event.is_set():
                try:
                    self._ocr_warmup_thread = threading.Thread(
                        target=self.ocr.warmup, args=(self.stop_event,),
                        name="OfflineOCRWarmup", daemon=True,
                    )
                    self._ocr_warmup_thread.start()
                except Exception as exc:
                    self.logger.warning("Could not start offline OCR warmup: %s", exc)
            try:
                self.logger.info("Agent loop started; stop monitor ready=%s; ambiguous screens are never clicked.",
                                 self.stop_monitor_ready.is_set())
            except Exception as exc:
                self.last_error = f"Startup logging failed: {exc}"[:500]

            # Initial ADB discovery uses a visible reference frame; after binding,
            # capture and input can continue through ADB in the background.
            # The global hook must remain alive for the entire autonomous run.
            while not self.stop_event.is_set():
                if watcher is None or not watcher.is_alive():
                    self._stop_monitor_failed("监听线程意外退出")
                    break
                cycle_started = time.perf_counter()
                try:
                    state = self._capture_state()
                    self._update_runtime_health(state)
                    if state is None:
                        self._wait(0.08)
                        continue
                    self._save_profiles_if_due()

                    episode_boundary = self.episode_exit_detector.observe(state)

                    if state.result in ("win", "loss", "draw") and state.result_confidence >= 0.86:
                        was_active = self._battle_active
                        completed = self.learner.finish_episode(state.result, state.result_confidence)
                        self._battle_active = False
                        self.episode_exit_detector.reset()
                        if self.match_started_at is not None:
                            self.last_match_duration = max(0.0, time.monotonic() - self.match_started_at)
                        self.match_started_at = None
                        if was_active:
                            self.logger.info(
                                "Recognized match result=%s; terminal reward applied to %d actions.",
                                state.result, completed,
                            )
                            # Persist result counters even when the match had no
                            # verified card actions and therefore no weight update.
                            self._save_learner_if_due(force=True)
                    elif self._battle_active and episode_boundary:
                        self._close_unlabeled_episode(episode_boundary)

                    # Build the local visual database from the actual game UI.
                    # This is a read-only detour: only the visible card-list scroll
                    # is used; no card is selected and the user's deck is unchanged.
                    if not self._catalog_scan_attempted and self.card_catalog_scanner.should_scan:
                        now_scan = time.monotonic()
                        if state.scene is Scene.HOME:
                            if self._catalog_scan_home_wait_since is None:
                                self._catalog_scan_home_wait_since = now_scan
                            target = state.target("deck_entry")
                            if (target is not None and target.confidence >= self.flow.MIN_NAV_CONFIDENCE
                                    and state.scene_confidence >= 0.78
                                    and not self._catalog_scan_open_requested):
                                scan_decision = FlowDecision(
                                    FlowStage.NAVIGATING, FlowAction.OPEN_DECK_FOR_SCAN,
                                    "open the verified card collection tab for local visual indexing",
                                    self.flow.STABLE_NAV_FRAMES, target,
                                )
                                if self._handle_navigation(scan_decision, state):
                                    self._catalog_scan_open_requested = True
                                    self._catalog_scan_open_requested_at = now_scan
                                    continue
                            if (self._catalog_scan_home_wait_since is not None and
                                    now_scan - self._catalog_scan_home_wait_since > 18.0):
                                self.card_catalog_scanner.mark_skipped(
                                    "no high-confidence card-tab target was exposed by local OCR"
                                )
                                self._catalog_scan_attempted = True
                                self.logger.warning("Card visual catalog scan skipped: no safe card-tab target.")
                            elif (self._catalog_scan_open_requested and
                                  now_scan - self._catalog_scan_open_requested_at > 10.0):
                                self.card_catalog_scanner.mark_skipped(
                                    "card collection tab did not open after the verified navigation tap"
                                )
                                self._catalog_scan_attempted = True
                                self.logger.warning("Card visual catalog scan skipped: collection screen did not open.")
                        elif state.scene is Scene.DECK:
                            snapshot = (self._last_ocr_snapshot
                                        if now_scan - self._last_ocr_at <= 2.5 else None)
                            step = self.card_catalog_scanner.observe(
                                self._last_frame, snapshot, state, now=now_scan
                            )
                            if step.action == "scroll":
                                scrolled = False
                                try:
                                    scrolled = scroll_window(
                                        self.hwnd, 0.50, 0.56, -120, self.stop_event
                                    )
                                except Exception as exc:
                                    self.logger.debug("Card-list scroll skipped: %s", exc)
                                self.card_catalog_scanner.mark_scrolled(scrolled)
                                self.logger.info(
                                    "Card catalog scan page: coverage=%d/%d samples=%d scroll=%s",
                                    step.coverage, step.expected, step.samples, scrolled,
                                )
                                self._wait(0.42)
                                continue
                            if not step.done:
                                self._wait(0.10)
                                continue
                            self._catalog_scan_attempted = True
                            status = self.card_catalog_scanner.status()
                            self.logger.info(
                                "Card catalog scan ended: coverage=%d/%d samples=%d scrolls=%d complete=%s reason=%s",
                                status["coverage"], status["expected"], status["samples"],
                                status["scrolls"], status["complete"], status["reason"],
                            )

                    decision_started = time.perf_counter()
                    # The existing deck is user-owned and remains unchanged.
                    # Only the explicitly requested mode/match navigation runs.
                    flow = self.flow.update(state)
                    decision_elapsed = time.perf_counter() - decision_started
                    self.decision_ms.append(decision_elapsed * 1000.0)
                    self.processing_seconds += decision_elapsed
                    self.stage_counts[flow.stage.value] += 1

                    if flow.action is FlowAction.PLAY:
                        if not self._battle_active:
                            self.learner.begin_episode()
                            self._battle_active = True
                            self.match_started_at = time.monotonic()
                            self.last_action_at = 0.0
                        self.battle_frames += 1
                        if min(state.confidence, state.scene_confidence) < 0.62:
                            self._wait(0.18)
                            continue
                        now = time.monotonic()
                        if now - self.last_action_at < self._action_cooldown(state):
                            self._wait(0.05)
                            continue
                        if state.elixir_confidence < 0.45 or state.elixir < 1.0:
                            self._wait(0.22)
                            continue
                        policy_started = time.perf_counter()
                        elapsed = max(0.0, now - (self.match_started_at or now))
                        choice = self.learner.choose(state, elapsed)
                        policy_elapsed = time.perf_counter() - policy_started
                        self.policy_ms.append(policy_elapsed * 1000.0)
                        self.processing_seconds += policy_elapsed
                        if choice is None:
                            self.hold_count += 1
                            self._wait(0.22)
                            continue
                        card, lane, features = choice
                        if self.stop_event.is_set():
                            break
                        input_started = time.perf_counter()
                        executed = self._execute(card, lane, state)
                        self.input_ms.append((time.perf_counter() - input_started) * 1000.0)
                        if not executed:
                            self._wait(0.12)
                            continue
                        self.action_count += 1
                        self.last_action_at = time.monotonic()
                        if now - self.last_decision_log_at >= 2.0:
                            card_name = state.card_names[card] if card < len(state.card_names) else ""
                            card_roles = state.card_roles[card] if card < len(state.card_roles) else ()
                            self.logger.info(
                                "Decision: card_slot=%d name=%s roles=%s lane=%s elixir=%.1f threats=(%.2f,%.2f) cooldown=%.2fs",
                                card + 1, card_name or "unidentified", ",".join(card_roles) or "unknown",
                                "left" if lane == 0 else "right", state.elixir,
                                state.left_threat, state.right_threat, self._action_cooldown(state),
                            )
                            self.last_decision_log_at = time.monotonic()
                        self._wait(self._post_action_wait(state))
                        if self.stop_event.is_set():
                            break
                        after = self._capture_state()
                        if after is not None and after.battle_detected:
                            elixir_drop = (state.elixir_confidence >= 0.55 and
                                           after.elixir_confidence >= 0.55 and
                                           state.elixir - after.elixir >= 0.35)
                            old_fp = state.card_fingerprints[card]
                            new_fp = after.card_fingerprints[card]
                            card_changed = bool(old_fp and new_fp and old_fp != new_fp)
                            verified = elixir_drop or card_changed
                            if verified:
                                self.verified_actions += 1
                                self.learner.record_action(
                                    card, lane, features,
                                    confidence=min(state.confidence, state.scene_confidence,
                                                   max(0.0, state.elixir_confidence)),
                                )
                                reward, confidence = self._reward(state, after, lane)
                                if confidence >= 0.25:
                                    self.learner.update(card, lane, features, reward, confidence)
                                self._save_learner_if_due()
                                self.logger.info(
                                    "Verified action #%d: card_slot=%d lane=%s elixir=%.1f->%.1f",
                                    self.verified_actions, card + 1,
                                    "left" if lane == 0 else "right", state.elixir, after.elixir,
                                )
                            else:
                                self.logger.warning("Input was sent but game-state change was not verified; sample discarded.")
                        continue

                    if flow.action not in (FlowAction.WAIT, FlowAction.PLAY):
                        self._handle_navigation(flow, state)
                        continue

                    if flow.action is FlowAction.WAIT:
                        now = time.monotonic()
                        if now - self.last_scene_log_at > 15.0:
                            self.logger.info("Waiting safely: scene=%s confidence=%.2f reason=%s",
                                             state.scene.value, state.scene_confidence, flow.reason)
                            self.last_scene_log_at = now
                        self._wait(0.30)
                except Exception as exc:
                    self.last_error = str(exc)[:500]
                    self.logger.exception("Recoverable loop error; Agent remains active.")
                    self._wait(0.55)
                finally:
                    elapsed_cycle = (time.perf_counter() - cycle_started) * 1000.0
                    self.cycle_ms.append(elapsed_cycle)
        finally:
            # Normal operation exits only after the configured stop key. Every
            # cleanup step is isolated so a disk/log/metrics failure cannot
            # prevent the UI restoration callback from being delivered.
            summary: dict = {
                "app_version": APP_VERSION, "actions": self.action_count,
                "policy_holds": self.hold_count,
                "verified_actions": self.verified_actions,
                "wins": self.learner.wins, "losses": self.learner.losses,
                "draws": self.learner.draws, "learn_count": self.learner.learn_count,
                "last_error": self.last_error,
                "card_visual_catalog": self.card_catalog_scanner.status(),
                "capture_mode": "adb+win32" if self.adb is not None else "win32_direct",
                "selected_window_is_emulator": self._selected_is_emulator,
            }
            try:
                try:
                    self.learner.abort_episode()
                except Exception:
                    self.logger.exception("Could not close the active learning episode.")
                try:
                    self._save_learner_if_due(force=True)
                except Exception:
                    self.logger.exception("Could not save the local learner state.")
                try:
                    self._save_profiles_if_due(force=True)
                except Exception:
                    self.logger.exception("Could not save local card profiles.")
                self.stop_event.set()
                if watcher is not None and watcher.is_alive():
                    watcher.join(timeout=1.5)
                try:
                    summary = self._save_summary()
                except Exception as exc:
                    self.last_error = f"Summary generation failed: {exc}"[:500]
                    summary["last_error"] = self.last_error
                    self.logger.exception("Could not generate the final run summary.")
                try:
                    self.logger.info("Agent stopped. Summary=%s", summary)
                except Exception:
                    pass
            finally:
                for handler in list(self.logger.handlers):
                    try:
                        handler.flush()
                        handler.close()
                    except Exception:
                        pass
                    self.logger.removeHandler(handler)
                try:
                    self.on_stopped(summary)
                except Exception:
                    pass
