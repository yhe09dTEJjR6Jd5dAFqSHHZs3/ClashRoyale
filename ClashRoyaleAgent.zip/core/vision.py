"""Model-free, conservative screen perception for Clash Royale.

The implementation deliberately separates measurable visual signals from semantic
claims.  It can estimate battle geometry, card-slot appearance, and a few coarse
scene signatures.  Card names, account unlocks, and result labels are only emitted
when an explicit high-confidence signal exists; otherwise they remain unknown.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, replace
from enum import Enum
from math import isfinite

from .cards import CardRecognition
from .win32 import Frame


class Scene(str, Enum):
    UNKNOWN = "unknown"
    BATTLE = "battle"
    HOME = "home"
    DECK = "deck"
    RESULT = "result"
    MATCHMAKING = "matchmaking"
    MODE_SELECT = "mode_select"
    LOADING = "loading"
    RECOVERY = "recovery"


@dataclass(frozen=True)
class NavigationTarget:
    name: str
    x: float
    y: float
    confidence: float
    # Accessibility coordinates are already normalized to the full Android
    # display. Pure visual coordinates are relative to the detected viewport.
    screen_space: bool = False


@dataclass(frozen=True)
class VisualCluster:
    """A color-segmented visual blob; it is not a semantic unit identity."""
    x: float
    y: float
    width: float
    height: float
    area: float
    confidence: float


@dataclass(frozen=True)
class ClusterTrack:
    """Short-lived motion estimate for a generic visual cluster, not a troop ID."""
    track_id: int
    x: float
    y: float
    vx: float
    vy: float
    width: float
    height: float
    area: float
    confidence: float
    age_seconds: float
    observations: int
    last_seen: float

    @property
    def lane(self) -> int:
        return 0 if self.x < 0.5 else 1


@dataclass(frozen=True)
class GameState:
    battle_detected: bool
    elixir: float
    left_threat: float
    right_threat: float
    left_support: float
    right_support: float
    card_scores: tuple[float, float, float, float]
    green_ratio: float
    red_ratio: float
    blue_ratio: float
    purple_ratio: float
    confidence: float
    scene: Scene = Scene.UNKNOWN
    scene_confidence: float = 0.0
    elixir_confidence: float = 0.0
    card_ready: tuple[bool, bool, bool, bool] = (False, False, False, False)
    ladder_unlocked: bool | None = None
    result: str | None = None
    frame_width: int = 0
    frame_height: int = 0
    card_fingerprints: tuple[str, str, str, str] = ("", "", "", "")
    card_descriptors: tuple[tuple[float, ...], ...] = ()
    card_ready_confidence: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    card_costs: tuple[float | None, float | None, float | None, float | None] = (None, None, None, None)
    result_confidence: float = 0.0
    targets: tuple[NavigationTarget, ...] = ()
    deck_confidence: float = 0.0
    card_names: tuple[str, str, str, str] = ("", "", "", "")
    card_roles: tuple[tuple[str, ...], ...] = ((), (), (), ())
    enemy_clusters: tuple[VisualCluster, ...] = ()
    friendly_clusters: tuple[VisualCluster, ...] = ()
    enemy_tracks: tuple[ClusterTrack, ...] = ()
    friendly_tracks: tuple[ClusterTrack, ...] = ()
    # Normalized content viewport in the original captured frame. This is
    # normally the full frame, but excludes symmetric letterbox/pillarbox bars.
    viewport: tuple[float, float, float, float] = (0.0, 0.0, 1.0, 1.0)
    card_forms: tuple[str, str, str, str] = ("base", "base", "base", "base")
    card_levels: tuple[int | None, int | None, int | None, int | None] = (None, None, None, None)
    card_elite: tuple[bool, bool, bool, bool] = (False, False, False, False)
    recognized_cards: tuple[CardRecognition, ...] = ()
    ocr_text: tuple[str, ...] = ()
    ocr_confidence: float = 0.0
    opponent_cycle_card: str = ""
    opponent_cycle_token: str = ""
    opponent_cycle_confidence: float = 0.0
    opponent_cycle_roles: tuple[str, ...] = ()
    opponent_play_count: int = 0
    opponent_recent_plays: tuple[str, ...] = ()
    opponent_seen_cards: tuple[str, ...] = ()
    opponent_cycle_eta: int | None = None
    opponent_cycle_complete: bool = False

    @property
    def red_total(self) -> float:
        return self.left_threat + self.right_threat

    @property
    def blue_total(self) -> float:
        return self.left_support + self.right_support

    @property
    def has_playable_card(self) -> bool:
        return any(self.card_ready)

    def target(self, name: str) -> NavigationTarget | None:
        for item in self.targets:
            if item.name == name:
                return item
        return None


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    if not isfinite(value):
        return low
    return max(low, min(high, value))


def _edge_bar_length(frame: Frame, axis: str, from_end: bool, *, maximum: float = 0.18) -> int:
    """Measure a strongly uniform near-black outer bar, conservatively.

    A single dark edge is not enough: the caller requires a matching bar at
    the opposite edge before cropping. This avoids treating normal dark game
    artwork or a status panel as a viewport boundary.
    """
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    length = h if axis == "y" else w
    cross = w if axis == "y" else h
    limit = int(length * maximum)
    start = length - 1 if from_end else 0
    direction = -1 if from_end else 1
    samples = range(max(1, int(cross * 0.05)), min(cross, int(cross * 0.95)), 7)
    count = len(samples)
    if count < 8:
        return 0
    run = 0
    for offset in range(limit):
        position = start + direction * offset
        dark_count = 0
        minimum = 255.0
        maximum = 0.0
        for cross_pos in samples:
            x, y = (cross_pos, position) if axis == "y" else (position, cross_pos)
            index = (y * w + x) * 4
            b, g, r = data[index], data[index + 1], data[index + 2]
            value = (b + g + r) / 3.0
            if value <= 18.0:
                dark_count += 1
            if value < minimum:
                minimum = value
            if value > maximum:
                maximum = value
        if dark_count / count >= 0.985 and maximum - minimum <= 20.0:
            run += 1
        else:
            break
    return run


def _detect_viewport(frame: Frame) -> tuple[int, int, int, int]:
    """Return an inner content rect only for paired, near-black outer bars."""
    w, h = frame.width, frame.height
    left = _edge_bar_length(frame, "x", False)
    right = _edge_bar_length(frame, "x", True)
    top = _edge_bar_length(frame, "y", False)
    bottom = _edge_bar_length(frame, "y", True)
    # Require a symmetric pair and a meaningful margin; asymmetrical game UI
    # is deliberately retained rather than guessed to be a letterbox.
    if left >= w * 0.025 and right >= w * 0.025 and abs(left - right) <= w * 0.025:
        left, right = min(left, right), min(left, right)
    else:
        left = right = 0
    if top >= h * 0.025 and bottom >= h * 0.025 and abs(top - bottom) <= h * 0.025:
        top, bottom = min(top, bottom), min(top, bottom)
    else:
        top = bottom = 0
    x0, y0, x1, y1 = left, top, w - right, h - bottom
    if (x1 - x0) * (y1 - y0) < w * h * 0.68:
        return 0, 0, w, h
    return x0, y0, x1, y1


def _crop_frame(frame: Frame, rect: tuple[int, int, int, int]) -> Frame:
    x0, y0, x1, y1 = rect
    if x0 == 0 and y0 == 0 and x1 == frame.width and y1 == frame.height:
        return frame
    width, height = x1 - x0, y1 - y0
    source = memoryview(frame.bgra)
    source_stride = frame.width * 4
    row_bytes = width * 4
    cropped = bytearray(height * row_bytes)
    for row in range(height):
        start = (y0 + row) * source_stride + x0 * 4
        cropped[row * row_bytes:(row + 1) * row_bytes] = source[start:start + row_bytes]
    return Frame(width, height, bytes(cropped), frame.source_hwnd)


def _region_stats(frame: Frame, x0: float, x1: float, y0: float, y1: float,
                  step: int = 4) -> tuple[int, int, int, int, int]:
    """Sample a region using strided BGRA reads."""
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    sx0, sx1 = max(0, int(w * x0)), min(w, max(int(w * x0) + 1, int(w * x1)))
    sy0, sy1 = max(0, int(h * y0)), min(h, max(int(h * y0) + 1, int(h * y1)))
    green = red = blue = purple = total = 0
    for yy in range(sy0, sy1, step):
        row = yy * w * 4
        for xx in range(sx0, sx1, step):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            total += 1
            if g > 58 and g > r * 1.12 and g > b * 1.04:
                green += 1
            if r > 78 and r > g * 1.22 and r > b * 1.18:
                red += 1
            if b > 78 and b > r * 1.14 and b > g * 1.06:
                blue += 1
            if r > 65 and b > 65 and r > g * 1.12 and b > g * 1.12:
                purple += 1
    return green, red, blue, purple, total


def _find_color_clusters(frame: Frame, team: str, step: int = 4) -> tuple[VisualCluster, ...]:
    """Find coarse red/blue arena blobs with bounded 8-neighbour components.

    These are position/count cues only. They are deliberately not labelled as
    troops, buildings, or card identities because spells and visual effects can
    produce similar colors.
    """
    if team not in ("enemy", "friendly"):
        raise ValueError("team must be 'enemy' or 'friendly'.")
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    x0, x1 = max(0, int(w * 0.06)), min(w, int(w * 0.94))
    y0, y1 = max(0, int(h * 0.35)), min(h, int(h * 0.80))
    xs = list(range(x0, x1, step))
    ys = list(range(y0, y1, step))
    grid_w, grid_h = len(xs), len(ys)
    if grid_w < 2 or grid_h < 2:
        return ()
    mask = bytearray(grid_w * grid_h)
    for gy, yy in enumerate(ys):
        row = yy * w * 4
        base = gy * grid_w
        for gx, xx in enumerate(xs):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            if team == "enemy":
                hit = r > 78 and r > g * 1.22 and r > b * 1.18
            else:
                hit = b > 78 and b > r * 1.14 and b > g * 1.06
            if hit:
                mask[base + gx] = 1

    seen = bytearray(len(mask))
    clusters: list[VisualCluster] = []
    for start, active in enumerate(mask):
        if not active or seen[start]:
            continue
        stack = [start]
        seen[start] = 1
        min_x = max_x = start % grid_w
        min_y = max_y = start // grid_w
        count = 0
        while stack:
            index = stack.pop()
            gx, gy = index % grid_w, index // grid_w
            count += 1
            min_x, max_x = min(min_x, gx), max(max_x, gx)
            min_y, max_y = min(min_y, gy), max(max_y, gy)
            for ny in range(max(0, gy - 1), min(grid_h, gy + 2)):
                row_base = ny * grid_w
                for nx in range(max(0, gx - 1), min(grid_w, gx + 2)):
                    neighbor = row_base + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        stack.append(neighbor)
        box_w = (max_x - min_x + 1) * step
        box_h = (max_y - min_y + 1) * step
        box_area = max(1.0, box_w * box_h)
        area_fraction = count * step * step / max(1.0, w * h)
        aspect = box_w / max(1.0, box_h)
        fill = count * step * step / box_area
        if (count < 3 or box_w < w * 0.025 or box_h < h * 0.018 or
                area_fraction > 0.085 or not 0.16 <= aspect <= 5.5 or fill < 0.10):
            continue
        left, right = xs[min_x], min(w, xs[max_x] + step)
        top, bottom = ys[min_y], min(h, ys[max_y] + step)
        confidence = _clamp(0.30 + min(0.35, count / 28.0 * 0.35) + min(0.30, fill * 0.30))
        clusters.append(VisualCluster(
            x=(left + right) / (2.0 * w), y=(top + bottom) / (2.0 * h),
            width=(right - left) / w, height=(bottom - top) / h,
            area=area_fraction, confidence=confidence,
        ))
    clusters.sort(key=lambda item: item.area * item.confidence, reverse=True)
    return tuple(clusters[:32])


def _components_from_mask(frame: Frame, mask: bytearray, xs: list[int], ys: list[int],
                          step: int = 4) -> tuple[VisualCluster, ...]:
    """Extract bounded connected components from a previously computed mask."""
    grid_w, grid_h = len(xs), len(ys)
    if grid_w < 2 or grid_h < 2:
        return ()
    seen = bytearray(len(mask))
    clusters: list[VisualCluster] = []
    for start, active in enumerate(mask):
        if not active or seen[start]:
            continue
        stack = [start]
        seen[start] = 1
        min_x = max_x = start % grid_w
        min_y = max_y = start // grid_w
        count = 0
        while stack:
            index = stack.pop()
            gx, gy = index % grid_w, index // grid_w
            count += 1
            min_x, max_x = min(min_x, gx), max(max_x, gx)
            min_y, max_y = min(min_y, gy), max(max_y, gy)
            for ny in range(max(0, gy - 1), min(grid_h, gy + 2)):
                row_base = ny * grid_w
                for nx in range(max(0, gx - 1), min(grid_w, gx + 2)):
                    neighbor = row_base + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        stack.append(neighbor)
        box_w = (max_x - min_x + 1) * step
        box_h = (max_y - min_y + 1) * step
        box_area = max(1.0, box_w * box_h)
        area_fraction = count * step * step / max(1.0, frame.width * frame.height)
        aspect = box_w / max(1.0, box_h)
        fill = count * step * step / box_area
        if (count < 3 or box_w < frame.width * 0.025 or box_h < frame.height * 0.018 or
                area_fraction > 0.085 or not 0.16 <= aspect <= 5.5 or fill < 0.10):
            continue
        left, right = xs[min_x], min(frame.width, xs[max_x] + step)
        top, bottom = ys[min_y], min(frame.height, ys[max_y] + step)
        confidence = _clamp(0.30 + min(0.35, count / 28.0 * 0.35) + min(0.30, fill * 0.30))
        clusters.append(VisualCluster(
            x=(left + right) / (2.0 * frame.width),
            y=(top + bottom) / (2.0 * frame.height),
            width=(right - left) / frame.width,
            height=(bottom - top) / frame.height,
            area=area_fraction,
            confidence=confidence,
        ))
    clusters.sort(key=lambda item: item.area * item.confidence, reverse=True)
    return tuple(clusters[:32])


def _battle_visuals(frame: Frame, step: int = 4) -> tuple[
        float, float, float, float, tuple[VisualCluster, ...], tuple[VisualCluster, ...]]:
    """Compute both team masks, both lane pressures and clusters in one image pass."""
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    x0, x1 = max(0, int(w * 0.06)), min(w, int(w * 0.94))
    y0, y1 = max(0, int(h * 0.35)), min(h, int(h * 0.80))
    xs, ys = list(range(x0, x1, step)), list(range(y0, y1, step))
    grid_w, grid_h = len(xs), len(ys)
    enemy_mask = bytearray(grid_w * grid_h)
    friendly_mask = bytearray(grid_w * grid_h)
    lane_enemy = [0.0, 0.0]
    lane_friendly = [0.0, 0.0]
    lane_total = [0.0, 0.0]
    lane_y0, lane_y1 = int(h * 0.40), int(h * 0.79)
    for gy, yy in enumerate(ys):
        row = yy * w * 4
        base = gy * grid_w
        in_lane_y = lane_y0 <= yy < lane_y1
        proximity = (0.55 + 0.90 * ((yy - lane_y0) / max(1, lane_y1 - lane_y0))) if in_lane_y else 0.0
        for gx, xx in enumerate(xs):
            index = row + xx * 4
            b, g, r = data[index], data[index + 1], data[index + 2]
            enemy = r > 78 and r > g * 1.22 and r > b * 1.18
            friendly = b > 78 and b > r * 1.14 and b > g * 1.06
            cell = base + gx
            if enemy:
                enemy_mask[cell] = 1
            if friendly:
                friendly_mask[cell] = 1
            if in_lane_y:
                if 0.08 <= xx / w < 0.48:
                    lane = 0
                elif 0.52 <= xx / w < 0.92:
                    lane = 1
                else:
                    lane = -1
            else:
                lane = -1
            if lane >= 0:
                lane_total[lane] += 1.0
                if enemy:
                    lane_enemy[lane] += proximity
                if friendly:
                    lane_friendly[lane] += proximity
    left_threat = _clamp(lane_enemy[0] / max(1.0, lane_total[0]) * 18.0)
    left_support = _clamp(lane_friendly[0] / max(1.0, lane_total[0]) * 18.0)
    right_threat = _clamp(lane_enemy[1] / max(1.0, lane_total[1]) * 18.0)
    right_support = _clamp(lane_friendly[1] / max(1.0, lane_total[1]) * 18.0)
    return (left_threat, right_threat, left_support, right_support,
            _components_from_mask(frame, enemy_mask, xs, ys, step),
            _components_from_mask(frame, friendly_mask, xs, ys, step))


def _card_features(frame: Frame, center_x: float) -> tuple[float, bool, float, str, tuple[float, ...]]:
    """Return visual score, readiness, readiness confidence, dHash, descriptor.

    The fingerprint is a local visual identity token, not a card-name prediction.
    """
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    x0 = max(0, int(w * (center_x - 0.065)))
    x1 = min(w, int(w * (center_x + 0.065)))
    y0, y1 = max(0, int(h * 0.855)), min(h, int(h * 0.975))
    brightness = saturation = contrast = colorful = total = 0.0
    rgb_sum = [0.0, 0.0, 0.0]
    hist = [0.0] * 12
    for yy in range(y0, y1, 3):
        row = yy * w * 4
        for xx in range(x0, x1, 3):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            hi, lo = max(r, g, b), min(r, g, b)
            lum = (0.114 * b + 0.587 * g + 0.299 * r) / 255.0
            sat = (hi - lo) / max(1.0, hi)
            brightness += lum
            saturation += sat
            contrast += (hi - lo) / 255.0
            if hi - lo > 30 and hi > 70:
                colorful += 1.0
            rgb_sum[0] += r / 255.0
            rgb_sum[1] += g / 255.0
            rgb_sum[2] += b / 255.0
            hist[min(3, r // 64)] += 1
            hist[4 + min(3, g // 64)] += 1
            hist[8 + min(3, b // 64)] += 1
            total += 1.0
    if total <= 0:
        return 0.0, False, 0.0, "", ()
    mean_brightness = brightness / total
    mean_saturation = saturation / total
    mean_contrast = contrast / total
    colorful_ratio = colorful / total
    visual_score = _clamp(0.30 * mean_brightness + 0.35 * mean_saturation + 0.20 * mean_contrast + 0.15 * colorful_ratio)
    # A greyed-out card normally loses saturation and contrast.  This remains a
    # readiness estimate; the game is authoritative and the value is verified
    # again after a click.
    readiness_margin = (0.58 * mean_saturation + 0.42 * mean_brightness) - 0.22
    ready = readiness_margin >= 0.025 and mean_brightness >= 0.18
    ready_confidence = _clamp(0.5 + readiness_margin * 2.4)
    if ready_confidence < 0.56:
        ready_confidence = 1.0 - ready_confidence
    descriptor = tuple(round(v / total, 5) for v in hist) + (
        round(mean_brightness, 5), round(mean_saturation, 5),
        round(mean_contrast, 5), round(colorful_ratio, 5),
        *(round(v / total, 5) for v in rgb_sum),
    )

    # 64-bit difference hash from an 9x8 luminance grid in the central card area.
    sample_rows: list[list[float]] = []
    cx0 = x0 + int((x1 - x0) * 0.12)
    cx1 = x1 - int((x1 - x0) * 0.12)
    cy0 = y0 + int((y1 - y0) * 0.12)
    cy1 = y1 - int((y1 - y0) * 0.12)
    for gy in range(8):
        row_values = []
        yy = min(h - 1, cy0 + int((cy1 - cy0 - 1) * gy / 7))
        for gx in range(9):
            xx = min(w - 1, cx0 + int((cx1 - cx0 - 1) * gx / 8))
            i = (yy * w + xx) * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            row_values.append(0.114 * b + 0.587 * g + 0.299 * r)
        sample_rows.append(row_values)
    bits = 0
    bit_index = 0
    for row_values in sample_rows:
        for gx in range(8):
            if row_values[gx] > row_values[gx + 1]:
                bits |= 1 << bit_index
            bit_index += 1
    return visual_score, ready, ready_confidence, f"{bits:016x}", descriptor


def _measure_elixir_bar(frame: Frame) -> tuple[float, float, float]:
    """Estimate elixir from the left-to-right fill length of the purple gauge."""
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    x0, x1 = max(0, int(w * 0.17)), min(w, int(w * 0.83))
    y0, y1 = max(0, int(h * 0.815)), min(h, int(h * 0.855))
    columns: list[float] = []
    hits = total = 0
    for xx in range(x0, x1, 2):
        col_hits = col_total = 0
        for yy in range(y0, y1, 2):
            i = (yy * w + xx) * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            col_total += 1
            if r > 65 and b > 65 and r > g * 1.12 and b > g * 1.12:
                col_hits += 1
        hits += col_hits
        total += col_total
        columns.append(col_hits / max(1, col_total))
    purple_ratio = hits / max(1, total)
    active = [ratio >= 0.38 for ratio in columns]
    try:
        first = active.index(True)
    except ValueError:
        return 0.0, purple_ratio, 0.0
    last = len(active) - 1 - active[::-1].index(True)
    prefix = active[:last + 1]
    active_ratio = sum(prefix) / max(1, len(prefix))
    start_quality = _clamp(1.0 - first / max(1.0, len(active) * 0.10))
    fill_fraction = _clamp((last + 1) / max(1, len(active)))
    strength = sum(columns[first:last + 1]) / max(1, last - first + 1)
    confidence = _clamp(active_ratio * start_quality * ((strength - 0.18) / 0.62))
    if first > len(active) * 0.18:
        confidence *= 0.25
    return fill_fraction * 10.0, purple_ratio, confidence


def _gold_ratio(frame: Frame, x0: float, x1: float, y0: float, y1: float,
                step: int = 3) -> float:
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    ax0, ax1 = max(0, int(w * x0)), min(w, int(w * x1))
    ay0, ay1 = max(0, int(h * y0)), min(h, int(h * y1))
    hits = total = 0
    for yy in range(ay0, ay1, step):
        row = yy * w * 4
        for xx in range(ax0, ax1, step):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            total += 1
            if r > 145 and g > 78 and g < r * 0.92 and b < g * 0.82 and r - g > 28:
                hits += 1
    return hits / max(1, total)


def _bright_saturated_ratio(frame: Frame, x0: float, x1: float, y0: float, y1: float,
                            step: int = 4) -> float:
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    ax0, ax1 = max(0, int(w * x0)), min(w, int(w * x1))
    ay0, ay1 = max(0, int(h * y0)), min(h, int(h * y1))
    hits = total = 0
    for yy in range(ay0, ay1, step):
        row = yy * w * 4
        for xx in range(ax0, ax1, step):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            hi, lo = max(r, g, b), min(r, g, b)
            total += 1
            if hi > 175 and hi - lo > 48:
                hits += 1
    return hits / max(1, total)


def _find_gold_components(frame: Frame, y_min: float = 0.08, y_max: float = 0.985,
                          step: int = 3) -> list[tuple[float, float, float, float, float]]:
    """Find large, compact gold-colored UI components; return normalized boxes."""
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    xs = list(range(0, w, step))
    ys = list(range(max(0, int(h * y_min)), min(h, int(h * y_max)), step))
    if not xs or not ys:
        return []
    width, height = len(xs), len(ys)
    mask = bytearray(width * height)
    for iy, yy in enumerate(ys):
        row = yy * w * 4
        base = iy * width
        for ix, xx in enumerate(xs):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            if r > 145 and g > 78 and g < r * 0.92 and b < g * 0.82 and r - g > 28:
                mask[base + ix] = 1
    seen = bytearray(len(mask))
    components = []
    for start, active in enumerate(mask):
        if not active or seen[start]:
            continue
        queue = deque([start])
        seen[start] = 1
        min_x = max_x = start % width
        min_y = max_y = start // width
        count = 0
        while queue:
            current = queue.popleft()
            ix, iy = current % width, current // width
            count += 1
            min_x, max_x = min(min_x, ix), max(max_x, ix)
            min_y, max_y = min(min_y, iy), max(max_y, iy)
            for nx, ny in ((ix - 1, iy), (ix + 1, iy), (ix, iy - 1), (ix, iy + 1)):
                if 0 <= nx < width and 0 <= ny < height:
                    neighbor = ny * width + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        queue.append(neighbor)
        box_w = (max_x - min_x + 1) * step
        box_h = (max_y - min_y + 1) * step
        area = box_w * box_h
        aspect = box_w / max(1.0, box_h)
        fill = count * step * step / max(1.0, area)
        if box_w < w * 0.18 or box_h < h * 0.025 or area < w * h * 0.004:
            continue
        if not 1.25 <= aspect <= 6.5 or fill < 0.25:
            continue
        left, top = xs[min_x], ys[min_y]
        right = min(w, xs[max_x] + step)
        bottom = min(h, ys[max_y] + step)
        compactness = _clamp(fill)
        area_fraction = area / max(1.0, w * h)
        size_score = _clamp(area_fraction / 0.012)
        confidence = _clamp(0.55 * compactness + 0.45 * size_score)
        components.append(((left + right) / (2 * w), (top + bottom) / (2 * h),
                           (right - left) / w, (bottom - top) / h, confidence))
    components.sort(key=lambda item: item[4], reverse=True)
    return components[:12]


def _grid_colorfulness(frame: Frame) -> tuple[int, float]:
    """Count colorful cells in a coarse 3x3 lower-screen grid."""
    colorful_cells = 0
    values = []
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    for row in range(3):
        y0 = 0.35 + row * 0.19
        y1 = y0 + 0.17
        for col in range(3):
            x0 = 0.08 + col * 0.28
            x1 = x0 + 0.24
            hits = count = 0
            for yy in range(max(0, int(h * y0)), min(h, int(h * y1)), 6):
                row_base = yy * w * 4
                for xx in range(max(0, int(w * x0)), min(w, int(w * x1)), 6):
                    i = row_base + xx * 4
                    b, g, r = data[i], data[i + 1], data[i + 2]
                    hi, lo = max(r, g, b), min(r, g, b)
                    count += 1
                    if hi > 85 and hi - lo > 42:
                        hits += 1
            ratio = hits / max(1, count)
            values.append(ratio)
            if ratio > 0.12 and count > 20:
                colorful_cells += 1
    return colorful_cells, sum(values) / max(1, len(values))


def _classify_scene(frame: Frame, portrait: bool, green_ratio: float,
                    red_ratio: float, blue_ratio: float, purple_ratio: float,
                    card_visual: float) -> tuple[Scene, float, float, str | None, float, tuple[NavigationTarget, ...], bool | None, float]:
    """Classify only coarse scenes; semantic labels stay unset when ambiguous."""
    if not portrait:
        return Scene.UNKNOWN, 0.0, 0.0, None, 0.0, (), None, 0.0

    arena_signal = _clamp((green_ratio - 0.012) / 0.055)
    unit_signal = _clamp((red_ratio + blue_ratio - 0.006) / 0.045)
    card_signal = _clamp((card_visual - 0.10) / 0.42)
    elixir_signal = _clamp((purple_ratio - 0.001) / 0.035)
    battle_score = (0.34 * arena_signal + 0.25 * unit_signal +
                    0.22 * card_signal + 0.19 * elixir_signal)
    if (green_ratio > 0.018 and red_ratio + blue_ratio + green_ratio > 0.075 and
            card_visual > 0.12 and purple_ratio > 0.0015 and battle_score >= 0.54):
        return Scene.BATTLE, _clamp(battle_score), battle_score, None, 0.0, (), None, 0.0

    components = _find_gold_components(frame)
    home_gold = _gold_ratio(frame, 0.22, 0.78, 0.64, 0.91)
    result_gold = _gold_ratio(frame, 0.16, 0.84, 0.22, 0.68)
    result_bright = _bright_saturated_ratio(frame, 0.12, 0.88, 0.18, 0.70)
    bottom_bright = _bright_saturated_ratio(frame, 0.20, 0.80, 0.72, 0.94)

    if result_gold > 0.055 and result_bright > 0.13 and bottom_bright > 0.07:
        score = _clamp(0.58 + result_gold * 1.8 + result_bright * 0.7)
        # Color and layout can identify a likely result screen, but cannot
        # reliably distinguish victory, defeat, or draw across themes/languages.
        # Outcome labels are therefore supplied only by explicit accessibility
        # text; a visual gold banner never trains the learner as a win.
        outcome = None
        result_confidence = 0.0
        target = None
        for cx, cy, bw, bh, confidence in components:
            if 0.25 <= cx <= 0.75 and cy >= 0.68 and bw >= 0.25:
                target = NavigationTarget("result_continue", cx, cy, confidence)
                break
        targets = (target,) if target is not None else ()
        return (Scene.RESULT, score, battle_score, outcome, result_confidence,
                targets, None, 0.0)

    if home_gold > 0.065 and card_visual < 0.50 and green_ratio < 0.10:
        score = _clamp(0.72 + home_gold * 2.0)
        targets = []
        # Only the mode-entry control is relevant to the accepted workflow;
        # no deck-editor target is exposed to the agent.
        for cx, cy, bw, bh, confidence in components:
            if 0.25 <= cx <= 0.75 and 0.58 <= cy <= 0.86 and bw >= 0.25:
                targets.append(NavigationTarget("mode_entry", cx, cy, confidence))
                break
        return Scene.HOME, score, battle_score, None, 0.0, tuple(targets), None, 0.0

    # A multi-button stack is a weak mode-selector signature.  It is reported
    # for diagnostics only; it never identifies which mode is unlocked.
    stacked = [item for item in components
               if 0.22 <= item[1] <= 0.88 and 0.22 <= item[0] <= 0.78
               and item[2] >= 0.25 and item[3] >= 0.025]
    if len(stacked) >= 2:
        ordered = sorted(stacked, key=lambda item: item[1])
        # The visual layer can locate the two vertically stacked mode cards,
        # but cannot read their text or prove unlock status.  Their positions
        # are therefore only geometry candidates; GameFlow still requires an
        # explicit accessibility signal for ladder_unlocked before clicking.
        separated = [ordered[0]]
        for item in ordered[1:]:
            if item[1] - separated[-1][1] >= 0.085:
                separated.append(item)
        if len(separated) >= 2 and separated[-1][1] - separated[0][1] >= 0.12:
            first, second = separated[0], separated[1]
            aligned = abs(first[0] - second[0]) <= 0.18
            if aligned:
                score = _clamp(0.76 + min(0.16, len(separated) * 0.03))
                confidence = lambda item: min(0.91, max(0.0, item[4] - 0.01))
                targets = (
                    NavigationTarget("ladder", first[0], first[1], confidence(first)),
                    NavigationTarget("journey", second[0], second[1], confidence(second)),
                )
                return Scene.MODE_SELECT, score, battle_score, None, 0.0, targets, None, 0.0

    cell_count, grid_score = _grid_colorfulness(frame)
    if cell_count >= 6 and grid_score > 0.14 and purple_ratio < 0.015 and green_ratio < 0.10:
        score = _clamp(0.58 + cell_count * 0.035 + grid_score * 0.25)
        return Scene.DECK, score, battle_score, None, 0.0, (), None, score

    # Loading/matchmaking screens are intentionally not inferred from a single
    # low-detail frame: static menu backgrounds can look identical.
    return Scene.UNKNOWN, _clamp(battle_score * 0.45), battle_score, None, 0.0, (), None, 0.0


def analyze_frame(frame: Frame, *, _detect_bars: bool = True) -> GameState:
    original_width, original_height = frame.width, frame.height
    if _detect_bars:
        rect = _detect_viewport(frame)
        if rect != (0, 0, frame.width, frame.height):
            cropped = _crop_frame(frame, rect)
            state = analyze_frame(cropped, _detect_bars=False)
            x0, y0, x1, y1 = rect
            return replace(
                state,
                frame_width=original_width,
                frame_height=original_height,
                viewport=(x0 / original_width, y0 / original_height,
                          x1 / original_width, y1 / original_height),
            )
    w, h = frame.width, frame.height
    data = memoryview(frame.bgra)
    if w < 120 or h < 240:
        return GameState(False, 0.0, 0.0, 0.0, 0.0, 0.0,
                         (0.0, 0.0, 0.0, 0.0), 0.0, 0.0, 0.0, 0.0, 0.0,
                         frame_width=w, frame_height=h)

    portrait = h >= w * 1.02
    green, red, blue, purple, total = _region_stats(frame, 0.07, 0.93, 0.14, 0.78, 4)
    denom = max(1, total)
    green_ratio, red_ratio, blue_ratio = green / denom, red / denom, blue / denom

    elixir, purple_ratio, elixir_confidence = _measure_elixir_bar(frame)
    card_data = tuple(_card_features(frame, cx) for cx in (0.20, 0.40, 0.60, 0.80))
    card_scores = tuple(item[0] for item in card_data)
    card_ready = tuple(item[1] for item in card_data)
    card_ready_confidence = tuple(item[2] for item in card_data)
    card_fingerprints = tuple(item[3] for item in card_data)
    card_descriptors = tuple(item[4] for item in card_data)
    card_visual = sum(card_scores) / len(card_scores)

    (scene, scene_confidence, battle_score, result, result_confidence,
     targets, ladder_unlocked, deck_confidence) = _classify_scene(
        frame, portrait, green_ratio, red_ratio, blue_ratio, purple_ratio, card_visual
    )
    battle_detected = scene is Scene.BATTLE and scene_confidence >= 0.54
    left_threat = right_threat = left_support = right_support = 0.0
    enemy_clusters: tuple[VisualCluster, ...] = ()
    friendly_clusters: tuple[VisualCluster, ...] = ()
    if battle_detected:
        (left_threat, right_threat, left_support, right_support,
         enemy_clusters, friendly_clusters) = _battle_visuals(frame)
    return GameState(
        battle_detected=battle_detected,
        elixir=elixir,
        left_threat=left_threat,
        right_threat=right_threat,
        left_support=left_support,
        right_support=right_support,
        card_scores=card_scores,
        green_ratio=green_ratio,
        red_ratio=red_ratio,
        blue_ratio=blue_ratio,
        purple_ratio=purple_ratio,
        confidence=battle_score,
        scene=scene,
        scene_confidence=scene_confidence,
        elixir_confidence=elixir_confidence,
        card_ready=card_ready,
        ladder_unlocked=ladder_unlocked,
        result=result,
        frame_width=w,
        frame_height=h,
        card_fingerprints=card_fingerprints,
        card_descriptors=card_descriptors,
        card_ready_confidence=card_ready_confidence,
        result_confidence=result_confidence,
        targets=targets,
        deck_confidence=deck_confidence,
        enemy_clusters=enemy_clusters,
        friendly_clusters=friendly_clusters,
        viewport=(0.0, 0.0, 1.0, 1.0),
    )
