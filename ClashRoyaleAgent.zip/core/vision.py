"""Model-free, conservative screen perception for Clash Royale.

The implementation deliberately separates measurable visual signals from semantic
claims.  It can estimate battle geometry, card-slot appearance, and a few coarse
scene signatures.  Card names, account unlocks, and result labels are only emitted
when an explicit high-confidence signal exists; otherwise they remain unknown.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, replace
from enum import Enum
from math import isfinite, sqrt

from .cards import CardRecognition
from .ui_adaptive import AdaptiveUIEvidence, detect_ui_evidence
from .win32 import Frame


class Scene(str, Enum):
    UNKNOWN = "unknown"
    BATTLE = "battle"
    HOME = "home"
    DECK = "deck"
    RESULT = "result"
    MATCHMAKING = "matchmaking"
    MODE_SELECT = "mode_select"
    LOADING = "loading"
    RECOVERY = "recovery"


@dataclass(frozen=True)
class NavigationTarget:
    name: str
    x: float
    y: float
    confidence: float
    # Accessibility coordinates are already normalized to the full Android
    # display. Pure visual coordinates are relative to the detected viewport.
    screen_space: bool = False


@dataclass(frozen=True)
class VisualCluster:
    """A color-segmented visual blob with a team-invariant appearance descriptor.

    The descriptor is a hand-built brightness/texture signature, not a pretrained
    embedding and not a card identity.  It becomes semantic only after it is
    matched against a locally learned, OCR/action-grounded prototype.
    """
    x: float
    y: float
    width: float
    height: float
    area: float
    confidence: float
    appearance: tuple[float, ...] = ()
    health_ratio: float | None = None
    health_confidence: float = 0.0


@dataclass(frozen=True)
class ClusterTrack:
    """Short-lived motion/appearance estimate; identity is assigned separately."""
    track_id: int
    x: float
    y: float
    vx: float
    vy: float
    width: float
    height: float
    area: float
    confidence: float
    age_seconds: float
    observations: int
    last_seen: float
    appearance: tuple[float, ...] = ()
    health_ratio: float | None = None
    health_confidence: float = 0.0

    @property
    def lane(self) -> int:
        return 0 if self.x < 0.5 else 1


@dataclass(frozen=True)
class SemanticUnit:
    """A troop/building identity supported by a learned local visual prototype."""
    track_id: int
    team: str
    card_key: str
    form: str
    confidence: float
    x: float
    y: float
    vx: float
    vy: float
    area: float
    observations: int
    level: int | None = None
    health_ratio: float | None = None
    health_confidence: float = 0.0
    evidence: str = "local-visual-prototype"
    roles: tuple[str, ...] = ()


@dataclass(frozen=True)
class GameState:
    battle_detected: bool
    elixir: float
    left_threat: float
    right_threat: float
    left_support: float
    right_support: float
    card_scores: tuple[float, float, float, float]
    green_ratio: float
    red_ratio: float
    blue_ratio: float
    purple_ratio: float
    confidence: float
    scene: Scene = Scene.UNKNOWN
    scene_confidence: float = 0.0
    elixir_confidence: float = 0.0
    card_ready: tuple[bool, bool, bool, bool] = (False, False, False, False)
    ladder_unlocked: bool | None = None
    ladder_lock_confidence: float = 0.0
    result: str | None = None
    frame_width: int = 0
    frame_height: int = 0
    card_fingerprints: tuple[str, str, str, str] = ("", "", "", "")
    card_descriptors: tuple[tuple[float, ...], ...] = ()
    card_ready_confidence: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    card_costs: tuple[float | None, float | None, float | None, float | None] = (None, None, None, None)
    result_confidence: float = 0.0
    targets: tuple[NavigationTarget, ...] = ()
    deck_confidence: float = 0.0
    card_names: tuple[str, str, str, str] = ("", "", "", "")
    card_roles: tuple[tuple[str, ...], ...] = ((), (), (), ())
    enemy_clusters: tuple[VisualCluster, ...] = ()
    friendly_clusters: tuple[VisualCluster, ...] = ()
    enemy_tracks: tuple[ClusterTrack, ...] = ()
    friendly_tracks: tuple[ClusterTrack, ...] = ()
    # Normalized content viewport in the original captured frame. This is
    # normally the full frame, but excludes symmetric letterbox/pillarbox bars.
    viewport: tuple[float, float, float, float] = (0.0, 0.0, 1.0, 1.0)
    card_forms: tuple[str, str, str, str] = ("base", "base", "base", "base")
    card_levels: tuple[int | None, int | None, int | None, int | None] = (None, None, None, None)
    card_elite: tuple[bool, bool, bool, bool] = (False, False, False, False)
    recognized_cards: tuple[CardRecognition, ...] = ()
    ocr_text: tuple[str, ...] = ()
    ocr_confidence: float = 0.0
    opponent_cycle_card: str = ""
    opponent_cycle_token: str = ""
    opponent_cycle_confidence: float = 0.0
    opponent_cycle_roles: tuple[str, ...] = ()
    opponent_play_count: int = 0
    opponent_recent_plays: tuple[str, ...] = ()
    opponent_seen_cards: tuple[str, ...] = ()
    opponent_cycle_eta: int | None = None
    opponent_cycle_complete: bool = False
    opponent_elixir_lower: float = 0.0
    opponent_elixir_upper: float = 10.0
    opponent_elixir_confidence: float = 0.0
    semantic_enemy_units: tuple[SemanticUnit, ...] = ()
    semantic_friendly_units: tuple[SemanticUnit, ...] = ()
    opponent_deck_top: tuple[str, ...] = ()
    opponent_deck_confirmed: tuple[str, ...] = ()
    opponent_deck_confidence: float = 0.0
    opponent_deck_unknown_slots: int = 8
    opponent_deck_complete: bool = False
    opponent_deck_candidates: tuple[tuple[str, ...], ...] = ()
    opponent_deck_candidate_confidences: tuple[float, ...] = ()
    # Per-frame geometry learned from repeated UI edges, not fixed pixel offsets.
    card_bounds: tuple[tuple[float, float, float, float], ...] = ()
    arena_bounds: tuple[float, float, float, float] | None = None
    elixir_bounds: tuple[float, float, float, float] | None = None

    @property
    def red_total(self) -> float:
        return self.left_threat + self.right_threat

    @property
    def blue_total(self) -> float:
        return self.left_support + self.right_support

    @property
    def has_playable_card(self) -> bool:
        return any(self.card_ready)

    def target(self, name: str) -> NavigationTarget | None:
        for item in self.targets:
            if item.name == name:
                return item
        return None


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    if not isfinite(value):
        return low
    return max(low, min(high, value))


def _edge_bar_length(frame: Frame, axis: str, from_end: bool, *, maximum: float = 0.18) -> int:
    """Measure a strongly uniform near-black outer bar, conservatively.

    A single dark edge is not enough: the caller requires a matching bar at
    the opposite edge before cropping. This avoids treating normal dark game
    artwork or a status panel as a viewport boundary.
    """
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    length = h if axis == "y" else w
    cross = w if axis == "y" else h
    limit = int(length * maximum)
    start = length - 1 if from_end else 0
    direction = -1 if from_end else 1
    samples = range(max(1, int(cross * 0.05)), min(cross, int(cross * 0.95)), 7)
    count = len(samples)
    if count < 8:
        return 0
    run = 0
    for offset in range(limit):
        position = start + direction * offset
        dark_count = 0
        minimum = 255.0
        maximum = 0.0
        for cross_pos in samples:
            x, y = (cross_pos, position) if axis == "y" else (position, cross_pos)
            index = (y * w + x) * 4
            b, g, r = data[index], data[index + 1], data[index + 2]
            value = (b + g + r) / 3.0
            if value <= 18.0:
                dark_count += 1
            if value < minimum:
                minimum = value
            if value > maximum:
                maximum = value
        if dark_count / count >= 0.985 and maximum - minimum <= 20.0:
            run += 1
        else:
            break
    return run


def _detect_viewport(frame: Frame) -> tuple[int, int, int, int]:
    """Return a symmetric, near-black game viewport, including portrait pillarboxes.

    A portrait mobile game is commonly centered inside a much wider desktop or
    emulator window.  Such a viewport can occupy less than 68% of the window,
    so the old area-only cutoff incorrectly kept both black sidebars and made
    every downstream normalized coordinate refer to the wrong layout.
    """
    w, h = frame.width, frame.height
    left = _edge_bar_length(frame, "x", False, maximum=0.48)
    right = _edge_bar_length(frame, "x", True, maximum=0.48)
    top = _edge_bar_length(frame, "y", False, maximum=0.32)
    bottom = _edge_bar_length(frame, "y", True, maximum=0.32)
    # Require a symmetric pair and a meaningful margin; asymmetrical game UI
    # is deliberately retained rather than guessed to be a letterbox.
    if left >= w * 0.025 and right >= w * 0.025 and abs(left - right) <= w * 0.025:
        left, right = min(left, right), min(left, right)
    else:
        left = right = 0
    if top >= h * 0.025 and bottom >= h * 0.025 and abs(top - bottom) <= h * 0.025:
        top, bottom = min(top, bottom), min(top, bottom)
    else:
        top = bottom = 0
    x0, y0, x1, y1 = left, top, w - right, h - bottom
    content_width, content_height = x1 - x0, y1 - y0
    if content_width <= 0 or content_height <= 0:
        return 0, 0, w, h
    area_ratio = content_width * content_height / max(1, w * h)
    content_aspect = content_width / max(1, content_height)
    portrait_pillarbox = (
        left > 0 and right > 0 and w / max(1, h) >= 1.12
        and 0.38 <= content_aspect <= 0.96
        and left >= w * 0.08 and right >= w * 0.08
    )
    conventional_letterbox = area_ratio >= 0.68
    if not (portrait_pillarbox or conventional_letterbox):
        return 0, 0, w, h
    return x0, y0, x1, y1


def _crop_frame(frame: Frame, rect: tuple[int, int, int, int]) -> Frame:
    x0, y0, x1, y1 = rect
    if x0 == 0 and y0 == 0 and x1 == frame.width and y1 == frame.height:
        return frame
    width, height = x1 - x0, y1 - y0
    source = memoryview(frame.bgra)
    source_stride = frame.width * 4
    row_bytes = width * 4
    cropped = bytearray(height * row_bytes)
    for row in range(height):
        start = (y0 + row) * source_stride + x0 * 4
        cropped[row * row_bytes:(row + 1) * row_bytes] = source[start:start + row_bytes]
    return Frame(width, height, bytes(cropped), frame.source_hwnd)


def _region_stats(frame: Frame, x0: float, x1: float, y0: float, y1: float,
                  step: int = 4) -> tuple[int, int, int, int, int]:
    """Sample a region using strided BGRA reads."""
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    sx0, sx1 = max(0, int(w * x0)), min(w, max(int(w * x0) + 1, int(w * x1)))
    sy0, sy1 = max(0, int(h * y0)), min(h, max(int(h * y0) + 1, int(h * y1)))
    green = red = blue = purple = total = 0
    for yy in range(sy0, sy1, step):
        row = yy * w * 4
        for xx in range(sx0, sx1, step):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            total += 1
            if g > 58 and g > r * 1.12 and g > b * 1.04:
                green += 1
            if r > 78 and r > g * 1.22 and r > b * 1.18:
                red += 1
            if b > 78 and b > r * 1.14 and b > g * 1.06:
                blue += 1
            if r > 65 and b > 65 and r > g * 1.12 and b > g * 1.12:
                purple += 1
    return green, red, blue, purple, total


def _appearance_descriptor(frame: Frame, left: int, top: int, right: int, bottom: int) -> tuple[float, ...]:
    """Build a small team-tint-resistant spatial brightness/texture signature."""
    width, height = max(1, right - left), max(1, bottom - top)
    data = memoryview(frame.bgra)
    spatial_brightness: list[float] = []
    spatial_saturation: list[float] = []
    brightness_hist = [0] * 8
    saturation_hist = [0] * 8
    for gy in range(4):
        for gx in range(4):
            x0 = left + width * gx // 4
            x1 = left + width * (gx + 1) // 4
            y0 = top + height * gy // 4
            y1 = top + height * (gy + 1) // 4
            stride_x = max(1, (x1 - x0) // 5)
            stride_y = max(1, (y1 - y0) // 5)
            bright_sum = sat_sum = samples = 0
            for yy in range(y0, max(y0 + 1, y1), stride_y):
                row = yy * frame.width * 4
                for xx in range(x0, max(x0 + 1, x1), stride_x):
                    i = row + xx * 4
                    b, g, r = data[i], data[i + 1], data[i + 2]
                    high, low = max(r, g, b), min(r, g, b)
                    brightness = high / 255.0
                    saturation = (high - low) / 255.0
                    bright_sum += high
                    sat_sum += high - low
                    brightness_hist[min(7, int(brightness * 8))] += 1
                    saturation_hist[min(7, int(saturation * 8))] += 1
                    samples += 1
            spatial_brightness.append(bright_sum / max(1, samples) / 255.0)
            spatial_saturation.append(sat_sum / max(1, samples) / 255.0)
    total_b = max(1, sum(brightness_hist))
    total_s = max(1, sum(saturation_hist))
    return tuple(spatial_brightness + spatial_saturation +
                 [value / total_b for value in brightness_hist] +
                 [value / total_s for value in saturation_hist])


def _estimate_health_bar(frame: Frame, left: int, top: int,
                         right: int, bottom: int) -> tuple[float | None, float]:
    """Estimate a unit's remaining health from a short colored bar above it.

    The estimate is intentionally low-confidence: it is only emitted when a
    compact, saturated horizontal run is spatially attached to a detected blob.
    A missing/ambiguous bar remains unknown instead of being interpreted as full
    health. The expected full-bar width is approximated from the unit box.
    """
    width = max(1, right - left)
    height = max(1, bottom - top)
    if width < 7 or height < 7 or top <= 1:
        return None, 0.0
    data = memoryview(frame.bgra)
    x0 = max(0, left - max(2, int(width * 0.08)))
    x1 = min(frame.width, right + max(2, int(width * 0.08)))
    band = max(5, min(18, int(height * 0.45)))
    y0 = max(0, top - band)
    best_length = 0
    best_row = -1
    best_start = best_end = 0
    row_runs: dict[int, tuple[int, int, int]] = {}
    for y in range(y0, top):
        row = y * frame.width * 4
        runs = []
        run_start = None
        for x in range(x0, x1):
            index = row + x * 4
            b, g, r = data[index], data[index + 1], data[index + 2]
            high, low = max(r, g, b), min(r, g, b)
            saturated = high >= 88 and high - low >= 38
            green = saturated and g >= r * 1.08 and g >= b * 1.04
            yellow = saturated and r >= 100 and g >= 78 and r >= b * 1.10 and g >= b * 1.04
            red = saturated and r >= 110 and r >= g * 1.12 and r >= b * 1.12
            active = green or yellow or red
            if active and run_start is None:
                run_start = x
            elif not active and run_start is not None:
                length = x - run_start
                if length >= max(4, int(width * 0.22)):
                    runs.append((length, run_start, x))
                run_start = None
        if run_start is not None:
            length = x1 - run_start
            if length >= max(4, int(width * 0.22)):
                runs.append((length, run_start, x1))
        if runs:
            run = max(runs)
            row_runs[y] = run
            if run[0] > best_length:
                best_length, best_start, best_end = run
                best_row = y
    if best_row < 0:
        return None, 0.0
    expected_width = max(6.0, width * 0.96)
    ratio = max(0.08, min(1.0, best_length / expected_width))
    supporting_rows = 0
    for y, (_length, start, end) in row_runs.items():
        if abs(y - best_row) <= 2 and min(end, best_end) > max(start, best_start):
            supporting_rows += 1
    row_support = min(1.0, supporting_rows / 3.0)
    confidence = _clamp(0.42 + 0.18 * min(1.0, best_length / expected_width)
                        + 0.16 * row_support)
    if best_length < width * 0.25:
        confidence *= 0.82
    return ratio, confidence


def _find_color_clusters(frame: Frame, team: str, step: int = 3) -> tuple[VisualCluster, ...]:
    """Find coarse red/blue arena blobs with bounded 8-neighbour components.

    These are position/count cues only. They are deliberately not labelled as
    troops, buildings, or card identities because spells and visual effects can
    produce similar colors.
    """
    if team not in ("enemy", "friendly"):
        raise ValueError("team must be 'enemy' or 'friendly'.")
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    x0, x1 = max(0, int(w * 0.06)), min(w, int(w * 0.94))
    y0, y1 = max(0, int(h * 0.35)), min(h, int(h * 0.80))
    xs = list(range(x0, x1, step))
    ys = list(range(y0, y1, step))
    grid_w, grid_h = len(xs), len(ys)
    if grid_w < 2 or grid_h < 2:
        return ()
    mask = bytearray(grid_w * grid_h)
    for gy, yy in enumerate(ys):
        row = yy * w * 4
        base = gy * grid_w
        for gx, xx in enumerate(xs):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            if team == "enemy":
                hit = r > 78 and r > g * 1.22 and r > b * 1.18
            else:
                hit = b > 78 and b > r * 1.14 and b > g * 1.06
            if hit:
                mask[base + gx] = 1

    seen = bytearray(len(mask))
    clusters: list[VisualCluster] = []
    for start, active in enumerate(mask):
        if not active or seen[start]:
            continue
        stack = [start]
        seen[start] = 1
        min_x = max_x = start % grid_w
        min_y = max_y = start // grid_w
        count = 0
        while stack:
            index = stack.pop()
            gx, gy = index % grid_w, index // grid_w
            count += 1
            min_x, max_x = min(min_x, gx), max(max_x, gx)
            min_y, max_y = min(min_y, gy), max(max_y, gy)
            for ny in range(max(0, gy - 1), min(grid_h, gy + 2)):
                row_base = ny * grid_w
                for nx in range(max(0, gx - 1), min(grid_w, gx + 2)):
                    neighbor = row_base + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        stack.append(neighbor)
        box_w = (max_x - min_x + 1) * step
        box_h = (max_y - min_y + 1) * step
        box_area = max(1.0, box_w * box_h)
        area_fraction = count * step * step / max(1.0, w * h)
        aspect = box_w / max(1.0, box_h)
        fill = count * step * step / box_area
        if (count < 3 or box_w < w * 0.025 or box_h < h * 0.018 or
                area_fraction > 0.085 or not 0.16 <= aspect <= 5.5 or fill < 0.10):
            continue
        left, right = xs[min_x], min(w, xs[max_x] + step)
        top, bottom = ys[min_y], min(h, ys[max_y] + step)
        confidence = _clamp(0.30 + min(0.35, count / 28.0 * 0.35) + min(0.30, fill * 0.30))
        health_ratio, health_confidence = _estimate_health_bar(frame, left, top, right, bottom)
        clusters.append(VisualCluster(
            x=(left + right) / (2.0 * w), y=(top + bottom) / (2.0 * h),
            width=(right - left) / w, height=(bottom - top) / h,
            area=area_fraction, confidence=confidence,
            appearance=_appearance_descriptor(frame, left, top, right, bottom),
            health_ratio=health_ratio, health_confidence=health_confidence,
        ))
    clusters.sort(key=lambda item: item.area * item.confidence, reverse=True)
    return tuple(clusters[:32])


def _components_from_mask(frame: Frame, mask: bytearray, xs: list[int], ys: list[int],
                          step: int = 4) -> tuple[VisualCluster, ...]:
    """Extract bounded connected components from a previously computed mask."""
    grid_w, grid_h = len(xs), len(ys)
    if grid_w < 2 or grid_h < 2:
        return ()
    seen = bytearray(len(mask))
    clusters: list[VisualCluster] = []
    for start, active in enumerate(mask):
        if not active or seen[start]:
            continue
        stack = [start]
        seen[start] = 1
        min_x = max_x = start % grid_w
        min_y = max_y = start // grid_w
        count = 0
        while stack:
            index = stack.pop()
            gx, gy = index % grid_w, index // grid_w
            count += 1
            min_x, max_x = min(min_x, gx), max(max_x, gx)
            min_y, max_y = min(min_y, gy), max(max_y, gy)
            for ny in range(max(0, gy - 1), min(grid_h, gy + 2)):
                row_base = ny * grid_w
                for nx in range(max(0, gx - 1), min(grid_w, gx + 2)):
                    neighbor = row_base + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        stack.append(neighbor)
        box_w = (max_x - min_x + 1) * step
        box_h = (max_y - min_y + 1) * step
        box_area = max(1.0, box_w * box_h)
        area_fraction = count * step * step / max(1.0, frame.width * frame.height)
        aspect = box_w / max(1.0, box_h)
        fill = count * step * step / box_area
        if (count < 3 or box_w < frame.width * 0.025 or box_h < frame.height * 0.018 or
                area_fraction > 0.085 or not 0.16 <= aspect <= 5.5 or fill < 0.10):
            continue
        left, right = xs[min_x], min(frame.width, xs[max_x] + step)
        top, bottom = ys[min_y], min(frame.height, ys[max_y] + step)
        confidence = _clamp(0.30 + min(0.35, count / 28.0 * 0.35) + min(0.30, fill * 0.30))
        health_ratio, health_confidence = _estimate_health_bar(frame, left, top, right, bottom)
        clusters.append(VisualCluster(
            x=(left + right) / (2.0 * frame.width),
            y=(top + bottom) / (2.0 * frame.height),
            width=(right - left) / frame.width,
            height=(bottom - top) / frame.height,
            area=area_fraction,
            confidence=confidence,
            appearance=_appearance_descriptor(frame, left, top, right, bottom),
            health_ratio=health_ratio, health_confidence=health_confidence,
        ))
    clusters.sort(key=lambda item: item.area * item.confidence, reverse=True)
    return tuple(clusters[:32])


def _battle_visuals(frame: Frame, step: int = 3,
                    arena_bounds: tuple[float, float, float, float] | None = None) -> tuple[
        float, float, float, float, tuple[VisualCluster, ...], tuple[VisualCluster, ...]]:
    """Compute team masks inside the detected arena, adapting to resized layouts."""
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    if arena_bounds is not None:
        ax0, ay0, ax1, ay1 = arena_bounds
        arena_w, arena_h = max(0.1, ax1 - ax0), max(0.1, ay1 - ay0)
        x0 = max(0, int(w * (ax0 + arena_w * 0.02)))
        x1 = min(w, int(w * (ax1 - arena_w * 0.02)))
        y0 = max(0, int(h * (ay0 + arena_h * 0.04)))
        y1 = min(h, int(h * (ay1 - arena_h * 0.02)))
        lane_x0 = ax0 + arena_w * 0.08
        lane_x1 = ax0 + arena_w * 0.48
        lane_x2 = ax0 + arena_w * 0.52
        lane_x3 = ax0 + arena_w * 0.92
        lane_y0 = int(h * (ay0 + arena_h * 0.38))
        lane_y1 = int(h * (ay1 - arena_h * 0.02))
    else:
        x0, x1 = max(0, int(w * 0.06)), min(w, int(w * 0.94))
        y0, y1 = max(0, int(h * 0.35)), min(h, int(h * 0.80))
        lane_x0, lane_x1, lane_x2, lane_x3 = 0.08, 0.48, 0.52, 0.92
        lane_y0, lane_y1 = int(h * 0.40), int(h * 0.79)
    xs, ys = list(range(x0, x1, step)), list(range(y0, y1, step))
    grid_w, grid_h = len(xs), len(ys)
    enemy_mask = bytearray(grid_w * grid_h)
    friendly_mask = bytearray(grid_w * grid_h)
    lane_enemy = [0.0, 0.0]
    lane_friendly = [0.0, 0.0]
    lane_total = [0.0, 0.0]
    for gy, yy in enumerate(ys):
        row = yy * w * 4
        base = gy * grid_w
        in_lane_y = lane_y0 <= yy < lane_y1
        proximity = (0.55 + 0.90 * ((yy - lane_y0) / max(1, lane_y1 - lane_y0))) if in_lane_y else 0.0
        for gx, xx in enumerate(xs):
            index = row + xx * 4
            b, g, r = data[index], data[index + 1], data[index + 2]
            enemy = r > 78 and r > g * 1.22 and r > b * 1.18
            friendly = b > 78 and b > r * 1.14 and b > g * 1.06
            cell = base + gx
            if enemy:
                enemy_mask[cell] = 1
            if friendly:
                friendly_mask[cell] = 1
            if in_lane_y:
                if lane_x0 <= xx / w < lane_x1:
                    lane = 0
                elif lane_x2 <= xx / w < lane_x3:
                    lane = 1
                else:
                    lane = -1
            else:
                lane = -1
            if lane >= 0:
                lane_total[lane] += 1.0
                if enemy:
                    lane_enemy[lane] += proximity
                if friendly:
                    lane_friendly[lane] += proximity
    left_threat = _clamp(lane_enemy[0] / max(1.0, lane_total[0]) * 18.0)
    left_support = _clamp(lane_friendly[0] / max(1.0, lane_total[0]) * 18.0)
    right_threat = _clamp(lane_enemy[1] / max(1.0, lane_total[1]) * 18.0)
    right_support = _clamp(lane_friendly[1] / max(1.0, lane_total[1]) * 18.0)
    return (left_threat, right_threat, left_support, right_support,
            _components_from_mask(frame, enemy_mask, xs, ys, step),
            _components_from_mask(frame, friendly_mask, xs, ys, step))


def _card_visual_signature(frame: Frame, bounds: tuple[int, int, int, int]) -> tuple[float, bool, float, str, tuple[float, ...]]:
    """Extract a multi-scale card signature from a normalized image rectangle.

    The descriptor combines global colour statistics with spatial luminance and
    colour grids.  It is deterministic, model-free, and shared by live hand
    cards and the autonomous collection-screen catalog scanner.
    """
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    raw_x0, raw_y0, raw_x1, raw_y1 = bounds
    x0 = max(0, min(w - 1, int(raw_x0)))
    x1 = max(x0 + 1, min(w, int(raw_x1)))
    y0 = max(0, min(h - 1, int(raw_y0)))
    y1 = max(y0 + 1, min(h, int(raw_y1)))
    crop_w, crop_h = x1 - x0, y1 - y0
    brightness = saturation = contrast = colorful = total = 0.0
    rgb_sum = [0.0, 0.0, 0.0]
    hist = [0.0] * 12
    lum_grid_sum = [0.0] * 64
    lum_grid_count = [0.0] * 64
    rgb_grid_sum = [[0.0, 0.0, 0.0] for _ in range(16)]
    rgb_grid_count = [0.0] * 16
    for yy in range(y0, y1, 2):
        gy8 = min(7, max(0, (yy - y0) * 8 // crop_h))
        gy4 = min(3, max(0, (yy - y0) * 4 // crop_h))
        row = yy * w * 4
        for xx in range(x0, x1, 2):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            hi, lo = max(r, g, b), min(r, g, b)
            lum = (0.114 * b + 0.587 * g + 0.299 * r) / 255.0
            sat = (hi - lo) / max(1.0, hi)
            brightness += lum
            saturation += sat
            contrast += (hi - lo) / 255.0
            if hi - lo > 30 and hi > 70:
                colorful += 1.0
            rn, gn, bn = r / 255.0, g / 255.0, b / 255.0
            rgb_sum[0] += rn
            rgb_sum[1] += gn
            rgb_sum[2] += bn
            hist[min(3, r // 64)] += 1
            hist[4 + min(3, g // 64)] += 1
            hist[8 + min(3, b // 64)] += 1
            gx8 = min(7, max(0, (xx - x0) * 8 // crop_w))
            cell8 = gy8 * 8 + gx8
            lum_grid_sum[cell8] += lum
            lum_grid_count[cell8] += 1.0
            gx4 = min(3, max(0, (xx - x0) * 4 // crop_w))
            cell4 = gy4 * 4 + gx4
            rgb_grid_sum[cell4][0] += rn
            rgb_grid_sum[cell4][1] += gn
            rgb_grid_sum[cell4][2] += bn
            rgb_grid_count[cell4] += 1.0
            total += 1.0
    if total <= 0:
        return 0.0, False, 0.0, "", ()
    mean_brightness = brightness / total
    mean_saturation = saturation / total
    mean_contrast = contrast / total
    colorful_ratio = colorful / total
    visual_score = _clamp(0.30 * mean_brightness + 0.35 * mean_saturation +
                          0.20 * mean_contrast + 0.15 * colorful_ratio)
    readiness_margin = (0.58 * mean_saturation + 0.42 * mean_brightness) - 0.22
    ready = readiness_margin >= 0.025 and mean_brightness >= 0.18
    ready_confidence = _clamp(0.5 + readiness_margin * 2.4)
    if ready_confidence < 0.56:
        ready_confidence = 1.0 - ready_confidence

    mean_rgb = [value / total for value in rgb_sum]
    hist_descriptor = [value / total for value in hist]
    global_descriptor = [mean_brightness, mean_saturation, mean_contrast,
                         colorful_ratio, *mean_rgb]
    lum_means = [lum_grid_sum[i] / lum_grid_count[i] if lum_grid_count[i] else mean_brightness
                 for i in range(64)]
    lum_variance = sum((value - mean_brightness) ** 2 for value in lum_means) / 64.0
    lum_scale = max(0.10, 2.0 * sqrt(lum_variance))
    spatial_luminance = [
        _clamp(0.5 + (value - mean_brightness) / lum_scale)
        for value in lum_means
    ]
    spatial_colour: list[float] = []
    for index in range(16):
        count = rgb_grid_count[index]
        values = ([value / count for value in rgb_grid_sum[index]]
                  if count else mean_rgb)
        for channel in range(3):
            spatial_colour.append(_clamp(0.5 + (values[channel] - mean_rgb[channel]) * 1.35))
    descriptor = tuple(round(value, 5) for value in (
        hist_descriptor + global_descriptor + spatial_luminance + spatial_colour
    ))

    # 64-bit difference hash from an 9x8 luminance grid in the central card area.
    sample_rows: list[list[float]] = []
    cx0 = x0 + int(crop_w * 0.12)
    cx1 = x1 - int(crop_w * 0.12)
    cy0 = y0 + int(crop_h * 0.12)
    cy1 = y1 - int(crop_h * 0.12)
    for gy in range(8):
        row_values = []
        yy = min(h - 1, cy0 + int((max(1, cy1 - cy0) - 1) * gy / 7))
        for gx in range(9):
            xx = min(w - 1, cx0 + int((max(1, cx1 - cx0) - 1) * gx / 8))
            i = (yy * w + xx) * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            row_values.append(0.114 * b + 0.587 * g + 0.299 * r)
        sample_rows.append(row_values)
    bits = 0
    bit_index = 0
    for row_values in sample_rows:
        for gx in range(8):
            if row_values[gx] > row_values[gx + 1]:
                bits |= 1 << bit_index
            bit_index += 1
    return visual_score, ready, ready_confidence, f"{bits:016x}", descriptor


def card_signature_for_bounds(frame: Frame, bounds: tuple[int, int, int, int]) -> tuple[float, str, tuple[float, ...]]:
    """Public, readiness-independent visual signature for an arbitrary card crop."""
    score, _ready, _ready_confidence, fingerprint, descriptor = _card_visual_signature(frame, bounds)
    return score, fingerprint, descriptor


def crop_frame_to_viewport(frame: Frame, viewport: tuple[float, float, float, float]) -> Frame:
    """Return the same letterbox-free viewport used by ``analyze_frame``."""
    if viewport == (0.0, 0.0, 1.0, 1.0):
        return frame
    x0 = max(0, min(frame.width - 1, int(frame.width * viewport[0])))
    y0 = max(0, min(frame.height - 1, int(frame.height * viewport[1])))
    x1 = max(x0 + 1, min(frame.width, int(frame.width * viewport[2])))
    y1 = max(y0 + 1, min(frame.height, int(frame.height * viewport[3])))
    return _crop_frame(frame, x0, y0, x1, y1)


def _card_features(frame: Frame,
                   normalized_bounds: tuple[float, float, float, float]) -> tuple[float, bool, float, str, tuple[float, ...]]:
    """Return a card signature only for a slot whose bounds were detected."""
    w, h = frame.width, frame.height
    x0, y0, x1, y1 = normalized_bounds
    bounds = (int(w * x0), int(h * y0), int(w * x1), int(h * y1))
    return _card_visual_signature(frame, bounds)


def _measure_elixir_bar(frame: Frame,
                        normalized_bounds: tuple[float, float, float, float] | None = None) -> tuple[float, float, float]:
    """Estimate elixir from the purple fill in the bar above the detected hand."""
    if normalized_bounds is None:
        # An unlocated purple strip may be a spell effect or decorative UI.
        # Do not let it authorize card selection or resource-sensitive actions.
        return 0.0, 0.0, 0.0
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    bx0, by0, bx1, by1 = normalized_bounds
    x0, x1 = max(0, int(w * bx0)), min(w, int(w * bx1))
    y0, y1 = max(0, int(h * by0)), min(h, int(h * by1))
    columns: list[float] = []
    hits = total = 0
    for xx in range(x0, x1, 2):
        col_hits = col_total = 0
        for yy in range(y0, y1, 2):
            i = (yy * w + xx) * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            col_total += 1
            if r > 65 and b > 65 and r > g * 1.12 and b > g * 1.12:
                col_hits += 1
        hits += col_hits
        total += col_total
        columns.append(col_hits / max(1, col_total))
    purple_ratio = hits / max(1, total)
    active = [ratio >= 0.38 for ratio in columns]
    try:
        first = active.index(True)
    except ValueError:
        return 0.0, purple_ratio, 0.0
    last = len(active) - 1 - active[::-1].index(True)
    prefix = active[:last + 1]
    active_ratio = sum(prefix) / max(1, len(prefix))
    start_quality = _clamp(1.0 - first / max(1.0, len(active) * 0.10))
    fill_fraction = _clamp((last + 1) / max(1, len(active)))
    strength = sum(columns[first:last + 1]) / max(1, last - first + 1)
    confidence = _clamp(active_ratio * start_quality * ((strength - 0.18) / 0.62))
    if first > len(active) * 0.18:
        confidence *= 0.25
    return fill_fraction * 10.0, purple_ratio, confidence


def _gold_ratio(frame: Frame, x0: float, x1: float, y0: float, y1: float,
                step: int = 3) -> float:
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    ax0, ax1 = max(0, int(w * x0)), min(w, int(w * x1))
    ay0, ay1 = max(0, int(h * y0)), min(h, int(h * y1))
    hits = total = 0
    for yy in range(ay0, ay1, step):
        row = yy * w * 4
        for xx in range(ax0, ax1, step):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            total += 1
            if r > 145 and g > 78 and g < r * 0.92 and b < g * 0.82 and r - g > 28:
                hits += 1
    return hits / max(1, total)


def _bright_saturated_ratio(frame: Frame, x0: float, x1: float, y0: float, y1: float,
                            step: int = 4) -> float:
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    ax0, ax1 = max(0, int(w * x0)), min(w, int(w * x1))
    ay0, ay1 = max(0, int(h * y0)), min(h, int(h * y1))
    hits = total = 0
    for yy in range(ay0, ay1, step):
        row = yy * w * 4
        for xx in range(ax0, ax1, step):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            hi, lo = max(r, g, b), min(r, g, b)
            total += 1
            if hi > 175 and hi - lo > 48:
                hits += 1
    return hits / max(1, total)


def _find_gold_components(frame: Frame, y_min: float = 0.08, y_max: float = 0.985,
                          step: int = 3) -> list[tuple[float, float, float, float, float]]:
    """Find large, compact gold-colored UI components; return normalized boxes."""
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    xs = list(range(0, w, step))
    ys = list(range(max(0, int(h * y_min)), min(h, int(h * y_max)), step))
    if not xs or not ys:
        return []
    width, height = len(xs), len(ys)
    mask = bytearray(width * height)
    for iy, yy in enumerate(ys):
        row = yy * w * 4
        base = iy * width
        for ix, xx in enumerate(xs):
            i = row + xx * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            if r > 145 and g > 78 and g < r * 0.92 and b < g * 0.82 and r - g > 28:
                mask[base + ix] = 1
    seen = bytearray(len(mask))
    components = []
    for start, active in enumerate(mask):
        if not active or seen[start]:
            continue
        queue = deque([start])
        seen[start] = 1
        min_x = max_x = start % width
        min_y = max_y = start // width
        count = 0
        while queue:
            current = queue.popleft()
            ix, iy = current % width, current // width
            count += 1
            min_x, max_x = min(min_x, ix), max(max_x, ix)
            min_y, max_y = min(min_y, iy), max(max_y, iy)
            for nx, ny in ((ix - 1, iy), (ix + 1, iy), (ix, iy - 1), (ix, iy + 1)):
                if 0 <= nx < width and 0 <= ny < height:
                    neighbor = ny * width + nx
                    if mask[neighbor] and not seen[neighbor]:
                        seen[neighbor] = 1
                        queue.append(neighbor)
        box_w = (max_x - min_x + 1) * step
        box_h = (max_y - min_y + 1) * step
        area = box_w * box_h
        aspect = box_w / max(1.0, box_h)
        fill = count * step * step / max(1.0, area)
        if box_w < w * 0.18 or box_h < h * 0.025 or area < w * h * 0.004:
            continue
        if not 1.25 <= aspect <= 6.5 or fill < 0.25:
            continue
        left, top = xs[min_x], ys[min_y]
        right = min(w, xs[max_x] + step)
        bottom = min(h, ys[max_y] + step)
        compactness = _clamp(fill)
        area_fraction = area / max(1.0, w * h)
        size_score = _clamp(area_fraction / 0.012)
        confidence = _clamp(0.55 * compactness + 0.45 * size_score)
        components.append(((left + right) / (2 * w), (top + bottom) / (2 * h),
                           (right - left) / w, (bottom - top) / h, confidence))
    components.sort(key=lambda item: item[4], reverse=True)
    return components[:12]


def _grid_colorfulness(frame: Frame) -> tuple[int, float]:
    """Count colorful cells in a coarse 3x3 lower-screen grid."""
    colorful_cells = 0
    values = []
    w, h, data = frame.width, frame.height, memoryview(frame.bgra)
    for row in range(3):
        y0 = 0.35 + row * 0.19
        y1 = y0 + 0.17
        for col in range(3):
            x0 = 0.08 + col * 0.28
            x1 = x0 + 0.24
            hits = count = 0
            for yy in range(max(0, int(h * y0)), min(h, int(h * y1)), 6):
                row_base = yy * w * 4
                for xx in range(max(0, int(w * x0)), min(w, int(w * x1)), 6):
                    i = row_base + xx * 4
                    b, g, r = data[i], data[i + 1], data[i + 2]
                    hi, lo = max(r, g, b), min(r, g, b)
                    count += 1
                    if hi > 85 and hi - lo > 42:
                        hits += 1
            ratio = hits / max(1, count)
            values.append(ratio)
            if ratio > 0.12 and count > 20:
                colorful_cells += 1
    return colorful_cells, sum(values) / max(1, len(values))


def _classify_scene(frame: Frame, green_ratio: float,
                    red_ratio: float, blue_ratio: float, purple_ratio: float,
                    card_visual: float, ui: AdaptiveUIEvidence | None = None,
                    components: list[tuple[float, float, float, float, float]] | None = None) -> tuple[Scene, float, float, str | None, float, tuple[NavigationTarget, ...], bool | None, float]:
    """Classify coarse scenes using layout geometry before broad color ratios."""
    ui = ui or AdaptiveUIEvidence()
    components = components if components is not None else _find_gold_components(frame)
    arena_signal = _clamp((green_ratio - 0.012) / 0.055)
    unit_signal = _clamp((red_ratio + blue_ratio - 0.006) / 0.045)
    card_signal = _clamp((card_visual - 0.10) / 0.42)
    elixir_signal = _clamp((purple_ratio - 0.001) / 0.035)
    battle_score = (0.34 * arena_signal + 0.25 * unit_signal +
                    0.22 * card_signal + 0.19 * elixir_signal)

    # Repeated four-column card tiles are a stronger deck-screen signature than
    # the red/blue/purple colors inside card artwork. Check it before battle.
    if ui.card_grid_confidence >= 0.55 and green_ratio < 0.14:
        score = _clamp(0.78 + ui.card_grid_confidence * 0.18)
        targets = ()
        if ui.bottom_nav_confidence >= 0.55:
            targets = (NavigationTarget("deck_back", 0.50, 0.955,
                                        min(0.91, 0.76 + ui.bottom_nav_confidence * 0.15)),)
        return Scene.DECK, score, battle_score, None, 0.0, targets, None, score

    # A mode selector is a stack of wide panels bounded by the screen edges.
    # These positions are only geometry candidates; OCR/accessibility must
    # still establish which label is the ladder and whether it is unlocked.
    if ui.mode_panel_centers:
        journey_y, ladder_y = ui.mode_panel_centers
        targets = (
            NavigationTarget("ladder", 0.50, ladder_y, 0.78),
            NavigationTarget("journey", 0.50, journey_y, 0.78),
        )
        return Scene.MODE_SELECT, 0.84, battle_score, None, 0.0, targets, None, 0.0

    # A large battle CTA plus the persistent navigation strip distinguishes the
    # lobby from result screens, even when the game's palette is redesigned.
    if ui.home_cta is not None and ui.bottom_nav_confidence >= 0.45 and green_ratio < 0.12:
        cx, cy, _bw, _bh, confidence = ui.home_cta
        target = NavigationTarget("mode_entry", cx, cy, max(0.78, confidence))
        return Scene.HOME, 0.90, battle_score, None, 0.0, (target,), None, 0.0

    if ui.loading_confidence >= 0.55:
        return Scene.LOADING, ui.loading_confidence, battle_score, None, 0.0, (), None, 0.0

    classic_battle = (green_ratio > 0.018 and red_ratio + blue_ratio + green_ratio > 0.075)
    alternate_arena = (red_ratio + blue_ratio > 0.12 and purple_ratio > 0.005)
    if ((classic_battle or alternate_arena) and card_visual > 0.12
            and purple_ratio > 0.0015 and battle_score >= 0.54):
        return Scene.BATTLE, _clamp(battle_score), battle_score, None, 0.0, (), None, 0.0

    home_gold = _gold_ratio(frame, 0.22, 0.78, 0.64, 0.91)
    result_gold = _gold_ratio(frame, 0.16, 0.84, 0.22, 0.68)
    result_bright = _bright_saturated_ratio(frame, 0.12, 0.88, 0.18, 0.70)
    bottom_bright = _bright_saturated_ratio(frame, 0.20, 0.80, 0.72, 0.94)

    if result_gold > 0.055 and result_bright > 0.13 and bottom_bright > 0.07:
        score = _clamp(0.58 + result_gold * 1.8 + result_bright * 0.7)
        # Visual gold banners never determine win/loss/draw semantics.
        target = None
        for cx, cy, bw, bh, confidence in components:
            if 0.25 <= cx <= 0.75 and cy >= 0.68 and bw >= 0.25:
                target = NavigationTarget("result_continue", cx, cy, confidence)
                break
        targets = (target,) if target is not None else ()
        return (Scene.RESULT, score, battle_score, None, 0.0,
                targets, None, 0.0)

    if home_gold > 0.065 and card_visual < 0.50 and green_ratio < 0.10:
        score = _clamp(0.72 + home_gold * 2.0)
        targets = []
        for cx, cy, bw, bh, confidence in components:
            if 0.25 <= cx <= 0.75 and 0.58 <= cy <= 0.86 and bw >= 0.25:
                targets.append(NavigationTarget("mode_entry", cx, cy, confidence))
                break
        return Scene.HOME, score, battle_score, None, 0.0, tuple(targets), None, 0.0

    # Retain the original geometry fallback for simpler/older game layouts.
    stacked = [item for item in components
               if 0.22 <= item[1] <= 0.88 and 0.22 <= item[0] <= 0.78
               and item[2] >= 0.25 and item[3] >= 0.025]
    if len(stacked) >= 2:
        ordered = sorted(stacked, key=lambda item: item[1])
        separated = [ordered[0]]
        for item in ordered[1:]:
            if item[1] - separated[-1][1] >= 0.085:
                separated.append(item)
        if len(separated) >= 2 and separated[-1][1] - separated[0][1] >= 0.12:
            first, second = separated[0], separated[1]
            aligned = abs(first[0] - second[0]) <= 0.18
            if aligned:
                score = _clamp(0.76 + min(0.16, len(separated) * 0.03))
                confidence = lambda item: min(0.91, max(0.0, item[4] - 0.01))
                # In the bundled Clash Royale selector, the upper primary
                # route is Royal Journey and the lower one is Trophy Road.
                # This fallback is geometry-only; unlock state remains None.
                targets = (
                    NavigationTarget("journey", first[0], first[1], confidence(first)),
                    NavigationTarget("ladder", second[0], second[1], confidence(second)),
                )
                return Scene.MODE_SELECT, score, battle_score, None, 0.0, targets, None, 0.0

    cell_count, grid_score = _grid_colorfulness(frame)
    if cell_count >= 6 and grid_score > 0.14 and purple_ratio < 0.015 and green_ratio < 0.10:
        score = _clamp(0.58 + cell_count * 0.035 + grid_score * 0.25)
        return Scene.DECK, score, battle_score, None, 0.0, (), None, score

    return Scene.UNKNOWN, _clamp(battle_score * 0.45), battle_score, None, 0.0, (), None, 0.0


def analyze_frame(frame: Frame, *, _detect_bars: bool = True) -> GameState:
    original_width, original_height = frame.width, frame.height
    if _detect_bars:
        rect = _detect_viewport(frame)
        if rect != (0, 0, frame.width, frame.height):
            cropped = _crop_frame(frame, rect)
            state = analyze_frame(cropped, _detect_bars=False)
            x0, y0, x1, y1 = rect
            return replace(
                state,
                frame_width=original_width,
                frame_height=original_height,
                viewport=(x0 / original_width, y0 / original_height,
                          x1 / original_width, y1 / original_height),
            )
    w, h = frame.width, frame.height
    data = memoryview(frame.bgra)
    if w < 120 or h < 240:
        return GameState(False, 0.0, 0.0, 0.0, 0.0, 0.0,
                         (0.0, 0.0, 0.0, 0.0), 0.0, 0.0, 0.0, 0.0, 0.0,
                         frame_width=w, frame_height=h)

    green, red, blue, purple, total = _region_stats(frame, 0.07, 0.93, 0.14, 0.78, 4)
    denom = max(1, total)
    green_ratio, red_ratio, blue_ratio = green / denom, red / denom, blue / denom
    battle_hint = (
        (green_ratio > 0.05 and (red_ratio + blue_ratio) > 0.006) or
        ((red_ratio + blue_ratio) > 0.12 and purple / denom > 0.005)
    )
    components = _find_gold_components(frame)
    ui_evidence = detect_ui_evidence(
        frame, gold_components=components, green_ratio=green_ratio,
        battle_hint=battle_hint,
    )

    # A hand is actionable only when four slot rectangles were actually
    # detected.  The old fixed 20/40/60/80% fallback produced plausible-looking
    # card descriptors on unrelated layouts and could lead to blind taps.
    card_bounds = ui_evidence.hand_slots if len(ui_evidence.hand_slots) == 4 else ()
    elixir, purple_ratio, elixir_confidence = _measure_elixir_bar(
        frame, ui_evidence.elixir_bounds,
    )
    card_data = (tuple(_card_features(frame, normalized_bounds=bounds) for bounds in card_bounds)
                 if len(card_bounds) == 4 else ((0.0, False, 0.0, "", ()),) * 4)
    card_scores = tuple(item[0] for item in card_data)
    card_ready = tuple(item[1] for item in card_data)
    card_ready_confidence = tuple(item[2] for item in card_data)
    card_fingerprints = tuple(item[3] for item in card_data)
    card_descriptors = tuple(item[4] for item in card_data)
    card_visual = sum(card_scores) / len(card_scores)

    (scene, scene_confidence, battle_score, result, result_confidence,
     targets, ladder_unlocked, deck_confidence) = _classify_scene(
        frame, green_ratio, red_ratio, blue_ratio, purple_ratio,
        card_visual, ui_evidence, components,
    )
    ladder_lock_confidence = (
        ui_evidence.ladder_lock_confidence if scene is Scene.MODE_SELECT else 0.0
    )
    if ladder_lock_confidence >= 0.70:
        # A detected padlock is positive evidence of the locked state.  No
        # corresponding inference is made from the absence of a padlock.
        ladder_unlocked = False
    battle_detected = scene is Scene.BATTLE and scene_confidence >= 0.54
    left_threat = right_threat = left_support = right_support = 0.0
    enemy_clusters: tuple[VisualCluster, ...] = ()
    friendly_clusters: tuple[VisualCluster, ...] = ()
    if battle_detected:
        (left_threat, right_threat, left_support, right_support,
         enemy_clusters, friendly_clusters) = _battle_visuals(frame, arena_bounds=ui_evidence.arena_bounds)

    return GameState(
        battle_detected=battle_detected,
        elixir=elixir,
        left_threat=left_threat,
        right_threat=right_threat,
        left_support=left_support,
        right_support=right_support,
        card_scores=card_scores,
        green_ratio=green_ratio,
        red_ratio=red_ratio,
        blue_ratio=blue_ratio,
        purple_ratio=purple_ratio,
        confidence=battle_score,
        scene=scene,
        scene_confidence=scene_confidence,
        elixir_confidence=elixir_confidence,
        card_ready=card_ready,
        ladder_unlocked=ladder_unlocked,
        ladder_lock_confidence=ladder_lock_confidence,
        result=result,
        frame_width=w,
        frame_height=h,
        card_fingerprints=card_fingerprints,
        card_descriptors=card_descriptors,
        card_ready_confidence=card_ready_confidence,
        result_confidence=result_confidence,
        targets=targets,
        deck_confidence=deck_confidence,
        enemy_clusters=enemy_clusters,
        friendly_clusters=friendly_clusters,
        viewport=(0.0, 0.0, 1.0, 1.0),
        card_bounds=tuple(card_bounds),
        arena_bounds=ui_evidence.arena_bounds if battle_detected else None,
        elixir_bounds=ui_evidence.elixir_bounds if battle_detected else None,
    )
