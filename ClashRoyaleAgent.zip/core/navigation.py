"""Conservative game-flow state machine for continuous Clash Royale matches.

The agent preserves the user's existing deck.  Its only navigation actions are
those required to enter the requested mode, start a match, return from a result,
and resume from a verified battle/deck screen.  Every click requires a verified
screen-specific target; ambiguous screens are never guessed.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import time

from .vision import GameState, NavigationTarget, Scene


class FlowStage(str, Enum):
    SEARCHING = "searching"
    IN_BATTLE = "in_battle"
    SELECTING_MODE = "selecting_mode"
    STARTING_MATCH = "starting_match"
    NAVIGATING = "navigating"
    WAITING_UNKNOWN = "waiting_unknown"


class FlowAction(str, Enum):
    WAIT = "wait"
    PLAY = "play"
    OPEN_MODE_SELECT = "open_mode_select"
    SELECT_LADDER = "select_ladder"
    SELECT_PATH = "select_path"
    START_MATCH = "start_match"
    CONTINUE_RESULT = "continue_result"
    RETURN_HOME = "return_home"
    RETRY_CONNECTION = "retry_connection"


@dataclass(frozen=True)
class FlowDecision:
    stage: FlowStage
    action: FlowAction
    reason: str
    stable_frames: int
    target: NavigationTarget | None = None


class GameFlow:
    """Debounces screens and prioritizes ladder, falling back only if locked."""

    MIN_NAV_CONFIDENCE = 0.82
    STABLE_NAV_FRAMES = 5
    NAV_COOLDOWN = 2.0
    MAX_NAV_ATTEMPTS = 4
    NAV_RETRY_COOLDOWN = 24.0

    def __init__(self):
        self.stage = FlowStage.SEARCHING
        self._last_scene = Scene.UNKNOWN
        self._stable_frames = 0
        self._last_navigation_at: dict[str, float] = {}
        self._navigation_attempts: dict[str, int] = {}
        self._mode_due = True
        self._mode_opened = False
        self._selected_mode: str | None = None
        self._start_requested = False

    def mark_action_completed(self, action: FlowAction) -> None:
        if action is FlowAction.OPEN_MODE_SELECT:
            self.stage = FlowStage.SELECTING_MODE
            self._mode_opened = True
        elif action is FlowAction.SELECT_LADDER:
            self.stage = FlowStage.SELECTING_MODE
            self._selected_mode = "ladder"
        elif action is FlowAction.SELECT_PATH:
            self.stage = FlowStage.SELECTING_MODE
            self._selected_mode = "journey"
        elif action is FlowAction.START_MATCH:
            self.stage = FlowStage.STARTING_MATCH
            self._start_requested = True
        elif action is FlowAction.CONTINUE_RESULT:
            self.stage = FlowStage.NAVIGATING
            self._mode_due = True
            self._mode_opened = False
            self._selected_mode = None
            self._start_requested = False
        elif action is FlowAction.RETURN_HOME:
            self.stage = FlowStage.NAVIGATING
            self._mode_due = True
            self._mode_opened = False
        elif action is FlowAction.RETRY_CONNECTION:
            self.stage = FlowStage.STARTING_MATCH
            self._start_requested = False

    def update(self, state: GameState, *, now: float | None = None) -> FlowDecision:
        now = time.monotonic() if now is None else now
        scene = state.scene
        if scene is self._last_scene:
            self._stable_frames += 1
        else:
            self._last_scene = scene
            self._stable_frames = 1
            self._navigation_attempts.clear()

        if scene not in (Scene.MODE_SELECT, Scene.MATCHMAKING, Scene.LOADING) and self._selected_mode is not None:
            self._selected_mode = None
        if scene in (Scene.HOME, Scene.DECK, Scene.RESULT, Scene.BATTLE):
            self._start_requested = False

        if state.battle_detected and state.confidence >= 0.62 and state.scene_confidence >= 0.60:
            if self._stable_frames >= 2:
                self.stage = FlowStage.IN_BATTLE
                self._mode_due = False
                self._mode_opened = False
                self._selected_mode = None
                self._start_requested = False
                return FlowDecision(self.stage, FlowAction.PLAY,
                                    "battle scene confirmed", self._stable_frames)
            return FlowDecision(FlowStage.SEARCHING, FlowAction.WAIT,
                                "confirming battle scene", self._stable_frames)

        if scene is Scene.RECOVERY and state.scene_confidence >= 0.82:
            self.stage = FlowStage.NAVIGATING
            return self._navigation_decision(
                FlowAction.RETRY_CONNECTION,
                "a connection error is visible; retry only through its verified visible button",
                state.target("connection_retry"), now, key="connection_retry",
            )

        if scene is Scene.RESULT and state.scene_confidence >= 0.88:
            self.stage = FlowStage.NAVIGATING
            self._mode_due = True
            self._mode_opened = False
            self._selected_mode = None
            return self._navigation_decision(
                FlowAction.CONTINUE_RESULT,
                "result confirmed; continue to the lobby for the next match",
                state.target("result_continue"), now, key="result_continue",
            )

        if scene is Scene.HOME and state.scene_confidence >= 0.84:
            # A cancelled matchmaking attempt or a game-return-to-lobby event
            # must resume the requested continuous-play flow.
            if not self._mode_due:
                self._mode_due = True
                self._mode_opened = False
            if self._mode_due and not self._mode_opened:
                self.stage = FlowStage.SELECTING_MODE
                return self._navigation_decision(
                    FlowAction.OPEN_MODE_SELECT,
                    "lobby confirmed; open mode selector while preserving the current deck",
                    state.target("mode_entry"), now, key="mode_entry",
                )
            if self._mode_due and self._mode_opened:
                if self._retry_due("mode_entry", now):
                    self._mode_opened = False
                    return self._navigation_decision(
                        FlowAction.OPEN_MODE_SELECT,
                        "mode selector did not appear; retry the verified entry target",
                        state.target("mode_entry"), now, key="mode_entry",
                    )
                return FlowDecision(FlowStage.SELECTING_MODE, FlowAction.WAIT,
                                    "waiting for the mode selector", self._stable_frames)
            return FlowDecision(FlowStage.WAITING_UNKNOWN, FlowAction.WAIT,
                                "lobby recognized with no pending navigation", self._stable_frames)

        if scene is Scene.DECK and state.scene_confidence >= 0.82:
            self.stage = FlowStage.NAVIGATING
            return self._navigation_decision(
                FlowAction.RETURN_HOME,
                "deck screen detected; return using its verified Battle/Home control without editing the deck",
                state.target("deck_back"), now, key="deck_back",
            )

        if scene is Scene.MODE_SELECT and state.scene_confidence >= 0.82:
            self.stage = FlowStage.SELECTING_MODE
            self._mode_opened = False
            if self._start_requested:
                if self._retry_due("start_match", now):
                    self._start_requested = False
                    return self._navigation_decision(
                        FlowAction.START_MATCH,
                        f"{self._selected_mode or 'selected mode'} did not transition; retry the verified start target",
                        state.target("start_match"), now, key="start_match",
                    )
                return FlowDecision(FlowStage.STARTING_MATCH, FlowAction.WAIT,
                                    "start action sent; waiting for matchmaking or loading", self._stable_frames)
            if self._selected_mode is not None:
                start_target = state.target("start_match")
                if start_target is not None:
                    return self._navigation_decision(
                        FlowAction.START_MATCH,
                        f"{self._selected_mode} selected; start the match",
                        start_target, now, key="start_match",
                    )
                return FlowDecision(self.stage, FlowAction.WAIT,
                                    f"{self._selected_mode} selected; waiting for a verified start target",
                                    self._stable_frames)
            if state.ladder_unlocked is True:
                return self._navigation_decision(
                    FlowAction.SELECT_LADDER,
                    "ladder is explicitly verified as unlocked; prioritize ladder",
                    state.target("ladder"), now, key="ladder",
                )
            if state.ladder_unlocked is False:
                return self._navigation_decision(
                    FlowAction.SELECT_PATH,
                    "ladder is explicitly verified as locked; use the journey path",
                    state.target("journey"), now, key="journey",
                )
            return FlowDecision(self.stage, FlowAction.WAIT,
                                "mode selector detected but ladder unlock status is unknown; waiting for explicit evidence",
                                self._stable_frames)

        if scene in (Scene.MATCHMAKING, Scene.LOADING):
            self._selected_mode = None
            self._start_requested = False
            self._mode_due = False
            self._mode_opened = False
            self.stage = FlowStage.STARTING_MATCH
            return FlowDecision(self.stage, FlowAction.WAIT,
                                "matchmaking/loading detected; waiting for the battle scene", self._stable_frames)

        self.stage = FlowStage.WAITING_UNKNOWN
        return FlowDecision(self.stage, FlowAction.WAIT,
                            f"no safe action for scene={scene.value}", self._stable_frames)

    def _retry_due(self, key: str, now: float) -> bool:
        attempts = self._navigation_attempts.get(key, 0)
        last = self._last_navigation_at.get(key, now)
        cooldown = self.NAV_RETRY_COOLDOWN if attempts >= self.MAX_NAV_ATTEMPTS else self.NAV_COOLDOWN * 2
        return now - last >= cooldown

    def _navigation_decision(self, action: FlowAction, reason: str,
                             target: NavigationTarget | None, now: float,
                             *, key: str) -> FlowDecision:
        if self._stable_frames < self.STABLE_NAV_FRAMES:
            return FlowDecision(self.stage, FlowAction.WAIT,
                                f"debouncing {reason}", self._stable_frames)
        if target is None or target.confidence < self.MIN_NAV_CONFIDENCE:
            return FlowDecision(self.stage, FlowAction.WAIT,
                                f"{reason}; no verified visual target is available", self._stable_frames)
        attempts = self._navigation_attempts.get(key, 0)
        last_attempt = self._last_navigation_at.get(key, 0.0)
        if now - last_attempt < self.NAV_COOLDOWN:
            return FlowDecision(self.stage, FlowAction.WAIT,
                                "waiting for the previous navigation transition", self._stable_frames)
        if attempts >= self.MAX_NAV_ATTEMPTS:
            # Do not click repeatedly when the game is still animating or an
            # accessibility target is stale.  But also do not dead-end forever:
            # after a quiet retry interval, re-evaluate the same verified target.
            if now - last_attempt < self.NAV_RETRY_COOLDOWN:
                self.stage = FlowStage.WAITING_UNKNOWN
                return FlowDecision(self.stage, FlowAction.WAIT,
                                    f"{key} transition is still unconfirmed; waiting before a safe retry",
                                    self._stable_frames)
            attempts = 0
            self._navigation_attempts[key] = 0
        self._last_navigation_at[key] = now
        self._navigation_attempts[key] = attempts + 1
        return FlowDecision(self.stage, action, reason, self._stable_frames, target)
