"""Short-horizon tracking of generic arena color clusters.

The tracker intentionally preserves the distinction between a color blob and a
known Clash Royale unit. It estimates persistence and motion only; it does not
invent troop identities, hit points, or attack targets.
"""
from __future__ import annotations

from dataclasses import replace
from math import exp, hypot
import time

from .vision import ClusterTrack, GameState, Scene, VisualCluster


class TemporalBattleTracker:
    """Greedy, bounded nearest-neighbour tracker for red/blue arena blobs."""

    MAX_TRACK_AGE = 1.8
    MAX_MATCH_DISTANCE = 0.145
    MAX_TRACKS_PER_TEAM = 24
    VELOCITY_EMA = 0.42

    def __init__(self) -> None:
        self._tracks: dict[str, list[ClusterTrack]] = {"enemy": [], "friendly": []}
        self._next_id = 1
        self._last_time: float | None = None

    def reset(self) -> None:
        self._tracks = {"enemy": [], "friendly": []}
        self._last_time = None

    @staticmethod
    def _cluster_distance(track: ClusterTrack, cluster: VisualCluster) -> float:
        # Size changes are tolerated, but very different boxes should not be
        # fused merely because their centers are nearby.
        center = hypot(track.x - cluster.x, track.y - cluster.y)
        old_size = max(1e-5, track.width * track.height)
        new_size = max(1e-5, cluster.width * cluster.height)
        size_delta = min(1.0, abs(old_size - new_size) / max(old_size, new_size))
        return center + 0.025 * size_delta

    def _update_team(self, team: str, clusters: tuple[VisualCluster, ...], now: float) -> tuple[ClusterTrack, ...]:
        old = [track for track in self._tracks[team]
               if 0.0 <= now - track.last_seen <= self.MAX_TRACK_AGE]
        candidates: list[tuple[float, int, int]] = []
        for old_index, track in enumerate(old):
            for cluster_index, cluster in enumerate(clusters):
                distance = self._cluster_distance(track, cluster)
                if distance <= self.MAX_MATCH_DISTANCE:
                    candidates.append((distance, old_index, cluster_index))
        candidates.sort(key=lambda item: item[0])
        used_old: set[int] = set()
        used_new: set[int] = set()
        matched: dict[int, ClusterTrack] = {}

        for _distance, old_index, cluster_index in candidates:
            if old_index in used_old or cluster_index in used_new:
                continue
            previous, cluster = old[old_index], clusters[cluster_index]
            dt = max(0.04, min(2.0, now - previous.last_seen))
            measured_vx = max(-1.5, min(1.5, (cluster.x - previous.x) / dt))
            measured_vy = max(-1.5, min(1.5, (cluster.y - previous.y) / dt))
            vx = previous.vx * (1.0 - self.VELOCITY_EMA) + measured_vx * self.VELOCITY_EMA
            vy = previous.vy * (1.0 - self.VELOCITY_EMA) + measured_vy * self.VELOCITY_EMA
            observations = min(10_000, previous.observations + 1)
            age = max(0.0, now - (previous.last_seen - previous.age_seconds))
            confidence = max(0.0, min(1.0, cluster.confidence * (0.72 + 0.28 * min(1.0, observations / 3.0))))
            matched[cluster_index] = ClusterTrack(
                previous.track_id, cluster.x, cluster.y, vx, vy,
                cluster.width, cluster.height, cluster.area, confidence,
                age, observations, now,
            )
            used_old.add(old_index)
            used_new.add(cluster_index)

        for cluster_index, cluster in enumerate(clusters):
            if cluster_index in used_new:
                continue
            matched[cluster_index] = ClusterTrack(
                self._next_id, cluster.x, cluster.y, 0.0, 0.0,
                cluster.width, cluster.height, cluster.area,
                max(0.0, min(1.0, cluster.confidence * 0.72)),
                0.0, 1, now,
            )
            self._next_id += 1

        # Keep unmatched tracks briefly with decayed confidence. This avoids
        # dropping a unit track on one noisy frame, but stale tracks never
        # survive beyond MAX_TRACK_AGE.
        for old_index, track in enumerate(old):
            if old_index in used_old:
                continue
            age_since_seen = max(0.0, now - track.last_seen)
            if age_since_seen <= self.MAX_TRACK_AGE:
                decayed = track.confidence * exp(-age_since_seen / 0.75)
                if decayed >= 0.12:
                    matched[-(old_index + 1)] = replace(track, confidence=decayed)

        result = sorted(matched.values(), key=lambda item: item.confidence * item.area,
                        reverse=True)[:self.MAX_TRACKS_PER_TEAM]
        self._tracks[team] = result
        return tuple(result)

    def update(self, state: GameState, *, now: float | None = None) -> GameState:
        now = time.monotonic() if now is None else float(now)
        if state.scene not in (Scene.BATTLE, Scene.UNKNOWN):
            self.reset()
            return replace(state, enemy_tracks=(), friendly_tracks=())
        if state.battle_detected:
            enemy = self._update_team("enemy", state.enemy_clusters, now)
            friendly = self._update_team("friendly", state.friendly_clusters, now)
        else:
            enemy = self._update_team("enemy", (), now)
            friendly = self._update_team("friendly", (), now)
        self._last_time = now
        return replace(state, enemy_tracks=enemy, friendly_tracks=friendly)

    @staticmethod
    def lane_advance(tracks: tuple[ClusterTrack, ...], lane: int,
                     *, toward_positive_y: bool) -> float:
        """Return normalized tracked motion toward the opponent/player side."""
        total = 0.0
        for track in tracks:
            if track.lane != lane or track.observations < 2 or track.confidence < 0.30:
                continue
            velocity = track.vy if toward_positive_y else -track.vy
            if velocity <= 0.0:
                continue
            total += min(0.55, velocity * 0.20) * min(1.0, track.area * 100.0) * track.confidence
        return max(0.0, min(1.0, total))

    @staticmethod
    def predicted_position(track: ClusterTrack, horizon: float = 0.25) -> tuple[float, float]:
        horizon = max(0.0, min(0.75, float(horizon)))
        return (
            max(0.05, min(0.95, track.x + track.vx * horizon)),
            max(0.25, min(0.82, track.y + track.vy * horizon)),
        )
