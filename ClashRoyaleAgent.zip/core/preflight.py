"""Fail-closed startup checks for the selected game window."""
from __future__ import annotations

import math

from .vision import GameState, Scene, analyze_frame


MIN_STARTUP_SCENE_CONFIDENCE = 0.52
MIN_FRAME_WIDTH = 120
MIN_FRAME_HEIGHT = 240


def validate_startup_frame(frame) -> GameState:
    """Require a usable frame and a positively recognized game scene.

    A valid HWND and a non-black screenshot are not enough: starting on an
    unrelated desktop window can otherwise leave the agent waiting or, worse,
    acting on a false-positive control. Recognized loading/home/deck/mode/battle
    and recovery scenes are accepted; UNKNOWN and low-confidence scenes fail
    closed before the agent thread is created.
    """
    width = int(getattr(frame, "width", 0) or 0)
    height = int(getattr(frame, "height", 0) or 0)
    if width < MIN_FRAME_WIDTH or height < MIN_FRAME_HEIGHT:
        raise OSError("游戏窗口截图尺寸无效。")

    state = analyze_frame(frame)
    confidence = float(getattr(state, "scene_confidence", 0.0) or 0.0)
    scene = getattr(state, "scene", Scene.UNKNOWN)
    if (scene is Scene.UNKNOWN or not math.isfinite(confidence) or
            confidence < MIN_STARTUP_SCENE_CONFIDENCE):
        raise OSError(
            "无法确认所选窗口属于皇室战争游戏界面。"
            "请打开游戏并停留在大厅、模式选择、卡组、战斗或加载界面后重试。"
        )
    return state
