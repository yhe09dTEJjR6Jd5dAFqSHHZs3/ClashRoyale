# Third-party notices

## Project source code

Original project source code is licensed under the MIT License in `LICENSE`.
That license does not apply to third-party data, Supercell intellectual
property, game assets, trademarks or external materials.

## Clash Royale card metadata

`data/cards.tsv` contains a compact subset of public card metadata: base card
names, type, rarity, elixir cost, card IDs where present, Evolution eligibility
and cycle count, Hero ability labels/costs, and Champion ability labels/costs.
The metadata base is the 2026-10-20 card table published by
[clash-royale-data](https://github.com/trillllllll/clash-royale-data). The
127-card roster was cross-checked against the 9 November 2026 card list; the
Giant and Mirror Evolution flags/cycle counts were corrected from Supercell's
official [November 2026 update notes](https://support.clashroyale.com/hc/en-us/articles/57579150651419-What-s-New-November-2026).
Spirit Empress variable-cost options were checked against the current card
list. Fandom-derived names and fields are attributed to **Clash Royale Wiki
contributors** and are shared under **Creative Commons Attribution-ShareAlike
3.0 (CC BY-SA 3.0)**:
https://creativecommons.org/licenses/by-sa/3.0/

The unused legacy third-party API ID field is left blank in the bundled table.

## Combat statistics and card attributes

`data/combat_profiles.tsv` is an edited, compact subset of the 2026-10-20
`stats_by_level.csv` (`source=fandom`, base form, level 11, table 0) and
`card_attributes.csv` from
[clash-royale-data](https://github.com/trillllllll/clash-royale-data).
The underlying per-level statistics and card attributes are derived from
[Clash Royale Wiki (Fandom)](https://clashroyale.fandom.com/) and are attributed
to **Clash Royale Wiki contributors** under **CC BY-SA 3.0**:
https://creativecommons.org/licenses/by-sa/3.0/
The compact selection and field mapping are documented in `data/README.md`.

## Deliberately excluded materials

- No Supercell card artwork, screenshots, icons or game UI images are bundled.
  The source archive did not contain evidence that the artwork rights holder
authorized redistribution. The runtime instead uses offline OCR and locally
  learned, identity-verified visual fingerprints.
- No RoyaleAPI popular-deck snapshot is bundled. The prior snapshot was
  attributed to RoyaleAPI but the archive did not contain a permission grant or
  license authorizing redistribution. The runtime uses local observations,
  locally learned complete decks and explicitly low-confidence structural
  heuristics instead.
- No Deck Shop-derived recommended decks, counter/synergy tables, card win
  rates, role tables or Deck Shop card data are included. Role hints in
  `core/cards.py` are authored as broad deterministic heuristics for this
  project; they are not a copied Deck Shop dataset or a trained model.

`data/ASSET_LICENSES.json` is checked by `tools/validate_data.py`. Any future
bundled card image must have a per-file source, license and explicit
redistribution-permission record. Any future non-empty deck-prior file must
have a source, license and explicit redistribution-permission record. A mere
source URL or attribution is not accepted as permission evidence by the release
validator.

## Supercell intellectual property

Clash Royale, its characters, card artwork, game UI, names and trademarks are
owned by Supercell and/or their respective rights holders. This is an unofficial
fan project and is not affiliated with, endorsed, sponsored or specifically
approved by Supercell. Use of the game remains subject to Supercell's terms and
fan-content policy.

Localized Chinese names for newer card records and the 127-card roster were
cross-checked against the CRTool card index and card detail pages:
https://crtool.app/zh-hant/units/ (game data version 16.635.1, updated
2026-11-09). This reference is used only for short factual card names and
roster verification; no site images, executable code or recognition model is
bundled.
