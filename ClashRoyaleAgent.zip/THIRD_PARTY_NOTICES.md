# Third-party notices

## Clash Royale card metadata

`data/cards.tsv` contains a compact subset of public card metadata: base card
names, type, rarity, elixir cost, card IDs where present, evolution eligibility
and cycle count, hero ability labels/costs, and champion ability labels/costs.

The metadata base is the 2026-10-20 card table published by
[clash-royale-data](https://github.com/trillllllll/clash-royale-data). The 127-card
roster was cross-checked against the 9 November 2026 card list; the Giant and
Mirror Evolution flags/cycle counts were corrected from Supercell's official
[November 2026 update notes](https://support.clashroyale.com/hc/en-us/articles/57579150651419-What-s-New-November-2026). Spirit Empress variable-cost options were checked against the current card list. The
included Wiki-derived names and fields are attributed to **Clash Royale Wiki
contributors** and are shared under **Creative Commons Attribution-ShareAlike
3.0 (CC BY-SA 3.0)**:
https://creativecommons.org/licenses/by-sa/3.0/

Legacy card IDs and selected localized names originate from
[RoyaleAPI/cr-api-data](https://github.com/RoyaleAPI/cr-api-data).

This package deliberately excludes Deck Shop-derived data, including card-form
usage/win rates, counter/synergy tables, construction-role tags, and recommended
decks. The role hints in `core/cards.py` are authored as broad deterministic
heuristics for this project; they are not copied from Deck Shop and are not a
trained model.

The software source code and the metadata file are separate works. The
Fandom-derived metadata in `data/cards.tsv` is provided under CC BY-SA 3.0;
changes to that metadata are identified in `data/README.md`.

## Supercell intellectual property

Clash Royale, its characters, card artwork, game UI, names, and trademarks are
owned by Supercell and/or their respective rights holders. The PNG files in
`data/card_images/` were supplied by the user in `Cards.zip` and are included
only as local visual-reference inputs for this requested package; this project
makes no claim of ownership or license over that artwork. Users are responsible
for ensuring their use and redistribution are permitted by the applicable
rights holders and Supercell policies. This is an unofficial fan project and
is not affiliated with, endorsed, sponsored, or specifically approved by
Supercell. Use of the game remains subject to Supercell's terms and fan-content
policy.

Localized Chinese names for the newer card records and the 127-card roster were
cross-checked against the current CRTool card index and card detail pages:
https://crtool.app/zh-hant/units/ (game data version 16.635.1, updated 2026-11-09).
This reference is used only for short factual card names and roster verification;
no site images, executable code, or recognition model is bundled.

## Combat statistics and card attributes

`data/combat_profiles.tsv` is an edited, compact subset of the 2026-10-20
`stats_by_level.csv` (`source=fandom`, base form, level 11, table 0) and
`card_attributes.csv` from
[clash-royale-data](https://github.com/trillllllll/clash-royale-data).
The underlying per-level statistics and card attributes are derived from
[Clash Royale Wiki (Fandom)](https://clashroyale.fandom.com/) and are attributed
to **Clash Royale Wiki contributors** under **CC BY-SA 3.0**:
https://creativecommons.org/licenses/by-sa/3.0/
The compact selection and field mapping are documented in `data/README.md`.

## Opponent deck prior

`data/meta_decks.tsv` is a 20-row, one-time snapshot of RoyaleAPI's global
Ranked / Path of Legends popular decks over the previous 7 days, collected on
2026-11-25 from the [RoyaleAPI popular-decks page](https://royaleapi.com/decks/popular?time=7d&type=Ranked).
The source is [RoyaleAPI](https://royaleapi.com/); deck data is copyrighted by
RoyaleAPI. The snapshot records the page's deck order and displayed usage share;
it is a dated, non-exhaustive probabilistic prior, not a guarantee of current
meta or deck performance. Observed opponent cards remain distinct from inferred
slots. The application does not refresh this data or make network requests at
runtime.

No Deck Shop-derived recommended decks, counter/synergy tables, card win rates,
role tables or Deck Shop card data are included in this package.
