# Third-party notices

## Clash Royale card metadata

`data/cards.tsv` contains a compact subset of public card metadata: base card
names, type, rarity, elixir cost, card IDs where present, evolution eligibility
and cycle count, hero ability labels/costs, and champion ability labels/costs.

The metadata snapshot is based on the 2026-10-20 card table published by
[clash-royale-data](https://github.com/trillllllll/clash-royale-data). The
included Wiki-derived names and fields are attributed to **Clash Royale Wiki
contributors** and are shared under **Creative Commons Attribution-ShareAlike
3.0 (CC BY-SA 3.0)**:
https://creativecommons.org/licenses/by-sa/3.0/

Legacy card IDs and selected localized names originate from
[RoyaleAPI/cr-api-data](https://github.com/RoyaleAPI/cr-api-data).

This package deliberately excludes Deck Shop-derived data, including card-form
usage/win rates, counter/synergy tables, construction-role tags, and recommended
decks. The role hints in `core/cards.py` are authored as broad deterministic
heuristics for this project; they are not copied from Deck Shop and are not a
trained model.

The software source code and the metadata file are separate works. The
Fandom-derived metadata in `data/cards.tsv` is provided under CC BY-SA 3.0;
changes to that metadata are identified in `data/README.md`.

## Supercell intellectual property

Clash Royale, its characters, card artwork, game UI, names, and trademarks are
owned by Supercell and/or their respective rights holders. This package does
not bundle card artwork or game assets. It is an unofficial fan project and is
not affiliated with, endorsed, sponsored, or specifically approved by
Supercell. Use of the game remains subject to Supercell's terms and fan-content
policy.
