@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "PYTHON_CMD="
where py.exe >nul 2>nul
if not errorlevel 1 (
    for %%V in (3.15 3.14 3.13 3.12 3.11 3.10) do (
        if not defined PYTHON_CMD (
            py -%%V-64 -c "import struct,sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] < (3,16) and struct.calcsize('P') == 8 else 1)" >nul 2>nul
            if not errorlevel 1 set "PYTHON_CMD=py -%%V-64"
        )
    )
)
if not defined PYTHON_CMD (
    where python.exe >nul 2>nul
    if not errorlevel 1 (
        python.exe -c "import struct,sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] < (3,16) and struct.calcsize('P') == 8 else 1)" >nul 2>nul
        if not errorlevel 1 set "PYTHON_CMD=python.exe"
    )
)
if not defined PYTHON_CMD goto :python_missing

echo Running regression tests with supported Python 3.10-3.15 x64...
%PYTHON_CMD% -m unittest discover -s tests -v
if errorlevel 1 goto :failed

rem The release already contains a verified Windows x64 launcher. Go is only
rem needed when rebuilding launcher_windows.go itself; Python-only changes can
rem be packaged on a clean Windows 11 + supported Python installation.
set "REBUILD_LAUNCHER=0"
where go.exe >nul 2>nul
if not errorlevel 1 (
    for /f "tokens=3" %%V in ('go version') do set "GO_VERSION=%%V"
    powershell -NoProfile -Command "if ([version]('!GO_VERSION:~2!') -ge [version]'1.23') { exit 0 } else { exit 1 }" >nul 2>nul
    if not errorlevel 1 set "REBUILD_LAUNCHER=1"
)
if "%REBUILD_LAUNCHER%"=="1" goto :build_launcher
echo Go 1.23+ not found; reusing the included, verified Windows x64 launcher.
goto :build_release

:build_launcher
echo Building native Windows x64 launcher with Go !GO_VERSION!...
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -trimpath -ldflags="-s -w -H windowsgui -buildid=" -o "%~dp0ClashRoyale.exe" "%~dp0launcher_windows.go"
if errorlevel 1 goto :failed

:build_release
echo Updating MANIFEST.sha256 and creating the release ZIP...
%PYTHON_CMD% tools\build_release.py --output "%~dp0ClashRoyaleAgent_v0.21.0.zip"
if errorlevel 1 goto :failed

echo.
echo Release build completed successfully.
pause
exit /b 0

:python_missing
echo A 64-bit Python 3.10-3.15 installation is required for release builds.
pause
exit /b 1

:failed
echo.
echo Build failed. No release ZIP was produced.
pause
exit /b 1
