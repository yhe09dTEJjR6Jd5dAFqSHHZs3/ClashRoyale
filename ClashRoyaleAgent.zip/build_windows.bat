@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "PYTHON_CMD="
where py.exe >nul 2>nul
if not errorlevel 1 (
    py -3.15-64 -c "import struct,sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) and struct.calcsize('P') == 8 else 1)" >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=py -3.15-64"
)
if not defined PYTHON_CMD (
    where python.exe >nul 2>nul
    if not errorlevel 1 (
        python.exe -c "import struct,sys; raise SystemExit(0 if sys.version_info[:2] == (3,15) and struct.calcsize('P') == 8 else 1)" >nul 2>nul
        if not errorlevel 1 set "PYTHON_CMD=python.exe"
    )
)
if not defined PYTHON_CMD goto :python_missing

echo Running regression tests with Python 3.15 x64...
%PYTHON_CMD% -m unittest discover -s tests -v
if errorlevel 1 goto :failed

where go.exe >nul 2>nul
if errorlevel 1 goto :go_missing
for /f "tokens=3" %%V in ('go version') do set "GO_VERSION=%%V"
powershell -NoProfile -Command "if ([version]('%GO_VERSION:~2%') -lt [version]'1.23') { exit 1 }" >nul 2>nul
if errorlevel 1 goto :go_old

set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
echo Building native Windows x64 launcher...
go build -trimpath -ldflags="-s -w -H windowsgui -buildid=" -o "%~dp0ClashRoyale.exe" "%~dp0launcher_windows.go"
if errorlevel 1 goto :failed

echo Updating MANIFEST.sha256 and creating the release ZIP...
%PYTHON_CMD% tools\build_release.py --output "%~dp0ClashRoyaleAgent_v0.14.0.zip"
if errorlevel 1 goto :failed

echo.
echo Release build completed successfully.
pause
exit /b 0

:python_missing
echo A 64-bit Python 3.15 installation is required for release builds.
pause
exit /b 1

:go_missing
echo Go 1.23 or later is required to rebuild ClashRoyale.exe.
echo The already-delivered launcher remains unchanged; no release ZIP was generated.
pause
exit /b 1

:go_old
echo Go 1.23 or later is required. Detected: %GO_VERSION%
pause
exit /b 1

:failed
echo.
echo Build failed. No release ZIP was produced.
pause
exit /b 1
