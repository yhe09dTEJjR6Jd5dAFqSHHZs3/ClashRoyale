# Optional card-image references

No card artwork is bundled in this release. Supercell's card illustrations and
related visual assets are protected intellectual property, and the supplied
archive did not include evidence of redistribution permission.

The runtime remains functional without this directory: it uses built-in offline
OCR for visible card names and learns visual fingerprints only from verified
in-game identities, storing those samples in the user-selected workspace.

Developers may use `tools/build_card_image_catalog.py --images-dir <licensed-png-dir>`
with image files they are independently authorized to process. Do not copy those
files into a distributable release unless the rights holder's redistribution
permission and applicable attribution are documented. The release validator
rejects unlicensed bundled image assets.
