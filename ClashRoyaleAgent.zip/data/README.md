# Bundled card catalog

`cards.tsv` is a local, read-only metadata table for 127 base cards (including
four tower troops). It includes 43 evolution-eligible cards, 18 hero-eligible
cards, and 8 champions in the 2026-10-20 source snapshot.

The table is intentionally limited to names, card type, rarity, elixir cost,
legacy IDs when present, and evolution/hero/champion ability metadata. It does
not contain card images, usage rates, win rates, deck lists, or third-party
counter data. Missing/unknown elixir costs and unavailable IDs remain blank.

The OCR engine uses these names as an offline vocabulary. It does not train a
model from this data and does not need network access at runtime.

Attribution and data terms are in `../THIRD_PARTY_NOTICES.md`. Fandom-derived
metadata is CC BY-SA 3.0; this table is a compact, edited subset of the cited
2026-10-20 snapshot.
