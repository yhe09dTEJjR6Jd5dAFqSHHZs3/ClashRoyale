# Bundled card metadata and visual references

`cards.tsv` is a local, read-only metadata table for 127 cards (including four
tower troops). The roster is checked against the 127-card collection list
current on 2026-11-09; the November 2026 Supercell update adds the Giant and
Mirror Evolution flags, bringing the table to 45 evolution-eligible cards,
18 hero-eligible cards, and 8 champions. It records known fixed elixir costs,
explicit variable-cost options/flags, legacy IDs when present, and
evolution/hero/champion ability metadata.

`card_images/` contains 190 PNG visual references supplied in the user's
`Cards.zip`: 127 base/champion card images, 45 Evolution images, and 18 Hero
images. These files are visual references only; they do not indicate that a
user owns a card or know its level.

`card_visual_catalog.json` is the precomputed local visual index for those
images. It stores a 64-bit difference hash and 131-dimensional colour/luminance
descriptor per image, linked to the exact card key and form in `cards.tsv`.
`core/deck_manager.py` merges these read-only references with optional
workspace-local OCR samples. User-captured samples supersede the bundled
reference only for the same card/form; conflicting identities are rejected. When
an OCR-verified card name is visible after an icon update, the current fingerprint
is added as another local sample. Unlisted cards are stored as anonymous visual
profiles by `DeckManager`; no name, type, or role is invented for them.

Regenerate the descriptor file with the standard-library-only tool:

```powershell
py -3.15-64 tools\build_card_image_catalog.py
```

The tool validates the full card/form coverage before writing the output. It
does not use Pillow, pretrained models, cloud services, network access, or
manually assigned ownership/level information. The runtime may append verified live-game samples to
`ClashRoyaleAgent/card_catalog.json` inside the user-selected workspace. A
complete bundled catalog does not require a first-run collection-screen scan;
verified OCR identities can refresh visual references opportunistically while
playing.

Unknown IDs, unavailable localized names, and unknown costs remain blank.
Spirit Empress records its 3/6 elixir options; Mirror is marked as
variable-cost. The OCR engine uses bundled Simplified/Traditional/English
names as an offline vocabulary. On Windows it also asks the built-in NLS API
for cached Chinese script aliases; no external conversion package is required.
It does not train a model from this data and does not need network access at
runtime.

Attribution and data terms are in `../THIRD_PARTY_NOTICES.md`. Fandom-derived
metadata is CC BY-SA 3.0; the table is a compact, edited subset of the
2026-10-20 metadata snapshot with later card-roster and official Evolution
corrections documented there. The card-art PNGs are user-supplied inputs and
remain subject to their original intellectual-property rights.
