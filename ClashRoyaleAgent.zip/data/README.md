# Bundled card metadata and combat profiles

`cards.tsv` contains a local, read-only metadata table for 127 cards (including
four tower troops). The roster was checked against the 127-card collection list
current on 2026-11-09. The November 2026 Supercell update adds the Giant and
Mirror Evolution flags, bringing the table to 45 evolution-eligible cards, 18
hero-eligible cards, and 8 champions. It records known fixed elixir costs,
explicit variable-cost options/flags, and Evolution/Hero/Champion ability
metadata. The unused legacy API ID field is deliberately blank in this release;
unknown localized names and costs remain blank rather than being guessed.

`combat_profiles.tsv` contains 127 base-card records. Its numeric combat values
are the level-11 `source=fandom`, `form=base`, `table=0` rows from the
2026-10-20 snapshot of `clash-royale-data`, joined to the corresponding
`card_attributes.csv` fields (target class, transport, movement speed, range,
attack cadence, count, splash, projectile speed and spell/building attributes).
The file is a compact, edited subset; missing cells mean that the source did not
provide a value or that the runtime deliberately does not guess it. The
simulator scales known level-dependent values by the documented
`1.1^(level-11)` rule.

The combat profiles do **not** constitute a private-engine specification. They
do not fully encode every spawned sub-unit, evolution/hero modifier, charge,
knockback, collision/hitbox, retarget rule, status interaction, tower-troop
variant or current hotfix. The runtime uses a bounded deterministic
micro-simulation with bridge-corridor routing, arena-relative tower proxies and
staged spawn handling for selected spells. It reduces confidence when form,
level, health or identity is unknown. Spell coverage uses explicit per-spell
rules in `core/combat.py`.

## Visual references and opponent deck priors

The default release intentionally bundles **no card-art PNG files** and no
third-party popular-deck snapshot. The original archive did not provide
redistribution permission for the underlying game artwork or RoyaleAPI deck
snapshot. Attribution alone does not establish those rights. The release
validator rejects image assets without per-file source/license/redistribution
records and rejects non-empty deck priors without a documented permission
record (`ASSET_LICENSES.json`).

`card_visual_catalog.json` is a valid empty version-1 index. This does not
prevent normal use: the runtime uses built-in Simplified/Traditional Chinese
and English OCR vocabulary, then learns visual fingerprints only when a card
identity is independently verified. These samples are stored in
`ClashRoyaleAgent/card_catalog.json` inside the user-selected workspace. When
there is no complete local card catalog, the collection scanner may opportunistically
learn from a safely identified collection screen; it does not invent names,
ownership or levels.

`meta_decks.tsv` is intentionally header-only. `OpponentDeckInferencer` uses
locally observed opponent cards, complete decks learned from high-confidence
matches in the user-selected workspace, and deterministic role/curve-balanced
seed decks. The latter are structural hypotheses, not popular-deck statistics;
when no empirical complete-deck prior exists, inferred confidence is capped at
0.24. Once exactly eight different opponent cards are directly observed at high
confidence, the candidate is the directly observed deck.

## Real battle evaluation

No real gameplay screenshots are included in this release. The synthetic and
adaptive UI fixtures are regression inputs only, not accuracy evidence.
`tests/fixtures/real_battle/README.md` defines the manual unit-box annotation
schema. `tools/evaluate_vision.py` compares an independently learned
`unit_visual_profiles.json` against those annotations and reports precision,
recall, F1 and support. The test labels are never used to train the recognizer.

`tools/evaluate_agent.py` aggregates explicit, confidence-gated outcomes from
local `.crr.gz` replays. It reports sample size, result-label coverage, win/loss/
draw counts, a Wilson interval for the observed win rate excluding draws, and
per-card action verification rates. It does not infer missing outcomes or claim
future performance.

## Attribution and terms

- `cards.tsv` includes a compact, edited subset of public metadata based on
  `clash-royale-data`, Supercell's November 2026 update notes and cross-checks
  against CRTool. Fandom-derived fields are attributed to Clash Royale Wiki
  contributors under **CC BY-SA 3.0**.
- `combat_profiles.tsv` is an edited subset of `clash-royale-data` / Clash Royale
  Wiki level-11 base-form attributes, also attributed under **CC BY-SA 3.0**.
- `core/cards.py` role hints are project-authored deterministic heuristics, not
  copied from Deck Shop and not a trained model.
- No Deck Shop recommended-deck, counter, synergy, role or win-rate data is
  included. No RoyaleAPI deck prior or card artwork is bundled.

See `../THIRD_PARTY_NOTICES.md` for source URLs, attribution and the separation
between project source-code licensing and third-party data terms.

## Snapshot integrity

`SNAPSHOT.json` records dates, row counts and SHA-256 hashes for the card table,
combat profiles, optional visual catalog, optional image tree, asset-license
manifest and header-only opponent-prior file. Run:

```powershell
py -3-64 tools\validate_data.py
```

After an intentional, authorized data update, review its source and
redistribution rights, update `ASSET_LICENSES.json`, then run
`py -3-64 tools\validate_data.py --refresh`. The release builder revalidates the
snapshot before packaging. Runtime remains offline; the validator never
contacts a network service.
