# Bundled card metadata and visual references

`cards.tsv` is a local, read-only metadata table for 127 cards (including four
tower troops). The roster is checked against the 127-card collection list
current on 2026-11-09; the November 2026 Supercell update adds the Giant and
Mirror Evolution flags, bringing the table to 45 evolution-eligible cards,
18 hero-eligible cards, and 8 champions. It records known fixed elixir costs,
explicit variable-cost options/flags, legacy IDs when present, and
evolution/hero/champion ability metadata.

`card_images/` contains 190 PNG visual references supplied in the user's
`Cards.zip`: 127 base/champion card images, 45 Evolution images, and 18 Hero
images. These files are visual references only; they do not indicate that a
user owns a card or know its level.

`card_visual_catalog.json` is the precomputed local visual index for those
images. It stores a 64-bit difference hash and 131-dimensional colour/luminance
descriptor per image, linked to the exact card key and form in `cards.tsv`.
`core/deck_manager.py` merges these read-only references with optional
workspace-local OCR samples. User-captured samples supersede the bundled
reference only for the same card/form; conflicting identities are rejected. When
an OCR-verified card name is visible after an icon update, the current fingerprint
is added as another local sample. Unlisted cards are stored as anonymous visual
profiles by `DeckManager`; no name, type, or role is invented for them.

Regenerate the descriptor file with the standard-library-only tool:

```powershell
py -3-64 tools\build_card_image_catalog.py
```

The tool validates the full card/form coverage before writing the output. It
does not use Pillow, pretrained models, cloud services, network access, or
manually assigned ownership/level information. The runtime may append verified live-game samples to
`ClashRoyaleAgent/card_catalog.json` inside the user-selected workspace. A
complete bundled catalog does not require a first-run collection-screen scan;
verified OCR identities can refresh visual references opportunistically while
playing.

Unknown IDs, unavailable localized names, and unknown costs remain blank.
Spirit Empress records its 3/6 elixir options; Mirror is marked as
variable-cost. The OCR engine uses bundled Simplified/Traditional/English
names as an offline vocabulary. On Windows it also asks the built-in NLS API
for cached Chinese script aliases; no external conversion package is required.
It does not train a model from this data and does not need network access at
runtime.

Attribution and data terms are in `../THIRD_PARTY_NOTICES.md`. Fandom-derived
metadata is CC BY-SA 3.0; the table is a compact, edited subset of the
2026-10-20 metadata snapshot with later card-roster and official Evolution
corrections documented there. The card-art PNGs are user-supplied inputs and
remain subject to their original intellectual-property rights.

## Combat profiles and opponent deck priors (Agent 0.25.0)

`combat_profiles.tsv` contains 127 base-card records. Its numeric combat values
are the level-11 `source=fandom`, `form=base`, `table=0` rows from the
2026-10-20 snapshot of `clash-royale-data`, joined to the corresponding
`card_attributes.csv` fields (target class, transport, movement speed, range,
attack cadence, count, splash, projectile speed and spell/building attributes).
The file is a compact, edited subset; missing cells mean that the source did not
provide a value or that the runtime deliberately does not guess it. The
simulator scales known level-dependent values by the Wiki's documented
`1.1^(level-11)` rule.

The combat profiles do **not** constitute a private-engine specification.
They do not fully encode every spawned sub-unit, evolution/hero modifier,
charge, knockback, collision/hitbox, retarget rule, status interaction,
tower-troop variant or current hotfix. The runtime uses a bounded deterministic
micro-simulation with bridge-corridor routing, arena-relative tower proxies and
staged spawn handling for selected spells; it reduces confidence when form,
level, health or identity is unknown. Spell coverage uses explicit per-spell
rules in `core/combat.py`.

`meta_decks.tsv` contains 20 ranked rows from RoyaleAPI's global Ranked / Path
of Legends popular-decks page, using its previous-7-day window and displayed
usage share, collected 2026-11-25. The source page is
https://royaleapi.com/decks/popular?time=7d&type=Ranked. It is a dated prior,
not an exhaustive deck registry or a guarantee of current performance.

Agent 0.25.0 no longer treats those 20 decks as the full opponent vocabulary.
`OpponentDeckInferencer` completes the best seed decks with cards from the full
local playable-card catalog (123 cards), using role balance, elixir curve,
co-occurrence and locally observed complete decks. It can emit up to 128
open-world hypotheses in addition to the measured 20-deck seed prior. These are
generated hypotheses, not 128 verified popular decks or an external meta-data
snapshot. Every observed opponent card is retained in each candidate; after
exactly eight different cards are observed at high confidence, the candidate
collapses to that observed deck. Complete eight-card decks are stored only in the user-selected
workspace as `opponent_model.json`; no network refresh is performed.

The tactical decision layer also searches up to three consecutive plays (including the current first move) from the
currently visible four-card hand and evaluates up to eight opponent posterior
branches. Search has a 22 ms hard time budget and a 220-node cap; it returns the
best fully evaluated line when the budget expires. It deliberately does not
invent unknown replacement draws or the opponent's exact elixir. Cross-match
sequence memory is stored locally in `tactical_memory.json` and learns only
from confirmed deployments plus high-confidence match outcomes. The offline
benchmark passes both search and memory into the policy path and reports their
actual invocation counts; the bundled synthetic battle fixture checks routing
only and is not a real-game accuracy sample.

`core/semantics.py` does not load a third-party model. It learns a small local
48-dimensional appearance prototype only when a card identity is verified by
the player's hand/action or a high-confidence OCR label spatially adjacent to
an enemy track. A prototype needs at least three samples before it can assign a
semantic unit identity. The resulting `unit_visual_profiles.json` is stored only
inside the user-selected workspace.

Source and attribution details are in `../THIRD_PARTY_NOTICES.md`. The Wiki
attributes remain CC BY-SA 3.0; RoyaleAPI deck data remains copyrighted by
RoyaleAPI and is included as a dated, attributed one-time snapshot. No Deck Shop
recommended-deck, counter, synergy, role or win-rate data is included.
