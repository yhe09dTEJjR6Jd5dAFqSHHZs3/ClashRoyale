//go:build windows

// ClashRoyale.exe is a native Windows x64 launcher for the local Python app.
// It selects an installed 64-bit Python 3.10+ interpreter and never
// downloads a runtime, package, or model.
package main

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

type pythonCandidate struct {
	exe    string
	prefix []string
}

func showError(message string) {
	user32 := syscall.NewLazyDLL("user32.dll")
	messageBox := user32.NewProc("MessageBoxW")
	title, _ := syscall.UTF16PtrFromString("Clash Royale Agent")
	body, _ := syscall.UTF16PtrFromString(message)
	const mbIconError = 0x00000010
	const mbSetForeground = 0x00010000
	_, _, _ = messageBox.Call(0, uintptr(unsafe.Pointer(body)), uintptr(unsafe.Pointer(title)), mbIconError|mbSetForeground)
}

func firstExisting(paths ...string) string {
	for _, candidate := range paths {
		if candidate == "" {
			continue
		}
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate
		}
	}
	return ""
}

func registryString(root syscall.Handle, subkey, valueName string) string {
	keyPath, err := syscall.UTF16PtrFromString(subkey)
	if err != nil {
		return ""
	}
	const keyWow64_64Key = 0x0100
	var key syscall.Handle
	if err := syscall.RegOpenKeyEx(root, keyPath, 0, syscall.KEY_READ|keyWow64_64Key, &key); err != nil {
		return ""
	}
	defer syscall.RegCloseKey(key)

	var valuePtr *uint16
	if valueName != "" {
		valuePtr, err = syscall.UTF16PtrFromString(valueName)
		if err != nil {
			return ""
		}
	}
	var valueType uint32
	var byteCount uint32
	if err := syscall.RegQueryValueEx(key, valuePtr, nil, &valueType, nil, &byteCount); err != nil {
		return ""
	}
	if valueType != syscall.REG_SZ && valueType != syscall.REG_EXPAND_SZ {
		return ""
	}
	if byteCount < 2 || byteCount > 32*1024 {
		return ""
	}
	buffer := make([]uint16, (byteCount+1)/2)
	if err := syscall.RegQueryValueEx(key, valuePtr, nil, &valueType,
		(*byte)(unsafe.Pointer(&buffer[0])), &byteCount); err != nil {
		return ""
	}
	value := syscall.UTF16ToString(buffer)
	if valueType == syscall.REG_EXPAND_SZ {
		value = os.ExpandEnv(value)
	}
	return strings.TrimSpace(value)
}

func registryPythonPaths() []string {
	roots := []syscall.Handle{syscall.HKEY_CURRENT_USER, syscall.HKEY_LOCAL_MACHINE}
	versions := []string{
		"3.15", "3.15-64", "3.14", "3.14-64", "3.13", "3.13-64",
		"3.12", "3.12-64", "3.11", "3.11-64", "3.10", "3.10-64",
	}
	paths := make([]string, 0, 24)
	for _, root := range roots {
		for _, version := range versions {
			key := `Software\Python\PythonCore\` + version + `\InstallPath`
			if executable := registryString(root, key, "ExecutablePath"); executable != "" {
				paths = append(paths, executable)
			}
			if directory := registryString(root, key, ""); directory != "" {
				paths = append(paths, filepath.Join(directory, "python.exe"))
			}
		}
	}
	return paths
}

func probePython(candidate pythonCandidate, appDir string) bool {
	// Validate the actual interpreter selected by py.exe, including bitness.
	const probe = "import struct,sys;sys.exit(0 if sys.version_info[:2]>=(3,10) and sys.version_info.releaselevel=='final' and struct.calcsize('P')==8 else 31)"
	args := append([]string{}, candidate.prefix...)
	args = append(args, "-c", probe)
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, candidate.exe, args...)
	cmd.Dir = appDir
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return cmd.Run() == nil
}

func pythonCommand(appDir string) (string, []string) {
	candidates := make([]pythonCandidate, 0, 64)
	seen := make(map[string]bool)
	add := func(exe string, prefix ...string) {
		if exe == "" {
			return
		}
		key := strings.ToLower(exe + "|" + strings.Join(prefix, " "))
		if !seen[key] {
			seen[key] = true
			candidates = append(candidates, pythonCandidate{exe: exe, prefix: prefix})
		}
	}

	// Prefer a recent interpreter, then fall back to the generic Python 3
	// launcher selector. The probe rejects Python <3.10 and 32-bit builds.
	versions := []string{"3.15", "3.14", "3.13", "3.12", "3.11", "3.10"}
	if path, err := exec.LookPath("py.exe"); err == nil {
		for _, version := range versions {
			add(path, "-"+version+"-64")
		}
		add(path, "-3-64")
	} else if path, err := exec.LookPath("py"); err == nil {
		for _, version := range versions {
			add(path, "-"+version+"-64")
		}
		add(path, "-3-64")
	}

	local := os.Getenv("LOCALAPPDATA")
	programFiles := os.Getenv("ProgramFiles")
	programFilesX86 := os.Getenv("ProgramFiles(x86)")
	for _, version := range versions {
		compact := strings.ReplaceAll(version, ".", "")
		for _, path := range []string{
			filepath.Join(local, "Programs", "Python", "Python"+compact, "python.exe"),
			filepath.Join(programFiles, "Python"+compact, "python.exe"),
			filepath.Join(programFilesX86, "Python"+compact, "python.exe"),
			filepath.Join(`C:\`, "Python"+compact, "python.exe"),
		} {
			add(firstExisting(path))
		}
	}
	// PATH may expose a generic python.exe/python3.exe even when py.exe is
	// absent. The probe below rejects 32-bit and unsupported interpreters.
	for _, version := range versions {
		if path, err := exec.LookPath("python" + version + ".exe"); err == nil {
			add(path)
		}
	}
	for _, command := range []string{"python.exe", "python3.exe"} {
		if path, err := exec.LookPath(command); err == nil {
			add(path)
		}
	}
	for _, path := range registryPythonPaths() {
		add(firstExisting(path))
	}

	for _, candidate := range candidates {
		if probePython(candidate, appDir) {
			return candidate.exe, candidate.prefix
		}
	}
	return "", nil
}

func main() {
	exePath, err := os.Executable()
	if err != nil {
		showError("无法定位程序目录：" + err.Error())
		return
	}
	appDir := filepath.Dir(exePath)
	scriptPath := filepath.Join(appDir, "ClashRoyale.py")
	if info, statErr := os.Stat(scriptPath); statErr != nil || info.IsDir() {
		showError("缺少 ClashRoyale.py。请将完整压缩包解压到同一文件夹后再运行。")
		return
	}

	pythonExe, prefixArgs := pythonCommand(appDir)
	if pythonExe == "" {
		showError("未找到可用的稳定版 64 位 Python 3.10 或更高版本。程序已检查 py.exe、PATH、常见安装路径和 Python 注册表安装信息；请安装 Python 3.10+ x64。程序内置原生 Windows 界面，不要求安装 Tkinter。")
		return
	}

	args := append([]string{}, prefixArgs...)
	args = append(args, scriptPath)
	cmd := exec.Command(pythonExe, args...)
	cmd.Dir = appDir
	cmd.Env = append(os.Environ(),
		"PYTHONDONTWRITEBYTECODE=1",
		"PYTHONUTF8=1",
		"PYTHONIOENCODING=utf-8",
		"PYTHONNOUSERSITE=1",
	)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	output, runErr := cmd.CombinedOutput()
	if runErr != nil {
		message := "Python 程序启动失败：\n" + runErr.Error()
		if trimmed := strings.TrimSpace(string(output)); trimmed != "" {
			message += "\n\n" + trimmed
		}
		if len(message) > 3500 {
			message = message[:3500] + "\n…"
		}
		showError(fmt.Sprintf("%s", message))
	}
}
