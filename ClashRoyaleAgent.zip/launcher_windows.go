//go:build windows

// ClashRoyale.exe is a native Windows x64 launcher for the local Python app.
// It selects only an exact 64-bit Python 3.15 interpreter and never downloads
// a runtime or model.
package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

type pythonCandidate struct {
	exe    string
	prefix []string
}

func showError(message string) {
	user32 := syscall.NewLazyDLL("user32.dll")
	messageBox := user32.NewProc("MessageBoxW")
	title, _ := syscall.UTF16PtrFromString("Clash Royale Agent")
	body, _ := syscall.UTF16PtrFromString(message)
	const mbIconError = 0x00000010
	const mbSetForeground = 0x00010000
	_, _, _ = messageBox.Call(0, uintptr(unsafe.Pointer(body)), uintptr(unsafe.Pointer(title)), mbIconError|mbSetForeground)
}

func firstExisting(paths ...string) string {
	for _, candidate := range paths {
		if candidate == "" {
			continue
		}
		if info, err := os.Stat(candidate); err == nil && !info.IsDir() {
			return candidate
		}
	}
	return ""
}

func probePython(candidate pythonCandidate, appDir string) bool {
	// Validate the actual interpreter selected by py.exe, including bitness.
	const probe = "import struct,sys;import tkinter;sys.exit(0 if sys.version_info[:2]==(3,15) and struct.calcsize('P')==8 else 31)"
	args := append([]string{}, candidate.prefix...)
	args = append(args, "-c", probe)
	cmd := exec.Command(candidate.exe, args...)
	cmd.Dir = appDir
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return cmd.Run() == nil
}

func pythonCommand(appDir string) (string, []string) {
	candidates := make([]pythonCandidate, 0, 8)
	seen := make(map[string]bool)
	add := func(exe string, prefix ...string) {
		if exe == "" {
			return
		}
		key := strings.ToLower(exe + "|" + strings.Join(prefix, " "))
		if !seen[key] {
			seen[key] = true
			candidates = append(candidates, pythonCandidate{exe: exe, prefix: prefix})
		}
	}

	// The launcher may exist without a matching 3.15 installation. Probe it,
	// then continue to direct installation paths rather than failing early.
	if path, err := exec.LookPath("py.exe"); err == nil {
		add(path, "-3.15-64")
	} else if path, err := exec.LookPath("py"); err == nil {
		add(path, "-3.15-64")
	}

	local := os.Getenv("LOCALAPPDATA")
	programFiles := os.Getenv("ProgramFiles")
	programFilesX86 := os.Getenv("ProgramFiles(x86)")
	for _, path := range []string{
		filepath.Join(local, "Programs", "Python", "Python315", "python.exe"),
		filepath.Join(programFiles, "Python315", "python.exe"),
		filepath.Join(programFilesX86, "Python315", "python.exe"),
		`C:\Python315\python.exe`,
	} {
		add(firstExisting(path))
	}
	if path, err := exec.LookPath("python3.15.exe"); err == nil {
		add(path)
	}

	for _, candidate := range candidates {
		if probePython(candidate, appDir) {
			return candidate.exe, candidate.prefix
		}
	}
	return "", nil
}

func main() {
	exePath, err := os.Executable()
	if err != nil {
		showError("无法定位程序目录：" + err.Error())
		return
	}
	appDir := filepath.Dir(exePath)
	scriptPath := filepath.Join(appDir, "ClashRoyale.py")
	if info, statErr := os.Stat(scriptPath); statErr != nil || info.IsDir() {
		showError("缺少 ClashRoyale.py。请将完整压缩包解压到同一文件夹后再运行。")
		return
	}

	pythonExe, prefixArgs := pythonCommand(appDir)
	if pythonExe == "" {
		showError("未找到可用的 64 位 Python 3.15（且包含 Tkinter）。程序已检查 py.exe 和常见安装路径；请安装 Python 3.15 x64 并选择包含 Tcl/Tk 的安装。")
		return
	}

	args := append([]string{}, prefixArgs...)
	args = append(args, scriptPath)
	cmd := exec.Command(pythonExe, args...)
	cmd.Dir = appDir
	cmd.Env = append(os.Environ(),
		"PYTHONDONTWRITEBYTECODE=1",
		"PYTHONUTF8=1",
		"PYTHONIOENCODING=utf-8",
	)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	output, runErr := cmd.CombinedOutput()
	if runErr != nil {
		message := "Python 程序启动失败：\n" + runErr.Error()
		if trimmed := strings.TrimSpace(string(output)); trimmed != "" {
			message += "\n\n" + trimmed
		}
		if len(message) > 3500 {
			message = message[:3500] + "\n…"
		}
		showError(fmt.Sprintf("%s", message))
	}
}
