from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tools.build_release import (MAX_RELEASE_BYTES, REQUIRED_TREE_FILES, ROOT,
                                 ROOT_DIRS, ROOT_FILES, payload_files,
                                 verify_windows_x64_launcher)


class ReleaseTests(unittest.TestCase):
    def test_release_requires_latest_acceptance_spec_and_complete_sources(self):
        self.assertIn("AGENTS202611241432.md", ROOT_FILES)
        self.assertNotIn("AGENTS202611241223.md", ROOT_FILES)
        names = {path.relative_to(ROOT).as_posix() for path in payload_files()}
        self.assertIn("AGENTS202611241432.md", names)
        self.assertIn("README.md", names)
        self.assertIn("requirements.txt", names)
        self.assertIn("requirements-build.txt", names)
        self.assertIn("ClashRoyale.exe", names)
        self.assertIn("core/agent.py", names)
        self.assertIn("core/vision.py", names)
        self.assertIn("core/native_ui.py", names)
        self.assertIn("core/tactics.py", names)
        self.assertIn("core/tracking.py", names)
        self.assertIn("tests/test_core.py", names)
        self.assertIn("tests/test_release.py", names)
        self.assertNotIn("AGENTS202611241351.md", names)
        self.assertNotIn("AGENTS202611240750.md", names)
        self.assertIn('APP_VERSION = "0.14.0"', (ROOT / "core" / "__init__.py").read_text(encoding="utf-8"))
        acceptance = (ROOT / "AGENTS202611241432.md").read_text(encoding="utf-8")
        self.assertIn("Windows 11 x64", acceptance)
        self.assertIn("不大于1GB", acceptance)

    def test_release_requires_a_valid_windows_x64_pe32_plus_launcher(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ClashRoyale.exe"
            data = bytearray(256)
            data[:2] = b"MZ"
            data[0x3C:0x40] = (128).to_bytes(4, "little")
            data[128:132] = b"PE\0\0"
            data[132:134] = (0x8664).to_bytes(2, "little")
            data[152:154] = (0x20B).to_bytes(2, "little")
            data[220:222] = (2).to_bytes(2, "little")
            path.write_bytes(data)
            verify_windows_x64_launcher(path)
            data[132:134] = (0x14C).to_bytes(2, "little")
            path.write_bytes(data)
            with self.assertRaises(SystemExit):
                verify_windows_x64_launcher(path)
            data[132:134] = (0x8664).to_bytes(2, "little")
            data[220:222] = (3).to_bytes(2, "little")
            path.write_bytes(data)
            with self.assertRaises(SystemExit):
                verify_windows_x64_launcher(path)

    def test_release_fails_if_required_source_directory_is_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in ROOT_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            for name in ROOT_DIRS:
                (root / name).mkdir(parents=True, exist_ok=True)
            for name in REQUIRED_TREE_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            with patch("tools.build_release.ROOT", root):
                self.assertTrue(payload_files())
                shutil.rmtree(root / "core")
                with self.assertRaises(SystemExit):
                    payload_files()

    def test_release_fails_if_a_critical_module_is_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in ROOT_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            for name in ROOT_DIRS:
                (root / name).mkdir(parents=True, exist_ok=True)
            for name in REQUIRED_TREE_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            (root / "core" / "agent.py").unlink()
            with patch("tools.build_release.ROOT", root):
                with self.assertRaises(SystemExit):
                    payload_files()

    def test_release_size_limit_is_strictly_below_one_decimal_gigabyte(self):
        self.assertEqual(MAX_RELEASE_BYTES, 1_000_000_000)


if __name__ == "__main__":
    unittest.main()
