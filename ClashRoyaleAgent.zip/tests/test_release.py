from __future__ import annotations

import unittest
from pathlib import Path

from tools.build_release import MAX_RELEASE_BYTES, ROOT, ROOT_FILES, payload_files


class ReleaseTests(unittest.TestCase):
    def test_release_requires_latest_acceptance_spec_and_complete_sources(self):
        self.assertIn("AGENTS202611240750.md", ROOT_FILES)
        self.assertNotIn("AGENTS202611232320.md", ROOT_FILES)
        names = {path.relative_to(ROOT).as_posix() for path in payload_files()}
        self.assertIn("AGENTS202611240750.md", names)
        self.assertIn("ClashRoyale.exe", names)
        self.assertIn("core/agent.py", names)
        self.assertIn("core/vision.py", names)
        self.assertIn("tests/test_core.py", names)
        self.assertIn("tests/test_release.py", names)
        self.assertNotIn("AGENTS202611232320.md", names)

    def test_release_size_limit_is_strictly_below_one_decimal_gigabyte(self):
        self.assertEqual(MAX_RELEASE_BYTES, 1_000_000_000)


if __name__ == "__main__":
    unittest.main()
