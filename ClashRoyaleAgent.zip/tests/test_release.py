from __future__ import annotations

import shutil
import tempfile
from dataclasses import replace
import unittest
from pathlib import Path
from unittest.mock import patch

from tools.build_release import (MAX_RELEASE_BYTES, REQUIRED_TREE_FILES, ROOT,
                                 ROOT_DIRS, ROOT_FILES, payload_files,
                                 verify_launcher_record, verify_windows_x64_launcher,
                                 write_launcher_record)
from tools.benchmark_vision import benchmark_frames
from core.cards import CardDatabase
from core.deck_manager import DeckManager


class ReleaseTests(unittest.TestCase):
    def test_release_requires_latest_acceptance_spec_and_complete_sources(self):
        self.assertIn("AGENTS202611241637.md", ROOT_FILES)
        self.assertNotIn("AGENTS202611241432.md", ROOT_FILES)
        self.assertIn("data", ROOT_DIRS)
        names = {path.relative_to(ROOT).as_posix() for path in payload_files()}
        for required in (
            "AGENTS202611241637.md", "README.md", "THIRD_PARTY_NOTICES.md",
            "launcher_windows.build.json",
            "requirements.txt", "requirements-build.txt", "ClashRoyale.exe",
            "core/agent.py", "core/vision.py", "core/ui_adaptive.py", "core/native_ui.py", "core/card_catalog.py",
            "core/runtime.py", "core/preflight.py", "core/planner.py", "core/episode.py", "core/tray.py",
            "core/tactics.py", "core/tracking.py", "core/cards.py",
            "core/offline_ocr.py", "core/opponent.py", "core/dxgi.py",
            "core/combat.py", "core/semantics.py", "core/tactical_memory.py", "core/tactical_search.py",
            "data/cards.tsv", "data/card_visual_catalog.json", "data/combat_profiles.tsv",
            "data/meta_decks.tsv", "tests/test_semantic_combat.py", "tests/test_tactical_upgrade.py",
            "tools/build_card_image_catalog.py", "data/README.md", "tests/test_core.py",
            "tools/benchmark_vision.py",
            "tests/test_new_features.py", "tests/test_adaptive.py", "tests/test_release.py",
            "tests/fixtures/adaptive_ui/labels.tsv",
            "tests/fixtures/adaptive_ui/01_loading.png",
            "tests/fixtures/adaptive_ui/05_mode_select.png",
            "tests/fixtures/adaptive_ui/09_deck.png",
            "tests/fixtures/synthetic_battle/README.md",
            "tests/fixtures/synthetic_battle/labels.json",
            "tests/fixtures/synthetic_battle/01_battle_synthetic.png",
        ):
            self.assertIn(required, names)
        self.assertEqual(len([name for name in names
                              if name.startswith("data/card_images/") and name.endswith(".png")]), 190)
        self.assertNotIn("AGENTS202611241432.md", names)
        self.assertIn('APP_VERSION = "0.25.0"', (ROOT / "core" / "__init__.py").read_text(encoding="utf-8"))
        acceptance = (ROOT / "AGENTS202611241637.md").read_text(encoding="utf-8")
        self.assertIn("Windows 11 x64", acceptance)
        self.assertIn("黑匣子", acceptance)

    def test_benchmark_tool_reports_stage_percentiles(self):
        fixture = ROOT / "tests" / "fixtures" / "adaptive_ui" / "05_mode_select.png"
        report = benchmark_frames([fixture], loops=1, max_width=240, warmup_frames=0)
        self.assertEqual(report["measured_frames"], 1)
        self.assertIn("p50_ms", report["latency"]["vision"])
        self.assertIn("p95_ms", report["latency"]["tracking"])
        self.assertIn("p95_ms", report["latency"]["semantic"])
        self.assertIn("p95_ms", report["latency"]["decision"])
        self.assertIn("does not measure win rate", report["limitations"][-1])

    def test_benchmark_exercises_tactical_search_on_battle_frames(self):
        fixture = ROOT / "tests" / "fixtures" / "synthetic_battle" / "01_battle_synthetic.png"
        cards = CardDatabase()
        keys = ("ice-spirit", "hog-rider", "musketeer", "fireball")

        def verified_synthetic_hand(_manager, state):
            return replace(
                state, card_names=keys, card_costs=(1.0, 4.0, 4.0, 4.0),
                card_roles=tuple(cards.roles_for(key) for key in keys),
                card_ready=(True, True, True, True),
                card_ready_confidence=(0.95, 0.95, 0.95, 0.95),
                card_scores=(0.9, 0.8, 0.7, 0.6), elixir=10.0,
                elixir_confidence=1.0,
            )

        with patch.object(DeckManager, "observe", verified_synthetic_hand):
            report = benchmark_frames([fixture], loops=1, max_width=360, warmup_frames=0)
        self.assertEqual(report["battle_frames"], 1)
        self.assertEqual(report["decision_calls"], 1)
        self.assertEqual(report["tactical_search"]["calls"], 1)
        self.assertEqual(report["tactical_search"]["results"], 1)
        self.assertGreater(report["tactical_search"]["nodes_total"], 0)
        self.assertIn("tactical_learning", report)
        self.assertEqual(report["tactical_search"]["budget_ms"], 22.0)
        self.assertIn("real-game battle replays", " ".join(report["limitations"]))

    def test_release_build_can_reuse_shipped_launcher_without_go(self):
        script = (ROOT / "build_windows.bat").read_text(encoding="utf-8")
        self.assertIn("REBUILD_LAUNCHER=0", script)
        self.assertIn("verifying the included launcher against its source-build record", script)
        self.assertIn("--verify-launcher-record", script)
        self.assertIn("--refresh-launcher-record", script)
        self.assertIn(":build_release", script)
        requirements = (ROOT / "requirements-build.txt").read_text(encoding="utf-8")
        self.assertIn("optional", requirements.lower())


    def test_launcher_build_record_rejects_stale_source_or_binary(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "launcher_windows.go").write_text("package main\n", encoding="utf-8")
            (root / "ClashRoyale.exe").write_bytes(b"test PE placeholder")
            with patch("tools.build_release.ROOT", root):
                write_launcher_record()
                verify_launcher_record()
                (root / "launcher_windows.go").write_text("package main\n// changed\n", encoding="utf-8")
                with self.assertRaises(SystemExit):
                    verify_launcher_record()
                write_launcher_record()
                verify_launcher_record()
                (root / "ClashRoyale.exe").write_bytes(b"different executable")
                with self.assertRaises(SystemExit):
                    verify_launcher_record()

    def test_launcher_prefers_stable_python_and_rejects_prereleases(self):
        launcher = (ROOT / "launcher_windows.go").read_text(encoding="utf-8")
        build = (ROOT / "build_windows.bat").read_text(encoding="utf-8")
        self.assertIn("sys.version_info.releaselevel=='final'", launcher)
        self.assertIn("sys.version_info.releaselevel == 'final'", build)
        self.assertNotIn('"3.16"', launcher)
        self.assertNotIn("3.16", build)

    def test_release_requires_a_valid_windows_x64_pe32_plus_launcher(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ClashRoyale.exe"
            data = bytearray(256)
            data[:2] = b"MZ"
            data[0x3C:0x40] = (128).to_bytes(4, "little")
            data[128:132] = b"PE\0\0"
            data[132:134] = (0x8664).to_bytes(2, "little")
            data[152:154] = (0x20B).to_bytes(2, "little")
            data[220:222] = (2).to_bytes(2, "little")
            path.write_bytes(data)
            verify_windows_x64_launcher(path)
            data[132:134] = (0x14C).to_bytes(2, "little")
            path.write_bytes(data)
            with self.assertRaises(SystemExit):
                verify_windows_x64_launcher(path)
            data[132:134] = (0x8664).to_bytes(2, "little")
            data[220:222] = (3).to_bytes(2, "little")
            path.write_bytes(data)
            with self.assertRaises(SystemExit):
                verify_windows_x64_launcher(path)

    def test_release_fails_if_required_source_directory_is_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in ROOT_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            for name in ROOT_DIRS:
                (root / name).mkdir(parents=True, exist_ok=True)
            for name in REQUIRED_TREE_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            with patch("tools.build_release.ROOT", root):
                self.assertTrue(payload_files())
                shutil.rmtree(root / "core")
                with self.assertRaises(SystemExit):
                    payload_files()

    def test_release_fails_if_a_critical_module_is_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name in ROOT_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            for name in ROOT_DIRS:
                (root / name).mkdir(parents=True, exist_ok=True)
            for name in REQUIRED_TREE_FILES:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"test")
            (root / "core" / "agent.py").unlink()
            with patch("tools.build_release.ROOT", root):
                with self.assertRaises(SystemExit):
                    payload_files()

    def test_release_size_limit_is_strictly_below_one_decimal_gigabyte(self):
        self.assertEqual(MAX_RELEASE_BYTES, 1_000_000_000)


if __name__ == "__main__":
    unittest.main()
