from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.replay import BattleReplayRecorder
from core.vision import GameState, Scene
from tools.evaluate_agent import evaluate_replays
from tools.evaluate_vision import match_units
from tools.windows_smoke_test import collect_smoke_report


def state():
    return GameState(
        battle_detected=True, elixir=5.0, left_threat=0.1, right_threat=0.2,
        left_support=0.1, right_support=0.1, card_scores=(0.8, 0.7, 0.6, 0.5),
        green_ratio=0.2, red_ratio=0.1, blue_ratio=0.1, purple_ratio=0.1,
        confidence=0.9, scene=Scene.BATTLE, scene_confidence=0.9,
    )


class EvaluationTests(unittest.TestCase):
    def test_agent_evaluation_reports_only_confident_results_and_verified_actions(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            paths = []
            for index, (result, confidence, status) in enumerate((
                ("win", 0.95, "verified"),
                ("loss", 0.93, "sent_unverified"),
                ("win", 0.50, "rejected"),
            )):
                recorder = BattleReplayRecorder(root / f"workspace-{index}")
                recorder.begin_match(frame_index=0)
                recorder.record_state(state(), frame_index=1,
                                      now=recorder._started_at + 1.0)
                recorder.record_action(card_key="hog-rider", form="base", slot=0,
                                       lane=0, status=status)
                paths.append(recorder.finish_match(result, confidence=confidence))
            report = evaluate_replays(paths)
            self.assertEqual(report["replays_read"], 3)
            self.assertEqual(report["matches"]["labelled"], 2)
            self.assertEqual(report["matches"]["wins"], 1)
            self.assertEqual(report["matches"]["losses"], 1)
            self.assertEqual(report["matches"]["unlabelled_or_low_confidence"], 1)
            self.assertEqual(report["matches"]["win_rate_excluding_draws"], 0.5)
            self.assertEqual(report["actions"]["by_card"]["hog-rider"]["verified"], 1)
            self.assertEqual(report["actions"]["by_card"]["hog-rider"]["sent_unverified"], 1)

    def test_windows_smoke_report_writes_probe_only_inside_selected_workspace(self):
        with tempfile.TemporaryDirectory() as directory:
            report = collect_smoke_report(Path(directory))
            workspace = Path(report["workspace"])
            self.assertTrue(workspace.is_relative_to(Path(directory)))
            self.assertTrue(report["checks"]["temporary_path_inside_selected_workspace"])
            self.assertTrue(report["checks"]["workspace_write"])
            self.assertFalse((workspace / ".tmp" / "smoke_write_probe.tmp").exists())

    def test_vision_evaluator_matches_by_location_and_exact_identity(self):
        expected = [{
            "team": "enemy", "card_key": "hog-rider", "form": "base",
            "bbox": (0.40, 0.30, 0.50, 0.40),
        }]
        predicted = [{
            "team": "enemy", "card_key": "hog-rider", "form": "base",
            "x": 0.45, "y": 0.35,
        }]
        metrics = match_units(expected, predicted, max_distance=0.065)
        self.assertEqual(metrics["tp"], 1)
        self.assertEqual(metrics["fp"], 0)
        self.assertEqual(metrics["fn"], 0)

    def test_vision_evaluator_counts_wrong_identity_as_false_positive_and_negative(self):
        expected = [{
            "team": "enemy", "card_key": "hog-rider", "form": "base",
            "bbox": (0.40, 0.30, 0.50, 0.40),
        }]
        predicted = [{
            "team": "enemy", "card_key": "knight", "form": "base",
            "x": 0.45, "y": 0.35,
        }]
        metrics = match_units(expected, predicted, max_distance=0.065)
        self.assertEqual(metrics["tp"], 0)
        self.assertEqual(metrics["fp"], 1)
        self.assertEqual(metrics["fn"], 1)
        self.assertEqual(metrics["misclassified_localizations"], 1)


if __name__ == "__main__":
    unittest.main()
