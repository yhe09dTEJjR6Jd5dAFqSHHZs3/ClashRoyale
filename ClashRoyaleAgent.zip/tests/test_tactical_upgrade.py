from __future__ import annotations

import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from core.cards import CardDatabase
from core.blackbox import MAX_BYTES, create_blackbox
from core.combat import CombatDatabase, CombatSimulator, _Unit
from core.opponent import OpponentDeckInferencer, OpponentPlay, OpponentElixirTracker
from core.policy import LocalLearner
from core.planner import plan_deployment
from core.tactical_memory import TacticalMemory
from core.tactical_search import SearchAction, TacticalSearch
from core.tracking import TemporalBattleTracker
from core.vision import ClusterTrack, GameState, Scene, VisualCluster, _estimate_health_bar
from core.win32 import Frame


def battle_state(**kwargs):
    values = dict(
        battle_detected=True, elixir=7.5,
        left_threat=0.62, right_threat=0.12,
        left_support=0.08, right_support=0.15,
        card_scores=(0.0, 0.0, 0.0, 0.0),
        green_ratio=0.0, red_ratio=0.0, blue_ratio=0.0, purple_ratio=0.0,
        confidence=0.92, scene=Scene.BATTLE, scene_confidence=0.92,
        elixir_confidence=0.95, frame_width=420, frame_height=840,
    )
    values.update(kwargs)
    return GameState(**values)


class OpponentElixirTests(unittest.TestCase):
    def test_matchmaking_anchor_and_known_spend_produce_conservative_interval(self):
        tracker = OpponentElixirTracker(CardDatabase())
        matchmaking = battle_state(scene=Scene.MATCHMAKING, battle_detected=False)
        tracker.observe(matchmaking, (), now=10.0)
        loading = battle_state(scene=Scene.LOADING, battle_detected=False)
        tracker.observe(loading, (), now=10.5)
        battle = tracker.observe(battle_state(), (), now=11.0)
        self.assertEqual(battle.opponent_elixir_lower, 5.0)
        self.assertEqual(battle.opponent_elixir_upper, 5.0)

        play = OpponentPlay("opp_0001", "hog-rider", 0.90, 13.8, 0, 0.5, "ocr")
        after_spend = tracker.observe(battle_state(), (play,), now=13.8)
        self.assertAlmostEqual(after_spend.opponent_elixir_lower, 2.0, places=2)
        self.assertAlmostEqual(after_spend.opponent_elixir_upper, 2.0, places=2)
        self.assertGreaterEqual(after_spend.opponent_elixir_confidence, 0.55)

    def test_late_attach_keeps_wide_low_confidence_interval(self):
        tracker = OpponentElixirTracker(CardDatabase())
        state = tracker.observe(battle_state(), (), now=500.0)
        self.assertEqual(state.opponent_elixir_lower, 0.0)
        self.assertEqual(state.opponent_elixir_upper, 10.0)
        self.assertLess(state.opponent_elixir_confidence, 0.55)


class TacticalSearchTests(unittest.TestCase):
    def setUp(self):
        self.cards = CardDatabase()

    def _actions(self, state):
        actions = []
        for index, key in enumerate(("ice-spirit", "hog-rider", "musketeer", "fireball")):
            for lane in (0, 1):
                actions.append(SearchAction(
                    card=index, lane=lane, features=[0.0] * 6,
                    base_score=0.30 + (0.08 if lane == 0 else 0.0),
                    card_key=key, form="base", level=11,
                    cost=float(state.card_costs[index]),
                    roles=self.cards.roles_for(key),
                ))
        return actions

    def test_search_returns_legal_action_and_multi_ply_principal_variation(self):
        state = battle_state(
            card_ready=(True, True, True, True),
            card_ready_confidence=(0.95, 0.95, 0.95, 0.95),
            card_costs=(2.0, 4.0, 3.0, 4.0),
            card_roles=tuple(self.cards.roles_for(key) for key in
                             ("ice-spirit", "hog-rider", "musketeer", "fireball")),
            opponent_deck_candidates=(
                ("arrows", "inferno-tower", "cannon", "musketeer", "mini-pekka", "knight", "fireball", "hog-rider"),
                ("the-log", "tesla", "hunter", "valkyrie", "rocket", "ice-spirit", "mortar", "miner"),
            ),
            opponent_deck_candidate_confidences=(0.65, 0.35),
            opponent_deck_confidence=0.70,
        )
        search = TacticalSearch()
        result = search.choose(state, self._actions(state), card_database=self.cards,
                               elapsed_seconds=30.0)
        self.assertIsNotNone(result)
        self.assertIn(result.action.card, range(4))
        self.assertIn(result.action.lane, (0, 1))
        self.assertGreaterEqual(result.depth, 2)
        self.assertGreater(result.nodes, 8)
        self.assertEqual(len(result.principal_variation), result.depth)
        self.assertGreater(result.opponent_branches, 0)
        self.assertTrue(search.last_summary["visible_hand_only"])

    def test_local_policy_uses_search_result_as_its_action(self):
        keys = ("ice-spirit", "hog-rider", "musketeer", "fireball")
        state = battle_state(
            card_scores=(0.9, 0.8, 0.7, 0.6),
            card_ready=(True, True, True, True),
            card_ready_confidence=(0.95, 0.95, 0.95, 0.95),
            card_costs=(1.0, 4.0, 4.0, 4.0),
            card_names=keys,
            card_roles=tuple(self.cards.roles_for(key) for key in keys),
        )
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            search = TacticalSearch()
            memory = TacticalMemory(Path(directory) / "tactical_memory.json")
            action = learner.choose(
                state, 30.0, card_database=self.cards,
                tactical_search=search, tactical_memory=memory,
            )
        self.assertIsNotNone(action)
        self.assertGreaterEqual(search.last_summary["depth"], 1)
        self.assertIn(action[0], range(4))
        self.assertIn(action[1], (0, 1))

    def test_search_time_budget_returns_best_completed_root_without_blocking(self):
        state = battle_state(
            card_ready=(True, True, True, True),
            card_ready_confidence=(0.95, 0.95, 0.95, 0.95),
            card_costs=(2.0, 4.0, 3.0, 4.0),
            card_roles=tuple(self.cards.roles_for(key) for key in
                             ("ice-spirit", "hog-rider", "musketeer", "fireball")),
        )
        search = TacticalSearch()
        search.MAX_SEARCH_MS = 0.0
        result = search.choose(state, self._actions(state), card_database=self.cards)
        self.assertIsNotNone(result)
        self.assertEqual(result.depth, 1)
        self.assertTrue(search.last_summary["budget_exhausted"])
        self.assertEqual(search.calls, 1)

    def test_counter_risk_ignores_a_counter_that_cannot_be_afforded(self):
        action = SearchAction(0, 0, [], 0.3, "skeleton-army", "base", 11, 3.0,
                              self.cards.roles_for("skeleton-army"))
        state = battle_state(
            opponent_deck_candidates=(("arrows",),),
            opponent_deck_candidate_confidences=(1.0,),
            opponent_deck_confidence=1.0,
            opponent_elixir_upper=2.0,
            opponent_elixir_confidence=0.85,
        )
        risk, _branches = TacticalSearch()._counter_risk(action, state, self.cards)
        self.assertEqual(risk, 0.0)

        affordable = battle_state(
            opponent_deck_candidates=(("arrows",),),
            opponent_deck_candidate_confidences=(1.0,),
            opponent_deck_confidence=1.0,
            opponent_elixir_upper=4.0,
            opponent_elixir_confidence=0.85,
        )
        risk, _branches = TacticalSearch()._counter_risk(action, affordable, self.cards)
        self.assertGreater(risk, 0.02)

    def test_counter_scenarios_penalize_vulnerable_swarm(self):
        state = battle_state(
            opponent_deck_candidates=(("arrows", "fireball", "cannon"),),
            opponent_deck_candidate_confidences=(1.0,),
            opponent_deck_confidence=0.9,
        )
        action = SearchAction(0, 0, [], 0.3, "skeleton-army", "base", 11, 3.0,
                              self.cards.roles_for("skeleton-army"))
        risk, branches = TacticalSearch()._counter_risk(action, state)
        self.assertGreater(risk, 0.02)
        self.assertEqual(branches, 1)


class TacticalMemoryTests(unittest.TestCase):
    def test_only_confident_labelled_matches_train_and_memory_persists(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "tactical_memory.json"
            memory = TacticalMemory(path)
            for _ in range(4):
                memory.begin_match()
                self.assertTrue(memory.record_play("hog-rider", 0, confidence=0.96))
                self.assertTrue(memory.record_play("fireball", 0, confidence=0.96))
                self.assertEqual(memory.finish_match("win", 0.96), 1)
            bonus = memory.bonus_from("hog-rider", 0, "fireball", 0)
            self.assertGreater(bonus, 0.0)
            restored = TacticalMemory(path)
            self.assertEqual(len(restored.pairs), 1)
            self.assertGreater(restored.bonus_from("hog-rider", 0, "fireball", 0), 0.0)

            restored.begin_match()
            restored.record_play("hog-rider", 0, confidence=0.96)
            restored.record_play("fireball", 0, confidence=0.96)
            self.assertEqual(restored.finish_match(None, 0.0), 0)
            self.assertEqual(restored.pairs["hog-rider|fireball|same"]["count"], 4)

    def test_low_confidence_or_invalid_play_is_not_recorded(self):
        memory = TacticalMemory(Path("unused-tactical-memory.json"))
        self.assertFalse(memory.record_play("hog-rider", 0, confidence=0.4))
        self.assertFalse(memory.record_play("hog rider", 0, confidence=0.99))
        self.assertEqual(memory.summary()["current_match_verified_plays"], 0)


class OpenWorldOpponentTests(unittest.TestCase):
    def setUp(self):
        self.cards = CardDatabase()

    def test_ranked_meta_snapshot_is_current_dated_and_has_valid_eight_card_rows(self):
        path = Path(__file__).resolve().parents[1] / "data" / "meta_decks.tsv"
        lines = path.read_text(encoding="utf-8").splitlines()
        self.assertIn("snapshot=RoyaleAPI ranked 7d, 2026-11-25", lines[0])
        rows = [line.split("|") for line in lines if line.strip() and not line.startswith("#")]
        self.assertEqual(len(rows), 20)
        for rank, name, usage, card_list in rows:
            self.assertTrue(name)
            self.assertGreaterEqual(float(usage), 0.0)
            keys = card_list.split(",")
            self.assertEqual(len(keys), 8)
            self.assertEqual(len(set(keys)), 8)
            for slug in keys:
                base, _form = OpponentDeckInferencer._split_slug(slug)
                self.assertIsNotNone(self.cards.get(base), (rank, slug))

    def test_opponent_hypotheses_exceed_20_priors_and_cover_full_catalog(self):
        inferencer = OpponentDeckInferencer(self.cards)
        state = battle_state()
        plays = (
            OpponentPlay("seen-1", "hog-rider", 0.96, 1.0, 0, 0.4, "ocr"),
            OpponentPlay("seen-2", "fireball", 0.95, 2.0, 0, 0.4, "ocr"),
        )
        enriched = inferencer.observe(state, plays)
        summary = inferencer.summary()
        self.assertEqual(summary["meta_priors"], 20)
        self.assertGreater(summary["generated_hypotheses"], 30)
        self.assertGreater(summary["candidate_pool"], 30)
        self.assertGreaterEqual(summary["card_pool"], 100)
        self.assertEqual(len(enriched.opponent_deck_candidates), 8)
        for candidate in enriched.opponent_deck_candidates:
            self.assertEqual(len(candidate), 8)
            self.assertEqual(len(set(candidate)), 8)
            self.assertTrue({"hog-rider", "fireball"}.issubset(candidate))
        self.assertLess(enriched.opponent_deck_confidence, 0.5)

    def test_eight_low_confidence_cards_do_not_become_a_persistent_exact_deck(self):
        keys = ("hog-rider", "fireball", "the-log", "ice-golem", "ice-spirit",
                "musketeer", "skeletons", "cannon")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "opponent_model.json"
            inferencer = OpponentDeckInferencer(self.cards, learning_path=path)
            plays = tuple(
                OpponentPlay(f"weak-{index}", key, 0.70, float(index + 1), index % 2,
                             0.4, "weak-ocr")
                for index, key in enumerate(keys)
            )
            enriched = inferencer.observe(battle_state(), plays)
            self.assertFalse(enriched.opponent_deck_complete)
            self.assertEqual(len(enriched.opponent_deck_candidates), 8)
            self.assertFalse(path.exists())

    def test_exact_eight_card_deck_is_learned_across_matches(self):
        keys = ("hog-rider", "fireball", "the-log", "ice-golem", "ice-spirit",
                "musketeer", "skeletons", "cannon")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "opponent_model.json"
            inferencer = OpponentDeckInferencer(self.cards, learning_path=path)
            plays = tuple(
                OpponentPlay(f"token-{index}", key, 0.98, float(index + 1), index % 2,
                             0.4, "ocr")
                for index, key in enumerate(keys)
            )
            enriched = inferencer.observe(battle_state(), plays)
            self.assertTrue(enriched.opponent_deck_complete)
            self.assertEqual(enriched.opponent_deck_unknown_slots, 0)
            self.assertEqual(enriched.opponent_deck_candidates, (tuple(keys),))
            self.assertTrue(path.is_file())
            saved = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(saved["version"], 1)
            restored = OpponentDeckInferencer(self.cards, learning_path=path)
            self.assertEqual(restored.learned_decks[tuple(sorted(keys))], 1)


class VisualAndCombatUpgradeTests(unittest.TestCase):
    def setUp(self):
        self.cards = CardDatabase()
        self.database = CombatDatabase(card_database=self.cards)
        self.simulator = CombatSimulator(self.database, self.cards)

    def test_health_bar_estimator_returns_partial_health_with_confidence(self):
        width = height = 120
        pixels = bytearray(width * height * 4)
        for index in range(3, len(pixels), 4):
            pixels[index] = 255
        # A 10-pixel green fill in an approximately 20-pixel health bar.
        for x in range(40, 50):
            index = (56 * width + x) * 4
            pixels[index:index + 4] = bytes((20, 220, 20, 255))
        frame = Frame(width, height, bytes(pixels))
        ratio, confidence = _estimate_health_bar(frame, 40, 60, 60, 80)
        self.assertIsNotNone(ratio)
        self.assertAlmostEqual(ratio, 0.52, delta=0.12)
        self.assertGreaterEqual(confidence, 0.55)

    def test_track_association_uses_appearance_as_a_tie_breaker(self):
        track = ClusterTrack(
            track_id=1, x=0.5, y=0.5, vx=0.0, vy=0.0,
            width=0.05, height=0.06, area=0.003, confidence=0.9,
            age_seconds=0.5, observations=4, last_seen=1.0,
            appearance=(0.1,) * 48,
        )
        matching = VisualCluster(0.5, 0.5, 0.05, 0.06, 0.003, 0.9,
                                 appearance=(0.1,) * 48)
        crossing = VisualCluster(0.5, 0.5, 0.05, 0.06, 0.003, 0.9,
                                 appearance=(0.9,) * 48)
        match_cost, _ = TemporalBattleTracker._cluster_distance(track, matching, 1.1)
        crossing_cost, _ = TemporalBattleTracker._cluster_distance(track, crossing, 1.1)
        self.assertLess(match_cost, crossing_cost)

    def test_simulator_towers_follow_detected_arena_geometry(self):
        state = battle_state(arena_bounds=(0.10, 0.30, 0.90, 0.84))
        units = self.simulator._make_units(state)
        towers = [unit for unit in units if unit.is_tower]
        self.assertEqual(len(towers), 4)
        self.assertAlmostEqual(self.simulator._river_y, 0.57)
        self.assertAlmostEqual(min(unit.y for unit in towers if unit.team == 1), 0.3486, places=3)
        self.assertAlmostEqual(max(unit.y for unit in towers if unit.team == 0), 0.7914, places=3)

    def test_ground_units_use_bridge_waypoint_but_air_units_do_not(self):
        ground, _ = self.database.get("hog-rider", level=11)
        air, _ = self.database.get("balloon", level=11)
        ground_unit = _Unit(1, 0, "hog-rider", ground, 0.50, 0.70,
                            ground.hp, ground.hp, 0.0, 0.9, 0.0)
        tower = _Unit(2, 1, "tower-princess", self.simulator._tower_profile,
                      0.69, 0.06, 3052.0, 3052.0, 0.0, 0.7, 0.3,
                      is_tower=True)
        waypoint = self.simulator._movement_waypoint(ground_unit, tower)
        self.assertAlmostEqual(waypoint[0], 0.69)
        self.assertAlmostEqual(waypoint[1], 0.575)
        air_unit = _Unit(3, 0, "balloon", air, 0.50, 0.70,
                         air.hp, air.hp, 0.0, 0.9, 0.0)
        self.assertEqual(self.simulator._movement_waypoint(air_unit, tower), (tower.x, tower.y))

    def test_spawn_spells_are_simulated_as_spawned_units_not_direct_spell_ticks(self):
        state = battle_state()
        result = self.simulator.evaluate_spell(state, "goblin-barrel", x=0.31, y=0.40)
        self.assertIn("spawn-spell", result.reason)
        self.assertGreater(result.damage_to_enemy, 0.0)
        self.assertGreater(result.score, 0.0)

    def test_barrel_and_graveyard_can_target_enemy_tower_lane_without_visible_troops(self):
        state = battle_state(card_roles=(("spell",), (), (), ()))
        plan = plan_deployment(state, 0, 0, combat_simulator=self.simulator,
                               card_key="goblin-barrel", level=11)
        self.assertGreater(plan.score, 0.0)
        self.assertGreaterEqual(plan.confidence, 0.42)
        self.assertIn("tower-lane", plan.reason)


    def test_blackbox_includes_all_local_learning_files_under_one_megabyte(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "workspace"
            desktop = Path(directory) / "desktop"
            workspace.mkdir()
            (workspace / "model.json").write_text('{"version":1}', encoding="utf-8")
            (workspace / "tactical_memory.json").write_text(
                '{"version":1,"pairs":[]}', encoding="utf-8"
            )
            (workspace / "opponent_model.json").write_text(
                '{"version":1,"decks":[]}', encoding="utf-8"
            )
            (workspace / "unit_visual_profiles.json").write_text(
                '{"version":1,"prototypes":[]}', encoding="utf-8"
            )
            archive = create_blackbox(workspace, desktop=desktop)
            self.assertLessEqual(archive.stat().st_size, MAX_BYTES)
            with zipfile.ZipFile(archive) as bundle:
                names = set(bundle.namelist())
            self.assertIn("tactical_memory.json", names)
            self.assertIn("opponent_model.json", names)
            self.assertIn("unit_visual_profiles.json", names)



if __name__ == "__main__":
    unittest.main()
