from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.cards import CardRecognition
from core.blackbox import create_blackbox, MAX_BYTES as BLACKBOX_MAX_BYTES
from core.replay import (
    BattleReplayRecorder, canonical_state_hash, load_replay,
    replay_state_hashes, state_from_dict, state_to_dict,
)
from core.status import format_stop_summary
from core.native_ui import scale_dpi
from core.vision import (
    ClusterTrack, GameState, NavigationTarget, Scene, SemanticUnit, VisualCluster,
)


def sample_state() -> GameState:
    cluster = VisualCluster(
        x=0.32, y=0.61, width=0.05, height=0.06, area=0.003,
        confidence=0.91, appearance=(0.1, 0.2, 0.3),
        health_ratio=0.75, health_confidence=0.7,
    )
    track = ClusterTrack(
        track_id=12, x=0.33, y=0.60, vx=0.01, vy=0.02,
        width=0.05, height=0.06, area=0.003, confidence=0.9,
        age_seconds=0.5, observations=4, last_seen=123.0,
        appearance=(0.1, 0.2), health_ratio=0.7, health_confidence=0.6,
    )
    return GameState(
        battle_detected=True, elixir=6.5, left_threat=0.2, right_threat=0.1,
        left_support=0.3, right_support=0.1, card_scores=(0.9, 0.8, 0.7, 0.6),
        green_ratio=0.1, red_ratio=0.2, blue_ratio=0.3, purple_ratio=0.1,
        confidence=0.91, scene=Scene.BATTLE, scene_confidence=0.95,
        elixir_confidence=0.9, card_ready=(True, True, False, True),
        card_ready_confidence=(0.95, 0.9, 0.1, 0.85),
        card_costs=(1.0, 4.0, 3.0, 4.0),
        card_names=("Ice Spirit", "Hog Rider", "", "Fireball"),
        card_roles=(("cycle",), ("win_condition",), (), ("spell",)),
        card_forms=("base", "base", "base", "base"),
        card_levels=(11, 12, None, 11),
        card_bounds=((0.1, 0.8, 0.2, 0.98), (0.3, 0.8, 0.4, 0.98),
                     (0.5, 0.8, 0.6, 0.98), (0.7, 0.8, 0.8, 0.98)),
        targets=(NavigationTarget("continue", 0.5, 0.8, 0.9),),
        enemy_clusters=(cluster,), enemy_tracks=(track,),
        semantic_enemy_units=(SemanticUnit(
            track_id=12, team="enemy", card_key="hog-rider", form="base",
            confidence=0.8, x=0.33, y=0.6, vx=0.01, vy=0.02,
            area=0.003, observations=4, level=11, roles=("win_condition",),
        ),),
        recognized_cards=(CardRecognition(
            card_key="hog-rider", name="Hog Rider", form="base", level=12,
            elite_level=False, confidence=0.95, variant_confidence=0.8,
            bounds=(10, 20, 30, 40),
        ),),
        opponent_deck_candidates=(("hog-rider", "fireball"),),
        opponent_deck_candidate_confidences=(0.7,),
    )


class BattleReplayTests(unittest.TestCase):
    def test_game_state_round_trip_preserves_nested_and_tuple_fields(self):
        original = sample_state()
        restored = state_from_dict(state_to_dict(original))
        self.assertEqual(restored.scene, Scene.BATTLE)
        self.assertEqual(restored.enemy_tracks[0].track_id, 12)
        self.assertEqual(restored.semantic_enemy_units[0].roles, ("win_condition",))
        self.assertEqual(restored.recognized_cards[0].bounds, (10, 20, 30, 40))
        self.assertEqual(canonical_state_hash(original), canonical_state_hash(restored))

    def test_recorder_writes_bounded_workspace_local_replay_and_loads_it(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "selected" / "ClashRoyaleAgent"
            recorder = BattleReplayRecorder(workspace)
            recorder.begin_match(frame_index=4)
            recorder.record_state(sample_state(), frame_index=5,
                                  now=recorder._started_at + 1.0)
            recorder.record_decision(card=1, lane=0, features=(0.1, 0.2), policy_ms=4.2)
            recorder.record_action(card_key="hog-rider", form="base", slot=1,
                                   lane=0, status="verified", plan=(0.32, 0.64))
            replay_path = recorder.finish_match("win", confidence=0.94)
            self.assertIsNotNone(replay_path)
            self.assertTrue(replay_path.is_relative_to(workspace))
            self.assertLessEqual(replay_path.stat().st_size, 8_000_000)
            events = load_replay(replay_path)
            state_events = [event for event in events if event["type"] == "state"]
            self.assertEqual(len(state_events), 1)
            self.assertEqual(state_events[0]["_decoded_state"].scene, Scene.BATTLE)
            self.assertEqual([event["type"] for event in events][-1], "match_end")
            self.assertEqual(len(list(replay_state_hashes(events))), 1)
            self.assertEqual(recorder.summary()["last_result"], "win")
            self.assertFalse(any("screenshot" in event for event in events))

    def test_blackbox_can_include_latest_small_replay_without_breaking_one_megabyte_cap(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "workspace"
            desktop = Path(directory) / "desktop"
            recorder = BattleReplayRecorder(workspace)
            recorder.begin_match()
            recorder.record_state(sample_state(), frame_index=1,
                                  now=recorder._started_at + 1.0)
            recorder.record_action(card_key="hog-rider", form="base", slot=1,
                                   lane=0, status="verified")
            recorder.finish_match("loss", confidence=0.9)
            archive_path = create_blackbox(workspace, desktop=desktop)
            self.assertLessEqual(archive_path.stat().st_size, BLACKBOX_MAX_BYTES)
            import zipfile
            with zipfile.ZipFile(archive_path) as archive:
                self.assertIn("latest_battle_replay.crr.gz", archive.namelist())

    def test_blackbox_falls_back_to_older_valid_replay_when_latest_is_oversized(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "workspace"
            desktop = Path(directory) / "desktop"
            recorder = BattleReplayRecorder(workspace)
            recorder.begin_match()
            recorder.record_state(sample_state(), frame_index=1,
                                  now=recorder._started_at + 1.0)
            valid_path = recorder.finish_match("win", confidence=0.95)
            self.assertIsNotNone(valid_path)
            oversized = workspace / "replays" / "newer_large.crr.gz"
            oversized.write_bytes(b"x" * 220_001)
            import os, time
            os.utime(oversized, (time.time() + 2, time.time() + 2))
            archive_path = create_blackbox(workspace, desktop=desktop)
            import zipfile, json
            with zipfile.ZipFile(archive_path) as archive:
                self.assertIn("latest_battle_replay.crr.gz", archive.namelist())
                self.assertEqual(archive.read("latest_battle_replay.crr.gz"), valid_path.read_bytes())
                metadata = json.loads(archive.read("blackbox.json"))
                self.assertEqual(metadata["selected_replay"], valid_path.relative_to(workspace).as_posix())
                self.assertIn("replays/newer_large.crr.gz", metadata["omitted_files"])
                self.assertEqual(
                    metadata["omitted_replay_reasons"]["replays/newer_large.crr.gz"],
                    "over_220kb_replay_cap",
                )

    def test_recorder_respects_sampling_interval_and_workspace_isolation(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "workspace"
            recorder = BattleReplayRecorder(workspace)
            recorder.begin_match()
            base = recorder._started_at
            self.assertTrue(recorder.record_state(sample_state(), frame_index=1, now=base + 1.0))
            self.assertFalse(recorder.record_state(sample_state(), frame_index=2, now=base + 1.1))
            recorder.finish_match(None, reason="user_stop")
            self.assertTrue((workspace / "replays").is_dir())
            self.assertEqual(list(Path(directory).glob("*.crr.gz")), [])

    def test_error_is_shown_even_after_successful_actions(self):
        status, severity = format_stop_summary({
            "stop_reason": "safety_failure", "stop_key": "ESC", "actions": 23,
            "verified_actions": 18, "wins": 2, "losses": 1, "draws": 0,
            "stop_monitor": "failed", "last_error": "global hook exited unexpectedly",
            "seconds_since_last_frame": 3.5,
        })
        self.assertIn("安全故障停止", status)
        self.assertIn("global hook exited unexpectedly", status)
        self.assertIn("23 次", status)
        self.assertEqual(severity, "error")

    def test_native_window_geometry_scales_for_common_monitor_dpi_values(self):
        self.assertEqual(scale_dpi(740, 96), 740)
        self.assertEqual(scale_dpi(740, 120), 925)
        self.assertEqual(scale_dpi(740, 144), 1110)
        self.assertEqual(scale_dpi(740, 192), 1480)

    def test_user_stop_is_distinguished_from_safety_shutdown(self):
        status, severity = format_stop_summary({
            "stop_reason": "user_stop", "stop_key": "F10", "actions": 2,
            "verified_actions": 2, "stop_monitor": "global_hook",
        })
        self.assertIn("已按 F10 停止", status)
        self.assertEqual(severity, "ready")


if __name__ == "__main__":
    unittest.main()
