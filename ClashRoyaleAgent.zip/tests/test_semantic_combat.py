from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.cards import CardDatabase, CardRecognition
from core.combat import CombatDatabase, CombatSimulator
from core.opponent import OpponentDeckInferencer, OpponentPlay, OpponentCycleTracker
from core.semantics import SemanticBattleRecognizer
from core.vision import ClusterTrack, GameState, Scene, SemanticUnit


def state(**kwargs):
    values = dict(
        battle_detected=True, elixir=6.0,
        left_threat=0.2, right_threat=0.1,
        left_support=0.1, right_support=0.1,
        card_scores=(0.0, 0.0, 0.0, 0.0),
        green_ratio=0.0, red_ratio=0.0, blue_ratio=0.0, purple_ratio=0.0,
        confidence=0.9, scene=Scene.BATTLE, scene_confidence=0.9,
        elixir_confidence=0.9, frame_width=420, frame_height=840,
    )
    values.update(kwargs)
    return GameState(**values)


def track(track_id: int, *, x=0.42, y=0.70, team="friendly", appearance=None,
          last_seen=1.0, age_seconds=0.0):
    return ClusterTrack(
        track_id=track_id, x=x, y=y, vx=0.0, vy=0.0,
        width=0.035, height=0.045, area=0.001575,
        confidence=0.94, age_seconds=age_seconds, observations=4, last_seen=last_seen,
        appearance=tuple(appearance or ([0.22] * 16 + [0.34] * 16 + [0.125] * 8 + [0.125] * 8)),
    )


class SemanticCombatTests(unittest.TestCase):
    def setUp(self):
        self.cards = CardDatabase()
        self.combat_data = CombatDatabase(card_database=self.cards)

    def test_combat_snapshot_covers_all_127_base_cards_and_scales_levels(self):
        self.assertEqual(len(self.combat_data), 127)
        knight_11, confidence_11 = self.combat_data.get("knight", level=11)
        knight_12, confidence_12 = self.combat_data.get("knight", level=12)
        self.assertAlmostEqual(knight_11.hp, 1766.0)
        self.assertAlmostEqual(knight_12.hp, 1766.0 * 1.1)
        self.assertEqual(confidence_11, 1.0)
        self.assertEqual(confidence_12, 1.0)

    def test_passive_spawners_remain_targetable_without_fake_attack_stats(self):
        cage = self.combat_data.base("goblin-cage")
        collector = self.combat_data.base("elixir-collector")
        self.assertTrue(cage.can_fight)
        self.assertTrue(cage.is_building)
        self.assertIsNone(cage.damage)
        self.assertTrue(collector.can_fight)
        self.assertIsNone(collector.hit_speed)
        self.assertEqual(self.combat_data.base("goblin-gang").count, 6)
        self.assertEqual(self.combat_data.base("skeleton-barrel").count, 1)

    def test_combat_profile_marks_spell_and_unverified_form_uncertainty(self):
        spell, confidence = self.combat_data.get("fireball", level=11)
        self.assertTrue(spell.is_spell)
        self.assertFalse(spell.can_fight)
        self.assertEqual(confidence, 1.0)
        evolved, evolved_confidence = self.combat_data.get("knight", form="evolution", level=11)
        self.assertTrue(evolved.can_fight)
        self.assertLess(evolved_confidence, 1.0)

    def test_candidate_deployment_uses_semantic_enemy_and_compares_against_hold(self):
        enemy = SemanticUnit(
            track_id=99, team="enemy", card_key="knight", form="base",
            confidence=0.90, x=0.50, y=0.53, vx=0.0, vy=0.02,
            area=0.0015, observations=5, level=11,
            health_ratio=0.72, health_confidence=0.9,
        )
        battle = state(semantic_enemy_units=(enemy,))
        simulator = CombatSimulator(self.combat_data, self.cards)
        result = simulator.evaluate_deployment(
            battle, "mini-pekka", form="base", level=11, x=0.50, y=0.62,
        )
        self.assertGreater(result.confidence, 0.45)
        self.assertIn("micro-simulation", result.reason)
        self.assertGreaterEqual(result.score, -1.0)
        self.assertLessEqual(result.score, 1.0)

    def test_spell_placement_scores_semantic_area_coverage(self):
        enemies = tuple(
            SemanticUnit(
                track_id=i, team="enemy", card_key=key, form="base",
                confidence=0.88, x=x, y=0.45, vx=0.0, vy=0.0,
                area=0.001, observations=3, level=11,
            )
            for i, (key, x) in enumerate((("archers", 0.49), ("musketeer", 0.51)), 1)
        )
        result = CombatSimulator(self.combat_data, self.cards).evaluate_spell(
            state(semantic_enemy_units=enemies), "fireball", x=0.50, y=0.45,
        )
        self.assertGreater(result.confidence, 0.5)
        self.assertGreater(result.damage_to_enemy, 0.0)

    def test_semantic_identity_is_learned_only_from_armed_verified_deployments(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            appearance = tuple([0.22] * 16 + [0.34] * 16 + [0.125] * 8 + [0.125] * 8)
            for index in range(3):
                now = 10.0 + index
                self.assertTrue(recognizer.arm_deployment(
                    "knight", "base", 0.42, 0.70, level=11, now=now,
                ))
                friendly_track = track(index + 1, appearance=appearance, last_seen=now + 0.2)
                recognizer.observe(state(friendly_tracks=(friendly_track,)), now=now + 0.2)
            prototype = recognizer.prototypes[("knight", "base")]
            self.assertEqual(prototype.samples, 3)
            enemy_track = track(77, x=0.42, y=0.30, appearance=appearance)
            observed = recognizer.observe(state(enemy_tracks=(enemy_track,)), now=14.0)
            self.assertEqual(len(observed.semantic_enemy_units), 1)
            self.assertEqual(observed.semantic_enemy_units[0].card_key, "knight")
            self.assertGreater(observed.semantic_enemy_units[0].confidence, 0.58)


    def test_preexisting_nearby_track_cannot_receive_a_new_deployment_label(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            self.assertTrue(recognizer.arm_deployment(
                "knight", "base", 0.42, 0.70, now=10.0, existing_track_ids=(41,),
            ))
            old_track = track(41, last_seen=10.2, age_seconds=4.0)
            recognizer.observe(state(friendly_tracks=(old_track,)), now=10.2)
            self.assertNotIn(("knight", "base"), recognizer.prototypes)
            self.assertEqual(len(recognizer.pending), 1)

    def test_old_track_not_in_baseline_ids_is_rejected_by_track_birth_time(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            self.assertTrue(recognizer.arm_deployment(
                "knight", "base", 0.42, 0.70, now=10.0,
            ))
            old_track = track(42, last_seen=10.2, age_seconds=3.5)
            recognizer.observe(state(friendly_tracks=(old_track,)), now=10.2)
            self.assertNotIn(("knight", "base"), recognizer.prototypes)

    def test_ambiguous_simultaneous_spawns_are_not_used_as_learning_samples(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            self.assertTrue(recognizer.arm_deployment(
                "knight", "base", 0.42, 0.70, now=10.0,
            ))
            first = track(51, x=0.419, y=0.70, last_seen=10.2, age_seconds=0.1)
            second = track(52, x=0.421, y=0.70, last_seen=10.2, age_seconds=0.1)
            recognizer.observe(state(friendly_tracks=(first, second)), now=10.2)
            self.assertNotIn(("knight", "base"), recognizer.prototypes)
            self.assertEqual(len(recognizer.pending), 1)
            recognizer.observe(state(friendly_tracks=(first,)), now=10.4)
            self.assertEqual(recognizer.prototypes[("knight", "base")].samples, 1)


    def test_spawn_after_two_same_lane_plays_is_assigned_to_the_later_action(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            self.assertTrue(recognizer.arm_deployment(
                "knight", "base", 0.42, 0.70, now=10.0,
            ))
            self.assertTrue(recognizer.arm_deployment(
                "musketeer", "base", 0.42, 0.70, now=10.15,
            ))
            spawned = track(71, x=0.42, y=0.70, last_seen=10.3, age_seconds=0.1)
            recognizer.observe(state(friendly_tracks=(spawned,)), now=10.35)
            self.assertNotIn(("knight", "base"), recognizer.prototypes)
            self.assertEqual(recognizer.prototypes[("musketeer", "base")].samples, 1)

    def test_invalid_appearance_descriptor_is_not_counted_as_learned(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            self.assertTrue(recognizer.arm_deployment(
                "knight", "base", 0.42, 0.70, now=10.0,
            ))
            invalid = track(61, appearance=[0.2] * 47, last_seen=10.2, age_seconds=0.1)
            recognizer.observe(state(friendly_tracks=(invalid,)), now=10.2)
            self.assertNotIn(("knight", "base"), recognizer.prototypes)
            self.assertEqual(len(recognizer.pending), 1)

    def test_high_confidence_ocr_near_enemy_track_can_seed_a_visual_prototype(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            label = CardRecognition(
                card_key="hog-rider", name="Hog Rider", form="base", level=11,
                elite_level=False, confidence=0.96, bounds=(160, 240, 180, 260),
            )
            enemy_track = track(55, x=0.405, y=0.298)
            recognizer.observe(state(enemy_tracks=(enemy_track,), recognized_cards=(label,)), now=4.0)
            self.assertEqual(recognizer.prototypes[("hog-rider", "base")].samples, 1)

    def test_rage_spell_values_friendly_semantic_units_not_enemy_blobs(self):
        friendly = SemanticUnit(
            track_id=22, team="friendly", card_key="musketeer", form="base",
            confidence=0.90, x=0.50, y=0.70, vx=0.0, vy=0.0,
            area=0.001, observations=4, level=11,
        )
        result = CombatSimulator(self.combat_data, self.cards).evaluate_spell(
            state(semantic_friendly_units=(friendly,)), "rage", x=0.50, y=0.70,
        )
        self.assertGreater(result.confidence, 0.5)
        self.assertGreater(result.score, 0.0)

    def test_semantic_recognizer_does_not_invent_identity_without_samples(self):
        with tempfile.TemporaryDirectory() as directory:
            recognizer = SemanticBattleRecognizer(
                Path(directory) / "unit_visual_profiles.json", self.cards, self.combat_data,
            )
            observed = recognizer.observe(state(enemy_tracks=(track(8),)), now=2.0)
            self.assertEqual(observed.semantic_enemy_units, ())

    def test_semantic_prototypes_persist_inside_selected_workspace(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "unit_visual_profiles.json"
            recognizer = SemanticBattleRecognizer(path, self.cards, self.combat_data)
            appearance = [0.22] * 16 + [0.34] * 16 + [0.125] * 8 + [0.125] * 8
            recognizer._add_sample("knight", "base", track(1, appearance=appearance))
            recognizer.save()
            restored = SemanticBattleRecognizer(path, self.cards, self.combat_data)
            self.assertEqual(restored.prototypes[("knight", "base")].samples, 1)
            self.assertTrue(path.is_file())

    def test_full_eight_card_opponent_hypothesis_includes_every_confirmed_play(self):
        inferencer = OpponentDeckInferencer(self.cards)
        plays = tuple(
            OpponentPlay(
                token=f"p{i}", card_key=key, confidence=0.90,
                timestamp=float(i), lane=0, strength=0.5,
                source="semantic-visual", track_id=i,
            )
            for i, key in enumerate(("hog-rider", "ice-golem", "ice-spirit", "musketeer"), 1)
        )
        result = inferencer.observe(state(), plays)
        self.assertEqual(len(result.opponent_deck_top), 8)
        self.assertEqual(len(set(result.opponent_deck_top)), 8)
        self.assertTrue(set(("hog-rider", "ice-golem", "ice-spirit", "musketeer"))
                        .issubset(set(result.opponent_deck_top)))
        self.assertEqual(result.opponent_deck_unknown_slots, 4)
        self.assertFalse(result.opponent_deck_complete)
        self.assertGreater(result.opponent_deck_confidence, 0.0)

    def test_unidentified_enemy_deployments_do_not_become_confirmed_deck_cards(self):
        inferencer = OpponentDeckInferencer(self.cards)
        anonymous = OpponentPlay(
            token="anonymous", card_key="", confidence=0.9,
            timestamp=1.0, lane=0, strength=0.3, source="enemy-cluster",
        )
        result = inferencer.observe(state(), (anonymous,))
        self.assertEqual(result.opponent_deck_confirmed, ())
        self.assertEqual(result.opponent_deck_top, ())
        self.assertEqual(result.opponent_deck_unknown_slots, 8)

    def test_semantic_enemy_track_upgrades_anonymous_opponent_event(self):
        tracker = OpponentCycleTracker(self.cards)
        first = track(100, x=0.4, y=0.3)
        generic = state(enemy_tracks=(first,))
        tracker.observe(generic, now=10.0)
        unit = SemanticUnit(
            track_id=100, team="enemy", card_key="hog-rider", form="base",
            confidence=0.88, x=0.4, y=0.3, vx=0.0, vy=0.1,
            area=0.001, observations=4,
        )
        updated = tracker.observe(state(enemy_tracks=(first,), semantic_enemy_units=(unit,)), now=10.2)
        self.assertEqual(tracker.history[-1].card_key, "hog-rider")
        self.assertEqual(updated.opponent_play_count, 1)


if __name__ == "__main__":
    unittest.main()
