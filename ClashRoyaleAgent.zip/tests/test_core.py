from __future__ import annotations

import json
import importlib
import sys
from collections import Counter
import os
import struct
import sys
import threading
import time
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import zlib
from dataclasses import replace
from pathlib import Path

from core.adb import (AdbBridge, _parse_display_size, decode_android_png,
                      enrich_state_with_accessibility, parse_uiautomator_xml)
from core.agent import ClashRoyaleAgent
from core.blackbox import MAX_BYTES, create_blackbox
from core.config import load_config, save_config
from core.deck_manager import CardProfile, DeckManager
from core.navigation import FlowAction, FlowStage, GameFlow
from core.native_ui import _vk_name
from core.policy import (FEATURES, FINGERPRINT_BITS, LEGACY_V7_FEATURES, ROLE_FEATURES,
                          LocalLearner, MODEL_VERSION, _invert, _matvec)
from core.vision import (ClusterTrack, GameState, NavigationTarget, Scene,
                         VisualCluster, analyze_frame)
from core.tracking import TemporalBattleTracker
from core.tactics import assess_lane, tactical_adjustment
from core.win32 import (Frame, _stop_key_matches, key_to_vk, keysym_to_key_name,
                        process_metrics, set_dpi_awareness, window_process_path,
                        window_process_id, _stop_key_event_transition)
from tools.build_card_catalog import validate_card_metadata
from tools.replay_screenshots import classification_metrics, percentile


def sample_state(**overrides) -> GameState:
    values = dict(
        battle_detected=True,
        elixir=6.0,
        left_threat=0.55,
        right_threat=0.12,
        left_support=0.10,
        right_support=0.08,
        card_scores=(0.35, 0.42, 0.28, 0.50),
        green_ratio=0.3,
        red_ratio=0.04,
        blue_ratio=0.03,
        purple_ratio=0.5,
        confidence=0.82,
        scene=Scene.BATTLE,
        scene_confidence=0.82,
        elixir_confidence=0.8,
        card_ready=(True, True, True, True),
        card_ready_confidence=(0.9, 0.9, 0.9, 0.9),
        frame_width=360,
        frame_height=640,
    )
    values.update(overrides)
    return GameState(**values)


def synthetic_battle_frame(width: int = 360, height: int = 640, elixir_fill: float = 1.0) -> Frame:
    pixels = bytearray(width * height * 4)

    def paint(x0, y0, x1, y1, bgra):
        for y in range(y0, y1):
            for x in range(x0, x1):
                i = (y * width + x) * 4
                pixels[i:i + 4] = bytes((*bgra, 255))

    paint(25, 90, 335, 500, (24, 112, 24))
    paint(55, 310, 94, 360, (20, 20, 220))
    paint(250, 340, 288, 390, (20, 20, 220))
    paint(110, 330, 145, 375, (220, 80, 20))
    paint(210, 300, 245, 345, (220, 80, 20))
    paint(60, 522, int(60 + 240 * max(0.0, min(1.0, elixir_fill))), 545, (155, 28, 155))
    for cx, color in zip((72, 144, 216, 288),
                         ((20, 100, 220), (220, 120, 20), (180, 40, 180), (20, 180, 220))):
        paint(cx - 18, 558, cx + 18, 620, color)
    return Frame(width, height, bytes(pixels))


def _png_chunk(kind: bytes, payload: bytes) -> bytes:
    return (len(payload).to_bytes(4, "big") + kind + payload +
            zlib.crc32(kind + payload).to_bytes(4, "big"))


def tiny_png(width: int = 2, height: int = 2) -> bytes:
    # RGBA, filter 0. Rows are red/green then blue/white.
    pixels = bytes((255, 0, 0, 255, 0, 255, 0, 255,
                    0, 0, 255, 255, 255, 255, 255, 255))
    raw = b"".join(b"\x00" + pixels[y * width * 4:(y + 1) * width * 4]
                   for y in range(height))
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + _png_chunk(b"IHDR", header) +
            _png_chunk(b"IDAT", zlib.compress(raw)) + _png_chunk(b"IEND", b""))


class CoreTests(unittest.TestCase):
    def test_native_ui_key_names_roundtrip_through_virtual_key_mapping(self):
        for vk in (0x08, 0x09, 0x0D, 0x1B, 0x20, 0x21, 0x25, 0x30,
                   0x41, 0x60, 0x6A, 0x70, 0x87):
            name = _vk_name(vk)
            self.assertTrue(name, f"missing name for VK {vk:#x}")
            self.assertEqual(key_to_vk(name), vk)

    def test_ui_imports_when_tkinter_is_not_installed(self):
        import core.ui as ui_module
        original = ui_module
        with patch.dict(sys.modules, {"tkinter": None}):
            reloaded = importlib.reload(ui_module)
            self.assertIsNone(reloaded.tk)
            self.assertTrue(callable(reloaded.launch))
        importlib.reload(original)

    def test_key_mapping(self):
        self.assertEqual(key_to_vk("ESC"), 0x1B)
        self.assertEqual(key_to_vk("F8"), 0x77)
        self.assertEqual(key_to_vk("F24"), 0x87)
        self.assertEqual(key_to_vk("A"), ord("A"))
        self.assertEqual(key_to_vk("NUMPAD7"), 0x67)
        self.assertEqual(key_to_vk("KP_2"), 0x62)
        self.assertEqual(key_to_vk("NUMPAD1"), 0x61)
        self.assertEqual(keysym_to_key_name("KP_1"), "NUMPAD1")
        self.assertEqual(keysym_to_key_name("KP_9"), "NUMPAD9")
        self.assertEqual(keysym_to_key_name("KP_Enter"), "ENTER")
        self.assertEqual(keysym_to_key_name("KP_Begin"), "NUMPAD5")
        self.assertEqual(key_to_vk(keysym_to_key_name("KP_1")), 0x61)
        self.assertEqual(key_to_vk("LEFT_CTRL"), 0xA2)
        self.assertEqual(key_to_vk(";"), 0xBA)
        self.assertEqual(key_to_vk(keysym_to_key_name("bracketleft")), 0xDB)
        self.assertIsNone(key_to_vk("NOT_A_KEY"))

    def test_card_catalog_builder_requires_verified_metadata(self):
        valid = validate_card_metadata({
            "name": "Example Card", "cost": 4,
            "roles": ["building", "tank_killer"], "level": 15, "owned": True,
        })
        self.assertEqual(valid["name"], "Example Card")
        self.assertEqual(valid["roles"], ["building", "tank_killer"])
        with self.assertRaises(ValueError):
            validate_card_metadata({"name": "Unknown", "cost": 4, "roles": ["made_up"]})

    def test_replay_metrics_include_per_class_precision_recall_and_support(self):
        confusion = {
            "battle": Counter({"battle": 8, "unknown": 2}),
            "unknown": Counter({"battle": 1, "unknown": 9}),
        }
        metrics = classification_metrics(confusion)
        self.assertEqual(metrics["support_by_class"], {"battle": 10, "unknown": 10})
        self.assertEqual(metrics["per_class"]["battle"]["predicted"], 9)
        self.assertAlmostEqual(metrics["per_class"]["battle"]["recall"], 0.8)
        self.assertIsNotNone(metrics["macro_f1"])

    def test_screenshot_replay_percentiles_are_bounded(self):
        self.assertEqual(percentile([], 0.95), 0.0)
        self.assertEqual(percentile([1.0, 2.0, 3.0, 4.0], 0.50), 3.0)
        self.assertEqual(percentile([1.0, 2.0, 3.0, 4.0], 0.95), 4.0)

    def test_frame_validates_buffer(self):
        with self.assertRaises(ValueError):
            Frame(10, 10, b"too short")

    def test_android_png_decoder_converts_rgba_to_bgra_without_temp_files(self):
        frame, native_size = decode_android_png(tiny_png())
        self.assertEqual(native_size, (2, 2))
        self.assertEqual((frame.width, frame.height), (2, 2))
        self.assertEqual(frame.bgra[:4], bytes((0, 0, 255, 255)))
        self.assertEqual(frame.bgra[4:8], bytes((0, 255, 0, 255)))
        self.assertEqual(frame.bgra[8:12], bytes((255, 0, 0, 255)))

    def test_android_png_decoder_rejects_non_png_and_truncated_data(self):
        with self.assertRaises(ValueError):
            decode_android_png(b"not a png")
        with self.assertRaises(ValueError):
            decode_android_png(b"\x89PNG\r\n\x1a\n" + b"\x00" * 10)

    def test_uiautomator_parser_uses_clickable_parent_bounds(self):
        xml = b'''<?xml version="1.0" encoding="UTF-8"?>
        <hierarchy><node text="" clickable="true" enabled="true" bounds="[10,20][210,220]">
          <node text="Trophy Road" content-desc="" clickable="false" enabled="true" bounds="[30,40][190,90]"/>
        </node></hierarchy>'''
        labels = parse_uiautomator_xml(xml)
        self.assertEqual(len(labels), 1)
        self.assertTrue(labels[0].target_clickable)
        self.assertEqual(labels[0].target_bounds, (10, 20, 210, 220))

    def test_accessibility_enrichment_identifies_mode_unlock_and_targets(self):
        xml = b'''<hierarchy>
          <node text="Trophy Road" clickable="true" enabled="true" bounds="[0,100][300,240]"/>
          <node text="Path of Legends" clickable="true" enabled="true" bounds="[0,280][300,420]"/>
        </hierarchy>'''
        labels = parse_uiautomator_xml(xml)
        state = sample_state(battle_detected=False, scene=Scene.UNKNOWN,
                             confidence=0.0, scene_confidence=0.0)
        enriched = enrich_state_with_accessibility(state, labels, 300, 600)
        self.assertEqual(enriched.scene, Scene.MODE_SELECT)
        self.assertTrue(enriched.ladder_unlocked)
        self.assertIsNotNone(enriched.target("ladder"))
        self.assertIsNotNone(enriched.target("journey"))
        self.assertAlmostEqual(enriched.target("ladder").x, 0.5)

    def test_accessibility_enrichment_does_not_mistake_unlocked_for_locked(self):
        cases = (
            ("Trophy Road Unlocked", True),
            ("Trophy Road - Unlock at 500 trophies", False),
            ("Trophy Road - Not unlocked", False),
            ("奖杯之路 已解锁", True),
            ("奖杯之路 尚未解锁", False),
        )
        for label_text, expected in cases:
            with self.subTest(label_text=label_text):
                xml = ("<hierarchy><node text=\"" + label_text +
                       "\" clickable=\"true\" enabled=\"true\" bounds=\"[0,100][300,240]\"/>"
                       "<node text=\"Path of Legends\" clickable=\"true\" enabled=\"true\" bounds=\"[0,280][300,420]\"/>"
                       "</hierarchy>").encode("utf-8")
                labels = parse_uiautomator_xml(xml)
                state = sample_state(battle_detected=False, scene=Scene.UNKNOWN,
                                     confidence=0.0, scene_confidence=0.0)
                enriched = enrich_state_with_accessibility(state, labels, 300, 600)
                self.assertEqual(enriched.ladder_unlocked, expected)

    def test_accessibility_enrichment_reads_unlocked_badge_under_ladder_parent(self):
        xml = b'''<hierarchy>
          <node text="Trophy Road" clickable="true" enabled="true" bounds="[0,100][300,240]">
            <node text="Unlocked" clickable="false" enabled="true" bounds="[20,120][160,160]"/>
          </node>
          <node text="Path of Legends" clickable="true" enabled="true" bounds="[0,280][300,420]"/>
        </hierarchy>'''
        labels = parse_uiautomator_xml(xml)
        state = sample_state(battle_detected=False, scene=Scene.UNKNOWN,
                             confidence=0.0, scene_confidence=0.0)
        enriched = enrich_state_with_accessibility(state, labels, 300, 600)
        self.assertTrue(enriched.ladder_unlocked)
        self.assertEqual(enriched.target("ladder").x, 0.5)
        self.assertTrue(enriched.target("ladder").screen_space)

    def test_accessibility_enrichment_does_not_mistake_pass_for_battle_button(self):
        xml = b'''<hierarchy>
          <node text="Play Pass" clickable="true" enabled="true" bounds="[0,100][300,240]">
            <node text="Play" clickable="false" enabled="true" bounds="[20,120][120,180]"/>
          </node>
        </hierarchy>'''
        labels = parse_uiautomator_xml(xml)
        state = sample_state(battle_detected=False, scene=Scene.HOME,
                             confidence=0.0, scene_confidence=0.91)
        enriched = enrich_state_with_accessibility(state, labels, 300, 600)
        self.assertIsNone(enriched.target("mode_entry"))

    def test_accessibility_enrichment_detects_locked_ladder_and_result_outcome(self):
        xml = b'''<hierarchy>
          <node text="Trophy Road locked" clickable="true" enabled="false" bounds="[0,100][300,240]"/>
          <node text="Path of Legends" clickable="true" enabled="true" bounds="[0,280][300,420]"/>
          <node text="Defeat" clickable="false" enabled="true" bounds="[20,20][280,80]"/>
          <node text="Continue" clickable="true" enabled="true" bounds="[40,450][260,540]"/>
        </hierarchy>'''
        labels = parse_uiautomator_xml(xml)
        state = sample_state(battle_detected=False, scene=Scene.UNKNOWN,
                             confidence=0.0, scene_confidence=0.0)
        enriched = enrich_state_with_accessibility(state, labels, 300, 600)
        self.assertEqual(enriched.scene, Scene.RESULT)
        self.assertFalse(enriched.battle_detected)
        self.assertEqual(enriched.result, "loss")
        self.assertGreaterEqual(enriched.result_confidence, 0.99)

    def test_adb_subprocess_is_interrupted_by_stop_event(self):
        bridge = AdbBridge(Path(sys.executable), "")
        stop_event = threading.Event()
        timer = threading.Timer(0.12, stop_event.set)
        timer.start()
        started = time.monotonic()
        try:
            result = bridge._run(["-c", "import time; time.sleep(10)"],
                                 timeout=5.0, stop_event=stop_event)
        finally:
            timer.cancel()
        self.assertEqual(result.returncode, 130)
        self.assertLess(time.monotonic() - started, 1.0)

    def test_adb_prefers_override_display_size(self):
        self.assertEqual(_parse_display_size("Physical size: 1080x1920\nOverride size: 720x1280"),
                         (720, 1280))
        self.assertEqual(_parse_display_size("Physical size: 1080x1920"), (1080, 1920))
        self.assertIsNone(_parse_display_size("Physical size: 80x90"))

    def test_adb_window_binding_requires_matching_live_frames(self):
        pixels = bytes((10, 30, 90, 255)) * (120 * 240)
        same = Frame(120, 240, pixels)
        different = Frame(120, 240, bytes((220, 10, 5, 255)) * (120 * 240))
        self.assertTrue(AdbBridge.frames_correspond(same, same))
        self.assertFalse(AdbBridge.frames_correspond(same, different))

    def test_adb_auth_and_temp_paths_stay_inside_selected_workspace(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "selected" / "ClashRoyaleAgent"
            bridge = AdbBridge(Path(sys.executable), "", state_dir=workspace)
            script = (
                "import os; print(os.environ['ANDROID_USER_HOME']); "
                "print(os.environ['ANDROID_SDK_HOME']); print(os.environ['TEMP'])"
            )
            result = bridge._run(["-c", script], timeout=3.0)
            lines = result.stdout.decode().splitlines()
            self.assertEqual(lines[0], str(workspace.resolve() / ".android"))
            self.assertEqual(lines[1], str(workspace.resolve()))
            self.assertEqual(lines[2], str(workspace.resolve() / ".tmp"))
            self.assertTrue((workspace / ".android").is_dir())
            self.assertTrue((workspace / ".tmp").is_dir())

    def test_visual_viewport_detection_and_original_frame_dimensions(self):
        width, height = 320, 640
        pixels = bytearray(width * height * 4)
        for y in range(height):
            for x in range(24, width - 24):
                offset = (y * width + x) * 4
                pixels[offset:offset + 4] = bytes((80, 90, 100, 255))
        state = analyze_frame(Frame(width, height, bytes(pixels)))
        self.assertEqual((state.frame_width, state.frame_height), (width, height))
        self.assertAlmostEqual(state.viewport[0], 24 / width, delta=0.01)
        self.assertAlmostEqual(state.viewport[2], (width - 24) / width, delta=0.01)

    def test_click_coordinates_are_mapped_through_detected_viewport(self):
        with tempfile.TemporaryDirectory() as directory:
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace", lambda _summary: None)
            state = sample_state(viewport=(0.10, 0.05, 0.90, 0.95))
            with patch("core.agent.click_ratio", return_value=True) as click:
                self.assertTrue(agent._click_ratio(0.25, 0.50, state=state))
                click.assert_called_once()
                args = click.call_args.args
                self.assertAlmostEqual(args[1], 0.30)
                self.assertAlmostEqual(args[2], 0.50)
            with patch("core.agent.click_ratio", return_value=True) as click:
                self.assertTrue(agent._click_ratio(0.25, 0.50, state=state, screen_space=True))
                args = click.call_args.args
                self.assertAlmostEqual(args[1], 0.25)
                self.assertAlmostEqual(args[2], 0.50)
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)

    def test_adb_input_is_suppressed_when_selected_window_identity_changes(self):
        class FakeAdb:
            def __init__(self):
                self.calls = 0
            def tap_ratio(self, *_args):
                self.calls += 1
                return True
        with tempfile.TemporaryDirectory() as directory:
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace", lambda _summary: None)
            fake = FakeAdb()
            agent.adb = fake
            with patch("core.agent.window_identity_matches", return_value=False):
                self.assertFalse(agent._click_ratio(0.5, 0.5))
            self.assertEqual(fake.calls, 0)
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)

    def test_non_windows_process_id_helper_is_safe(self):
        if os.name != "nt":
            self.assertIsNone(window_process_id(1))

    def test_dpi_and_process_metrics_helpers_are_safe_on_non_windows_hosts(self):
        if os.name != "nt":
            self.assertFalse(set_dpi_awareness())
            self.assertIsNone(process_metrics())

    def test_tactical_lane_assessment_uses_enemy_motion_and_projected_front(self):
        stationary = ClusterTrack(1, 0.30, 0.70, 0.0, 0.0, 0.08, 0.06,
                                  0.008, 0.9, 1.0, 3, 10.0)
        advancing = replace(stationary, vy=0.45)
        base = sample_state(left_threat=0.05, right_threat=0.05,
                            enemy_tracks=(stationary,))
        moving = replace(base, enemy_tracks=(advancing,))
        self.assertGreater(assess_lane(moving, 0).enemy_advance,
                           assess_lane(base, 0).enemy_advance)
        self.assertGreater(assess_lane(moving, 0).defensive_urgency,
                           assess_lane(base, 0).defensive_urgency)

    def test_tactical_spell_score_requires_cluster_evidence(self):
        no_cluster = sample_state(left_threat=0.30, right_threat=0.05,
                                  card_roles=(("spell",), (), (), ()))
        clusters = (
            VisualCluster(0.30, 0.60, 0.08, 0.06, 0.006, 0.9),
            VisualCluster(0.34, 0.64, 0.08, 0.06, 0.006, 0.9),
        )
        clustered = replace(no_cluster, enemy_clusters=clusters)
        self.assertGreater(tactical_adjustment(clustered, 0, 0),
                           tactical_adjustment(no_cluster, 0, 0))

    def test_tactical_defender_is_preferred_under_lane_pressure(self):
        state = sample_state(left_threat=0.62, right_threat=0.08,
                             card_roles=(("win_condition",), ("tank_killer",), (), ()))
        defender = tactical_adjustment(state, 1, 0)
        win_condition = tactical_adjustment(state, 0, 0)
        self.assertGreater(defender, win_condition)

    def test_vision_detects_synthetic_battle_and_card_fingerprints(self):
        state = analyze_frame(synthetic_battle_frame())
        self.assertTrue(state.battle_detected)
        self.assertEqual(state.scene, Scene.BATTLE)
        self.assertGreaterEqual(state.confidence, 0.54)
        self.assertGreater(state.elixir_confidence, 0.8)
        self.assertGreaterEqual(state.elixir, 9.5)
        self.assertTrue(state.has_playable_card)
        self.assertTrue(all(len(value) == 16 for value in state.card_fingerprints))
        self.assertEqual(len(state.card_descriptors), 4)
        self.assertGreaterEqual(len(state.enemy_clusters), 2)
        self.assertGreaterEqual(len(state.friendly_clusters), 2)
        self.assertTrue(all(0.0 <= item.x <= 1.0 and 0.0 <= item.y <= 1.0
                            for item in state.enemy_clusters + state.friendly_clusters))

    def test_vision_estimates_half_elixir_bar_from_fill_length(self):
        state = analyze_frame(synthetic_battle_frame(elixir_fill=0.5))
        self.assertAlmostEqual(state.elixir, 5.0, delta=0.25)
        self.assertGreater(state.elixir_confidence, 0.8)

    def test_visual_mode_selector_provides_geometry_but_not_unlock_claim(self):
        width, height = 360, 640
        pixels = bytearray(width * height * 4)
        for index in range(0, len(pixels), 4):
            pixels[index:index + 4] = bytes((28, 30, 36, 255))
        gold = bytes((20, 120, 220, 255))
        for y0, y1 in ((180, 240), (320, 380)):
            for y in range(y0, y1):
                for x in range(60, 300):
                    offset = (y * width + x) * 4
                    pixels[offset:offset + 4] = gold
        state = analyze_frame(Frame(width, height, bytes(pixels)))
        self.assertEqual(state.scene, Scene.MODE_SELECT)
        self.assertIsNone(state.ladder_unlocked)
        self.assertIsNotNone(state.target("ladder"))
        self.assertIsNotNone(state.target("journey"))
        self.assertLess(state.target("ladder").y, state.target("journey").y)

    def test_vision_does_not_guess_blank_screen(self):
        frame = Frame(360, 640, bytes(360 * 640 * 4))
        state = analyze_frame(frame)
        self.assertFalse(state.battle_detected)
        self.assertEqual(state.scene, Scene.UNKNOWN)
        self.assertIsNone(state.ladder_unlocked)
        self.assertIsNone(state.result)

    def test_flow_debounces_battle(self):
        flow = GameFlow()
        state = sample_state()
        first = flow.update(state, now=100.0)
        second = flow.update(state, now=100.1)
        self.assertEqual(first.action, FlowAction.WAIT)
        self.assertEqual(second.action, FlowAction.PLAY)
        self.assertEqual(second.stage, FlowStage.IN_BATTLE)

    def test_flow_waits_when_ladder_unlock_status_is_unknown(self):
        flow = GameFlow()
        state = sample_state(battle_detected=False, scene=Scene.MODE_SELECT,
                             confidence=0.0, scene_confidence=0.9)
        decision = flow.update(state, now=100.0)
        self.assertEqual(decision.action, FlowAction.WAIT)
        self.assertIn("ladder unlock status is unknown", decision.reason)

    def test_home_opens_only_the_verified_mode_selector_and_preserves_deck(self):
        flow = GameFlow()
        target = NavigationTarget("mode_entry", 0.5, 0.72, 0.96)
        state = sample_state(battle_detected=False, scene=Scene.HOME,
                             confidence=0.0, scene_confidence=0.91, targets=(target,))
        decisions = [flow.update(state, now=100.0 + index * 0.1) for index in range(5)]
        self.assertEqual(decisions[-1].action, FlowAction.OPEN_MODE_SELECT)
        self.assertEqual(decisions[-1].target, target)
        self.assertFalse(hasattr(flow, "deck_due"))

    def test_home_without_target_never_uses_a_fixed_click(self):
        flow = GameFlow()
        state = sample_state(battle_detected=False, scene=Scene.HOME,
                             confidence=0.0, scene_confidence=0.91)
        decisions = [flow.update(state, now=100.0 + index * 0.1) for index in range(6)]
        self.assertTrue(all(item.action is FlowAction.WAIT for item in decisions))
        self.assertIn("no verified visual target", decisions[-1].reason)

    def test_mode_entry_waits_for_transition_and_retries_only_after_timeout(self):
        flow = GameFlow()
        target = NavigationTarget("mode_entry", 0.5, 0.7, 0.96)
        state = sample_state(battle_detected=False, scene=Scene.HOME,
                             confidence=0.0, scene_confidence=0.91, targets=(target,))
        decisions = [flow.update(state, now=300.0 + i * 0.1) for i in range(5)]
        self.assertEqual(decisions[-1].action, FlowAction.OPEN_MODE_SELECT)
        flow.mark_action_completed(FlowAction.OPEN_MODE_SELECT)
        self.assertEqual(flow.update(state, now=300.6).action, FlowAction.WAIT)
        self.assertEqual(flow.update(state, now=306.0).action, FlowAction.OPEN_MODE_SELECT)

    def test_cancelled_matchmaking_resumes_mode_selection_from_lobby(self):
        flow = GameFlow()
        matchmaking = sample_state(battle_detected=False, scene=Scene.MATCHMAKING,
                                   confidence=0.0, scene_confidence=0.8)
        self.assertEqual(flow.update(matchmaking, now=50.0).action, FlowAction.WAIT)
        target = NavigationTarget("mode_entry", 0.5, 0.7, 0.96)
        home = sample_state(battle_detected=False, scene=Scene.HOME,
                            confidence=0.0, scene_confidence=0.91, targets=(target,))
        decisions = [flow.update(home, now=60.0 + i * 0.1) for i in range(5)]
        self.assertEqual(decisions[-1].action, FlowAction.OPEN_MODE_SELECT)

    def test_deck_page_returns_home_without_editing_cards(self):
        flow = GameFlow()
        target = NavigationTarget("deck_back", 0.15, 0.94, 0.96)
        state = sample_state(battle_detected=False, scene=Scene.DECK,
                             confidence=0.0, scene_confidence=0.91, targets=(target,))
        decisions = [flow.update(state, now=120.0 + i * 0.1) for i in range(5)]
        self.assertEqual(decisions[-1].action, FlowAction.RETURN_HOME)
        self.assertEqual(decisions[-1].target, target)

    def test_selected_mode_can_advance_to_verified_start_button(self):
        flow = GameFlow()
        ladder = NavigationTarget("ladder", 0.5, 0.4, 0.97)
        start = NavigationTarget("start_match", 0.5, 0.8, 0.97)
        state = sample_state(battle_detected=False, scene=Scene.MODE_SELECT,
                             confidence=0.0, scene_confidence=0.92,
                             ladder_unlocked=True, targets=(ladder, start))
        for index in range(4):
            flow.update(state, now=200.0 + index * 0.1)
        selected = flow.update(state, now=200.4)
        self.assertEqual(selected.action, FlowAction.SELECT_LADDER)
        flow.mark_action_completed(selected.action)
        next_decision = flow.update(state, now=203.0)
        self.assertEqual(next_decision.action, FlowAction.START_MATCH)
        flow.mark_action_completed(next_decision.action)
        self.assertEqual(flow.update(state, now=206.0).action, FlowAction.WAIT)
        self.assertEqual(flow.update(state, now=209.0).action, FlowAction.START_MATCH)

    def test_result_continues_to_lobby_then_reopens_mode_selector(self):
        flow = GameFlow()
        result_target = NavigationTarget("result_continue", 0.5, 0.85, 0.95)
        result_state = sample_state(battle_detected=False, scene=Scene.RESULT,
                                    confidence=0.0, scene_confidence=0.95,
                                    targets=(result_target,))
        for index in range(4):
            self.assertEqual(flow.update(result_state, now=100.0 + index * 0.1).action,
                             FlowAction.WAIT)
        decision = flow.update(result_state, now=100.4)
        self.assertEqual(decision.action, FlowAction.CONTINUE_RESULT)
        flow.mark_action_completed(decision.action)

        mode_target = NavigationTarget("mode_entry", 0.5, 0.7, 0.95)
        home_state = sample_state(battle_detected=False, scene=Scene.HOME,
                                  confidence=0.0, scene_confidence=0.91,
                                  targets=(mode_target,))
        decisions = [flow.update(home_state, now=104.0 + index * 0.1) for index in range(5)]
        self.assertEqual(decisions[-1].action, FlowAction.OPEN_MODE_SELECT)

    def test_mode_selection_prefers_ladder_and_falls_back_only_when_locked(self):
        ladder_flow = GameFlow()
        ladder_target = NavigationTarget("ladder", 0.5, 0.42, 0.97)
        ladder_state = sample_state(battle_detected=False, scene=Scene.MODE_SELECT,
                                    confidence=0.0, scene_confidence=0.92,
                                    ladder_unlocked=True, targets=(ladder_target,))
        for index in range(4):
            ladder_flow.update(ladder_state, now=200.0 + index * 0.1)
        self.assertEqual(ladder_flow.update(ladder_state, now=200.4).action,
                         FlowAction.SELECT_LADDER)

        path_flow = GameFlow()
        path_target = NavigationTarget("journey", 0.5, 0.68, 0.97)
        path_state = replace(ladder_state, ladder_unlocked=False, targets=(path_target,))
        for index in range(4):
            path_flow.update(path_state, now=300.0 + index * 0.1)
        self.assertEqual(path_flow.update(path_state, now=300.4).action,
                         FlowAction.SELECT_PATH)

    def test_journey_fallback_rechecks_and_switches_to_ladder_after_unlock(self):
        flow = GameFlow()
        journey = NavigationTarget("journey", 0.5, 0.65, 0.97)
        start = NavigationTarget("start_match", 0.5, 0.82, 0.97)
        locked = sample_state(battle_detected=False, scene=Scene.MODE_SELECT,
                              confidence=0.0, scene_confidence=0.92,
                              ladder_unlocked=False, targets=(journey, start))
        decision = None
        for index in range(5):
            decision = flow.update(locked, now=400.0 + index * 0.1)
        self.assertEqual(decision.action, FlowAction.SELECT_PATH)
        flow.mark_action_completed(decision.action)
        self.assertEqual(flow.update(locked, now=403.0).action, FlowAction.START_MATCH)
        result_target = NavigationTarget("result_continue", 0.5, 0.85, 0.97)
        result = sample_state(battle_detected=False, scene=Scene.RESULT,
                              confidence=0.0, scene_confidence=0.95, targets=(result_target,))
        result_decision = None
        for index in range(5):
            result_decision = flow.update(result, now=410.0 + index * 0.1)
        self.assertEqual(result_decision.action, FlowAction.CONTINUE_RESULT)
        flow.mark_action_completed(result_decision.action)
        home_target = NavigationTarget("mode_entry", 0.5, 0.72, 0.97)
        home = sample_state(battle_detected=False, scene=Scene.HOME,
                            confidence=0.0, scene_confidence=0.92, targets=(home_target,))
        for index in range(5):
            home_decision = flow.update(home, now=420.0 + index * 0.1)
        self.assertEqual(home_decision.action, FlowAction.OPEN_MODE_SELECT)
        flow.mark_action_completed(home_decision.action)
        unlocked = sample_state(battle_detected=False, scene=Scene.MODE_SELECT,
                                confidence=0.0, scene_confidence=0.92,
                                ladder_unlocked=True,
                                targets=(NavigationTarget("ladder", 0.5, 0.4, 0.97), start))
        for index in range(5):
            ladder_decision = flow.update(unlocked, now=430.0 + index * 0.1)
        self.assertEqual(ladder_decision.action, FlowAction.SELECT_LADDER)

    def test_deck_manager_learns_visual_identity_and_cost_interval(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(Path(directory) / "card_profiles.json")
            fingerprint = "0123456789abcdef"
            base = sample_state(card_fingerprints=(fingerprint, "", "", ""),
                                 card_ready=(False, False, False, False),
                                 card_ready_confidence=(0.95, 0.0, 0.0, 0.0), elixir=3.4)
            for _ in range(3):
                manager.observe(base)
                ready_state = replace(base, card_ready=(True, False, False, False), elixir=4.4)
                manager.observe(ready_state)
            observed = manager.observe(ready_state)
            self.assertEqual(len(manager.profiles), 1)
            profile = next(iter(manager.profiles.values()))
            self.assertGreater(profile.cost_samples, 0)
            self.assertIsNotNone(observed.card_costs[0])
            manager.save()
            restored = DeckManager(Path(directory) / "card_profiles.json")
            self.assertEqual(len(restored.profiles), 1)

    def test_deck_manager_plans_only_from_owned_role_verified_cards(self):
        with tempfile.TemporaryDirectory() as directory:
            catalog = {}
            manager = DeckManager(Path(directory) / "card_profiles.json", catalog=catalog)
            role_sets = [
                ["win_condition"], ["spell"], ["spell"], ["air_defense"],
                ["building"], ["support"], ["cycle"], ["tank_killer", "support"],
            ]
            for index, roles in enumerate(role_sets, 1):
                fingerprint = f"{index:016x}"
                manager.profiles[f"card_{index:04d}"] = CardProfile(
                    profile_id=f"card_{index:04d}", fingerprint=fingerprint,
                    observations=10, cost_samples=4, cost_estimate=3.8,
                    cost_low=3.6, cost_high=4.0,
                )
                catalog[fingerprint] = {"owned": True, "roles": roles, "cost": 3.8, "level": 12}
            manager.catalog = catalog
            plan = manager.build_plan()
            self.assertIsNotNone(plan)
            self.assertEqual(len(plan), 8)
            self.assertEqual(len(set(plan)), 8)

    def test_deck_manager_loads_only_valid_local_catalog_entries(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "card_catalog.json").write_text(json.dumps({
                "version": 1,
                "cards": {
                    "0123456789abcdef": {"name": "Card A", "owned": True,
                                         "roles": ["win_condition", "invalid_role"],
                                         "cost": 4, "level": 12},
                    "bad-fingerprint": {"name": "Bad", "owned": True,
                                        "roles": ["spell"], "cost": 3, "level": 10},
                    "1111111111111111": {"name": "Bad cost", "owned": True,
                                         "roles": ["spell"], "cost": 99, "level": 10},
                },
            }), encoding="utf-8")
            manager = DeckManager(root / "card_profiles.json")
            self.assertEqual(list(manager.catalog), ["0123456789abcdef"])
            self.assertEqual(manager.catalog["0123456789abcdef"]["roles"], ["win_condition"])

    def test_deck_manager_matches_verified_catalog_descriptors_and_exposes_roles(self):
        with tempfile.TemporaryDirectory() as directory:
            fingerprint = "0000000000000000"
            descriptor = [0.2] * 19
            manager = DeckManager(
                Path(directory) / "card_profiles.json",
                catalog={fingerprint: {
                    "name": "Verified Card", "roles": ["building", "tank_killer"],
                    "cost": 4, "level": 12, "owned": True,
                    "descriptor": descriptor,
                }},
            )
            state = sample_state(
                card_fingerprints=("0000000000000001", "", "", ""),
                card_descriptors=(tuple(descriptor),),
            )
            observed = manager.observe(state)
            self.assertEqual(observed.card_names[0], "Verified Card")
            self.assertEqual(observed.card_roles[0], ("building", "tank_killer"))
            self.assertEqual(observed.card_costs[0], 4.0)

    def test_deck_manager_does_not_learn_battle_hand_fingerprints_from_deck_screen(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(Path(directory) / "card_profiles.json")
            state = sample_state(scene=Scene.DECK)
            manager.observe(state)
            self.assertEqual(manager.profiles, {})

    def test_deck_manager_does_not_merge_different_cards_on_hash_alone(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(Path(directory) / "card_profiles.json")
            first = manager._match_or_create("0000000000000000", tuple([0.0] * 16))
            second = manager._match_or_create("0000000000000001", tuple([1.0] * 16))
            self.assertNotEqual(first.profile_id, second.profile_id)
            self.assertEqual(len(manager.profiles), 2)

    def test_deck_manager_does_not_merge_ambiguous_nearest_profiles(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(Path(directory) / "profiles.json", catalog={})
            descriptor = tuple([0.5] * 19)
            manager.profiles["card_0001"] = CardProfile(
                "card_0001", "0000000000000000", observations=4,
                descriptor=list(descriptor), last_seen=1,
            )
            manager.profiles["card_0002"] = CardProfile(
                "card_0002", "0000000000000000", observations=5,
                descriptor=list(descriptor), last_seen=2,
            )
            manager._next_id = 3
            matched = manager._match_or_create("0000000000000000", descriptor)
            self.assertEqual(matched.profile_id, "card_0003")
            self.assertEqual(manager.profiles["card_0001"].observations, 4)
            self.assertEqual(manager.profiles["card_0002"].observations, 5)

    def test_deck_manager_refuses_to_invent_a_deck_without_semantics(self):
        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(Path(directory) / "card_profiles.json")
            self.assertIsNone(manager.build_plan())
            self.assertFalse(manager.assessment().can_recommend)

    def test_policy_uses_expanded_card_aware_features_and_respects_cost(self):
        state = sample_state(card_ready=(True, True, False, False),
                             card_costs=(7.0, 3.0, None, None),
                             card_fingerprints=("0123456789abcdef", "fedcba9876543210", "", ""))
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            choice = learner.choose(state, 12.0)
            self.assertIsNotNone(choice)
            card, lane, features = choice
            self.assertEqual(card, 1)
            self.assertIn(lane, (0, 1))
            self.assertEqual(len(features), FEATURES)

    def test_policy_encodes_card_fingerprint_as_binary_dimensions_not_one_scalar(self):
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            zeros = sample_state(card_fingerprints=("0000000000000000", "", "", ""))
            ones = sample_state(card_fingerprints=("ffffffffffffffff", "", "", ""))
            zero_features = learner.features(zeros, 0, 0, 1.0)
            one_features = learner.features(ones, 0, 0, 1.0)
            bit_start = LEGACY_V7_FEATURES
            self.assertEqual(FINGERPRINT_BITS, 64)
            self.assertEqual(len(zero_features), FEATURES)
            self.assertEqual(zero_features[12], 0.0)  # reserved legacy scalar slot
            self.assertEqual(zero_features[bit_start:], [0.0] * FINGERPRINT_BITS)
            self.assertEqual(one_features[bit_start:], [1.0] * FINGERPRINT_BITS)
            self.assertEqual(len(ROLE_FEATURES), 11)

    def test_policy_features_include_enemy_and_friendly_visual_cluster_context(self):
        enemy = (VisualCluster(0.30, 0.72, 0.08, 0.06, 0.004, 0.9),
                 VisualCluster(0.35, 0.44, 0.06, 0.05, 0.003, 0.8))
        friendly = (VisualCluster(0.28, 0.65, 0.07, 0.06, 0.003, 0.8),)
        state = sample_state(enemy_clusters=enemy, friendly_clusters=friendly)
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            features = learner.features(state, 0, 0, 12.0)
            self.assertEqual(features[15], 0.4)
            self.assertEqual(features[16], 0.2)
            self.assertEqual(features[17], 0.72)

    def test_policy_features_include_verified_card_roles(self):
        state = sample_state(card_roles=(("spell", "air_defense"), (), (), ()))
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            features = learner.features(state, 0, 0, 12.0)
            self.assertEqual(features[19], 1.0)  # spell
            self.assertEqual(features[20], 1.0)  # air defense
            self.assertEqual(features[18], 0.0)  # win condition

    def test_policy_keeps_cached_prediction_after_rank_one_learning_update(self):
        state = sample_state(card_ready=(True, False, False, False))
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            learner.choose(state, 12.0)
            first_builds = learner._prediction_cache_builds
            learner.choose(state, 13.0)
            self.assertEqual(learner._prediction_cache_builds, first_builds)
            features = learner.features(state, 0, 0, 13.0)
            learner._prediction(0)
            builds_before_update = learner._prediction_cache_builds
            self.assertTrue(learner.update(0, 0, features, 0.4, confidence=0.9))
            learner._prediction(0)
            self.assertEqual(learner._prediction_cache_builds, builds_before_update)

    def test_policy_rank_one_cache_update_matches_full_matrix_inverse(self):
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            action = 3
            learner._prediction(action)
            features = [0.0] * FEATURES
            features[0] = 1.0
            features[4] = 0.25
            features[-1] = 0.5
            learner._apply(action, features, reward=0.35, weight=0.17, decay=0.9997)
            cached_inverse, cached_theta = learner._prediction(action)
            expected_inverse = _invert(learner.matrices[action])
            expected_theta = _matvec(expected_inverse, learner.targets[action])
            theta_error = max(abs(a - b) for a, b in zip(cached_theta, expected_theta))
            inverse_error = max(
                abs(cached_inverse[row][col] - expected_inverse[row][col])
                for row in range(FEATURES) for col in range(FEATURES)
            )
            self.assertLess(theta_error, 1e-7)
            self.assertLess(inverse_error, 1e-7)

    def test_online_learner_roundtrip(self):
        state = sample_state(card_ready=(False, True, False, False))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            learner = LocalLearner(path)
            choice = learner.choose(state, 12.0)
            self.assertIsNotNone(choice)
            card, lane, features = choice
            self.assertEqual(card, 1)
            self.assertTrue(learner.update(card, lane, features, 0.25, confidence=0.4))
            learner.save()
            restored = LocalLearner(path)
            self.assertEqual(restored.learn_count, 1)
            self.assertEqual(restored.load_status, "loaded")
            self.assertEqual(restored.replay[0]["action"], card * 2 + lane)

    def test_low_confidence_update_is_discarded(self):
        state = sample_state()
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            features = learner.features(state, 0, 0, 1.0)
            self.assertFalse(learner.update(0, 0, features, 0.8, confidence=0.1))
            self.assertEqual(learner.learn_count, 0)

    def test_terminal_match_reward_is_recorded_and_persisted(self):
        state = sample_state()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            learner = LocalLearner(path)
            features = learner.features(state, 1, 0, 20.0)
            learner.begin_episode()
            learner.record_action(1, 0, features, confidence=0.9)
            self.assertEqual(learner.finish_episode("win"), 1)
            self.assertEqual(learner.episode_count, 1)
            self.assertEqual(learner.wins, 1)
            self.assertEqual(learner.learn_count, 1)
            self.assertEqual(learner.replay[-1]["outcome"], "win")
            learner.save()
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "loaded")
            self.assertEqual(restored.wins, 1)
            self.assertEqual(restored.episode_count, 1)

    def test_interrupted_episode_does_not_invent_a_result(self):
        state = sample_state()
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            learner.begin_episode()
            learner.record_action(0, 0, learner.features(state, 0, 0, 1.0), 0.8)
            learner.abort_episode()
            self.assertEqual(learner.finish_episode("win"), 0)
            self.assertEqual(learner.episode_count, 0)

    def test_unlabeled_match_is_counted_without_training(self):
        state = sample_state()
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            learner.begin_episode()
            learner.record_action(0, 0, learner.features(state, 0, 0, 1.0), 0.9)
            learner.abort_episode(unknown_result=True)
            self.assertEqual(learner.unlabeled_episodes, 1)
            self.assertEqual(learner.learn_count, 0)
            self.assertEqual(learner.finish_episode("win"), 0)

    def test_terminal_credit_is_confidence_gated_and_recency_weighted(self):
        state = sample_state()
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            features = learner.features(state, 0, 0, 1.0)
            learner.begin_episode()
            learner.record_action(0, 0, features, 0.9)
            learner.record_action(0, 0, features, 0.9)
            self.assertEqual(learner.finish_episode("win", confidence=0.5), 0)
            self.assertEqual(learner.episode_count, 0)
            learner.begin_episode()
            learner.record_action(0, 0, features, 0.9)
            learner.record_action(0, 0, features, 0.9)
            self.assertEqual(learner.finish_episode("win", confidence=0.95), 2)
            first_weight = learner.replay[-2]["confidence"]
            last_weight = learner.replay[-1]["confidence"]
            self.assertGreater(last_weight, first_weight)
            self.assertEqual(learner.recent_win_rate, 1.0)

    def test_model_recovers_from_last_known_good_backup(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            learner = LocalLearner(path)
            learner.save()
            learner.learn_count = 12
            learner.save()
            backup = path.with_suffix(path.suffix + ".bak")
            self.assertTrue(backup.is_file())
            path.write_text("{broken", encoding="utf-8")
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "recovered_backup")
            self.assertEqual(restored.learn_count, 0)

    def test_v5_model_migrates_to_v8_without_discarding_old_weights(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            old_features = 15
            matrices = [[[1.0 if r == c else 0.0 for c in range(old_features)]
                         for r in range(old_features)] for _ in range(8)]
            matrices[0][0][0] = 2.5
            targets = [[0.0] * old_features for _ in range(8)]
            targets[0][0] = 0.75
            payload = {"version": 5, "learn_count": 6, "reward_sum": 1.25,
                       "matrices": matrices, "targets": targets, "replay": [],
                       "episode_count": 0, "wins": 0, "losses": 0, "draws": 0}
            path.write_text(json.dumps(payload), encoding="utf-8")
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "migrated_v5")
            self.assertEqual(restored.learn_count, 6)
            self.assertEqual(len(restored.matrices[0]), FEATURES)
            self.assertAlmostEqual(restored.matrices[0][0][0], 2.5)
            self.assertAlmostEqual(restored.targets[0][0], 0.75)

    def test_v3_model_migrates_to_v8_without_discarding_old_weights(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            old_features = 9
            matrices = [[[1.0 if r == c else 0.0 for c in range(old_features)]
                         for r in range(old_features)] for _ in range(8)]
            matrices[0][0][0] = 2.5
            targets = [[0.0] * old_features for _ in range(8)]
            targets[0][0] = 0.75
            payload = {"version": 3, "learn_count": 4, "reward_sum": 1.5,
                       "matrices": matrices, "targets": targets, "replay": [],
                       "episode_count": 0, "wins": 0, "losses": 0, "draws": 0}
            path.write_text(json.dumps(payload), encoding="utf-8")
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "migrated_v3")
            self.assertEqual(restored.learn_count, 4)
            self.assertEqual(len(restored.matrices[0]), FEATURES)
            self.assertAlmostEqual(restored.matrices[0][0][0], 2.5)
            self.assertAlmostEqual(restored.targets[0][0], 0.75)

    def test_v6_model_migrates_to_v8_with_verified_role_features_zeroed(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            old_features = 18
            matrices = [[[1.0 if r == c else 0.0 for c in range(old_features)]
                         for r in range(old_features)] for _ in range(8)]
            targets = [[0.0] * old_features for _ in range(8)]
            matrices[0][3][3] = 1.75
            targets[0][3] = 0.5
            payload = {"version": 6, "learn_count": 9, "reward_sum": 1.0,
                       "matrices": matrices, "targets": targets, "replay": [],
                       "episode_count": 0, "wins": 0, "losses": 0, "draws": 0}
            path.write_text(json.dumps(payload), encoding="utf-8")
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "migrated_v6")
            self.assertEqual(len(restored.matrices[0]), FEATURES)
            self.assertAlmostEqual(restored.matrices[0][3][3], 1.75)
            self.assertEqual(restored.matrices[0][18][18], 1.0)
            self.assertEqual(restored.targets[0][18], 0.0)

    def test_v7_model_migrates_to_v8_without_discarding_existing_features(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            old_features = LEGACY_V7_FEATURES
            matrices = [[[1.0 if r == c else 0.0 for c in range(old_features)]
                         for r in range(old_features)] for _ in range(8)]
            targets = [[0.0] * old_features for _ in range(8)]
            matrices[0][12][12] = 2.25
            targets[0][12] = 0.75
            payload = {"version": 7, "learn_count": 17, "reward_sum": 2.0,
                       "matrices": matrices, "targets": targets, "replay": [],
                       "episode_count": 0, "wins": 0, "losses": 0, "draws": 0}
            path.write_text(json.dumps(payload), encoding="utf-8")
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "migrated_v7")
            self.assertEqual(restored.learn_count, 17)
            self.assertEqual(len(restored.matrices[0]), FEATURES)
            self.assertAlmostEqual(restored.matrices[0][12][12], 2.25)
            self.assertAlmostEqual(restored.targets[0][12], 0.75)
            self.assertEqual(restored.matrices[0][LEGACY_V7_FEATURES][LEGACY_V7_FEATURES], 1.0)

    def test_v2_model_migrates_with_missing_episode_statistics(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            old_features = 9
            matrices = [[[1.0 if r == c else 0.0 for c in range(old_features)]
                         for r in range(old_features)] for _ in range(8)]
            targets = [[0.0] * old_features for _ in range(8)]
            matrices[2][3][3] = 1.75
            payload = {"version": 2, "learn_count": 2, "reward_sum": -0.5,
                       "matrices": matrices, "targets": targets, "replay": []}
            path.write_text(json.dumps(payload), encoding="utf-8")
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "migrated_v2")
            self.assertEqual(restored.episode_count, 0)
            self.assertAlmostEqual(restored.matrices[2][3][3], 1.75)

    def test_indefinite_model_matrix_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            learner = LocalLearner(path)
            learner.save()
            raw = json.loads(path.read_text(encoding="utf-8"))
            raw["matrices"][0][0][1] = 2.0
            raw["matrices"][0][1][0] = 2.0
            path.write_text(json.dumps(raw), encoding="utf-8")
            path.with_suffix(path.suffix + ".bak").unlink(missing_ok=True)
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "invalid_reset")

    def test_corrupt_or_nonfinite_model_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.json"
            learner = LocalLearner(path)
            learner.save()
            raw = json.loads(path.read_text(encoding="utf-8"))
            raw["matrices"][0][0][0] = float("nan")
            path.write_text(json.dumps(raw), encoding="utf-8")
            path.with_suffix(path.suffix + ".bak").unlink(missing_ok=True)
            restored = LocalLearner(path)
            self.assertEqual(restored.load_status, "invalid_reset")
            self.assertEqual(restored.learn_count, 0)

    def test_learner_save_interval_does_not_repeat_on_same_modulo_count(self):
        with tempfile.TemporaryDirectory() as directory:
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace", lambda _summary: None)
            saved = []
            agent.learner.save = lambda: saved.append(agent.learner.learn_count)
            agent.learner.learn_count = 8
            agent._save_learner_if_due()
            agent._save_learner_if_due()
            self.assertEqual(saved, [8])
            agent.learner.learn_count = 16
            agent._save_learner_if_due()
            self.assertEqual(saved, [8, 16])
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)

    def test_run_summary_includes_latency_and_process_usage_fields(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "workspace"
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", workspace, lambda _summary: None)
            summary = agent._save_summary()
            self.assertIn("process_usage", summary)
            self.assertIn("working_set_mb", summary["process_usage"])
            self.assertIn("capture_p95", summary["latency_ms"])
            self.assertIn("adb_discovery_p95", summary["latency_ms"])
            self.assertIn("accessibility_p95", summary["latency_ms"])
            self.assertIn("tracking_p95", summary["latency_ms"])
            self.assertEqual(summary["stop_monitor"], "not_ready")
            self.assertIn("measured_processing_seconds", summary)
            self.assertTrue((workspace / "run_summary.json").is_file())
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)

    def test_agent_always_notifies_ui_when_summary_generation_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            notifications = []
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace",
                                     lambda summary: notifications.append(summary))
            agent.stop_event.set()
            def fail_summary():
                raise OSError("simulated disk error")
            agent._save_summary = fail_summary
            agent.run()
            self.assertEqual(len(notifications), 1)
            self.assertIn("Summary generation failed", notifications[0]["last_error"])

    def test_agent_watcher_creation_failure_uses_fallback_and_restores_ui(self):
        with tempfile.TemporaryDirectory() as directory:
            notifications = []
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace",
                                     lambda summary: notifications.append(summary))
            with patch("core.agent.threading.Thread", side_effect=RuntimeError("thread limit")), \
                    patch.object(agent, "_capture_state") as capture:
                agent.run()
            self.assertTrue(agent._fallback_stop_watch)
            self.assertIn("无法启动停止按键监听线程", agent.startup_error)
            capture.assert_not_called()
            self.assertEqual(len(notifications), 1)

    def test_generic_modifier_stop_keys_match_both_physical_sides(self):
        self.assertTrue(_stop_key_matches(0x10, 0xA0))
        self.assertTrue(_stop_key_matches(0x10, 0xA1))
        self.assertTrue(_stop_key_matches(0x11, 0xA2))
        self.assertTrue(_stop_key_matches(0x12, 0xA5))
        self.assertFalse(_stop_key_matches(0xA0, 0xA1))
        self.assertFalse(_stop_key_matches(0x1B, 0x41))

    def test_stop_key_hook_swallows_matching_events_and_triggers_only_on_armed_keydown(self):
        matched, armed, trigger = _stop_key_event_transition(0x1B, 0x1B, 0x0100, True)
        self.assertTrue(matched)
        self.assertFalse(armed)
        self.assertTrue(trigger)
        matched, armed, trigger = _stop_key_event_transition(0x1B, 0x1B, 0x0101, False)
        self.assertTrue(matched)
        self.assertTrue(armed)
        self.assertFalse(trigger)
        matched, armed, trigger = _stop_key_event_transition(0x1B, 0x41, 0x0100, True)
        self.assertFalse(matched)
        self.assertTrue(armed)
        self.assertFalse(trigger)
        matched, armed, trigger = _stop_key_event_transition(0x1B, 0x1B, 0x0100, False)
        self.assertTrue(matched)  # repeated/held keydown is still suppressed
        self.assertFalse(armed)
        self.assertFalse(trigger)

    def test_agent_stop_watcher_prefers_event_driven_global_hook(self):
        with tempfile.TemporaryDirectory() as directory:
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace",
                                     lambda _summary: None)
            def trigger(_vk, event, *, ready_event=None):
                if ready_event is not None:
                    ready_event.set()
                event.set()
                return True
            with patch("core.agent.watch_global_key", side_effect=trigger):
                agent._watch_stop_key()
            self.assertTrue(agent.stop_event.is_set())
            self.assertTrue(agent.stop_monitor_ready.is_set())
            self.assertFalse(agent._fallback_stop_watch)
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)

    def test_agent_stop_watcher_falls_back_when_global_hook_is_unavailable(self):
        with tempfile.TemporaryDirectory() as directory:
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace",
                                     lambda _summary: None)
            with patch("core.agent.watch_global_key", side_effect=OSError("hook denied")), \
                    patch("core.agent.is_key_down", side_effect=[False, True]):
                agent._watch_stop_key()
            self.assertTrue(agent._fallback_stop_watch)
            self.assertTrue(agent.stop_monitor_ready.is_set())
            self.assertTrue(agent.stop_event.is_set())
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)

    def test_temporal_tracker_estimates_persistent_cluster_motion(self):
        tracker = TemporalBattleTracker()
        first_cluster = VisualCluster(x=0.32, y=0.42, width=0.06, height=0.05,
                                      area=0.003, confidence=0.90)
        first = tracker.update(sample_state(enemy_clusters=(first_cluster,)), now=10.0)
        self.assertEqual(len(first.enemy_tracks), 1)
        self.assertEqual(first.enemy_tracks[0].observations, 1)

        second_cluster = VisualCluster(x=0.33, y=0.48, width=0.06, height=0.05,
                                       area=0.003, confidence=0.92)
        second = tracker.update(sample_state(enemy_clusters=(second_cluster,)), now=10.5)
        self.assertEqual(len(second.enemy_tracks), 1)
        track = second.enemy_tracks[0]
        self.assertEqual(track.track_id, first.enemy_tracks[0].track_id)
        self.assertEqual(track.observations, 2)
        self.assertGreater(track.vy, 0.0)
        self.assertGreater(TemporalBattleTracker.lane_advance(
            second.enemy_tracks, 0, toward_positive_y=True), 0.0)
        _predicted_x, predicted_y = TemporalBattleTracker.predicted_position(track, 0.2)
        self.assertGreater(predicted_y, track.y)

    def test_temporal_tracker_expires_stale_tracks_and_resets_outside_battle(self):
        tracker = TemporalBattleTracker()
        cluster = VisualCluster(x=0.32, y=0.42, width=0.06, height=0.05,
                                area=0.003, confidence=0.90)
        tracker.update(sample_state(enemy_clusters=(cluster,)), now=10.0)
        stale = tracker.update(sample_state(enemy_clusters=()), now=12.1)
        self.assertEqual(stale.enemy_tracks, ())
        tracker.update(sample_state(enemy_clusters=(cluster,)), now=13.0)
        home = replace(sample_state(battle_detected=False, scene=Scene.HOME),
                       enemy_clusters=(cluster,))
        reset = tracker.update(home, now=13.2)
        self.assertEqual(reset.enemy_tracks, ())

    def test_policy_features_use_temporal_lane_motion_in_reserved_feature(self):
        track = ClusterTrack(
            track_id=1, x=0.30, y=0.50, vx=0.0, vy=0.65,
            width=0.08, height=0.06, area=0.004, confidence=0.85,
            age_seconds=0.5, observations=3, last_seen=10.0,
        )
        state = sample_state(enemy_tracks=(track,))
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            features = learner.features(state, 0, 0, 1.0)
            self.assertEqual(len(features), FEATURES)
            self.assertGreater(features[12], 0.0)
            self.assertEqual(features[12], TemporalBattleTracker.lane_advance(
                state.enemy_tracks, 0, toward_positive_y=True))

    def test_config_roundtrip_restores_key_and_window_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "ClashRoyaleAgent"
            save_config(workspace, stop_key="NUMPAD1", window_title="Android Emulator",
                        window_class="Qt5152QWindowIcon", app_version="0.8.0")
            restored = load_config(workspace)
            self.assertEqual(restored["stop_key"], "NUMPAD1")
            self.assertEqual(restored["window_title"], "Android Emulator")
            self.assertEqual(restored["window_class"], "Qt5152QWindowIcon")

    def test_config_rejects_invalid_stop_key(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory)
            (workspace / "config.json").write_text('{"stop_key":"NOT_A_KEY"}', encoding="utf-8")
            self.assertEqual(load_config(workspace), {})

    def test_learner_returns_none_when_no_card_is_ready(self):
        state = sample_state(card_ready=(False, False, False, False))
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            self.assertIsNone(learner.choose(state, 1.0))

    def test_learner_refuses_low_confidence_card_readiness(self):
        state = sample_state(card_ready_confidence=(0.2, 0.2, 0.2, 0.2))
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            self.assertIsNone(learner.choose(state, 1.0))

    def test_deployment_uses_verified_card_roles_and_enemy_cluster_positions(self):
        enemy = VisualCluster(x=0.34, y=0.48, width=0.08, height=0.06,
                              area=0.004, confidence=0.9)
        spell_state = sample_state(card_roles=(("spell",), (), (), ()),
                                   enemy_clusters=(enemy,))
        self.assertEqual(ClashRoyaleAgent._deployment_point(spell_state, 0, 0),
                         (enemy.x, enemy.y))
        building_state = sample_state(card_roles=(("building",), (), (), ()))
        self.assertEqual(ClashRoyaleAgent._deployment_point(building_state, 0, 1),
                         (0.50, 0.675))
        unknown_state = sample_state(card_roles=((), (), (), ()))
        self.assertEqual(ClashRoyaleAgent._deployment_point(unknown_state, 0, 0),
                         (0.30, 0.695))

    def test_card_deployment_requires_a_slot_local_selection_change(self):
        baseline = tuple(tuple([0.20] * 19) for _ in range(4))
        before = sample_state(
            card_descriptors=baseline,
            card_fingerprints=("1111111111111111", "2222222222222222",
                               "3333333333333333", "4444444444444444"),
        )
        selected = list(baseline)
        selected[1] = tuple([0.28] * 19)
        after = sample_state(
            card_descriptors=tuple(selected),
            card_fingerprints=("1111111111111111", "aaaaaaaaaaaaaaaa",
                               "3333333333333333", "4444444444444444"),
        )
        self.assertTrue(ClashRoyaleAgent._card_selection_confirmed(before, after, 1))
        global_change = sample_state(card_descriptors=tuple(
            tuple([0.28] * 19) for _ in range(4)))
        self.assertFalse(ClashRoyaleAgent._card_selection_confirmed(before, global_change, 1))

    def test_action_cooldown_adapts_to_pressure_without_zero_delay(self):
        urgent = sample_state(left_threat=0.6, right_threat=0.1)
        calm = sample_state(left_threat=0.02, right_threat=0.02, elixir=5.0)
        self.assertGreater(ClashRoyaleAgent._action_cooldown(urgent), 0.0)
        self.assertLess(ClashRoyaleAgent._action_cooldown(urgent),
                        ClashRoyaleAgent._action_cooldown(calm))

    def test_visual_proxy_reward_is_gated_and_can_train_only_on_strong_lane_change(self):
        before = sample_state()
        weak = replace(before, left_threat=0.52, left_support=0.12)
        _weak_reward, weak_confidence = ClashRoyaleAgent._reward(before, weak, 0)
        self.assertLess(weak_confidence, 0.25)

        strong = replace(before, left_threat=0.10, left_support=0.40)
        reward, confidence = ClashRoyaleAgent._reward(before, strong, 0)
        self.assertGreater(reward, 0.0)
        self.assertGreaterEqual(confidence, 0.25)
        self.assertLessEqual(confidence, 0.55)
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            features = learner.features(before, 0, 0, 1.0)
            self.assertTrue(learner.update(0, 0, features, reward, confidence))
            self.assertEqual(learner.learn_count, 1)

    def test_visual_proxy_reward_rejects_unrelated_lane_motion(self):
        before = sample_state()
        after = replace(before, left_threat=0.10, left_support=0.40,
                        right_threat=0.50, right_support=0.45)
        _reward, confidence = ClashRoyaleAgent._reward(before, after, 0)
        self.assertLess(confidence, 0.25)

    def test_blackbox_is_under_one_megabyte_and_valid_zip(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            workspace = root / "workspace"
            desktop = root / "Desktop"
            workspace.mkdir()
            desktop.mkdir()
            (workspace / "agent.log").write_bytes(os.urandom(600_000))
            (workspace / "agent.log.1").write_bytes(os.urandom(600_000))
            (workspace / "model.json").write_text('{"version":5}', encoding="utf-8")
            (workspace / "model.json.bak").write_text('{"version":5}', encoding="utf-8")
            (workspace / "card_profiles.json").write_text('{"version":1,"profiles":[]}', encoding="utf-8")
            (workspace / "run_summary.json").write_text('{"actions":3}', encoding="utf-8")
            archive = create_blackbox(workspace, desktop=desktop)
            self.assertLessEqual(archive.stat().st_size, MAX_BYTES)
            self.assertEqual([path.name for path in desktop.iterdir()], [archive.name])
            with zipfile.ZipFile(archive) as zf:
                self.assertIn("blackbox.json", zf.namelist())
                self.assertIn("model.json", zf.namelist())
                self.assertIn("model.json.bak", zf.namelist())
                self.assertIn("card_profiles.json", zf.namelist())
                self.assertTrue(zf.testzip() is None)

    def test_blackbox_redacts_paths_and_window_titles(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            workspace = root / "workspace"
            desktop = root / "Desktop"
            workspace.mkdir()
            desktop.mkdir()
            private_title = "Private Emulator Window"
            (workspace / "agent.log").write_text(
                f"selected window={private_title} path={workspace}\\user\\secret\n"
                "old error path=C:\\Users\\Alice\\AppData\\Local\\private.txt email=alice@example.com\n",
                encoding="utf-8",
            )
            (workspace / "run_summary.json").write_text(
                json.dumps({"last_error": str(workspace / "private.txt"),
                            "legacy_windows_error": r"C:\Users\Alice\AppData\Local\private.txt"}),
                encoding="utf-8"
            )
            archive = create_blackbox(workspace, desktop=desktop)
            with zipfile.ZipFile(archive) as zf:
                log = zf.read("agent.log").decode("utf-8")
                summary = zf.read("run_summary.json").decode("utf-8")
            self.assertNotIn(private_title, log)
            self.assertNotIn(str(workspace), log)
            self.assertNotIn(str(workspace), summary)
            self.assertNotIn("Alice", summary)
            self.assertNotIn("Alice", log)
            self.assertNotIn("alice@example.com", log)


    def test_policy_holds_elixir_in_a_quiet_lane_until_near_overflow(self):
        quiet = sample_state(
            elixir=6.0,
            left_threat=0.0,
            right_threat=0.0,
            left_support=0.0,
            right_support=0.0,
            card_roles=((), (), (), ()),
            card_costs=(None, None, None, None),
            enemy_clusters=(),
        )
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            self.assertIsNone(learner.choose(quiet, 20.0))
            near_overflow = replace(quiet, elixir=9.8)
            self.assertIsNotNone(learner.choose(near_overflow, 20.0))
            under_pressure = replace(quiet, left_threat=0.32)
            self.assertIsNotNone(learner.choose(under_pressure, 20.0))

    def test_completed_match_without_played_cards_is_still_counted(self):
        with tempfile.TemporaryDirectory() as directory:
            learner = LocalLearner(Path(directory) / "model.json")
            learner.begin_episode()
            self.assertEqual(learner.finish_episode("win", confidence=0.99), 0)
            self.assertEqual(learner.episode_count, 1)
            self.assertEqual(learner.wins, 1)
            self.assertEqual(learner.learn_count, 0)
            self.assertEqual(learner.recent_win_rate, 1.0)
            learner.save()
            restored = LocalLearner(Path(directory) / "model.json")
            self.assertEqual(restored.episode_count, 1)
            self.assertEqual(restored.wins, 1)
            learner.begin_episode()
            learner.abort_episode(unknown_result=True)
            self.assertEqual(learner.unlabeled_episodes, 1)

    def test_navigation_retries_after_a_cooldown_instead_of_dead_ending(self):
        flow = GameFlow()
        flow._stable_frames = flow.STABLE_NAV_FRAMES
        target = NavigationTarget("mode_entry", 0.5, 0.72, 0.96)
        for index in range(flow.MAX_NAV_ATTEMPTS):
            decision = flow._navigation_decision(
                FlowAction.OPEN_MODE_SELECT, "retry test", target,
                100.0 + index * 3.0, key="retry_test",
            )
            self.assertEqual(decision.action, FlowAction.OPEN_MODE_SELECT)
        blocked = flow._navigation_decision(
            FlowAction.OPEN_MODE_SELECT, "retry test", target,
            112.0, key="retry_test",
        )
        self.assertEqual(blocked.action, FlowAction.WAIT)
        retried = flow._navigation_decision(
            FlowAction.OPEN_MODE_SELECT, "retry test", target,
            134.0, key="retry_test",
        )
        self.assertEqual(retried.action, FlowAction.OPEN_MODE_SELECT)

    def test_mode_entry_retry_path_recovers_after_max_attempts(self):
        flow = GameFlow()
        target = NavigationTarget("mode_entry", 0.5, 0.72, 0.96)
        state = sample_state(battle_detected=False, scene=Scene.HOME,
                             confidence=0.0, scene_confidence=0.91, targets=(target,))
        decision = None
        for index in range(flow.STABLE_NAV_FRAMES):
            decision = flow.update(state, now=100.0 + index * 0.1)
        self.assertEqual(decision.action, FlowAction.OPEN_MODE_SELECT)
        flow.mark_action_completed(FlowAction.OPEN_MODE_SELECT)
        current = 100.4
        for _ in range(flow.MAX_NAV_ATTEMPTS - 1):
            current += flow.NAV_COOLDOWN * 2 + 0.1
            decision = flow.update(state, now=current)
            self.assertEqual(decision.action, FlowAction.OPEN_MODE_SELECT)
            flow.mark_action_completed(FlowAction.OPEN_MODE_SELECT)
        current += flow.NAV_COOLDOWN * 2 + 0.1
        blocked = flow.update(state, now=current)
        self.assertEqual(blocked.action, FlowAction.WAIT)
        current += flow.NAV_RETRY_COOLDOWN + 0.1
        recovered = flow.update(state, now=current)
        self.assertEqual(recovered.action, FlowAction.OPEN_MODE_SELECT)

    def test_traditional_chinese_accessibility_labels_resolve_ladder_and_result(self):
        state = sample_state(battle_detected=False, scene=Scene.UNKNOWN,
                             confidence=0.0, scene_confidence=0.0)
        mode_xml = """<hierarchy>
          <node text="獎盃之路 尚未解鎖" clickable="true" enabled="false" bounds="[0,100][300,240]"/>
          <node text="皇室征程" clickable="true" enabled="true" bounds="[0,280][300,420]"/>
        </hierarchy>""".encode("utf-8")
        mode = enrich_state_with_accessibility(state, parse_uiautomator_xml(mode_xml), 300, 600)
        self.assertEqual(mode.scene, Scene.MODE_SELECT)
        self.assertEqual(mode.ladder_unlocked, False)
        self.assertIsNotNone(mode.target("journey"))

        result_xml = """<hierarchy>
          <node text="勝利" clickable="false" enabled="true" bounds="[20,20][280,80]"/>
          <node text="繼續" clickable="true" enabled="true" bounds="[40,450][260,540]"/>
        </hierarchy>""".encode("utf-8")
        result = enrich_state_with_accessibility(state, parse_uiautomator_xml(result_xml), 300, 600)
        self.assertEqual(result.scene, Scene.RESULT)
        self.assertEqual(result.result, "win")
        self.assertIsNotNone(result.target("result_continue"))

    def test_stop_after_frame_analysis_skips_further_state_work(self):
        with tempfile.TemporaryDirectory() as directory:
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace",
                                     lambda _summary: None)
            frame = Frame(360, 640, bytes(360 * 640 * 4))
            agent._refresh_selected_window = lambda: True
            agent._ensure_adb = lambda _frame: None
            def analyze_and_stop(_frame):
                agent.stop_event.set()
                return sample_state()
            with patch("core.agent.window_is_valid", return_value=True), \
                    patch("core.agent.capture_window", return_value=frame), \
                    patch("core.agent.analyze_frame", side_effect=analyze_and_stop), \
                    patch.object(agent.deck_manager, "observe") as observe:
                self.assertIsNone(agent._capture_state())
                observe.assert_not_called()
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)

    def test_wait_uses_event_driven_stop_hook_without_busy_polling(self):
        class FakeEvent:
            def __init__(self):
                self.stopped = False
                self.timeouts = []
            def is_set(self):
                return self.stopped
            def wait(self, timeout=None):
                self.timeouts.append(timeout)
                self.stopped = True
                return True
        class AliveWatcher:
            @staticmethod
            def is_alive():
                return True
        with tempfile.TemporaryDirectory() as directory:
            agent = ClashRoyaleAgent(1, 0x1B, "ESC", Path(directory) / "workspace",
                                     lambda _summary: None)
            fake = FakeEvent()
            agent.stop_event = fake
            agent._stop_watcher = AliveWatcher()
            agent._wait(1.0)
            self.assertEqual(len(fake.timeouts), 1)
            self.assertLessEqual(fake.timeouts[0], 0.050)
            for handler in list(agent.logger.handlers):
                handler.close()
                agent.logger.removeHandler(handler)


if __name__ == "__main__":
    unittest.main()
