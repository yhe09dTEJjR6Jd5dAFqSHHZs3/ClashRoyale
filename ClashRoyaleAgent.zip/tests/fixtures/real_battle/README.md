# Real battle evaluation dataset

No gameplay screenshots are included in the release. This directory defines the
annotation contract for a developer-owned, permission-cleared real-game dataset.
Do not treat `synthetic_battle/` or `adaptive_ui/` fixtures as real-game accuracy
samples.

For semantic troop evaluation, place PNG screenshots in a private test directory
and create a JSON labels file with this shape:

```json
{
  "version": 1,
  "frames": {
    "battle_001.png": {
      "units": [
        {
          "team": "enemy",
          "card_key": "hog-rider",
          "form": "base",
          "bbox": [0.42, 0.30, 0.54, 0.43]
        }
      ]
    }
  }
}
```

`bbox` uses normalized `[left, top, right, bottom]` coordinates in the original
screenshot. `team` is `enemy` or `friendly`; `card_key` and `form` must match
`data/cards.tsv`. Labels must be independently verified. The evaluator compares
against an existing local `unit_visual_profiles.json`; it does not train from the
test labels.

Run:

```powershell
py -3-64 tools\evaluate_vision.py --input C:\path\to\real_pngs --labels C:\path\to\labels.json --profiles C:\path\to\ClashRoyaleAgent\unit_visual_profiles.json --output C:\path\to\vision_report.json
py -3-64 tools\evaluate_agent.py C:\path\to\ClashRoyaleAgent\replays --output C:\path\to\agent_report.json
```

These are developer QA tools. They do not require the end user to prepare data
for normal application use, and their reports must not be described as top-player
performance or future win-rate guarantees.
