# Synthetic battle fixture

`01_battle_synthetic.png` is a generated color-block scene used only to exercise
battle-scene routing, temporal tracking, policy invocation, and bounded tactical
search in automated tests. It is **not** a Clash Royale screenshot and must not
be used to claim troop/card recognition accuracy, game-state accuracy, or win rate.

The production benchmark accepts real PNG replay frames supplied by the user or
captured by a developer. The bundled `adaptive_ui` screenshots remain UI-only.
