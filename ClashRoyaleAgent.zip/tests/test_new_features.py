from __future__ import annotations

import hashlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from core.cards import CardDatabase, CardRecognition
from core.deck_manager import DeckManager
from core.dxgi import capture_window_dxgi
from core.offline_ocr import OfflineOCR, OCRLine, _normalize_mask
from core.opponent import OpponentCycleTracker
from core.vision import ClusterTrack, GameState, NavigationTarget, Scene
from core.win32 import Frame, capture_window


def make_state(**kwargs):
    values = dict(
        battle_detected=True, elixir=6.0,
        left_threat=0.0, right_threat=0.0,
        left_support=0.0, right_support=0.0,
        card_scores=(0.0, 0.0, 0.0, 0.0),
        green_ratio=0.0, red_ratio=0.0, blue_ratio=0.0,
        purple_ratio=0.0, confidence=0.9,
        scene=Scene.BATTLE, scene_confidence=0.9,
        elixir_confidence=0.9, frame_width=420, frame_height=840,
    )
    values.update(kwargs)
    return GameState(**values)


class _DeterministicRenderer:
    """Test-only raster source; production uses Windows GDI."""
    def render(self, text, family, size=26):
        width, height = 64, 20
        digest = hashlib.sha256(text.encode("utf-8")).digest()
        mask = bytearray(width * height)
        for x in range(width):
            for y in (3, 7, 11, 15):
                mask[y * width + x] = 1
            for y in range(2, height - 2):
                bit = digest[(x * 7 + y * 13) % len(digest)] >> ((x + y) % 8) & 1
                if bit:
                    mask[y * width + x] = 1
        return mask, width, height


def make_text_frame(mask, width, height):
    frame_w, frame_h = 240, 180
    bgra = bytearray(frame_w * frame_h * 4)
    for y in range(height):
        for x in range(width):
            if mask[y * width + x]:
                offset = ((45 + y) * frame_w + 80 + x) * 4
                bgra[offset:offset + 4] = bytes((255, 255, 255, 255))
    return Frame(frame_w, frame_h, bytes(bgra))


class FeatureTests(unittest.TestCase):
    def test_bundled_card_database_covers_all_base_cards_and_forms(self):
        database = CardDatabase()
        self.assertEqual(len(database), 127)
        self.assertEqual(database.evolution_count, 43)
        self.assertEqual(database.hero_count, 18)
        self.assertEqual(database.champion_count, 8)
        self.assertEqual(database.find("Hog Rider").key, "hog-rider")
        self.assertEqual(database.find("野猪骑士").key, "hog-rider")
        self.assertEqual(database.find("野豬騎士").key, "hog-rider")
        self.assertIn("evolution", database.find("Knight").available_forms)
        self.assertIn("hero", database.find("Knight").available_forms)
        self.assertEqual(database.find("Evo Knight").key, "knight")
        self.assertEqual(database.find("進化騎士").key, "knight")
        self.assertEqual(database.roles_for("Hog Rider"), ("win_condition", "melee"))

    def test_card_resolution_detects_elite_level_and_evolution_form(self):
        database = CardDatabase()
        elite = database.resolve("Knight", level=15, confidence=0.95)
        evolved = database.resolve(
            "Knight", level=16, evolution_marker=True, confidence=0.96,
            marker_confidence=0.92,
        )
        self.assertIsNotNone(elite)
        self.assertTrue(elite.elite_level)
        self.assertEqual(elite.level, 15)
        self.assertEqual(evolved.form, "evolution")
        self.assertTrue(evolved.elite_level)

    def test_card_resolution_never_invents_ineligible_evolution(self):
        database = CardDatabase()
        result = database.resolve("Hog Rider", evolution_marker=True, confidence=0.9)
        self.assertEqual(result.form, "base")
        self.assertEqual(result.variant_confidence, 0.0)

    def test_card_resolution_supports_hero_champion_and_explicit_elite_markers(self):
        database = CardDatabase()
        hero = database.resolve("Knight", hero_marker=True, confidence=0.94,
                                marker_confidence=0.90)
        champion = database.resolve("Monk", confidence=0.96)
        elite = database.resolve("Knight", elite_marker=True, confidence=0.92)
        self.assertEqual(hero.form, "hero")
        self.assertEqual(champion.form, "champion")
        self.assertTrue(elite.elite_level)
        self.assertIsNone(elite.level)

    def test_deck_manager_uses_exact_ocr_card_name_for_cost_and_roles(self):
        database = CardDatabase()
        with tempfile.TemporaryDirectory() as tmp:
            manager = DeckManager(Path(tmp) / "profiles.json", card_database=database)
            state = make_state(card_names=("Hog Rider", "", "", ""))
            enriched = manager.observe(state)
        self.assertEqual(enriched.card_costs[0], 4.0)
        self.assertIn("win_condition", enriched.card_roles[0])

    def test_offline_ocr_template_engine_recognizes_a_known_phrase(self):
        database = CardDatabase()
        renderer = _DeterministicRenderer()
        ocr = OfflineOCR(database, renderer=renderer)
        self.assertTrue(ocr.warmup())
        mask, width, height = renderer.render("Trophy Road", "Segoe UI", 26)
        frame = make_text_frame(mask, width, height)
        snapshot = ocr.recognize(frame)
        self.assertTrue(snapshot.available)
        self.assertIn("Trophy Road", [line.text for line in snapshot.lines])

    def test_offline_ocr_uses_no_external_backend_on_non_windows(self):
        if os.name == "nt":
            self.skipTest("This host has Windows GDI.")
        ocr = OfflineOCR(CardDatabase())
        self.assertFalse(ocr.available)
        self.assertFalse(ocr.recognize(Frame(120, 160, bytes(120 * 160 * 4))).available)

    def test_ocr_label_conversion_never_marks_text_as_clickable(self):
        from core.offline_ocr import OCRSnapshot
        ocr = OfflineOCR(CardDatabase(), renderer=_DeterministicRenderer())
        snapshot = OCRSnapshot(
            lines=(OCRLine("Trophy Road", 0.95, (80, 40, 160, 60)),),
            confidence=0.95, available=True,
        )
        labels = ocr.labels_for(snapshot)
        self.assertEqual(len(labels), 1)
        self.assertFalse(labels[0].clickable)
        self.assertFalse(labels[0].target_clickable)

    def test_normalize_mask_returns_fixed_bit_grid_and_aspect(self):
        mask = bytearray(20 * 10)
        for y in range(2, 8):
            for x in range(3, 17):
                if (x + y) % 2 == 0:
                    mask[y * 20 + x] = 1
        result = _normalize_mask(mask, 20, 10)
        self.assertIsNotNone(result)
        bits, aspect = result
        self.assertGreater(bits, 0)
        self.assertGreater(aspect, 1.0)

    def test_opponent_cycle_predicts_the_first_play_after_five_observations(self):
        tracker = OpponentCycleTracker(CardDatabase())
        result = None
        for index in range(5):
            track = ClusterTrack(
                track_id=index + 1, x=0.30 + index * 0.02, y=0.44,
                vx=0.0, vy=0.0, width=0.04, height=0.04, area=0.02,
                confidence=0.8, age_seconds=0.0, observations=1,
                last_seen=float(index + 1),
            )
            state = make_state(enemy_tracks=(track,))
            result = tracker.observe(state, now=float(index + 1))
        self.assertTrue(result.opponent_cycle_complete)
        self.assertEqual(result.opponent_play_count, 5)
        self.assertEqual(result.opponent_cycle_token, "opp_0001")
        self.assertLessEqual(result.opponent_cycle_confidence, 0.46)
        self.assertEqual(result.opponent_cycle_card, "")

    def test_opponent_cycle_only_names_a_card_when_ocr_identifies_it(self):
        tracker = OpponentCycleTracker(CardDatabase())
        first = ClusterTrack(
            track_id=1, x=0.31, y=0.40, vx=0.0, vy=0.0,
            width=0.04, height=0.04, area=0.02, confidence=0.8,
            age_seconds=0.0, observations=1, last_seen=1.0,
        )
        named = CardRecognition(
            "hog-rider", "Hog Rider", "base", None, False, 0.96,
            bounds=(110, 300, 150, 330),
        )
        first_state = make_state(enemy_tracks=(first,), recognized_cards=(named,))
        tracker.observe(first_state, now=1.0)
        result = None
        for index in range(1, 5):
            track = ClusterTrack(
                track_id=index + 1, x=0.34, y=0.44, vx=0.0, vy=0.0,
                width=0.04, height=0.04, area=0.02, confidence=0.8,
                age_seconds=0.0, observations=1, last_seen=float(index + 1),
            )
            result = tracker.observe(make_state(enemy_tracks=(track,)), now=float(index + 1))
        self.assertEqual(result.opponent_cycle_card, "hog-rider")
        self.assertIn("win_condition", result.opponent_cycle_roles)
        self.assertLess(result.opponent_cycle_confidence, 0.65)

    def test_fully_named_five_play_window_has_counter_usable_confidence(self):
        tracker = OpponentCycleTracker(CardDatabase())
        keys = ("hog-rider", "fireball", "knight", "arrows", "golem")
        result = None
        for index, key in enumerate(keys):
            record = CardDatabase().get(key)
            card = CardRecognition(
                key, record.name_en, "base", None, False, 0.96,
                bounds=(110, 300, 150, 330),
            )
            track = ClusterTrack(
                track_id=index + 1, x=0.31, y=0.40, vx=0.0, vy=0.0,
                width=0.04, height=0.04, area=0.02, confidence=0.8,
                age_seconds=0.0, observations=1, last_seen=float(index + 1),
            )
            state = make_state(enemy_tracks=(track,), recognized_cards=(card,))
            result = tracker.observe(state, now=float(index + 1))
        self.assertEqual(result.opponent_cycle_card, "hog-rider")
        self.assertGreaterEqual(result.opponent_cycle_confidence, 0.65)
        self.assertIn("win_condition", result.opponent_cycle_roles)

    def test_opponent_cycle_resets_outside_a_battle(self):
        tracker = OpponentCycleTracker(CardDatabase())
        track = ClusterTrack(
            track_id=1, x=0.3, y=0.4, vx=0.0, vy=0.0,
            width=0.04, height=0.04, area=0.02, confidence=0.8,
            age_seconds=0.0, observations=1, last_seen=1.0,
        )
        tracker.observe(make_state(enemy_tracks=(track,)), now=1.0)
        lobby = tracker.observe(make_state(scene=Scene.HOME, battle_detected=False), now=2.0)
        self.assertEqual(lobby.opponent_play_count, 0)
        self.assertEqual(tracker.history, [])

    def test_dxgi_capture_is_a_last_resort_after_gdi_and_printclient(self):
        frame = Frame(120, 160, bytes([255, 255, 255, 255]) * 120 * 160)
        with patch("core.win32.window_is_interactive", return_value=True), \
             patch("core.win32._capture_screen_gdi", side_effect=OSError("gdi")), \
             patch("core.win32._capture_wm_printclient", side_effect=OSError("print")), \
             patch("core.dxgi.capture_window_dxgi", return_value=frame) as dxgi:
            result = capture_window(123)
        self.assertIs(result, frame)
        dxgi.assert_called_once_with(123, 420)

    def test_dxgi_is_not_attempted_after_window_loses_interactivity(self):
        with patch("core.win32.window_is_interactive", side_effect=(True, True, False)), \
             patch("core.win32._capture_screen_gdi", side_effect=OSError("gdi")), \
             patch("core.win32._capture_wm_printclient", side_effect=OSError("print")), \
             patch("core.dxgi.capture_window_dxgi") as dxgi:
            with self.assertRaises(OSError):
                capture_window(123)
        dxgi.assert_not_called()

    def test_dxgi_backend_fails_closed_on_non_windows(self):
        if os.name == "nt":
            self.skipTest("This host has DXGI.")
        with self.assertRaisesRegex(OSError, "requires Windows 11"):
            capture_window_dxgi(123)


if __name__ == "__main__":
    unittest.main()
