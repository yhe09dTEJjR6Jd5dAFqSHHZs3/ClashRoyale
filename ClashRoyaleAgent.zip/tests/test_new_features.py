from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from core.cards import CardDatabase, CardRecognition
from core.card_catalog import CardCatalogScanner
from core.deck_manager import CardProfile, DeckManager
from core.dxgi import capture_window_dxgi
from core.episode import MatchExitDetector
from core.offline_ocr import OCRSnapshot, OfflineOCR, OCRLine, _normalize_mask
from core.opponent import OpponentCycleTracker
from core.vision import (ClusterTrack, GameState, NavigationTarget, Scene,
                         card_signature_for_bounds)
from core.win32 import Frame, capture_window, is_android_emulator_window
from core.adb import AccessibilityLabel, decode_android_png, enrich_state_with_accessibility
from tools.build_card_image_catalog import build_catalog, expected_identities, image_identity


def make_state(**kwargs):
    values = dict(
        battle_detected=True, elixir=6.0,
        left_threat=0.0, right_threat=0.0,
        left_support=0.0, right_support=0.0,
        card_scores=(0.0, 0.0, 0.0, 0.0),
        green_ratio=0.0, red_ratio=0.0, blue_ratio=0.0,
        purple_ratio=0.0, confidence=0.9,
        scene=Scene.BATTLE, scene_confidence=0.9,
        elixir_confidence=0.9, frame_width=420, frame_height=840,
    )
    values.update(kwargs)
    return GameState(**values)


class _DeterministicRenderer:
    """Test-only raster source; production uses Windows GDI."""
    def render(self, text, family, size=26):
        width, height = 64, 20
        digest = hashlib.sha256(text.encode("utf-8")).digest()
        mask = bytearray(width * height)
        for x in range(width):
            for y in (3, 7, 11, 15):
                mask[y * width + x] = 1
            for y in range(2, height - 2):
                bit = digest[(x * 7 + y * 13) % len(digest)] >> ((x + y) % 8) & 1
                if bit:
                    mask[y * width + x] = 1
        return mask, width, height


def make_text_frame(mask, width, height):
    frame_w, frame_h = 240, 180
    bgra = bytearray(frame_w * frame_h * 4)
    for y in range(height):
        for x in range(width):
            if mask[y * width + x]:
                offset = ((45 + y) * frame_w + 80 + x) * 4
                bgra[offset:offset + 4] = bytes((255, 255, 255, 255))
    return Frame(frame_w, frame_h, bytes(bgra))


def make_collection_frame() -> Frame:
    width, height = 420, 840
    pixels = bytearray(width * height * 4)
    for center_x, seed in ((105, 31), (280, 127)):
        for y in range(300, 400):
            for x in range(center_x - 27, center_x + 27):
                r = (x * 5 + y * 3 + seed) % 256
                g = (x * 2 + y * 7 + seed * 3) % 256
                b = (x * 11 + y + seed * 5) % 256
                offset = (y * width + x) * 4
                pixels[offset:offset + 4] = bytes((b, g, r, 255))
    return Frame(width, height, bytes(pixels))


class FeatureTests(unittest.TestCase):
    def test_match_exit_detector_ignores_transient_unknown_frames(self):
        detector = MatchExitDetector()
        battle = make_state()
        unknown = make_state(scene=Scene.UNKNOWN, battle_detected=False,
                             confidence=0.0, scene_confidence=0.0)
        self.assertIsNone(detector.observe(battle, now=10.0))
        self.assertIsNone(detector.observe(unknown, now=10.3))
        self.assertIsNone(detector.observe(unknown, now=10.6))
        self.assertIsNone(detector.observe(battle, now=10.9))

    def test_match_exit_detector_requires_stable_non_battle_scene(self):
        detector = MatchExitDetector()
        home = make_state(scene=Scene.HOME, battle_detected=False,
                          confidence=0.9, scene_confidence=0.9)
        self.assertIsNone(detector.observe(make_state(), now=1.0))
        self.assertIsNone(detector.observe(home, now=2.0))
        self.assertIsNone(detector.observe(home, now=2.2))
        self.assertEqual(detector.observe(home, now=2.4), "stable_home")

    def test_match_exit_detector_closes_long_unknown_as_unlabeled_boundary(self):
        detector = MatchExitDetector()
        unknown = make_state(scene=Scene.UNKNOWN, battle_detected=False,
                             confidence=0.0, scene_confidence=0.0)
        self.assertIsNone(detector.observe(make_state(), now=0.0))
        self.assertIsNone(detector.observe(unknown, now=14.9))
        self.assertEqual(detector.observe(unknown, now=15.0), "unknown_timeout")

    def test_runtime_catalog_scanner_builds_stable_visual_samples_from_real_tile_regions(self):
        database = CardDatabase()
        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(Path(directory) / "card_profiles.json", card_database=database)
            scanner = CardCatalogScanner(database, manager)
            frame = make_collection_frame()
            snapshot = OCRSnapshot(
                cards=(
                    CardRecognition("knight", "Knight", "base", None, False, 0.97,
                                    bounds=(88, 400, 122, 414)),
                    CardRecognition("hog-rider", "Hog Rider", "base", None, False, 0.96,
                                    bounds=(263, 400, 297, 414)),
                ),
                confidence=0.96,
                available=True,
            )
            deck = make_state(scene=Scene.DECK, battle_detected=False,
                              scene_confidence=0.95, viewport=(0.0, 0.0, 1.0, 1.0))
            for index in range(3):
                step = scanner.observe(frame, snapshot, deck, now=10.0 + index * 0.1)
            self.assertEqual(scanner.coverage, 2)
            self.assertEqual(scanner.sample_count, 2)
            self.assertEqual(step.action, "scroll")
            self.assertTrue(all(len(item["descriptor"]) == 131
                                for item in manager.catalog.values()))
            catalog_path = Path(directory) / "card_catalog.json"
            self.assertTrue(catalog_path.is_file())
            reloaded = DeckManager(Path(directory) / "reloaded_profiles.json",
                                   catalog_path=catalog_path, card_database=database)
            self.assertEqual(len(reloaded.catalog), 2)
            self.assertTrue(all(len(item["descriptor"]) == 131
                                for item in reloaded.catalog.values()))

    def test_runtime_catalog_scanner_rejects_low_confidence_card_names(self):
        database = CardDatabase()
        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(Path(directory) / "card_profiles.json", card_database=database)
            scanner = CardCatalogScanner(database, manager)
            frame = make_collection_frame()
            snapshot = OCRSnapshot(
                cards=(CardRecognition("knight", "Knight", "base", None, False, 0.50,
                                       bounds=(88, 400, 122, 414)),),
                confidence=0.50, available=True,
            )
            deck = make_state(scene=Scene.DECK, battle_detected=False, scene_confidence=0.95)
            for index in range(4):
                scanner.observe(frame, snapshot, deck, now=20.0 + index * 0.1)
            self.assertEqual(scanner.coverage, 0)
            self.assertEqual(manager.catalog, {})

    def test_visual_catalog_resolves_same_card_across_multiple_reference_samples(self):
        with tempfile.TemporaryDirectory() as directory:
            descriptor = tuple([0.5] * 131)
            manager = DeckManager(Path(directory) / "profiles.json", catalog={
                "0000000000000000": {"name": "Knight", "card_key": "knight",
                                     "form": "base", "cost": 3, "level": None,
                                     "roles": ["melee"], "descriptor": list(descriptor)},
                "0000000000000001": {"name": "Knight", "card_key": "knight",
                                     "form": "base", "cost": 3, "level": None,
                                     "roles": ["melee"], "descriptor": list(descriptor)},
            })
            profile = CardProfile("card_0001", "0000000000000000",
                                  observations=5, descriptor=list(descriptor))
            result = manager.metadata_for_profile(profile)
            self.assertIsNotNone(result)
            self.assertEqual(result["card_key"], "knight")

    def test_variable_elixir_metadata_and_november_evolutions_are_explicit(self):
        database = CardDatabase()
        spirit = database.get("spirit-empress")
        mirror = database.get("mirror")
        giant = database.get("giant")
        self.assertEqual(spirit.elixir_cost_options, (3, 6))
        self.assertTrue(spirit.variable_elixir_cost)
        self.assertEqual(database.find("亡靈巨人").key, "minion-giant")
        self.assertEqual(database.find("刺客首領").key, "boss-bandit")
        self.assertEqual(database.find("科學怪哥布林").key, "goblinstein")
        self.assertTrue(mirror.variable_elixir_cost)
        self.assertTrue(mirror.has_evolution)
        self.assertEqual(mirror.evolution_cycles, 2)
        self.assertTrue(giant.has_evolution)
        self.assertEqual(giant.evolution_cycles, 1)
        self.assertNotIn("melee", database.roles_for("Balloon"))

    def test_visual_catalog_preserves_variable_cost_options_without_guessing(self):
        database = CardDatabase()
        with tempfile.TemporaryDirectory() as directory:
            catalog_path = Path(directory) / "card_catalog.json"
            manager = DeckManager(Path(directory) / "profiles.json",
                                  catalog_path=catalog_path, card_database=database)
            descriptor = tuple([0.4] * 131)
            self.assertTrue(manager.add_catalog_sample(
                "spirit-empress", "base", "1234567890abcdef", descriptor, 0.96
            ))
            self.assertTrue(manager.add_catalog_sample(
                "tower-princess", "base", "abcdef1234567890", descriptor, 0.96
            ))
            reloaded = DeckManager(Path(directory) / "profiles2.json",
                                   catalog_path=catalog_path, card_database=database)
            spirit = reloaded.catalog["1234567890abcdef"]
            tower = reloaded.catalog["abcdef1234567890"]
            self.assertIsNone(spirit["cost"])
            self.assertTrue(spirit["variable_cost"])
            self.assertEqual(spirit["cost_options"], [3, 6])
            self.assertIsNone(tower["cost"])
            self.assertEqual(tower["card_type"], "Tower Troop")

    def test_native_windows_can_be_selected_without_an_android_emulator(self):
        self.assertFalse(is_android_emulator_window(
            1, "Clash Royale", "UnityWndClass", Path("C:/Games/ClashRoyale.exe")
        ))
        self.assertTrue(is_android_emulator_window(
            1, "BlueStacks App Player", "Qt5152QWindowIcon", Path("C:/BlueStacks/HD-Player.exe")
        ))

    def test_ocr_labels_can_drive_card_tab_navigation_without_adb(self):
        home = make_state(scene=Scene.HOME, battle_detected=False, scene_confidence=0.90)
        label = AccessibilityLabel(
            "Cards", "", "", False, True, (300, 760, 370, 800), None,
            False, True, True, True,
        )
        enriched = enrich_state_with_accessibility(home, [label], 420, 840, 0.94)
        target = enriched.target("deck_entry")
        self.assertIsNotNone(target)
        self.assertGreaterEqual(target.confidence, 0.82)
        self.assertTrue(target.screen_space)

    def test_bundled_card_database_covers_all_base_cards_and_forms(self):
        database = CardDatabase()
        self.assertEqual(len(database), 127)
        self.assertEqual(database.evolution_count, 45)
        self.assertEqual(database.hero_count, 18)
        self.assertEqual(database.champion_count, 8)
        self.assertEqual(database.find("Hog Rider").key, "hog-rider")
        self.assertEqual(database.find("野猪骑士").key, "hog-rider")
        self.assertEqual(database.find("野豬騎士").key, "hog-rider")
        self.assertIn("evolution", database.find("Knight").available_forms)
        self.assertIn("hero", database.find("Knight").available_forms)
        self.assertEqual(database.find("Evo Knight").key, "knight")
        self.assertEqual(database.find("進化騎士").key, "knight")
        self.assertEqual(database.roles_for("Hog Rider"), ("win_condition", "melee"))

    def test_release_bundles_no_unlicensed_card_art_and_keeps_empty_catalog_valid(self):
        root = Path(__file__).resolve().parents[1]
        images_dir = root / "data" / "card_images"
        catalog_path = root / "data" / "card_visual_catalog.json"
        database = CardDatabase()
        packaged = json.loads(catalog_path.read_text(encoding="utf-8"))
        rebuilt = build_catalog(images_dir, database)
        self.assertEqual(rebuilt, packaged)
        self.assertEqual(packaged["expected_cards"], 127)
        self.assertEqual(packaged["expected_forms"], 0)
        self.assertEqual(packaged["cards"], {})
        self.assertEqual(list(images_dir.glob("*.png")), [])

        with tempfile.TemporaryDirectory() as directory:
            manager = DeckManager(
                Path(directory) / "profiles.json",
                catalog_path=Path(directory) / "card_catalog.json",
                card_database=database,
                bundled_catalog_path=catalog_path,
            )
            self.assertEqual(len(manager.catalog), 0)
            scanner = CardCatalogScanner(database, manager)
            self.assertEqual(scanner.coverage, 0)
            self.assertTrue(scanner.should_scan)

    def test_bundled_catalog_rejects_a_local_fingerprint_identity_collision(self):
        with tempfile.TemporaryDirectory() as directory:
            bundled_path = Path(directory) / "bundled.json"
            local_path = Path(directory) / "card_catalog.json"
            fingerprint = "0123456789abcdef"
            descriptor = [0.5] * 131
            bundled_path.write_text(json.dumps({
                "version": 1, "cards": {fingerprint: {
                    "name": "Knight", "owned": False, "roles": ["melee"],
                    "cost": 3, "level": None, "descriptor": descriptor,
                    "card_key": "knight", "form": "base",
                    "source": "bundled_card_image",
                }}
            }), encoding="utf-8")
            local_path.write_text(json.dumps({
                "version": 1,
                "cards": {
                    fingerprint: {
                        "name": "Not the bundled card", "owned": False,
                        "roles": ["melee"], "cost": 3, "level": None,
                        "descriptor": descriptor,
                        "card_key": "archers", "form": "base",
                        "source": "runtime_ocr_visual_scan",
                    }
                },
            }), encoding="utf-8")
            manager = DeckManager(
                Path(directory) / "profiles.json", catalog_path=local_path,
                bundled_catalog_path=bundled_path,
            )
            self.assertNotIn(fingerprint, manager.catalog)

    def test_card_resolution_detects_elite_level_and_evolution_form(self):
        database = CardDatabase()
        elite = database.resolve("Knight", level=15, confidence=0.95)
        evolved = database.resolve(
            "Knight", level=16, evolution_marker=True, confidence=0.96,
            marker_confidence=0.92,
        )
        self.assertIsNotNone(elite)
        self.assertTrue(elite.elite_level)
        self.assertEqual(elite.level, 15)
        self.assertEqual(evolved.form, "evolution")
        self.assertTrue(evolved.elite_level)

    def test_card_resolution_never_invents_ineligible_evolution(self):
        database = CardDatabase()
        result = database.resolve("Hog Rider", evolution_marker=True, confidence=0.9)
        self.assertEqual(result.form, "base")
        self.assertEqual(result.variant_confidence, 0.0)

    def test_card_resolution_supports_hero_champion_and_explicit_elite_markers(self):
        database = CardDatabase()
        hero = database.resolve("Knight", hero_marker=True, confidence=0.94,
                                marker_confidence=0.90)
        champion = database.resolve("Monk", confidence=0.96)
        elite = database.resolve("Knight", elite_marker=True, confidence=0.92)
        self.assertEqual(hero.form, "hero")
        self.assertEqual(champion.form, "champion")
        self.assertTrue(elite.elite_level)
        self.assertIsNone(elite.level)

    def test_deck_manager_uses_exact_ocr_card_name_for_cost_and_roles(self):
        database = CardDatabase()
        with tempfile.TemporaryDirectory() as tmp:
            manager = DeckManager(Path(tmp) / "profiles.json", card_database=database)
            state = make_state(card_names=("Hog Rider", "", "", ""))
            enriched = manager.observe(state)
        self.assertEqual(enriched.card_costs[0], 4.0)
        self.assertIn("win_condition", enriched.card_roles[0])

    def test_offline_ocr_template_engine_recognizes_a_known_phrase(self):
        database = CardDatabase()
        renderer = _DeterministicRenderer()
        ocr = OfflineOCR(database, renderer=renderer)
        self.assertTrue(ocr.warmup())
        mask, width, height = renderer.render("Trophy Road", "Segoe UI", 26)
        frame = make_text_frame(mask, width, height)
        snapshot = ocr.recognize(frame)
        self.assertTrue(snapshot.available)
        self.assertIn("Trophy Road", [line.text for line in snapshot.lines])
        self.assertEqual(OfflineOCR.FONT_SIZES, (20, 26, 32))

    def test_ocr_does_not_bind_card_identity_when_hand_geometry_is_missing(self):
        database = CardDatabase()
        ocr = OfflineOCR(database, renderer=_DeterministicRenderer())
        record = database.get("hog-rider")
        card = CardRecognition(
            "hog-rider", record.name_en, "base", None, False, 0.97,
            bounds=(150, 730, 190, 770),
        )
        state = make_state(card_bounds=(), card_names=("", "", "", ""))
        frame = Frame(420, 840, bytes(420 * 840 * 4))
        snapshot = OCRSnapshot(cards=(card,), confidence=0.97, available=True)
        enriched = ocr.enrich_state(state, frame, snapshot)
        self.assertEqual(enriched.card_names, ("", "", "", ""))
        self.assertEqual(enriched.card_costs, (None, None, None, None))
        self.assertEqual(enriched.recognized_cards, (card,))

    def test_offline_ocr_uses_no_external_backend_on_non_windows(self):
        if os.name == "nt":
            self.skipTest("This host has Windows GDI.")
        ocr = OfflineOCR(CardDatabase())
        self.assertFalse(ocr.available)
        self.assertFalse(ocr.recognize(Frame(120, 160, bytes(120 * 160 * 4))).available)

    def test_ocr_label_conversion_never_marks_text_as_clickable(self):
        from core.offline_ocr import OCRSnapshot
        ocr = OfflineOCR(CardDatabase(), renderer=_DeterministicRenderer())
        snapshot = OCRSnapshot(
            lines=(OCRLine("Trophy Road", 0.95, (80, 40, 160, 60)),),
            confidence=0.95, available=True,
        )
        labels = ocr.labels_for(snapshot)
        self.assertEqual(len(labels), 1)
        self.assertFalse(labels[0].clickable)
        self.assertFalse(labels[0].target_clickable)

    def test_normalize_mask_returns_fixed_bit_grid_and_aspect(self):
        mask = bytearray(20 * 10)
        for y in range(2, 8):
            for x in range(3, 17):
                if (x + y) % 2 == 0:
                    mask[y * 20 + x] = 1
        result = _normalize_mask(mask, 20, 10)
        self.assertIsNotNone(result)
        bits, aspect = result
        self.assertGreater(bits, 0)
        self.assertGreater(aspect, 1.0)

    def test_opponent_cycle_predicts_the_first_play_after_four_observations(self):
        tracker = OpponentCycleTracker(CardDatabase())
        result = None
        for index in range(4):
            track = ClusterTrack(
                track_id=index + 1, x=0.30 + index * 0.02, y=0.44,
                vx=0.0, vy=0.0, width=0.04, height=0.04, area=0.02,
                confidence=0.8, age_seconds=0.0, observations=1,
                last_seen=float(index + 1),
            )
            state = make_state(enemy_tracks=(track,))
            result = tracker.observe(state, now=float(index + 1))
        self.assertTrue(result.opponent_cycle_complete)
        self.assertEqual(result.opponent_play_count, 4)
        self.assertEqual(result.opponent_cycle_token, "opp_0001")
        self.assertLessEqual(result.opponent_cycle_confidence, 0.46)
        self.assertEqual(result.opponent_cycle_card, "")

    def test_opponent_cycle_only_names_a_card_when_ocr_identifies_it(self):
        tracker = OpponentCycleTracker(CardDatabase())
        first = ClusterTrack(
            track_id=1, x=0.31, y=0.40, vx=0.0, vy=0.0,
            width=0.04, height=0.04, area=0.02, confidence=0.8,
            age_seconds=0.0, observations=1, last_seen=1.0,
        )
        named = CardRecognition(
            "hog-rider", "Hog Rider", "base", None, False, 0.96,
            bounds=(110, 300, 150, 330),
        )
        first_state = make_state(enemy_tracks=(first,), recognized_cards=(named,))
        tracker.observe(first_state, now=1.0)
        result = None
        for index in range(1, 4):
            track = ClusterTrack(
                track_id=index + 1, x=0.34, y=0.44, vx=0.0, vy=0.0,
                width=0.04, height=0.04, area=0.02, confidence=0.8,
                age_seconds=0.0, observations=1, last_seen=float(index + 1),
            )
            result = tracker.observe(make_state(enemy_tracks=(track,)), now=float(index + 1))
        self.assertEqual(result.opponent_cycle_card, "hog-rider")
        self.assertIn("win_condition", result.opponent_cycle_roles)
        self.assertLess(result.opponent_cycle_confidence, 0.65)

    def test_fully_named_four_play_window_has_counter_usable_confidence(self):
        tracker = OpponentCycleTracker(CardDatabase())
        keys = ("hog-rider", "fireball", "knight", "arrows")
        result = None
        for index, key in enumerate(keys):
            record = CardDatabase().get(key)
            card = CardRecognition(
                key, record.name_en, "base", None, False, 0.96,
                bounds=(110, 300, 150, 330),
            )
            track = ClusterTrack(
                track_id=index + 1, x=0.31, y=0.40, vx=0.0, vy=0.0,
                width=0.04, height=0.04, area=0.02, confidence=0.8,
                age_seconds=0.0, observations=1, last_seen=float(index + 1),
            )
            state = make_state(enemy_tracks=(track,), recognized_cards=(card,))
            result = tracker.observe(state, now=float(index + 1))
        self.assertEqual(result.opponent_cycle_card, "hog-rider")
        self.assertGreaterEqual(result.opponent_cycle_confidence, 0.65)
        self.assertIn("win_condition", result.opponent_cycle_roles)

    def test_fifth_play_advances_the_four_card_cycle_by_one(self):
        tracker = OpponentCycleTracker(CardDatabase())
        keys = ("hog-rider", "fireball", "knight", "arrows", "golem")
        result = None
        for index, key in enumerate(keys):
            card = CardRecognition(
                key, CardDatabase().get(key).name_en, "base", None, False, 0.96,
                bounds=(110, 300, 150, 330),
            )
            track = ClusterTrack(
                track_id=index + 1, x=0.31, y=0.40, vx=0.0, vy=0.0,
                width=0.04, height=0.04, area=0.02, confidence=0.8,
                age_seconds=0.0, observations=1, last_seen=float(index + 1),
            )
            result = tracker.observe(make_state(enemy_tracks=(track,), recognized_cards=(card,)),
                                     now=float(index + 1))
        self.assertEqual(result.opponent_cycle_card, "fireball")

    def test_opponent_cycle_resets_outside_a_battle(self):
        tracker = OpponentCycleTracker(CardDatabase())
        track = ClusterTrack(
            track_id=1, x=0.3, y=0.4, vx=0.0, vy=0.0,
            width=0.04, height=0.04, area=0.02, confidence=0.8,
            age_seconds=0.0, observations=1, last_seen=1.0,
        )
        tracker.observe(make_state(enemy_tracks=(track,)), now=1.0)
        lobby = tracker.observe(make_state(scene=Scene.HOME, battle_detected=False), now=2.0)
        self.assertEqual(lobby.opponent_play_count, 0)
        self.assertEqual(tracker.history, [])

    def test_opponent_cycle_survives_a_transient_unknown_scene(self):
        tracker = OpponentCycleTracker(CardDatabase())
        result = None
        for index in range(5):
            track = ClusterTrack(
                track_id=index + 1, x=0.30 + index * 0.02, y=0.44,
                vx=0.0, vy=0.0, width=0.04, height=0.04, area=0.02,
                confidence=0.8, age_seconds=0.0, observations=1,
                last_seen=float(index + 1),
            )
            result = tracker.observe(make_state(enemy_tracks=(track,)), now=float(index + 1))
        unknown = make_state(scene=Scene.UNKNOWN, battle_detected=False,
                             confidence=0.0, scene_confidence=0.0)
        held = tracker.observe(unknown, now=5.3)
        self.assertEqual(held.opponent_play_count, 5)
        returned = tracker.observe(make_state(), now=5.6)
        self.assertEqual(returned.opponent_play_count, 5)

    def test_opponent_cycle_history_and_seen_track_cache_are_bounded(self):
        tracker = OpponentCycleTracker(CardDatabase())
        for track_id in range(1, tracker.MAX_SEEN_TRACK_IDS + 100):
            self.assertTrue(tracker._remember_track_id(track_id))
        self.assertEqual(len(tracker._seen_track_ids), tracker.MAX_SEEN_TRACK_IDS)
        self.assertEqual(len(tracker._seen_track_order), tracker.MAX_SEEN_TRACK_IDS)
        self.assertFalse(tracker._remember_track_id(tracker.MAX_SEEN_TRACK_IDS + 99))

    def test_dxgi_capture_is_a_last_resort_after_gdi_and_printclient(self):
        frame = Frame(120, 160, bytes([255, 255, 255, 255]) * 120 * 160)
        with patch("core.win32.window_is_interactive", return_value=True), \
             patch("core.win32._capture_screen_gdi", side_effect=OSError("gdi")), \
             patch("core.win32._capture_wm_printclient", side_effect=OSError("print")), \
             patch("core.dxgi.capture_window_dxgi", return_value=frame) as dxgi:
            result = capture_window(123)
        self.assertIs(result, frame)
        dxgi.assert_called_once_with(123, 420)

    def test_dxgi_is_not_attempted_after_window_loses_interactivity(self):
        with patch("core.win32.window_is_interactive", side_effect=(True, True, False)), \
             patch("core.win32._capture_screen_gdi", side_effect=OSError("gdi")), \
             patch("core.win32._capture_wm_printclient", side_effect=OSError("print")), \
             patch("core.dxgi.capture_window_dxgi") as dxgi:
            with self.assertRaises(OSError):
                capture_window(123)
        dxgi.assert_not_called()

    def test_dxgi_backend_fails_closed_on_non_windows(self):
        if os.name == "nt":
            self.skipTest("This host has DXGI.")
        with self.assertRaisesRegex(OSError, "requires Windows 11"):
            capture_window_dxgi(123)


if __name__ == "__main__":
    unittest.main()
