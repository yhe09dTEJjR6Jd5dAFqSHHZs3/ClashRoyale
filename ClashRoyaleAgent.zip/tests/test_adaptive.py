from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.adb import AccessibilityLabel, decode_android_png, enrich_state_with_accessibility
from core.cards import CardDatabase
from core.deck_manager import DeckManager
from core.preflight import validate_startup_frame
from core.ui_adaptive import _edge_profile, _luma
from core.vision import GameState, Scene, analyze_frame
from core.win32 import Frame


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures" / "adaptive_ui"


def shifted_battle_frame() -> Frame:
    """A synthetic battle with a moved arena, hand row, and elixir gauge."""
    width, height = 420, 720
    pixels = bytearray(width * height * 4)

    def paint(x0: int, y0: int, x1: int, y1: int, bgra: tuple[int, int, int]) -> None:
        color = bytes((*bgra, 255))
        for y in range(y0, y1):
            row = (y * width + x0) * 4
            pixels[row:row + (x1 - x0) * 4] = color * (x1 - x0)

    paint(20, 75, 400, 520, (24, 112, 24))
    paint(65, 300, 105, 345, (20, 20, 220))
    paint(300, 330, 340, 375, (20, 20, 220))
    paint(150, 310, 185, 350, (220, 80, 20))
    paint(235, 285, 270, 330, (220, 80, 20))
    paint(72, 552, 345, 575, (155, 28, 155))
    for center, color in zip((88, 170, 252, 334),
                             ((20, 100, 220), (220, 120, 20), (180, 40, 180), (20, 180, 220))):
        paint(center - 20, 590, center + 20, 690, color)
    return Frame(width, height, bytes(pixels))


def landscape_battle_frame() -> Frame:
    """A native 16:9 battle layout with the hand and elixir at the bottom."""
    width, height = 720, 405
    pixels = bytearray(width * height * 4)

    def paint(x0: int, y0: int, x1: int, y1: int, bgra: tuple[int, int, int]) -> None:
        color = bytes((*bgra, 255))
        for y in range(y0, y1):
            row = (y * width + x0) * 4
            pixels[row:row + (x1 - x0) * 4] = color * (x1 - x0)

    paint(28, 24, 692, 286, (24, 112, 24))
    paint(90, 145, 132, 188, (20, 20, 220))
    paint(565, 180, 610, 225, (20, 20, 220))
    paint(315, 150, 352, 194, (220, 80, 20))
    paint(405, 192, 442, 235, (220, 80, 20))
    paint(40, 310, 680, 326, (190, 20, 190))
    for center, color in zip((90, 270, 450, 630),
                             ((20, 100, 220), (220, 120, 20),
                              (180, 40, 180), (20, 180, 220))):
        paint(center - 44, 332, center + 44, 397, color)
    return Frame(width, height, bytes(pixels))


def pillarboxed_frame() -> Frame:
    """Place a portrait battle in a wide black desktop capture."""
    source = shifted_battle_frame()
    width, height = 1280, source.height
    left = (width - source.width) // 2
    pixels = bytearray(width * height * 4)
    source_view = memoryview(source.bgra)
    row_bytes = source.width * 4
    for y in range(height):
        start = y * width * 4 + left * 4
        pixels[start:start + row_bytes] = source_view[y * row_bytes:(y + 1) * row_bytes]
    return Frame(width, height, bytes(pixels))


class AdaptiveLayoutTests(unittest.TestCase):
    def test_optimized_edge_profile_matches_reference_luminance_differences(self):
        frame = shifted_battle_frame()
        data = memoryview(frame.bgra)
        for axis, region, sample_positions in (
            ("vertical", (0.01, 0.10, 0.99, 0.88), (40, 120, 210, 380)),
            ("horizontal", (0.01, 0.10, 0.99, 0.92), (100, 240, 500, 650)),
        ):
            profile, start, end = _edge_profile(frame, axis, region)
            for position in sample_positions:
                if not start <= position < end:
                    continue
                total = 0.0
                count = 0
                if axis == "vertical":
                    y_step = max(2, frame.height // 160)
                    for y in range(max(0, int(frame.height * region[1])),
                                   min(frame.height, int(frame.height * region[3])), y_step):
                        current = (y * frame.width + position) * 4
                        total += abs(_luma(data, current) - _luma(data, current - 4))
                        count += 1
                else:
                    y_step = max(1, frame.height // 320)
                    x_step = max(2, frame.width // 160)
                    left = max(0, int(frame.width * region[0]))
                    right = min(frame.width, int(frame.width * region[2]))
                    for x in range(left, right, x_step):
                        current = (position * frame.width + x) * 4
                        previous = current - frame.width * 4
                        total += abs(_luma(data, current) - _luma(data, previous))
                        count += 1
                self.assertAlmostEqual(profile[position], total / max(1, count), places=9)

    def test_startup_preflight_accepts_recognized_game_scene_and_rejects_unknown(self):
        home, _ = decode_android_png((FIXTURES / "04_home.png").read_bytes(), max_width=240)
        state = validate_startup_frame(home)
        self.assertEqual(state.scene, Scene.HOME)
        self.assertGreaterEqual(state.scene_confidence, 0.52)

        blank = Frame(360, 640, bytes(360 * 640 * 4))
        with self.assertRaisesRegex(OSError, "无法确认所选窗口属于皇室战争"):
            validate_startup_frame(blank)

    def test_user_screenshots_are_classified_from_structure(self):
        labels = {}
        for line in (FIXTURES / "labels.tsv").read_text(encoding="utf-8").splitlines():
            if not line or line.startswith("#"):
                continue
            filename, label = line.split("\t", 1)
            labels[filename] = label
        self.assertEqual(len(labels), 9)
        for filename, expected in labels.items():
            frame, _metadata = decode_android_png((FIXTURES / filename).read_bytes(), max_width=240)
            state = analyze_frame(frame)
            with self.subTest(filename=filename):
                self.assertEqual(state.scene.value, expected)
                self.assertGreaterEqual(state.scene_confidence, 0.60 if expected == "loading" else 0.78)
        home, _ = decode_android_png((FIXTURES / "04_home.png").read_bytes(), max_width=240)
        home_state = analyze_frame(home)
        self.assertIsNotNone(home_state.target("mode_entry"))
        mode, _ = decode_android_png((FIXTURES / "05_mode_select.png").read_bytes(), max_width=240)
        mode_state = analyze_frame(mode)
        self.assertFalse(mode_state.ladder_unlocked)  # positive padlock evidence is sufficient
        self.assertGreaterEqual(mode_state.ladder_lock_confidence, 0.70)
        self.assertGreater(mode_state.target("journey").y, 0.32)
        self.assertLess(mode_state.target("journey").y, 0.43)
        self.assertGreater(mode_state.target("ladder").y, mode_state.target("journey").y)

    def test_ladder_lock_state_remains_unknown_without_positive_lock_evidence(self):
        path = FIXTURES / "05_mode_select.png"
        frame, _ = decode_android_png(path.read_bytes(), max_width=240)
        pixels = bytearray(frame.bgra)
        x0, x1 = int(frame.width * 0.72), int(frame.width * 0.96)
        y0, y1 = int(frame.height * 0.78), int(frame.height * 0.98)
        for y in range(y0, y1):
            start = (y * frame.width + x0) * 4
            end = (y * frame.width + x1) * 4
            pixels[start:end] = bytes((24, 30, 36, 255)) * (x1 - x0)
        state = analyze_frame(Frame(frame.width, frame.height, bytes(pixels)))
        self.assertEqual(state.scene, Scene.MODE_SELECT)
        self.assertIsNone(state.ladder_unlocked)
        self.assertLess(state.ladder_lock_confidence, 0.70)

    def test_chinese_ladder_labels_and_unlock_text_override_visual_candidates(self):
        frame, _metadata = decode_android_png((FIXTURES / "05_mode_select.png").read_bytes(), max_width=240)
        state = analyze_frame(frame)
        labels = [
            AccessibilityLabel("皇室征程", "", "", True, True,
                               (20, 180, 190, 225), (0, 145, 240, 275), True, True),
            AccessibilityLabel("天梯", "", "奖杯数达到13000时解锁", True, True,
                               (20, 420, 130, 455), (0, 380, 240, 510), True, True),
        ]
        enriched = enrich_state_with_accessibility(state, labels, frame.width, frame.height)
        self.assertEqual(enriched.scene, Scene.MODE_SELECT)
        self.assertFalse(enriched.ladder_unlocked)
        self.assertTrue(enriched.target("ladder").screen_space)
        self.assertTrue(enriched.target("journey").screen_space)

    def test_hand_and_arena_geometry_follow_a_shifted_layout(self):
        state = analyze_frame(shifted_battle_frame())
        self.assertEqual(state.scene, Scene.BATTLE)
        self.assertIsNotNone(state.arena_bounds)
        self.assertIsNotNone(state.elixir_bounds)
        self.assertEqual(len(state.card_bounds), 4)
        self.assertGreater(state.card_bounds[0][1], 0.80)
        self.assertLess(state.card_bounds[0][1], 0.88)
        self.assertGreater(state.elixir_bounds[1], 0.76)
        self.assertLess(state.elixir_bounds[1], state.card_bounds[0][1])
        self.assertGreater(state.elixir_confidence, 0.55)

    def test_native_landscape_battle_layout_is_classified_and_tracks_hand(self):
        state = analyze_frame(landscape_battle_frame())
        self.assertEqual(state.scene, Scene.BATTLE)
        self.assertTrue(state.battle_detected)
        self.assertEqual(len(state.card_bounds), 4)
        self.assertIsNotNone(state.elixir_bounds)
        self.assertGreater(state.elixir_confidence, 0.45)

    def test_wide_window_pillarboxed_portrait_viewport_is_cropped_and_mapped(self):
        state = analyze_frame(pillarboxed_frame())
        self.assertEqual(state.scene, Scene.BATTLE)
        self.assertTrue(state.battle_detected)
        self.assertEqual(state.frame_width, 1280)
        self.assertEqual(state.frame_height, 720)
        self.assertGreater(state.viewport[0], 0.25)
        self.assertLess(state.viewport[2], 0.75)
        self.assertEqual(len(state.card_bounds), 4)

    def test_verified_ocr_name_teaches_a_new_icon_fingerprint(self):
        database = CardDatabase()
        record = database.find("Knight")
        self.assertIsNotNone(record)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manager = DeckManager(root / "profiles.json", catalog_path=root / "catalog.json",
                                  card_database=database)
            fingerprint = "0123456789abcdef"
            descriptor = tuple([0.31] * 19)
            state = GameState(
                left_threat=0.0, right_threat=0.0, left_support=0.0, right_support=0.0,
                card_scores=(0.3, 0.3, 0.3, 0.3),
                green_ratio=0.3, red_ratio=0.02, blue_ratio=0.02, purple_ratio=0.2,
                confidence=0.9,
                scene=Scene.BATTLE,
                battle_detected=True,
                scene_confidence=0.9,
                elixir=6.0,
                elixir_confidence=0.9,
                card_ready=(True, False, False, False),
                card_ready_confidence=(0.9, 0.9, 0.9, 0.9),
                card_names=(record.name_en, "", "", ""),
                card_fingerprints=(fingerprint, "", "", ""),
                card_descriptors=(descriptor, (), (), ()),
                ocr_confidence=0.92,
            )
            observed = manager.observe(state)
            profile = next(iter(manager.profiles.values()))
            self.assertEqual(observed.card_names[0], record.name_en)
            self.assertEqual(manager.metadata_for_profile(profile)["card_key"], record.key)
            self.assertEqual(manager.runtime_catalog_samples, 1)
            manager.save()
            self.assertTrue((root / "catalog.json").exists())

    def test_new_card_without_metadata_becomes_a_persistent_visual_profile(self):
        database = CardDatabase()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manager = DeckManager(root / "profiles.json", card_database=database)
            state = GameState(
                left_threat=0.0, right_threat=0.0, left_support=0.0, right_support=0.0,
                card_scores=(0.3, 0.3, 0.3, 0.3),
                green_ratio=0.3, red_ratio=0.02, blue_ratio=0.02, purple_ratio=0.2,
                confidence=0.9,
                scene=Scene.BATTLE,
                battle_detected=True,
                scene_confidence=0.9,
                elixir=5.0,
                elixir_confidence=0.9,
                card_ready=(True, False, False, False),
                card_ready_confidence=(0.9, 0.9, 0.9, 0.9),
                card_fingerprints=("fedcba9876543210", "", "", ""),
                card_descriptors=(tuple([0.44] * 19), (), (), ()),
            )
            manager.observe(state)
            self.assertEqual(len(manager.profiles), 1)
            self.assertEqual(manager.unknown_visual_profiles, 1)
            manager.save()
            restored = DeckManager(root / "profiles.json", card_database=database)
            self.assertEqual(len(restored.profiles), 1)
            self.assertEqual(restored.unknown_visual_profiles, 1)


if __name__ == "__main__":
    unittest.main()
