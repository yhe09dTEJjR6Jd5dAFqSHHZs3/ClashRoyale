from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.adb import AccessibilityLabel, decode_android_png, enrich_state_with_accessibility
from core.cards import CardDatabase
from core.deck_manager import DeckManager
from core.vision import GameState, Scene, analyze_frame
from core.win32 import Frame


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests" / "fixtures" / "adaptive_ui"


def shifted_battle_frame() -> Frame:
    """A synthetic battle with a moved arena, hand row, and elixir gauge."""
    width, height = 420, 720
    pixels = bytearray(width * height * 4)

    def paint(x0: int, y0: int, x1: int, y1: int, bgra: tuple[int, int, int]) -> None:
        color = bytes((*bgra, 255))
        for y in range(y0, y1):
            row = (y * width + x0) * 4
            pixels[row:row + (x1 - x0) * 4] = color * (x1 - x0)

    paint(20, 75, 400, 520, (24, 112, 24))
    paint(65, 300, 105, 345, (20, 20, 220))
    paint(300, 330, 340, 375, (20, 20, 220))
    paint(150, 310, 185, 350, (220, 80, 20))
    paint(235, 285, 270, 330, (220, 80, 20))
    paint(72, 552, 345, 575, (155, 28, 155))
    for center, color in zip((88, 170, 252, 334),
                             ((20, 100, 220), (220, 120, 20), (180, 40, 180), (20, 180, 220))):
        paint(center - 20, 590, center + 20, 690, color)
    return Frame(width, height, bytes(pixels))


class AdaptiveLayoutTests(unittest.TestCase):
    def test_user_screenshots_are_classified_from_structure(self):
        labels = {}
        for line in (FIXTURES / "labels.tsv").read_text(encoding="utf-8").splitlines():
            if not line or line.startswith("#"):
                continue
            filename, label = line.split("\t", 1)
            labels[filename] = label
        self.assertEqual(len(labels), 9)
        for filename, expected in labels.items():
            frame, _metadata = decode_android_png((FIXTURES / filename).read_bytes(), max_width=240)
            state = analyze_frame(frame)
            with self.subTest(filename=filename):
                self.assertEqual(state.scene.value, expected)
                self.assertGreaterEqual(state.scene_confidence, 0.60 if expected == "loading" else 0.78)
        home, _ = decode_android_png((FIXTURES / "04_home.png").read_bytes(), max_width=240)
        home_state = analyze_frame(home)
        self.assertIsNotNone(home_state.target("mode_entry"))
        mode, _ = decode_android_png((FIXTURES / "05_mode_select.png").read_bytes(), max_width=240)
        mode_state = analyze_frame(mode)
        self.assertIsNone(mode_state.ladder_unlocked)  # visual geometry never guesses unlock status
        self.assertGreater(mode_state.target("ladder").y, mode_state.target("journey").y)

    def test_chinese_ladder_labels_and_unlock_text_override_visual_candidates(self):
        frame, _metadata = decode_android_png((FIXTURES / "05_mode_select.png").read_bytes(), max_width=240)
        state = analyze_frame(frame)
        labels = [
            AccessibilityLabel("皇室征程", "", "", True, True,
                               (20, 180, 190, 225), (0, 145, 240, 275), True, True),
            AccessibilityLabel("天梯", "", "奖杯数达到13000时解锁", True, True,
                               (20, 420, 130, 455), (0, 380, 240, 510), True, True),
        ]
        enriched = enrich_state_with_accessibility(state, labels, frame.width, frame.height)
        self.assertEqual(enriched.scene, Scene.MODE_SELECT)
        self.assertFalse(enriched.ladder_unlocked)
        self.assertTrue(enriched.target("ladder").screen_space)
        self.assertTrue(enriched.target("journey").screen_space)

    def test_hand_and_arena_geometry_follow_a_shifted_layout(self):
        state = analyze_frame(shifted_battle_frame())
        self.assertEqual(state.scene, Scene.BATTLE)
        self.assertIsNotNone(state.arena_bounds)
        self.assertIsNotNone(state.elixir_bounds)
        self.assertEqual(len(state.card_bounds), 4)
        self.assertGreater(state.card_bounds[0][1], 0.80)
        self.assertLess(state.card_bounds[0][1], 0.88)
        self.assertGreater(state.elixir_bounds[1], 0.76)
        self.assertLess(state.elixir_bounds[1], state.card_bounds[0][1])
        self.assertGreater(state.elixir_confidence, 0.55)

    def test_verified_ocr_name_teaches_a_new_icon_fingerprint(self):
        database = CardDatabase()
        record = database.find("Knight")
        self.assertIsNotNone(record)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manager = DeckManager(root / "profiles.json", catalog_path=root / "catalog.json",
                                  card_database=database)
            fingerprint = "0123456789abcdef"
            descriptor = tuple([0.31] * 19)
            state = GameState(
                left_threat=0.0, right_threat=0.0, left_support=0.0, right_support=0.0,
                card_scores=(0.3, 0.3, 0.3, 0.3),
                green_ratio=0.3, red_ratio=0.02, blue_ratio=0.02, purple_ratio=0.2,
                confidence=0.9,
                scene=Scene.BATTLE,
                battle_detected=True,
                scene_confidence=0.9,
                elixir=6.0,
                elixir_confidence=0.9,
                card_ready=(True, False, False, False),
                card_ready_confidence=(0.9, 0.9, 0.9, 0.9),
                card_names=(record.name_en, "", "", ""),
                card_fingerprints=(fingerprint, "", "", ""),
                card_descriptors=(descriptor, (), (), ()),
                ocr_confidence=0.92,
            )
            observed = manager.observe(state)
            profile = next(iter(manager.profiles.values()))
            self.assertEqual(observed.card_names[0], record.name_en)
            self.assertEqual(manager.metadata_for_profile(profile)["card_key"], record.key)
            self.assertEqual(manager.runtime_catalog_samples, 1)
            manager.save()
            self.assertTrue((root / "catalog.json").exists())

    def test_new_card_without_metadata_becomes_a_persistent_visual_profile(self):
        database = CardDatabase()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manager = DeckManager(root / "profiles.json", card_database=database)
            state = GameState(
                left_threat=0.0, right_threat=0.0, left_support=0.0, right_support=0.0,
                card_scores=(0.3, 0.3, 0.3, 0.3),
                green_ratio=0.3, red_ratio=0.02, blue_ratio=0.02, purple_ratio=0.2,
                confidence=0.9,
                scene=Scene.BATTLE,
                battle_detected=True,
                scene_confidence=0.9,
                elixir=5.0,
                elixir_confidence=0.9,
                card_ready=(True, False, False, False),
                card_ready_confidence=(0.9, 0.9, 0.9, 0.9),
                card_fingerprints=("fedcba9876543210", "", "", ""),
                card_descriptors=(tuple([0.44] * 19), (), (), ()),
            )
            manager.observe(state)
            self.assertEqual(len(manager.profiles), 1)
            self.assertEqual(manager.unknown_visual_profiles, 1)
            manager.save()
            restored = DeckManager(root / "profiles.json", card_database=database)
            self.assertEqual(len(restored.profiles), 1)
            self.assertEqual(restored.unknown_visual_profiles, 1)


if __name__ == "__main__":
    unittest.main()
