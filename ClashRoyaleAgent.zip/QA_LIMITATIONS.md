# v0.27.0 verification boundaries

## Verified in the build environment

- Python 3.13.5 syntax compilation and 242 automated tests (after the final test run; see release test output).
- Release ZIP integrity and exact file-list check.
- `MANIFEST.sha256` verification and launcher source/binary build-record verification.
- Windows x64 PE32+ structure check for the bundled launcher.
- Data snapshot hashes and redistribution-manifest checks.
- Blackbox ZIP remains at or below 1,000,000 bytes in automated tests.
- Synthetic tactical-search smoke test completes with a non-zero node count.

## Not verified by this build environment

- Execution of `ClashRoyale.exe` on a physical Windows 11 x64 machine.
- Real Windows GDI/DXGI capture and input behavior on different GPUs, window classes and monitor topologies.
- Real 100%, 125%, 150% and 200% DPI layouts or monitor hot-plugging.
- 8-hour/24-hour live-game soak runs, including real memory/handle trends and game updates.
- Accuracy on a representative, manually labelled real-game screenshot set. No such screenshots are bundled.
- A statistically meaningful real-match win rate or performance parity with top human players.
- Complete game-engine fidelity for all card forms, level modifiers, spawned units, hitboxes, collision, knockback, retargeting, status interactions and balance hotfixes.

The automated suite validates deterministic code paths and regression behavior; it is
not a substitute for the real-device and real-match evidence above. Do not describe
these unverified properties as passed or guaranteed.

## Normal user requirements

The limitations above do not add a setup step for normal users. The application still
starts from the supplied executable, asks the user to choose a work folder and game
window, and does not require users to collect screenshots, write labels, install a
third-party model, or connect to a cloud service.
