"""Replay real PNG screenshots through the local vision pipeline for QA.

Optional labels.json format:
{
  "battle_001.png": "battle",
  "mode_select_001.png": {"scene": "mode_select"}
}
Only the scene classifier is measured here; UIAutomator evidence is not present
in static PNGs and must be tested separately on the target emulator.
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.adb import decode_android_png
from core.vision import analyze_frame

VALID_SCENES = {"unknown", "battle", "home", "deck", "result", "matchmaking", "mode_select", "loading"}


def percentile(values: list[float], quantile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, round((len(ordered) - 1) * quantile)))
    return round(ordered[index], 3)




def classification_metrics(confusion: dict[str, Counter[str]]) -> dict[str, Any]:
    """Compute per-class precision/recall/F1 from expected -> predicted counts."""
    classes = sorted(set(confusion) | {predicted for row in confusion.values() for predicted in row})
    per_class: dict[str, dict[str, float | int]] = {}
    precision_values: list[float] = []
    recall_values: list[float] = []
    f1_values: list[float] = []
    supports: dict[str, int] = {}
    for label in classes:
        true_positive = int(confusion.get(label, Counter()).get(label, 0))
        support = sum(confusion.get(label, Counter()).values())
        predicted_count = sum(row.get(label, 0) for row in confusion.values())
        precision = true_positive / predicted_count if predicted_count else 0.0
        recall = true_positive / support if support else 0.0
        f1 = (2.0 * precision * recall / (precision + recall)
              if precision + recall else 0.0)
        per_class[label] = {
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "support": support,
            "predicted": predicted_count,
        }
        supports[label] = support
        if support:
            precision_values.append(precision)
            recall_values.append(recall)
            f1_values.append(f1)
    return {
        "per_class": per_class,
        "support_by_class": supports,
        "macro_precision": round(statistics.fmean(precision_values), 4) if precision_values else None,
        "macro_recall": round(statistics.fmean(recall_values), 4) if recall_values else None,
        "macro_f1": round(statistics.fmean(f1_values), 4) if f1_values else None,
    }


def load_labels(path: Path | None) -> dict[str, str]:
    if path is None:
        return {}
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("标签文件必须是 JSON 对象。")
    result: dict[str, str] = {}
    for filename, value in raw.items():
        scene = value.get("scene") if isinstance(value, dict) else value
        if not isinstance(filename, str) or Path(filename).name != filename:
            raise ValueError(f"无效截图文件名：{filename!r}")
        if scene not in VALID_SCENES:
            raise ValueError(f"{filename} 的 scene 标签无效：{scene!r}")
        result[filename] = scene
    return result


def replay_directory(input_dir: Path, labels: dict[str, str] | None = None) -> dict[str, Any]:
    input_dir = Path(input_dir).resolve()
    if not input_dir.is_dir():
        raise OSError(f"截图目录不存在：{input_dir}")
    labels = labels or {}
    paths = sorted(input_dir.glob("*.png"), key=lambda item: item.name.casefold())
    if not paths:
        raise ValueError("截图目录中没有 PNG 文件。")

    records: list[dict[str, Any]] = []
    latencies: list[float] = []
    actual_counts: Counter[str] = Counter()
    confusion: dict[str, Counter[str]] = defaultdict(Counter)
    correct = labelled = 0
    labelled_files: set[str] = set()
    for path in paths:
        started = time.perf_counter()
        record: dict[str, Any] = {"file": path.name}
        try:
            frame, native_size = decode_android_png(path.read_bytes(), max_width=420)
            state = analyze_frame(frame)
            actual = state.scene.value
            expected = labels.get(path.name)
            record.update({
                "native_size": list(native_size),
                "analysis_size": [frame.width, frame.height],
                "scene": actual,
                "scene_confidence": round(state.scene_confidence, 4),
                "battle_confidence": round(state.confidence, 4),
                "ladder_unlocked": state.ladder_unlocked,
                "result": state.result,
                "expected_scene": expected,
            })
            actual_counts[actual] += 1
            if expected is not None:
                labelled += 1
                labelled_files.add(path.name)
                confusion[expected][actual] += 1
                if expected == actual:
                    correct += 1
        except Exception as exc:
            record["error"] = str(exc)[:300]
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        record["latency_ms"] = round(elapsed_ms, 3)
        latencies.append(elapsed_ms)
        records.append(record)

    metrics = classification_metrics(confusion)
    present_names = {path.name for path in paths}
    return {
        "input_directory": str(input_dir),
        "images": len(paths),
        "decoded": sum("error" not in item for item in records),
        "labelled_images": labelled,
        "label_coverage": round(labelled / max(1, len(paths)), 4),
        "unlabelled_files": sorted(present_names - labelled_files),
        "labels_without_screenshot": sorted(set(labels) - present_names),
        "scene_accuracy": round(correct / labelled, 4) if labelled else None,
        "scene_metrics": metrics,
        "scene_confusion_expected_to_actual": {
            expected: dict(sorted(counts.items()))
            for expected, counts in sorted(confusion.items())
        },
        "scene_counts": dict(sorted(actual_counts.items())),
        "latency_ms": {
            "mean": round(statistics.fmean(latencies), 3) if latencies else 0.0,
            "p50": percentile(latencies, 0.50),
            "p95": percentile(latencies, 0.95),
            "max": round(max(latencies), 3) if latencies else 0.0,
        },
        "records": records,
        "limitations": [
            "Static PNG replay does not include Android UIAutomator labels or live input validation.",
            "Scene accuracy and per-class metrics are meaningful only when labels are manually verified and representative.",
            "A small or class-imbalanced screenshot set can make metrics unstable; inspect support_by_class before drawing conclusions.",
            "This report does not measure card identity, troop identity, tower health, opponent elixir, or tactical win rate.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="PNG 截图目录")
    parser.add_argument("--labels", type=Path, help="可选的人工 scene 标签 JSON")
    parser.add_argument("--output", type=Path, required=True, help="报告 JSON 输出路径")
    args = parser.parse_args()
    labels = load_labels(args.labels)
    report = replay_directory(args.input, labels)
    output = args.output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    try:
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
        temp.replace(output)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass
    print(f"截图 {report['images']} 张，成功解码 {report['decoded']} 张")
    print(f"场景准确率：{report['scene_accuracy'] if report['scene_accuracy'] is not None else '未提供标签'}")
    print(f"视觉处理 p50/p95：{report['latency_ms']['p50']:.3f}/{report['latency_ms']['p95']:.3f} ms")
    print(f"报告：{output}")


if __name__ == "__main__":
    main()
