"""Read-only Windows 11 smoke checks; writes its report only under --workspace."""
from __future__ import annotations

import argparse
import ctypes
import json
import os
from pathlib import Path
import platform
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.runtime import runtime_support_error
from core.workspace import app_workspace
from tools.build_release import verify_windows_x64_launcher
from tools.validate_data import verify_snapshot


def collect_smoke_report(workspace: Path) -> dict:
    workspace = Path(workspace).expanduser().resolve()
    app_data = app_workspace(workspace)
    temp_dir = app_data / ".tmp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "python": sys.version.split()[0],
        "python_bits": struct.calcsize("P") * 8,
        "windows_build": None,
        "supported_host": False,
        "workspace": str(app_data),
        "temporary_directory": str(temp_dir),
        "checks": {},
        "limitations": [
            "This smoke test does not launch the game, capture a real game window, or send input.",
            "It does not replace Windows 11 tests at 100/125/150/200 percent DPI or 8/24-hour live soak tests.",
        ],
    }
    if os.name == "nt":
        try:
            report["windows_build"] = int(sys.getwindowsversion().build)
        except (AttributeError, OSError, TypeError, ValueError):
            pass
    compatibility_error = runtime_support_error()
    report["supported_host"] = compatibility_error is None
    report["compatibility_error"] = compatibility_error
    try:
        report["checks"]["data_snapshot"] = verify_snapshot(ROOT).get("counts", {})
    except Exception as exc:
        report["checks"]["data_snapshot_error"] = str(exc)[:240]
    try:
        verify_windows_x64_launcher(ROOT / "ClashRoyale.exe")
        report["checks"]["launcher_pe32_plus_x64"] = True
    except Exception as exc:
        report["checks"]["launcher_error"] = str(exc)[:240]
    if os.name == "nt":
        libraries = {}
        for name in ("user32.dll", "gdi32.dll", "kernel32.dll", "d3d11.dll", "dxgi.dll"):
            try:
                ctypes.WinDLL(name)
                libraries[name] = True
            except OSError:
                libraries[name] = False
        report["checks"]["system_libraries"] = libraries
        try:
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            get_dpi = getattr(user32, "GetDpiForSystem", None)
            report["checks"]["system_dpi"] = int(get_dpi()) if get_dpi else None
        except Exception:
            report["checks"]["system_dpi"] = None
    else:
        report["checks"]["system_libraries"] = "not_checked_non_windows"
        report["checks"]["system_dpi"] = None
    probe = temp_dir / "smoke_write_probe.tmp"
    try:
        probe.write_bytes(b"workspace-write-test")
        report["checks"]["workspace_write"] = probe.read_bytes() == b"workspace-write-test"
    except OSError as exc:
        report["checks"]["workspace_write_error"] = str(exc)[:240]
    finally:
        try:
            probe.unlink()
        except OSError:
            pass
    report["checks"]["temporary_path_inside_selected_workspace"] = probe.parent.is_relative_to(app_data)
    return report


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, required=True,
                        help="the selected folder; report is written under its ClashRoyaleAgent subfolder")
    args = parser.parse_args(argv)
    report = collect_smoke_report(args.workspace)
    output = Path(report["workspace"]) / "windows_smoke_report.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    try:
        temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temporary.replace(output)
    finally:
        try:
            temporary.unlink()
        except OSError:
            pass
    print(f"Windows 11 x64 supported host: {report['supported_host']}")
    print(f"Report: {output}")
    return 0 if report["supported_host"] and report["checks"].get("workspace_write") else 2


if __name__ == "__main__":
    raise SystemExit(main())
