"""Build the model-free card-image reference catalog from bundled PNG art.

The script uses only the Python standard library. Each PNG is decoded by the
same pure-Python path used for deterministic test/release builds, then passed
through the live hand-card descriptor extractor. No pretrained model, network,
Pillow, or manually assigned ownership/level data is involved.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.adb import decode_android_png
from core.cards import CardDatabase
from core.vision import card_signature_for_bounds

BACKGROUND_RGB = (28, 36, 52)
CATALOG_VERSION = 1
EXPECTED_DESCRIPTOR_SIZE = 131


def image_identity(path: Path, database: CardDatabase) -> tuple[str, str]:
    stem = path.stem.casefold()
    if stem.endswith("-ev1"):
        key, form = stem[:-4], "evolution"
    elif stem.endswith("-hero"):
        key, form = stem[:-5], "hero"
    else:
        key = stem
        record = database.get(key)
        form = "champion" if record is not None and record.is_champion else "base"
    record = database.get(key)
    if record is None:
        raise ValueError(f"Image has no matching card metadata: {path.name}")
    if form not in record.available_forms:
        raise ValueError(f"Image form is not supported for {key}: {form}")
    return key, form


def expected_identities(database: CardDatabase) -> set[tuple[str, str]]:
    expected: set[tuple[str, str]] = set()
    for record in database.cards:
        expected.add((record.key, "champion" if record.is_champion else "base"))
        if record.has_evolution:
            expected.add((record.key, "evolution"))
        if record.has_hero:
            expected.add((record.key, "hero"))
    return expected


def build_catalog(images_dir: Path, database: CardDatabase | None = None) -> dict:
    images_dir = Path(images_dir)
    if not images_dir.is_dir():
        raise OSError(f"Card image directory does not exist: {images_dir}")
    database = database or CardDatabase()
    if len(database) < 100:
        raise ValueError("Bundled card metadata is incomplete; refusing to build image references.")

    image_paths = sorted(images_dir.glob("*.png"), key=lambda item: item.name.casefold())
    if not image_paths:
        raise ValueError("No PNG card images were found.")

    expected = expected_identities(database)
    observed: dict[tuple[str, str], Path] = {}
    cards: dict[str, dict] = {}
    for path in image_paths:
        identity = image_identity(path, database)
        if identity in observed:
            raise ValueError(f"Duplicate image for card form {identity}: {observed[identity].name}, {path.name}")
        observed[identity] = path

        payload = path.read_bytes()
        frame, _original_size = decode_android_png(
            payload, max_width=256, use_gdiplus=False, background_rgb=BACKGROUND_RGB,
        )
        visual_score, fingerprint, descriptor = card_signature_for_bounds(
            frame, (0, 0, frame.width, frame.height),
        )
        if (not fingerprint or len(fingerprint) != 16 or
                len(descriptor) != EXPECTED_DESCRIPTOR_SIZE or visual_score < 0.10):
            raise ValueError(f"Card image failed visual validation: {path.name}")
        if fingerprint in cards:
            other = cards[fingerprint]
            raise ValueError(
                f"64-bit fingerprint collision: {path.name} and "
                f"{other['card_key']}:{other['form']}"
            )

        key, form = identity
        record = database.get(key)
        assert record is not None
        cards[fingerprint] = {
            "name": record.name_en,
            "owned": False,
            "roles": list(database.roles_for(record)),
            "cost": float(record.elixir_cost) if record.elixir_cost is not None else None,
            "level": None,
            "descriptor": list(descriptor),
            "card_key": record.key,
            "form": form,
            "source": "bundled_card_image",
            "confidence": 0.96,
            "samples": 1,
            "card_type": record.card_type,
            "variable_cost": record.variable_elixir_cost,
            "cost_options": list(record.elixir_cost_options),
            "image": path.name,
        }

    missing = sorted(expected - set(observed))
    extra = sorted(set(observed) - expected)
    if missing or extra:
        raise ValueError(f"Card image coverage mismatch. missing={missing}, extra={extra}")
    if len(cards) != len(expected):
        raise ValueError(f"Expected {len(expected)} unique forms, generated {len(cards)}.")
    return {
        "version": CATALOG_VERSION,
        "descriptor": "cr-card-visual-131-v1",
        "background_rgb": list(BACKGROUND_RGB),
        "expected_cards": len(database),
        "expected_forms": len(expected),
        "cards": dict(sorted(cards.items())),
    }


def write_catalog(catalog: dict, output: Path) -> None:
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    try:
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(catalog, stream, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, output)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the offline card-image fingerprint catalog.")
    parser.add_argument("--images-dir", type=Path, default=ROOT / "data" / "card_images")
    parser.add_argument("--output", type=Path, default=ROOT / "data" / "card_visual_catalog.json")
    args = parser.parse_args()
    catalog = build_catalog(args.images_dir)
    write_catalog(catalog, args.output)
    print(
        f"Built {len(catalog['cards'])} visual references for "
        f"{catalog['expected_cards']} cards ({catalog['expected_forms']} forms): {args.output}"
    )


if __name__ == "__main__":
    main()
