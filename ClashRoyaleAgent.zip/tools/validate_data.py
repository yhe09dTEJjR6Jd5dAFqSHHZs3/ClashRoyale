"""Offline validation and SHA-256 pinning for bundled game-data snapshots."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
SNAPSHOT = DATA / "SNAPSHOT.json"
PINNED_FILES = (
    "cards.tsv", "combat_profiles.tsv", "meta_decks.tsv", "card_visual_catalog.json",
    "ASSET_LICENSES.json", "card_images",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _image_tree_sha256(directory: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(directory.glob("*.png"), key=lambda item: item.name.lower()):
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(sha256(path)))
    return digest.hexdigest()


def _rows(path: Path) -> list[list[str]]:
    result = []
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        result.append(line.split("|"))
    return result


def _validate_asset_licenses(data: Path, image_files: list[Path], deck_rows: list[list[str]]) -> dict:
    path = data / "ASSET_LICENSES.json"
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or raw.get("format_version") != 1:
        raise ValueError("ASSET_LICENSES.json is missing or has an unsupported format")
    image_licenses = raw.get("card_images")
    if not isinstance(image_licenses, dict):
        raise ValueError("ASSET_LICENSES.json card_images must be an object")
    actual_names = {item.name for item in image_files}
    if set(image_licenses) != actual_names:
        raise ValueError("Every bundled card image must have exactly one matching license record")
    for filename, record in image_licenses.items():
        if not isinstance(record, dict):
            raise ValueError(f"Invalid card image license record: {filename}")
        if (not str(record.get("source") or "").strip() or
                not str(record.get("license") or "").strip() or
                record.get("redistribution_permission") is not True):
            raise ValueError(f"Card image lacks documented redistribution permission: {filename}")

    deck_license = raw.get("meta_decks")
    if not isinstance(deck_license, dict):
        raise ValueError("ASSET_LICENSES.json meta_decks must be an object")
    if int(deck_license.get("rows", -1)) != len(deck_rows):
        raise ValueError("ASSET_LICENSES.json meta_decks row count does not match meta_decks.tsv")
    if deck_rows and (
        not str(deck_license.get("source") or "").strip() or
        not str(deck_license.get("license") or "").strip() or
        deck_license.get("redistribution_permission") is not True
    ):
        raise ValueError("Third-party deck priors require documented redistribution permission")
    return raw


def validate_data_contents(root: Path = ROOT) -> dict:
    data = Path(root) / "data"
    cards = _rows(data / "cards.tsv")
    if len(cards) != 127 or any(len(row) < 6 for row in cards):
        raise ValueError(f"cards.tsv must contain 127 complete rows; found {len(cards)}")
    card_keys = [row[0].strip() for row in cards]
    if len(set(card_keys)) != len(card_keys) or any(not key for key in card_keys):
        raise ValueError("cards.tsv contains an empty or duplicate card key")

    combat = _rows(data / "combat_profiles.tsv")
    combat_keys = [row[0].strip() for row in combat if row]
    if len(combat_keys) != 127 or set(combat_keys) != set(card_keys):
        raise ValueError("combat_profiles.tsv must contain exactly one row for each bundled card")

    visual_path = data / "card_visual_catalog.json"
    visual = json.loads(visual_path.read_text(encoding="utf-8"))
    visual_cards = visual.get("cards") if isinstance(visual, dict) else None
    if (not isinstance(visual_cards, dict) or visual.get("expected_cards") != 127 or
            visual.get("expected_forms") != len(visual_cards) or
            visual.get("descriptor") != "cr-card-visual-131-v1"):
        raise ValueError("card_visual_catalog.json does not match the 127-card optional-reference schema")
    if any(not isinstance(item, dict) or len(item.get("descriptor", [])) != 131
           for item in visual_cards.values()):
        raise ValueError("visual catalog contains a descriptor with an unexpected dimension")
    image_dir = data / "card_images"
    image_files = list(image_dir.glob("*.png"))
    allowed_image_tree = {image_dir / "README.md", *image_files}
    unexpected_image_files = [item for item in image_dir.rglob("*")
                              if item.is_file() and item not in allowed_image_tree]
    if unexpected_image_files:
        raise ValueError("card_images contains an unsupported or unlicensed non-PNG file")
    if len(image_files) != len(visual_cards):
        raise ValueError("card_visual_catalog.json and card_images PNG counts differ")
    if any(not (image_dir / str(item.get("image", ""))).is_file()
           for item in visual_cards.values()):
        raise ValueError("visual catalog references a missing card image")

    decks = _rows(data / "meta_decks.tsv")
    for row in decks:
        if len(row) != 4:
            raise ValueError("meta_decks.tsv row must have rank, name, usage, and card list")
        rank, name, usage, card_list = row
        rank_value = int(rank)
        usage_value = float(usage)
        deck = [card.strip() for card in card_list.split(",") if card.strip()]
        if (not name.strip() or not 1 <= rank_value <= 100 or
                not 0.0 <= usage_value <= 1.0 or len(deck) != 8 or len(set(deck)) != 8):
            raise ValueError("meta_decks.tsv contains an invalid deck prior row")

    _validate_asset_licenses(data, image_files, decks)
    return {
        "cards": len(cards), "combat_profiles": len(combat_keys),
        "visual_forms": len(visual_cards), "card_images": len(image_files),
        "meta_decks": len(decks),
    }


def refresh_snapshot(root: Path = ROOT) -> dict:
    root = Path(root)
    counts = validate_data_contents(root)
    files = {
        name: (_image_tree_sha256(root / "data" / "card_images") if name == "card_images"
               else sha256(root / "data" / name))
        for name in PINNED_FILES
    }
    manifest = {
        "format_version": 1,
        "snapshot_dates": {
            "card_roster": "2026-11-09",
            "combat_profiles": "2026-10-20",
            "opponent_deck_priors": None,
        },
        "counts": counts,
        "sources": {
            "card_roster": "clash-royale-data; Supercell November 2026 update notes; CRTool roster cross-check",
            "combat_profiles": "clash-royale-data / Clash Royale Wiki level-11 base-form snapshot",
            "opponent_deck_priors": "none; deterministic local heuristics and user-workspace learning only",
            "visual_catalog": "none bundled; runtime OCR-grounded local samples only",
        },
        "redistribution_review": {
            "status": "clean_default_release",
            "royaleapi_prior": "not_bundled; no redistribution permission was supplied",
            "user_supplied_card_art": "not_bundled; underlying artwork rights were not verified",
            "fandom_metadata": "CC-BY-SA-3.0 attribution and share-alike obligations apply",
        },
        "sha256": files,
    }
    target = root / "data" / "SNAPSHOT.json"
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def verify_snapshot(root: Path = ROOT) -> dict:
    root = Path(root)
    counts = validate_data_contents(root)
    try:
        manifest = json.loads((root / "data" / "SNAPSHOT.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError(f"data/SNAPSHOT.json is missing or invalid: {exc}") from exc
    if not isinstance(manifest, dict) or manifest.get("format_version") != 1:
        raise ValueError("unsupported data snapshot manifest format")
    if manifest.get("counts") != counts:
        raise ValueError("data snapshot record counts do not match the bundled data")
    expected = manifest.get("sha256")
    if not isinstance(expected, dict):
        raise ValueError("data snapshot SHA-256 table is missing")
    actual = {
        name: (_image_tree_sha256(root / "data" / "card_images") if name == "card_images"
               else sha256(root / "data" / name))
        for name in PINNED_FILES
    }
    if expected != actual:
        changed = sorted(name for name in PINNED_FILES if expected.get(name) != actual[name])
        raise ValueError(f"bundled data hash mismatch: {changed}")
    if manifest.get("redistribution_review", {}).get("status") != "clean_default_release":
        raise ValueError("data snapshot does not certify the clean default redistribution set")
    return manifest


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--refresh", action="store_true", help="refresh snapshot hashes after an intentional data update")
    args = parser.parse_args(argv)
    try:
        manifest = refresh_snapshot() if args.refresh else verify_snapshot()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"Data validation failed: {exc}", file=sys.stderr)
        return 2
    print("Data snapshots: OK" if not args.refresh else "Data snapshot hashes refreshed")
    print(json.dumps(manifest.get("counts", {}), ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
