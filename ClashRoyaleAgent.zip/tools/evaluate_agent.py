"""Aggregate labelled outcomes and verified actions from local battle replays.

This reports observed replay statistics only. It does not predict future win rate
or infer unrecorded match outcomes.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.replay import load_replay


def wilson_interval(successes: int, trials: int, z: float = 1.959963984540054):
    if trials <= 0:
        return None
    p = successes / trials
    denominator = 1.0 + z * z / trials
    center = (p + z * z / (2.0 * trials)) / denominator
    margin = z * math.sqrt((p * (1.0 - p) + z * z / (4.0 * trials)) / trials) / denominator
    return [round(max(0.0, center - margin), 4), round(min(1.0, center + margin), 4)]


def _safe_confidence(value) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return 0.0
    return result if math.isfinite(result) else 0.0


def evaluate_replays(paths: list[Path], *, min_result_confidence: float = 0.86) -> dict:
    if not 0.0 <= min_result_confidence <= 1.0:
        raise ValueError("min_result_confidence must be between 0 and 1")
    if not paths:
        raise ValueError("No replay files were supplied")

    match_rows = []
    result_counts: Counter[str] = Counter()
    card_actions: dict[str, Counter[str]] = defaultdict(Counter)
    opponent_groups: dict[str, Counter[str]] = defaultdict(Counter)
    errors = []
    for path in sorted((Path(item) for item in paths), key=lambda item: str(item).casefold()):
        try:
            events = load_replay(path)
        except Exception as exc:
            errors.append({"file": path.name, "error": str(exc)[:240]})
            continue
        end = next((event for event in reversed(events) if event.get("type") == "match_end"), {})
        result = end.get("result")
        confidence = _safe_confidence(end.get("result_confidence", 0.0))
        labelled = result in ("win", "loss", "draw") and confidence >= min_result_confidence
        if labelled:
            result_counts[str(result)] += 1
        else:
            result_counts["unlabelled"] += 1

        actions = [event for event in events if event.get("type") == "action"]
        for event in actions:
            key = str(event.get("card_key") or "unknown")[:64]
            status = str(event.get("status") or "unknown")
            if status not in ("verified", "sent_unverified", "rejected", "unknown"):
                status = "unknown"
            card_actions[key][status] += 1

        state_events = [event for event in events if event.get("type") == "state"]
        opponent_key = "unidentified"
        for event in reversed(state_events):
            state = event.get("_decoded_state")
            if state is None:
                continue
            if getattr(state, "opponent_deck_complete", False):
                confirmed = tuple(getattr(state, "opponent_deck_confirmed", ()) or ())
                if len(confirmed) == 8:
                    opponent_key = ",".join(sorted(confirmed))
                    break
        opponent_groups[opponent_key][str(result) if labelled else "unlabelled"] += 1
        match_rows.append({
            "file": path.name,
            "app_version": events[0].get("app_version"),
            "result": str(result) if labelled else None,
            "result_confidence": round(confidence, 4),
            "duration_seconds": round(max(0.0, _safe_confidence(end.get("elapsed_ms"))) / 1000.0, 2),
            "actions": len(actions),
            "verified_actions": sum(event.get("status") == "verified" for event in actions),
            "opponent_deck": opponent_key,
        })

    wins = result_counts["win"]
    losses = result_counts["loss"]
    draws = result_counts["draw"]
    decided = wins + losses
    labelled = wins + losses + draws
    total = len(match_rows) + len(errors)
    card_metrics = {}
    for key, counts in sorted(card_actions.items()):
        attempted = sum(counts.values())
        verified = counts["verified"]
        card_metrics[key] = {
            "attempted": attempted,
            "verified": verified,
            "sent_unverified": counts["sent_unverified"],
            "rejected": counts["rejected"],
            "unknown": counts["unknown"],
            "verified_rate": round(verified / attempted, 4) if attempted else None,
        }
    return {
        "replays_found": total,
        "replays_read": len(match_rows),
        "invalid_replays": len(errors),
        "result_confidence_threshold": min_result_confidence,
        "matches": {
            "labelled": labelled,
            "unlabelled_or_low_confidence": result_counts["unlabelled"],
            "wins": wins,
            "losses": losses,
            "draws": draws,
            "win_rate_excluding_draws": round(wins / decided, 4) if decided else None,
            "win_rate_wilson_95_excluding_draws": wilson_interval(wins, decided),
            "win_share_including_draws": round(wins / labelled, 4) if labelled else None,
            "result_label_coverage": round(labelled / max(1, len(match_rows)), 4)
            if match_rows else None,
        },
        "actions": {
            "total": sum(sum(item.values()) for item in card_actions.values()),
            "verified": sum(item["verified"] for item in card_actions.values()),
            "verified_rate": round(
                sum(item["verified"] for item in card_actions.values()) /
                max(1, sum(sum(item.values()) for item in card_actions.values())), 4
            ) if card_actions else None,
            "by_card": card_metrics,
        },
        "opponent_decks": {
            key: dict(counts) for key, counts in sorted(opponent_groups.items())
        },
        "match_rows": match_rows,
        "errors": errors,
        "limitations": [
            "Only replay outcomes explicitly labelled with sufficient confidence are counted.",
            "The interval describes this recorded sample; it is not a forecast or a guarantee of future win rate.",
            "Opponent-deck grouping is shown only when a replay recorded a complete, directly observed eight-card deck.",
            "A verified action means a measurable post-input state change, not proof that the tactical choice was optimal.",
        ],
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="a .crr.gz replay or folder containing replays")
    parser.add_argument("--min-result-confidence", type=float, default=0.86)
    parser.add_argument("--output", type=Path, help="optional JSON report destination")
    args = parser.parse_args(argv)
    paths = sorted(args.path.glob("*.crr.gz")) if args.path.is_dir() else [args.path]
    try:
        report = evaluate_replays(paths, min_result_confidence=args.min_result_confidence)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    rendered = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        output = args.output.expanduser().resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        temporary = output.with_suffix(output.suffix + ".tmp")
        try:
            temporary.write_text(rendered + "\n", encoding="utf-8")
            temporary.replace(output)
        finally:
            try:
                temporary.unlink()
            except OSError:
                pass
        print(f"Report: {output}")
    else:
        print(rendered)
    return 2 if report["invalid_replays"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
