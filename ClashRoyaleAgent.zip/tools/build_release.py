"""Generate and verify a deterministic source-complete Windows release ZIP."""
from __future__ import annotations

import argparse
import hashlib
import os
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST.sha256"
EXCLUDED_DIRS = {".git", ".venv", "__pycache__", "build", "dist"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".tmp", ".zip"}
ROOT_FILES = {
    "AGENTS202611241637.md", "ClashRoyale.exe", "ClashRoyale.py",
    "README.md", "THIRD_PARTY_NOTICES.md", "card_catalog.example.json",
    "build_windows.bat", "launcher_windows.go", "launcher_windows.build.json", "pyproject.toml",
    "requirements.txt", "requirements-build.txt",
}
ROOT_DIRS = {"core", "data", "tests", "tools"}
REQUIRED_TREE_FILES = {
    "core/__init__.py", "core/adb.py", "core/agent.py", "core/blackbox.py", "core/card_catalog.py",
    "core/config.py", "core/deck_manager.py", "core/episode.py", "core/navigation.py",
    "core/policy.py", "core/tactics.py", "core/tracking.py", "core/tactical_memory.py", "core/tactical_search.py", "core/ui.py", "core/native_ui.py",
    "core/runtime.py", "core/preflight.py", "core/planner.py", "core/tray.py",
    "core/vision.py", "core/ui_adaptive.py", "core/win32.py", "core/cards.py", "core/offline_ocr.py",
    "core/opponent.py", "core/dxgi.py", "core/combat.py", "core/semantics.py",
    "data/cards.tsv", "data/card_visual_catalog.json", "data/combat_profiles.tsv",
    "data/meta_decks.tsv", "data/README.md",
    "tests/test_core.py", "tests/test_new_features.py", "tests/test_adaptive.py",
    "tests/test_release.py", "tests/test_semantic_combat.py", "tests/test_tactical_upgrade.py",
    "tests/fixtures/adaptive_ui/labels.tsv",
    "tests/fixtures/adaptive_ui/01_loading.png", "tests/fixtures/adaptive_ui/02_loading.png",
    "tests/fixtures/adaptive_ui/03_loading.png", "tests/fixtures/adaptive_ui/04_home.png",
    "tests/fixtures/adaptive_ui/05_mode_select.png", "tests/fixtures/adaptive_ui/06_deck.png",
    "tests/fixtures/adaptive_ui/07_deck.png", "tests/fixtures/adaptive_ui/08_deck.png",
    "tests/fixtures/adaptive_ui/09_deck.png",
    "tests/fixtures/synthetic_battle/README.md",
    "tests/fixtures/synthetic_battle/labels.json",
    "tests/fixtures/synthetic_battle/01_battle_synthetic.png",
    "tools/build_release.py", "tools/build_card_catalog.py", "tools/build_card_image_catalog.py",
    "tools/replay_screenshots.py", "tools/benchmark_vision.py",
}
MAX_RELEASE_BYTES = 1_000_000_000


def verify_windows_x64_launcher(path: Path) -> None:
    """Reject a missing, malformed, 32-bit, or non-Windows launcher binary."""
    data = Path(path).read_bytes()
    if len(data) < 256 or data[:2] != b"MZ":
        raise SystemExit("ClashRoyale.exe is not a valid PE executable.")
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if pe_offset < 0x40 or pe_offset + 26 > len(data) or data[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise SystemExit("ClashRoyale.exe has an invalid PE header.")
    machine = struct.unpack_from("<H", data, pe_offset + 4)[0]
    optional_magic = struct.unpack_from("<H", data, pe_offset + 24)[0]
    if machine != 0x8664 or optional_magic != 0x20B:
        raise SystemExit("ClashRoyale.exe must be a Windows x64 PE32+ executable.")
    # The launcher is intentionally GUI-only; a console subsystem can flash a
    # terminal behind the UI and violates the one-click consumer experience.
    subsystem_offset = pe_offset + 24 + 68
    if subsystem_offset + 2 > len(data):
        raise SystemExit("ClashRoyale.exe has a truncated PE optional header.")
    subsystem = struct.unpack_from("<H", data, subsystem_offset)[0]
    if subsystem != 2:
        raise SystemExit("ClashRoyale.exe must use the Windows GUI subsystem.")


def payload_files() -> list[Path]:
    """Return only explicitly supported release files, never arbitrary workspace data."""
    files: list[Path] = []
    missing = [name for name in ROOT_FILES
               if (ROOT / name).is_symlink() or not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"Required release files are missing: {sorted(missing)}")
    for name in sorted(ROOT_FILES):
        path = ROOT / name
        files.append(path)
    missing_dirs = [name for name in ROOT_DIRS
                    if (ROOT / name).is_symlink() or not (ROOT / name).is_dir()]
    if missing_dirs:
        raise SystemExit(f"Required release source directories are missing: {sorted(missing_dirs)}")
    for directory in sorted(ROOT_DIRS):
        base = ROOT / directory
        for path in base.rglob("*"):
            if path.is_symlink() or not path.is_file():
                continue
            try:
                path.resolve().relative_to(ROOT.resolve())
            except ValueError:
                raise SystemExit(f"Release source escapes project root: {path}")
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED_DIRS for part in relative.parts):
                continue
            if path.suffix.lower() in EXCLUDED_SUFFIXES:
                continue
            files.append(path)
    found = {path.relative_to(ROOT).as_posix() for path in files}
    missing_tree_files = sorted(REQUIRED_TREE_FILES - found)
    if missing_tree_files:
        raise SystemExit(f"Required development source files are missing: {missing_tree_files}")
    return sorted(set(files), key=lambda item: item.relative_to(ROOT).as_posix().lower())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_launcher_record() -> None:
    """Record the exact launcher source/binary pair produced by a Go build.

    This allows Python-only rebuilds on machines without Go, while refusing to
    package a stale EXE after launcher_windows.go has changed.
    """
    source = ROOT / "launcher_windows.go"
    binary = ROOT / "ClashRoyale.exe"
    if not source.is_file() or not binary.is_file():
        raise SystemExit("Launcher source or executable is missing; cannot record build provenance.")
    record = {
        "format_version": 1,
        "target": "windows/amd64",
        "source_sha256": sha256(source),
        "binary_sha256": sha256(binary),
        "go_version": os.environ.get("CLASH_ROYALE_GO_VERSION", "unspecified")[:64],
        "build_flags": "-trimpath -s -w -H windowsgui -buildid=",
    }
    target = ROOT / "launcher_windows.build.json"
    import json
    target.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                       encoding="utf-8")


def verify_launcher_record() -> None:
    """Fail when the shipped launcher was not built from the bundled source."""
    import json
    target = ROOT / "launcher_windows.build.json"
    try:
        record = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError) as exc:
        raise SystemExit(f"Launcher build record is missing or invalid: {exc}") from exc
    expected = {
        "format_version": 1,
        "target": "windows/amd64",
        "source_sha256": sha256(ROOT / "launcher_windows.go"),
        "binary_sha256": sha256(ROOT / "ClashRoyale.exe"),
        "build_flags": "-trimpath -s -w -H windowsgui -buildid=",
    }
    for key, value in expected.items():
        if record.get(key) != value:
            raise SystemExit(
                f"Bundled launcher build record mismatch for {key}; rebuild ClashRoyale.exe "
                "from launcher_windows.go with Go 1.23+ before packaging."
            )
    if not isinstance(record.get("go_version"), str) or len(record["go_version"]) > 64:
        raise SystemExit("Launcher build record has an invalid Go version field.")


def write_manifest() -> None:
    lines = [
        f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}"
        for path in payload_files()
    ]
    MANIFEST.write_text("\n".join(lines) + "\n", encoding="utf-8")


def verify_manifest() -> None:
    expected = {}
    for line_number, line in enumerate(MANIFEST.read_text(encoding="utf-8").splitlines(), 1):
        try:
            digest, relative = line.split("  ", 1)
        except ValueError as exc:
            raise SystemExit(f"Malformed MANIFEST.sha256 line {line_number}.") from exc
        relative_path = Path(relative)
        if (len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest.lower())
                or relative_path.is_absolute() or ".." in relative_path.parts
                or relative in expected):
            raise SystemExit(f"Unsafe or duplicate MANIFEST.sha256 entry on line {line_number}.")
        expected[relative] = digest.lower()
    actual = {
        path.relative_to(ROOT).as_posix(): sha256(path)
        for path in payload_files()
    }
    if expected != actual:
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - set(expected))
        changed = sorted(key for key in set(expected) & set(actual) if expected[key] != actual[key])
        raise SystemExit(f"Manifest mismatch. missing={missing}, extra={extra}, changed={changed}")


def build_zip(output: Path) -> None:
    verify_manifest()
    verify_windows_x64_launcher(ROOT / "ClashRoyale.exe")
    verify_launcher_record()
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, strict_timestamps=False) as archive:
            entries = payload_files() + [MANIFEST]
            for path in sorted(entries, key=lambda item: item.relative_to(ROOT).as_posix().lower()):
                relative = path.relative_to(ROOT).as_posix()
                info = zipfile.ZipInfo(relative, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.flag_bits |= 0x800
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                                 compresslevel=9)
        os.replace(temp, output)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass
    if output.stat().st_size > MAX_RELEASE_BYTES:
        size = output.stat().st_size
        try:
            output.unlink()
        except OSError:
            pass
        raise SystemExit(f"Release ZIP exceeds 1,000,000,000 bytes: {size}")
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"ZIP integrity check failed at {bad}")
        expected_names = {path.relative_to(ROOT).as_posix() for path in payload_files()} | {MANIFEST.name}
        actual_names = set(archive.namelist())
        if actual_names != expected_names:
            raise SystemExit(
                f"ZIP file-list mismatch. missing={sorted(expected_names - actual_names)}, "
                f"extra={sorted(actual_names - expected_names)}"
            )
        if any(name.startswith("/") or ".." in Path(name).parts for name in actual_names):
            raise SystemExit("ZIP contains an unsafe path.")
    print(f"Release: {output}")
    print(f"Files: {len(payload_files()) + 1}")
    print(f"Bytes: {output.stat().st_size}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "ClashRoyaleAgent_v0.25.0.zip")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--refresh-launcher-record", action="store_true",
                        help="record the current launcher after rebuilding it with Go")
    parser.add_argument("--verify-launcher-record", action="store_true",
                        help="verify the bundled EXE matches launcher_windows.go")
    parser.add_argument("--allow-host-python", action="store_true",
                        help="development-only override for non-target build environments")
    args = parser.parse_args()

    if not args.allow_host_python:
        if (sys.version_info[:2] < (3, 10) or sys.version_info.releaselevel != "final"
                or struct.calcsize("P") != 8):
            raise SystemExit("Release build requires stable 64-bit Python 3.10 or newer.")
    if args.refresh_launcher_record:
        verify_windows_x64_launcher(ROOT / "ClashRoyale.exe")
        write_launcher_record()
        print("Launcher build record refreshed.")
        return
    if args.verify_launcher_record:
        verify_windows_x64_launcher(ROOT / "ClashRoyale.exe")
        verify_launcher_record()
        print("Launcher source/binary build record: OK")
        return
    if args.verify_only:
        verify_manifest()
        verify_windows_x64_launcher(ROOT / "ClashRoyale.exe")
        verify_launcher_record()
        print("MANIFEST.sha256, launcher record, and Windows x64 launcher: OK")
        return
    write_manifest()
    build_zip(args.output)


if __name__ == "__main__":
    main()
