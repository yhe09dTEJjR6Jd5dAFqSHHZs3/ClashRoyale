"""Generate and verify a deterministic source-complete Windows release ZIP."""
from __future__ import annotations

import argparse
import hashlib
import os
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST.sha256"
EXCLUDED_DIRS = {".git", ".venv", "__pycache__", "build", "dist"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".tmp", ".zip"}
ROOT_FILES = {
    "AGENTS202611240750.md", "ClashRoyale.exe", "ClashRoyale.py",
    "README.md", "card_catalog.example.json", "build_windows.bat", "launcher_windows.go",
    "pyproject.toml", "requirements.txt", "requirements-build.txt",
}
ROOT_DIRS = {"core", "tests", "tools"}
MAX_RELEASE_BYTES = 1_000_000_000


def payload_files() -> list[Path]:
    """Return only explicitly supported release files, never arbitrary workspace data."""
    files: list[Path] = []
    missing = [name for name in ROOT_FILES
               if (ROOT / name).is_symlink() or not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"Required release files are missing: {sorted(missing)}")
    for name in sorted(ROOT_FILES):
        path = ROOT / name
        files.append(path)
    for directory in sorted(ROOT_DIRS):
        base = ROOT / directory
        if base.is_symlink():
            raise SystemExit(f"Release source directory must not be a symlink: {base}")
        if not base.is_dir():
            continue
        for path in base.rglob("*"):
            if path.is_symlink() or not path.is_file():
                continue
            try:
                path.resolve().relative_to(ROOT.resolve())
            except ValueError:
                raise SystemExit(f"Release source escapes project root: {path}")
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED_DIRS for part in relative.parts):
                continue
            if path.suffix.lower() in EXCLUDED_SUFFIXES:
                continue
            files.append(path)
    return sorted(set(files), key=lambda item: item.relative_to(ROOT).as_posix().lower())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_manifest() -> None:
    lines = [
        f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}"
        for path in payload_files()
    ]
    MANIFEST.write_text("\n".join(lines) + "\n", encoding="utf-8")


def verify_manifest() -> None:
    expected = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        expected[relative] = digest
    actual = {
        path.relative_to(ROOT).as_posix(): sha256(path)
        for path in payload_files()
    }
    if expected != actual:
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - set(expected))
        changed = sorted(key for key in set(expected) & set(actual) if expected[key] != actual[key])
        raise SystemExit(f"Manifest mismatch. missing={missing}, extra={extra}, changed={changed}")


def build_zip(output: Path) -> None:
    verify_manifest()
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, strict_timestamps=False) as archive:
            entries = payload_files() + [MANIFEST]
            for path in sorted(entries, key=lambda item: item.relative_to(ROOT).as_posix().lower()):
                archive.write(path, path.relative_to(ROOT).as_posix())
        os.replace(temp, output)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass
    if output.stat().st_size > MAX_RELEASE_BYTES:
        size = output.stat().st_size
        try:
            output.unlink()
        except OSError:
            pass
        raise SystemExit(f"Release ZIP exceeds 1,000,000,000 bytes: {size}")
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"ZIP integrity check failed at {bad}")
        expected_names = {path.relative_to(ROOT).as_posix() for path in payload_files()} | {MANIFEST.name}
        actual_names = set(archive.namelist())
        if actual_names != expected_names:
            raise SystemExit(
                f"ZIP file-list mismatch. missing={sorted(expected_names - actual_names)}, "
                f"extra={sorted(actual_names - expected_names)}"
            )
        if any(name.startswith("/") or ".." in Path(name).parts for name in actual_names):
            raise SystemExit("ZIP contains an unsafe path.")
    print(f"Release: {output}")
    print(f"Files: {len(payload_files()) + 1}")
    print(f"Bytes: {output.stat().st_size}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "ClashRoyaleAgent_v0.7.0.zip")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--allow-host-python", action="store_true",
                        help="development-only override for non-target build environments")
    args = parser.parse_args()

    if not args.allow_host_python:
        if sys.version_info[:2] != (3, 15) or struct.calcsize("P") != 8:
            raise SystemExit("Release build requires 64-bit Python 3.15.")
    if args.verify_only:
        verify_manifest()
        print("MANIFEST.sha256: OK")
        return
    write_manifest()
    build_zip(args.output)


if __name__ == "__main__":
    main()
