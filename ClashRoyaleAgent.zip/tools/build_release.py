"""Generate and verify a deterministic source-complete Windows release ZIP."""
from __future__ import annotations

import argparse
import hashlib
import os
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST.sha256"
EXCLUDED_DIRS = {".git", ".venv", "__pycache__", "build", "dist"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".tmp", ".zip"}
ROOT_FILES = {
    "AGENTS202611241432.md", "ClashRoyale.exe", "ClashRoyale.py",
    "README.md", "card_catalog.example.json", "build_windows.bat", "launcher_windows.go",
    "pyproject.toml", "requirements.txt", "requirements-build.txt",
}
ROOT_DIRS = {"core", "tests", "tools"}
REQUIRED_TREE_FILES = {
    "core/__init__.py", "core/adb.py", "core/agent.py", "core/blackbox.py",
    "core/config.py", "core/deck_manager.py", "core/navigation.py",
    "core/policy.py", "core/tactics.py", "core/tracking.py", "core/ui.py", "core/native_ui.py",
    "core/vision.py", "core/win32.py",
    "tests/test_core.py", "tests/test_release.py", "tools/build_release.py",
    "tools/build_card_catalog.py", "tools/replay_screenshots.py",
}
MAX_RELEASE_BYTES = 1_000_000_000


def verify_windows_x64_launcher(path: Path) -> None:
    """Reject a missing, malformed, 32-bit, or non-Windows launcher binary."""
    data = Path(path).read_bytes()
    if len(data) < 256 or data[:2] != b"MZ":
        raise SystemExit("ClashRoyale.exe is not a valid PE executable.")
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if pe_offset < 0x40 or pe_offset + 26 > len(data) or data[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise SystemExit("ClashRoyale.exe has an invalid PE header.")
    machine = struct.unpack_from("<H", data, pe_offset + 4)[0]
    optional_magic = struct.unpack_from("<H", data, pe_offset + 24)[0]
    if machine != 0x8664 or optional_magic != 0x20B:
        raise SystemExit("ClashRoyale.exe must be a Windows x64 PE32+ executable.")
    # The launcher is intentionally GUI-only; a console subsystem can flash a
    # terminal behind the UI and violates the one-click consumer experience.
    subsystem_offset = pe_offset + 24 + 68
    if subsystem_offset + 2 > len(data):
        raise SystemExit("ClashRoyale.exe has a truncated PE optional header.")
    subsystem = struct.unpack_from("<H", data, subsystem_offset)[0]
    if subsystem != 2:
        raise SystemExit("ClashRoyale.exe must use the Windows GUI subsystem.")


def payload_files() -> list[Path]:
    """Return only explicitly supported release files, never arbitrary workspace data."""
    files: list[Path] = []
    missing = [name for name in ROOT_FILES
               if (ROOT / name).is_symlink() or not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"Required release files are missing: {sorted(missing)}")
    for name in sorted(ROOT_FILES):
        path = ROOT / name
        files.append(path)
    missing_dirs = [name for name in ROOT_DIRS
                    if (ROOT / name).is_symlink() or not (ROOT / name).is_dir()]
    if missing_dirs:
        raise SystemExit(f"Required release source directories are missing: {sorted(missing_dirs)}")
    for directory in sorted(ROOT_DIRS):
        base = ROOT / directory
        for path in base.rglob("*"):
            if path.is_symlink() or not path.is_file():
                continue
            try:
                path.resolve().relative_to(ROOT.resolve())
            except ValueError:
                raise SystemExit(f"Release source escapes project root: {path}")
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED_DIRS for part in relative.parts):
                continue
            if path.suffix.lower() in EXCLUDED_SUFFIXES:
                continue
            files.append(path)
    found = {path.relative_to(ROOT).as_posix() for path in files}
    missing_tree_files = sorted(REQUIRED_TREE_FILES - found)
    if missing_tree_files:
        raise SystemExit(f"Required development source files are missing: {missing_tree_files}")
    return sorted(set(files), key=lambda item: item.relative_to(ROOT).as_posix().lower())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_manifest() -> None:
    lines = [
        f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}"
        for path in payload_files()
    ]
    MANIFEST.write_text("\n".join(lines) + "\n", encoding="utf-8")


def verify_manifest() -> None:
    expected = {}
    for line_number, line in enumerate(MANIFEST.read_text(encoding="utf-8").splitlines(), 1):
        try:
            digest, relative = line.split("  ", 1)
        except ValueError as exc:
            raise SystemExit(f"Malformed MANIFEST.sha256 line {line_number}.") from exc
        relative_path = Path(relative)
        if (len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest.lower())
                or relative_path.is_absolute() or ".." in relative_path.parts
                or relative in expected):
            raise SystemExit(f"Unsafe or duplicate MANIFEST.sha256 entry on line {line_number}.")
        expected[relative] = digest.lower()
    actual = {
        path.relative_to(ROOT).as_posix(): sha256(path)
        for path in payload_files()
    }
    if expected != actual:
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - set(expected))
        changed = sorted(key for key in set(expected) & set(actual) if expected[key] != actual[key])
        raise SystemExit(f"Manifest mismatch. missing={missing}, extra={extra}, changed={changed}")


def build_zip(output: Path) -> None:
    verify_manifest()
    verify_windows_x64_launcher(ROOT / "ClashRoyale.exe")
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, strict_timestamps=False) as archive:
            entries = payload_files() + [MANIFEST]
            for path in sorted(entries, key=lambda item: item.relative_to(ROOT).as_posix().lower()):
                relative = path.relative_to(ROOT).as_posix()
                info = zipfile.ZipInfo(relative, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.flag_bits |= 0x800
                archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                                 compresslevel=9)
        os.replace(temp, output)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass
    if output.stat().st_size > MAX_RELEASE_BYTES:
        size = output.stat().st_size
        try:
            output.unlink()
        except OSError:
            pass
        raise SystemExit(f"Release ZIP exceeds 1,000,000,000 bytes: {size}")
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"ZIP integrity check failed at {bad}")
        expected_names = {path.relative_to(ROOT).as_posix() for path in payload_files()} | {MANIFEST.name}
        actual_names = set(archive.namelist())
        if actual_names != expected_names:
            raise SystemExit(
                f"ZIP file-list mismatch. missing={sorted(expected_names - actual_names)}, "
                f"extra={sorted(actual_names - expected_names)}"
            )
        if any(name.startswith("/") or ".." in Path(name).parts for name in actual_names):
            raise SystemExit("ZIP contains an unsafe path.")
    print(f"Release: {output}")
    print(f"Files: {len(payload_files()) + 1}")
    print(f"Bytes: {output.stat().st_size}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "ClashRoyaleAgent_v0.14.0.zip")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--allow-host-python", action="store_true",
                        help="development-only override for non-target build environments")
    args = parser.parse_args()

    if not args.allow_host_python:
        if sys.version_info[:2] != (3, 15) or struct.calcsize("P") != 8:
            raise SystemExit("Release build requires 64-bit Python 3.15.")
    if args.verify_only:
        verify_manifest()
        verify_windows_x64_launcher(ROOT / "ClashRoyale.exe")
        print("MANIFEST.sha256 and Windows x64 launcher: OK")
        return
    write_manifest()
    build_zip(args.output)


if __name__ == "__main__":
    main()
