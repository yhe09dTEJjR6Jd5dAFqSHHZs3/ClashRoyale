"""Inspect and deterministically validate local .crr.gz battle-state replays."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.replay import load_replay, replay_state_hashes


def inspect(path: Path) -> dict:
    events = load_replay(path)
    start = events[0]
    end = next((event for event in reversed(events) if event.get("type") == "match_end"), {})
    states = [event for event in events if event.get("type") == "state"]
    actions = [event for event in events if event.get("type") == "action"]
    decisions = [event for event in events if event.get("type") == "decision"]
    hashes = list(replay_state_hashes(events))
    digest = hashlib.sha256("".join(hashes).encode("ascii")).hexdigest()
    return {
        "file": path.name,
        "format_version": start.get("format_version"),
        "app_version": start.get("app_version"),
        "started_local": start.get("started_local"),
        "states": len(states),
        "decisions": len(decisions),
        "actions": len(actions),
        "verified_actions": sum(event.get("status") == "verified" for event in actions),
        "rejected_actions": sum(event.get("status") == "rejected" for event in actions),
        "result": end.get("result"),
        "result_confidence": end.get("result_confidence", 0.0),
        "duration_seconds": round(float(end.get("elapsed_ms", 0.0)) / 1000.0, 2),
        "state_snapshots": len(hashes),
        "state_digest_sha256": digest,
        "deterministic_state_replay": True,
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="a replay file or a folder containing *.crr.gz")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    args = parser.parse_args(argv)
    paths = sorted(args.path.glob("*.crr.gz")) if args.path.is_dir() else [args.path]
    if not paths:
        parser.error("no .crr.gz replay files were found")
    results = []
    for path in paths:
        try:
            results.append(inspect(path))
        except (OSError, ValueError) as exc:
            print(f"{path}: replay validation failed: {exc}", file=sys.stderr)
            return 2
    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for item in results:
            print(
                f"{item['file']}: states={item['states']} decisions={item['decisions']} "
                f"actions={item['actions']} verified={item['verified_actions']} "
                f"result={item['result'] or 'unlabelled'} "
                f"duration={item['duration_seconds']:.2f}s deterministic=OK"
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
