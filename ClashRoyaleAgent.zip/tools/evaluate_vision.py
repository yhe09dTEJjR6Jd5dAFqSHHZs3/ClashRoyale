"""Evaluate semantic troop identity against manually labelled real battle frames.

Labels use normalized bounding boxes in original screenshot coordinates:
{
  "version": 1,
  "frames": {
    "battle_001.png": {"units": [
      {"team":"enemy", "card_key":"hog-rider", "form":"base",
       "bbox":[0.42,0.30,0.54,0.43]}
    ]}
  }
}
The evaluator never trains from its test labels; supply an existing, locally
learned unit_visual_profiles.json with --profiles to measure recognition.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import statistics
import sys
import time
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.adb import decode_android_png
from core.cards import CardDatabase
from core.combat import CombatDatabase
from core.semantics import SemanticBattleRecognizer
from core.tracking import TemporalBattleTracker
from core.vision import analyze_frame


def _valid_box(value) -> tuple[float, float, float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise ValueError("bbox must contain four normalized coordinates")
    box = tuple(float(item) for item in value)
    if (not all(math.isfinite(item) for item in box) or
            not (0.0 <= box[0] < box[2] <= 1.0 and 0.0 <= box[1] < box[3] <= 1.0)):
        raise ValueError("bbox coordinates must be normalized and ordered")
    return box


def load_ground_truth(path: Path, image_names: set[str], database: CardDatabase) -> dict[str, list[dict]]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or raw.get("version") != 1 or not isinstance(raw.get("frames"), dict):
        raise ValueError("labels file must contain version=1 and a frames object")
    result = {}
    for filename, frame_data in raw["frames"].items():
        if not isinstance(filename, str) or Path(filename).name != filename:
            raise ValueError(f"invalid frame filename: {filename!r}")
        if filename not in image_names:
            raise ValueError(f"label references missing screenshot: {filename}")
        if not isinstance(frame_data, dict) or not isinstance(frame_data.get("units", []), list):
            raise ValueError(f"{filename}: units must be an array")
        units = []
        for item in frame_data.get("units", []):
            if not isinstance(item, dict):
                raise ValueError(f"{filename}: each unit label must be an object")
            team = item.get("team")
            key = item.get("card_key")
            form = item.get("form", "base")
            if team not in ("enemy", "friendly") or database.get(key) is None:
                raise ValueError(f"{filename}: invalid team or card_key")
            if form not in ("base", "evolution", "hero", "champion"):
                raise ValueError(f"{filename}: invalid card form")
            if form not in database.get(key).available_forms:
                raise ValueError(f"{filename}: {key} does not support form {form}")
            units.append({"team": team, "card_key": key, "form": form,
                          "bbox": _valid_box(item.get("bbox"))})
        result[filename] = units
    return result


def match_units(expected: list[dict], predicted: list[dict], max_distance: float = 0.065) -> dict:
    """Greedy one-to-one center-distance matching with exact semantic labels."""
    pairs = []
    for expected_index, truth in enumerate(expected):
        x0, y0, x1, y1 = truth["bbox"]
        tx, ty = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        for predicted_index, item in enumerate(predicted):
            distance = math.hypot(tx - item["x"], ty - item["y"])
            if distance <= max_distance:
                pairs.append((distance, expected_index, predicted_index))
    pairs.sort()
    used_expected: set[int] = set()
    used_predicted: set[int] = set()
    true_positive = 0
    misclassified = 0
    matched = []
    for _distance, expected_index, predicted_index in pairs:
        if expected_index in used_expected or predicted_index in used_predicted:
            continue
        used_expected.add(expected_index)
        used_predicted.add(predicted_index)
        truth, item = expected[expected_index], predicted[predicted_index]
        correct = (truth["team"], truth["card_key"], truth["form"]) == (
            item["team"], item["card_key"], item["form"])
        if correct:
            true_positive += 1
        else:
            misclassified += 1
        matched.append({"expected_index": expected_index,
                        "predicted_index": predicted_index, "correct": correct})
    false_positive = len(predicted) - true_positive
    false_negative = len(expected) - true_positive
    return {
        "tp": true_positive, "fp": false_positive, "fn": false_negative,
        "misclassified_localizations": misclassified,
        "matched": matched,
        "unmatched_expected": sorted(set(range(len(expected))) - used_expected),
        "unmatched_predicted": sorted(set(range(len(predicted))) - used_predicted),
    }


def evaluate_directory(input_dir: Path, labels_path: Path, *, profiles_path: Path | None = None,
                       max_width: int = 960, max_distance: float = 0.065) -> dict:
    input_dir = Path(input_dir).resolve()
    if not input_dir.is_dir():
        raise OSError(f"screenshot directory does not exist: {input_dir}")
    if not math.isfinite(max_distance) or not 0.01 <= max_distance <= 0.25:
        raise ValueError("max_distance must be between 0.01 and 0.25")
    paths = sorted(input_dir.glob("*.png"), key=lambda item: item.name.casefold())
    if not paths:
        raise ValueError("no PNG screenshots were found")
    cards = CardDatabase()
    labels = load_ground_truth(labels_path, {path.name for path in paths}, cards)
    combat = CombatDatabase(card_database=cards)
    recognizer = SemanticBattleRecognizer(
        profiles_path or (input_dir / ".read-only-no-profiles.json"), cards, combat,
    )
    tracker = TemporalBattleTracker()
    totals = Counter()
    per_card: dict[str, Counter[str]] = defaultdict(Counter)
    latencies = []
    frame_rows = []
    unlabelled_images = []
    for index, path in enumerate(paths):
        if path.name not in labels:
            unlabelled_images.append(path.name)
            continue
        started = time.perf_counter()
        frame, native_size = decode_android_png(path.read_bytes(), max_width=max_width)
        state = analyze_frame(frame)
        now = index * 0.12
        state = tracker.update(state, now=now)
        state = recognizer.observe(state, now=now)
        viewport = state.viewport or (0.0, 0.0, 1.0, 1.0)
        predicted = []
        for unit in (*state.semantic_enemy_units, *state.semantic_friendly_units):
            predicted.append({
                "team": unit.team, "card_key": unit.card_key, "form": unit.form,
                "x": viewport[0] + unit.x * (viewport[2] - viewport[0]),
                "y": viewport[1] + unit.y * (viewport[3] - viewport[1]),
                "confidence": float(unit.confidence),
            })
        expected = labels.get(path.name, [])
        metrics = match_units(expected, predicted, max_distance=max_distance)
        totals.update({key: metrics[key] for key in ("tp", "fp", "fn", "misclassified_localizations")})
        for item in expected:
            per_card[f"{item['team']}:{item['card_key']}:{item['form']}"]["expected"] += 1
        for item in predicted:
            per_card[f"{item['team']}:{item['card_key']}:{item['form']}"]["predicted"] += 1
        for pair in metrics["matched"]:
            truth = expected[pair["expected_index"]]
            prediction = predicted[pair["predicted_index"]]
            if pair["correct"]:
                per_card[f"{truth['team']}:{truth['card_key']}:{truth['form']}"]["tp"] += 1
            else:
                per_card[f"{truth['team']}:{truth['card_key']}:{truth['form']}"]["fn"] += 1
                per_card[f"{prediction['team']}:{prediction['card_key']}:{prediction['form']}"]["fp"] += 1
        for item_index in metrics["unmatched_expected"]:
            item = expected[item_index]
            per_card[f"{item['team']}:{item['card_key']}:{item['form']}"]["fn"] += 1
        for item_index in metrics["unmatched_predicted"]:
            item = predicted[item_index]
            per_card[f"{item['team']}:{item['card_key']}:{item['form']}"]["fp"] += 1
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        latencies.append(elapsed_ms)
        frame_rows.append({
            "file": path.name, "native_size": list(native_size),
            "expected_units": len(expected), "predicted_units": len(predicted),
            **{key: metrics[key] for key in ("tp", "fp", "fn", "misclassified_localizations")},
            "latency_ms": round(elapsed_ms, 3),
        })

    precision = totals["tp"] / (totals["tp"] + totals["fp"]) if totals["tp"] + totals["fp"] else None
    recall = totals["tp"] / (totals["tp"] + totals["fn"]) if totals["tp"] + totals["fn"] else None
    f1 = (2 * precision * recall / (precision + recall)
          if precision is not None and recall is not None and precision + recall else None)
    for item in per_card.values():
        card_precision = item["tp"] / item["predicted"] if item["predicted"] else None
        card_recall = item["tp"] / item["expected"] if item["expected"] else None
        card_f1 = (2 * card_precision * card_recall / (card_precision + card_recall)
                   if card_precision is not None and card_recall is not None and
                   card_precision + card_recall else None)
        item["precision"] = round(card_precision, 4) if card_precision is not None else None
        item["recall"] = round(card_recall, 4) if card_recall is not None else None
        item["f1"] = round(card_f1, 4) if card_f1 is not None else None
    return {
        "images": len(paths), "labelled_images": len(labels),
        "unlabelled_images_skipped": sorted(unlabelled_images),
        "prototype_file": str(profiles_path) if profiles_path else None,
        "prototype_count": len(recognizer.prototypes),
        "matching_center_distance": max_distance,
        "units": {
            **dict(totals),
            "precision": round(precision, 4) if precision is not None else None,
            "recall": round(recall, 4) if recall is not None else None,
            "f1": round(f1, 4) if f1 is not None else None,
        },
        "per_card_support": {key: dict(value) for key, value in sorted(per_card.items())},
        "latency_ms": {
            "mean": round(statistics.fmean(latencies), 3) if latencies else 0.0,
            "p95": round(sorted(latencies)[min(len(latencies) - 1, int((len(latencies) - 1) * 0.95))], 3)
            if latencies else 0.0,
        },
        "frames": frame_rows,
        "limitations": [
            "Labels must be manually verified and representative of real matches, resolutions, effects and occlusion.",
            "This evaluates learned semantic unit labels only; it does not validate card-in-hand OCR, elixir, health, opponent deck or tactical choices.",
            "The evaluator never learns from the test labels. Recognition requires independently learned profiles with at least three samples.",
            "No real battle screenshots are bundled in this release; synthetic UI fixtures are not accuracy evidence.",
        ],
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="real battle PNG frame directory")
    parser.add_argument("--labels", type=Path, required=True, help="manual labels JSON")
    parser.add_argument("--profiles", type=Path, help="existing local unit_visual_profiles.json")
    parser.add_argument("--output", type=Path, required=True, help="JSON report destination")
    parser.add_argument("--max-width", type=int, default=960)
    parser.add_argument("--max-distance", type=float, default=0.065)
    args = parser.parse_args(argv)
    report = evaluate_directory(args.input, args.labels, profiles_path=args.profiles,
                                max_width=args.max_width, max_distance=args.max_distance)
    output = args.output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    try:
        temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temporary.replace(output)
    finally:
        try:
            temporary.unlink()
        except OSError:
            pass
    print(f"Frames: {report['images']} | prototypes: {report['prototype_count']}")
    print(f"Unit precision/recall/F1: {report['units']['precision']} / {report['units']['recall']} / {report['units']['f1']}")
    print(f"Report: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
