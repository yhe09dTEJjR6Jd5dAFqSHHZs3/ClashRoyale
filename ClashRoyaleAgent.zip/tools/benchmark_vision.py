"""Offline, dependency-free replay benchmark for the local agent pipeline.

Example:
    python tools/benchmark_vision.py tests/fixtures/adaptive_ui --loops 5

The report separates decoding, vision, tracking, semantic matching, opponent
inference, card profiling, and policy/placement decision latency. It does not
perform live Windows capture, OCR, game input, or real-game win-rate testing.
"""
from __future__ import annotations

import argparse
import json
import platform
import statistics
from types import SimpleNamespace
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.adb import decode_android_png
from core.cards import CardDatabase
from core.combat import CombatDatabase, CombatSimulator
from core.deck_manager import DeckManager
from core.opponent import OpponentCycleTracker, OpponentDeckInferencer, OpponentElixirTracker
from core.policy import LocalLearner
from core.semantics import SemanticBattleRecognizer
from core.tactical_memory import TacticalMemory
from core.tactical_search import SearchAction, TacticalSearch
from core.tracking import TemporalBattleTracker
from core.vision import Scene, analyze_frame


def percentile(values: list[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, int(round((len(ordered) - 1) * fraction))))
    return round(ordered[index], 3)


def synthetic_tactical_search_smoke(cards: CardDatabase) -> dict:
    """Exercise the search algorithm with a clearly synthetic, verified hand.

    This is deliberately separate from frame-derived pipeline statistics: a
    synthetic hand must never be presented as OCR/vision recognition evidence.
    """
    hand = ("ice-spirit", "hog-rider", "musketeer", "fireball")
    costs = (1.0, 4.0, 4.0, 4.0)
    actions = []
    for index, key in enumerate(hand):
        roles = tuple(sorted(cards.roles_for(key)))
        for lane in (0, 1):
            actions.append(SearchAction(
                card=index, lane=lane, features=[],
                base_score=0.20 + 0.015 * index - 0.01 * lane,
                card_key=key, form="base", level=11,
                cost=costs[index], roles=roles,
            ))
    state = SimpleNamespace(
        elixir=10.0, left_threat=0.42, right_threat=0.26,
        left_support=0.10, right_support=0.12,
        opponent_deck_candidates=(), opponent_deck_candidate_confidences=(),
        opponent_deck_confirmed=(), opponent_deck_confidence=0.0,
        opponent_elixir_confidence=0.0, opponent_elixir_upper=10.0,
    )
    search = TacticalSearch()
    started = time.perf_counter()
    result = search.choose(state, actions, card_database=cards,
                           elapsed_seconds=35.0, time_budget_ms=search.MAX_SEARCH_MS)
    wall_ms = (time.perf_counter() - started) * 1000.0
    return {
        "synthetic_only": True,
        "verified_hand_fixture": list(hand),
        "calls": search.calls,
        "result": result is not None,
        "nodes": int(search.last_summary.get("nodes", 0) or 0),
        "depth": int(search.last_summary.get("depth", 0) or 0),
        "elapsed_ms": round(wall_ms, 3),
        "budget_ms": search.MAX_SEARCH_MS,
    }


def benchmark_frames(paths: list[Path], *, loops: int = 1, max_width: int = 960,
                     warmup_frames: int = 1) -> dict:
    if not paths:
        raise ValueError("No PNG frames were supplied.")
    if loops < 1 or max_width < 120 or warmup_frames < 0:
        raise ValueError("loops must be >=1, max_width >=120, and warmup_frames >=0")

    payloads = [(path.name, path.read_bytes()) for path in paths]
    # Benchmarks must not leave model/profile artifacts in the source tree.
    scratch_manager = tempfile.TemporaryDirectory(prefix="clash-royale-benchmark-")
    scratch = Path(scratch_manager.name)
    cards = CardDatabase()
    combat_database = CombatDatabase(card_database=cards)
    combat_simulator = CombatSimulator(combat_database, cards)
    tracker = TemporalBattleTracker()
    semantic = SemanticBattleRecognizer(
        scratch / "unit-profiles.json", cards, combat_database,
    )
    opponent = OpponentCycleTracker(cards)
    opponent_elixir = OpponentElixirTracker(cards)
    deck_inferencer = OpponentDeckInferencer(cards)
    deck_manager = DeckManager(
        scratch / "card-profiles.json",
        catalog_path=scratch / "card-catalog.json",
        card_database=cards,
        bundled_catalog_path=ROOT / "data" / "card_visual_catalog.json",
    )
    learner = LocalLearner(scratch / "model.json")
    tactical_memory = TacticalMemory(scratch / "tactical-memory.json")
    tactical_search = TacticalSearch()
    samples: dict[str, list[float]] = {
        "decode": [], "vision": [], "tracking": [], "semantic": [],
        "opponent": [], "card_profile": [], "decision": [], "total": [],
    }
    scenes: dict[str, int] = {}
    hands_detected = 0
    battle_frames = 0
    decision_calls = 0
    choices = 0
    tactical_search_calls = 0
    tactical_search_results = 0
    tactical_search_nodes = 0
    tactical_search_budget_hits = 0
    tactical_search_latencies: list[float] = []
    semantic_enemy_observations = 0
    semantic_friendly_observations = 0
    total_frames = 0
    warmups = 0
    base_time = time.monotonic()

    for loop_index in range(loops):
        for frame_index, (_name, payload) in enumerate(payloads):
            start = time.perf_counter()
            stage = time.perf_counter()
            frame, _metadata = decode_android_png(payload, max_width=max_width)
            decode_ms = (time.perf_counter() - stage) * 1000.0

            stage = time.perf_counter()
            state = analyze_frame(frame)
            vision_ms = (time.perf_counter() - stage) * 1000.0

            replay_now = base_time + (loop_index * len(payloads) + frame_index) * 0.12
            stage = time.perf_counter()
            state = tracker.update(state, now=replay_now)
            tracking_ms = (time.perf_counter() - stage) * 1000.0

            stage = time.perf_counter()
            state = semantic.observe(state, now=replay_now)
            semantic_ms = (time.perf_counter() - stage) * 1000.0

            stage = time.perf_counter()
            state = opponent.observe(state, now=replay_now)
            state = opponent_elixir.observe(state, opponent.history, now=replay_now)
            state = deck_inferencer.observe(state, opponent.history)
            opponent_ms = (time.perf_counter() - stage) * 1000.0

            stage = time.perf_counter()
            state = deck_manager.observe(state)
            card_profile_ms = (time.perf_counter() - stage) * 1000.0

            decision_ms = 0.0
            search_calls_delta = 0
            search_summary = None
            is_battle = state.scene is Scene.BATTLE and state.battle_detected
            choice = None
            if is_battle:
                stage = time.perf_counter()
                calls_before = tactical_search.calls
                choice = learner.choose(
                    state, (loop_index * len(payloads) + frame_index) * 0.12,
                    combat_simulator=combat_simulator, card_database=cards,
                    tactical_search=tactical_search, tactical_memory=tactical_memory,
                )
                decision_ms = (time.perf_counter() - stage) * 1000.0
                search_calls_delta = tactical_search.calls - calls_before
                if search_calls_delta:
                    search_summary = dict(tactical_search.last_summary)

            total_ms = (time.perf_counter() - start) * 1000.0
            if loop_index == 0 and frame_index < warmup_frames:
                warmups += 1
                continue
            if is_battle:
                battle_frames += 1
                semantic_enemy_observations += len(state.semantic_enemy_units)
                semantic_friendly_observations += len(state.semantic_friendly_units)
                decision_calls += 1
                if choice is not None:
                    choices += 1
                tactical_search_calls += search_calls_delta
                if search_summary is not None:
                    tactical_search_nodes += int(search_summary.get("nodes", 0) or 0)
                    tactical_search_latencies.append(float(search_summary.get("elapsed_ms", 0.0) or 0.0))
                    if tactical_search.last_result is not None:
                        tactical_search_results += 1
                    if search_summary.get("budget_exhausted"):
                        tactical_search_budget_hits += 1
            samples["decode"].append(decode_ms)
            samples["vision"].append(vision_ms)
            samples["tracking"].append(tracking_ms)
            samples["semantic"].append(semantic_ms)
            samples["opponent"].append(opponent_ms)
            samples["card_profile"].append(card_profile_ms)
            if is_battle:
                samples["decision"].append(decision_ms)
            samples["total"].append(total_ms)
            total_frames += 1
            scenes[state.scene.value] = scenes.get(state.scene.value, 0) + 1
            if len(state.card_bounds) == 4:
                hands_detected += 1

    def summary(values: list[float]) -> dict:
        return {
            "samples": len(values),
            "p50_ms": percentile(values, 0.50),
            "p95_ms": percentile(values, 0.95),
            "mean_ms": round(statistics.fmean(values), 3) if values else 0.0,
        }

    total_seconds = sum(samples["total"]) / 1000.0
    report = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "input_frames": len(paths),
        "loops": loops,
        "warmup_frames": warmups,
        "measured_frames": total_frames,
        "battle_frames": battle_frames,
        "decision_calls": decision_calls,
        "decisions_with_playable_choice": choices,
        "tactical_search": {
            "calls": tactical_search_calls,
            "results": tactical_search_results,
            "nodes_total": tactical_search_nodes,
            "budget_exhausted_calls": tactical_search_budget_hits,
            "latency_ms": summary(tactical_search_latencies),
            "budget_ms": tactical_search.MAX_SEARCH_MS,
            "last_summary": dict(tactical_search.last_summary),
        },
        "synthetic_tactical_search_smoke": synthetic_tactical_search_smoke(cards),
        "tactical_learning": tactical_memory.summary(),
        "semantic_observations": {
            "enemy_units": semantic_enemy_observations,
            "friendly_units": semantic_friendly_observations,
        },
        "latency": {name: summary(values) for name, values in samples.items()},
        "measured_fps": round(total_frames / max(0.001, total_seconds), 2),
        "scene_counts": scenes,
        "four_slot_hand_rate": round(hands_detected / max(1, total_frames), 4),
        "limitations": [
            "Recorded PNG replay only; live Windows capture, OCR, accessibility, and input latency are excluded.",
            "Policy/placement timing is measured only on frames classified as battles.",
            "Semantic identity quality requires manually labelled, representative real-game battle replays.",
            "Frame-derived tactical search can be zero when no verified playable hand is visible; synthetic_tactical_search_smoke separately exercises the algorithm and is not image-recognition evidence.",
            "This benchmark does not measure win rate or prove top-player-level strategy.",
        ],
    }
    scratch_manager.cleanup()
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="directory containing PNG frames")
    parser.add_argument("--loops", type=int, default=1)
    parser.add_argument("--max-width", type=int, default=960)
    parser.add_argument("--warmup-frames", type=int, default=1)
    parser.add_argument("--output", type=Path, help="optional JSON output path")
    args = parser.parse_args()
    paths = sorted(path for path in args.input.glob("*.png") if path.is_file())
    if not paths:
        parser.error(f"No PNG frames found in {args.input}")
    result = benchmark_frames(paths, loops=args.loops, max_width=args.max_width,
                              warmup_frames=args.warmup_frames)
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
