"""Offline, dependency-free benchmark for capture decoding and vision stages.

Example:
    python tools/benchmark_vision.py tests/fixtures/adaptive_ui --loops 5

The tool reports latency percentiles separately so a vision change cannot hide
behind aggregate FPS. It does not send input to a game or require a model.
"""
from __future__ import annotations

import argparse
import json
import platform
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.adb import decode_android_png
from core.cards import CardDatabase
from core.opponent import OpponentCycleTracker
from core.tracking import TemporalBattleTracker
from core.vision import analyze_frame


def percentile(values: list[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, int(round((len(ordered) - 1) * fraction))))
    return round(ordered[index], 3)


def benchmark_frames(paths: list[Path], *, loops: int = 1, max_width: int = 960,
                     warmup_frames: int = 1) -> dict:
    if not paths:
        raise ValueError("No PNG frames were supplied.")
    if loops < 1 or max_width < 120 or warmup_frames < 0:
        raise ValueError("loops must be >=1, max_width >=120, and warmup_frames >=0")

    payloads = [(path.name, path.read_bytes()) for path in paths]
    tracker = TemporalBattleTracker()
    opponent = OpponentCycleTracker(CardDatabase())
    samples: dict[str, list[float]] = {
        "decode": [], "vision": [], "tracking": [], "total": [],
    }
    scenes: dict[str, int] = {}
    hands_detected = 0
    total_frames = 0
    warmups = 0

    for loop_index in range(loops):
        for frame_index, (_name, payload) in enumerate(payloads):
            start = time.perf_counter()
            stage = time.perf_counter()
            frame, _metadata = decode_android_png(payload, max_width=max_width)
            decode_ms = (time.perf_counter() - stage) * 1000.0

            stage = time.perf_counter()
            state = analyze_frame(frame)
            vision_ms = (time.perf_counter() - stage) * 1000.0

            stage = time.perf_counter()
            state = tracker.update(state)
            state = opponent.observe(state)
            tracking_ms = (time.perf_counter() - stage) * 1000.0
            total_ms = (time.perf_counter() - start) * 1000.0

            if loop_index == 0 and frame_index < warmup_frames:
                warmups += 1
                continue
            samples["decode"].append(decode_ms)
            samples["vision"].append(vision_ms)
            samples["tracking"].append(tracking_ms)
            samples["total"].append(total_ms)
            total_frames += 1
            scenes[state.scene.value] = scenes.get(state.scene.value, 0) + 1
            if len(state.card_bounds) == 4:
                hands_detected += 1

    def summary(values: list[float]) -> dict:
        return {
            "p50_ms": percentile(values, 0.50),
            "p95_ms": percentile(values, 0.95),
            "mean_ms": round(statistics.fmean(values), 3) if values else 0.0,
        }

    total_seconds = sum(samples["total"]) / 1000.0
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "input_frames": len(paths),
        "loops": loops,
        "warmup_frames": warmups,
        "measured_frames": total_frames,
        "latency": {name: summary(values) for name, values in samples.items()},
        "measured_fps": round(total_frames / max(0.001, total_seconds), 2),
        "scene_counts": scenes,
        "four_slot_hand_rate": round(hands_detected / max(1, total_frames), 4),
        "note": "Synthetic/recorded frame benchmark only; not a real-game win-rate test.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="directory containing PNG frames")
    parser.add_argument("--loops", type=int, default=1)
    parser.add_argument("--max-width", type=int, default=960)
    parser.add_argument("--warmup-frames", type=int, default=1)
    parser.add_argument("--output", type=Path, help="optional JSON output path")
    args = parser.parse_args()
    paths = sorted(path for path in args.input.glob("*.png") if path.is_file())
    if not paths:
        parser.error(f"No PNG frames found in {args.input}")
    result = benchmark_frames(paths, loops=args.loops, max_width=args.max_width,
                              warmup_frames=args.warmup_frames)
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
