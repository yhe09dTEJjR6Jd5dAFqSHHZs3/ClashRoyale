"""Build a local card catalog from manually labelled battle screenshots.

No external OCR, model, network request, or third-party package is used. The
operator supplies screenshots and a small JSON file with the four visible card
labels for each screenshot. Only fingerprints/descriptors produced by the same
runtime feature extractor are written to the catalog.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.adb import decode_android_png
from core.vision import analyze_frame

ALLOWED_ROLES = {
    "win_condition", "spell", "air_defense", "building", "tank_killer",
    "swarm", "support", "cycle", "tank", "ranged", "melee",
}
MAX_LABEL_BYTES = 2_000_000
MAX_OUTPUT_CARDS = 512


def validate_card_metadata(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError("每张卡牌标注必须是 JSON 对象。")
    name = raw.get("name")
    cost = raw.get("cost")
    roles = raw.get("roles")
    level = raw.get("level", 1)
    owned = raw.get("owned", True)
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 80:
        raise ValueError("卡牌 name 必须是 1–80 个字符的非空字符串。")
    if isinstance(cost, bool) or not isinstance(cost, (int, float)) or not math.isfinite(float(cost)) or not 1 <= float(cost) <= 10:
        raise ValueError(f"卡牌 {name!r} 的 cost 必须在 1–10 之间。")
    if not isinstance(roles, list) or not roles or any(role not in ALLOWED_ROLES for role in roles):
        raise ValueError(f"卡牌 {name!r} 必须提供有效的 roles 列表。")
    if isinstance(level, bool) or not isinstance(level, (int, float)) or not math.isfinite(float(level)) or not 1 <= float(level) <= 16:
        raise ValueError(f"卡牌 {name!r} 的 level 必须在 1–16 之间。")
    if not isinstance(owned, bool):
        raise ValueError(f"卡牌 {name!r} 的 owned 必须为布尔值。")
    return {
        "name": name.strip(),
        "cost": float(cost),
        "roles": sorted(set(roles)),
        "level": float(level),
        "owned": owned,
    }


def build_catalog(screenshot_dir: Path, labels_path: Path) -> dict[str, Any]:
    screenshot_dir = Path(screenshot_dir).resolve()
    labels_path = Path(labels_path).resolve()
    if not screenshot_dir.is_dir():
        raise OSError(f"截图目录不存在：{screenshot_dir}")
    if labels_path.stat().st_size > MAX_LABEL_BYTES:
        raise ValueError("标注 JSON 超过 2 MB。")
    labels = json.loads(labels_path.read_text(encoding="utf-8"))
    if not isinstance(labels, dict) or not labels:
        raise ValueError("标注 JSON 必须是非空对象，键为 PNG 文件名。")

    catalog: dict[str, dict[str, Any]] = {}
    for filename, card_labels in sorted(labels.items()):
        if (not isinstance(filename, str) or Path(filename).name != filename or
                Path(filename).suffix.lower() != ".png"):
            raise ValueError(f"不安全或非 PNG 截图文件名：{filename!r}")
        if not isinstance(card_labels, list) or len(card_labels) != 4:
            raise ValueError(f"{filename} 必须恰好标注 4 张手牌，顺序为左到右。")
        image_path = (screenshot_dir / filename).resolve()
        try:
            image_path.relative_to(screenshot_dir)
        except ValueError as exc:
            raise ValueError(f"截图路径越界：{filename}") from exc
        if not image_path.is_file():
            raise FileNotFoundError(image_path)
        frame, _native_size = decode_android_png(image_path.read_bytes(), max_width=420)
        state = analyze_frame(frame)
        if len(state.card_fingerprints) != 4 or len(state.card_descriptors) != 4:
            raise ValueError(f"{filename} 无法提取完整的四张手牌特征。")

        for slot, raw_metadata in enumerate(card_labels):
            metadata = validate_card_metadata(raw_metadata)
            fingerprint = state.card_fingerprints[slot]
            descriptor = state.card_descriptors[slot]
            if (not isinstance(fingerprint, str) or len(fingerprint) != 16 or
                    len(descriptor) not in (19, 131) or
                    not all(math.isfinite(float(value)) and 0.0 <= float(value) <= 1.0 for value in descriptor)):
                raise ValueError(f"{filename} 第 {slot + 1} 张手牌特征无效。")
            existing = catalog.get(fingerprint)
            if existing is None:
                catalog[fingerprint] = {
                    **metadata,
                    "descriptor": [float(value) for value in descriptor],
                    "_samples": 1,
                }
                continue
            existing_metadata = {key: existing[key] for key in ("name", "cost", "roles", "level", "owned")}
            if existing_metadata != metadata:
                raise ValueError(
                    f"指纹 {fingerprint} 被标注为不同卡牌：{existing['name']!r} 与 {metadata['name']!r}。"
                )
            count = int(existing["_samples"])
            existing["descriptor"] = [
                (old * count + float(new)) / (count + 1)
                for old, new in zip(existing["descriptor"], descriptor)
            ]
            existing["_samples"] = count + 1

    if not catalog:
        raise ValueError("没有生成任何卡牌条目。")
    if len(catalog) > MAX_OUTPUT_CARDS:
        raise ValueError(f"卡牌条目超过上限 {MAX_OUTPUT_CARDS}。")
    for item in catalog.values():
        item.pop("_samples", None)
    return {"version": 1, "cards": catalog}


def write_catalog(payload: dict[str, Any], output: Path) -> None:
    output = Path(output).expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    try:
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, output)
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except OSError:
            pass


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--screenshots", type=Path, required=True,
                        help="包含真实皇室战争对局 PNG 截图的目录")
    parser.add_argument("--labels", type=Path, required=True,
                        help="JSON：每个截图文件名对应从左到右的四张卡牌标注")
    parser.add_argument("--output", type=Path, required=True,
                        help="输出 card_catalog.json 路径")
    args = parser.parse_args()
    payload = build_catalog(args.screenshots, args.labels)
    write_catalog(payload, args.output)
    print(f"已生成 {len(payload['cards'])} 个本地卡牌条目：{args.output.resolve()}")
    print("注意：只有你人工核对过的截图和标签才会进入目录；这不是自动识别全部卡牌的保证。")


if __name__ == "__main__":
    main()
